cmake_minimum_required(VERSION 3.22)

# ----------------------------------------------------------------------------
# orbit-amp — the device / voicing PLAYER plugin (C++/JUCE). Felitronics line, by Darwin's Cat.
#
# The chain:  preamp (voicing) -> EQ -> delay -> reverb -> cabinet.
#
# One CMake config builds VST3 + AU + Standalone. JUCE 8 and the felitronics libraries are
# fetched by CMake (FetchContent) — NOT vendored, NOT system-installed. Each dependency is
# HYBRID: a local sibling checkout is used when present (co-development), otherwise a pinned
# release is fetched, so a clean clone still configures.
# ----------------------------------------------------------------------------

# THE OLDEST macOS THE BINARIES RUN ON. Left unsaid, the compiler marks every binary for the macOS of
# the machine that built it — OrbitAmp 0.7.0 and CatpitAmp 0.2.0 went out marked for macOS 26, and a Mac
# one release behind would not open them. 11.0, Big Sur, is the first macOS on Apple Silicon, so as far
# back as the arm64 half of a universal binary can go — and both halves say the same. A cache default,
# so a configure can still say otherwise (-DCMAKE_OSX_DEPLOYMENT_TARGET=…); and before project(),
# because that is where CMake reads it. Elsewhere than the Mac nothing reads it at all.
set(CMAKE_OSX_DEPLOYMENT_TARGET "11.0" CACHE STRING "The oldest macOS the binaries run on")

# THE FAMILY'S VERSION, said here and nowhere else. Every amp this tree builds is released together, as
# Darwin's Cat Amps, under one tag, vX.Y.Z — and this is its number: every amp shows it, stamps its bundles
# with it and compares the family's releases against it (add_amp). The release refuses a tag that says
# another (installer/version.sh, which reads it from this line).
project(OrbitAmp VERSION 0.10.1 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)   # clangd / IDE indexing

# Auto-install built plug-ins into the user's plug-in folders (the everyday dev loop).
# Turn OFF for CI / secondary worktrees so an experiment never overwrites the installed build.
option(ORBITAMP_COPY_PLUGIN "Copy built plug-ins to the user plug-in folders after build" ON)

# Universal binary on Apple Silicon + Intel. Configure-time only; skipped if the caller chose.
if(APPLE AND NOT CMAKE_OSX_ARCHITECTURES)
    set(CMAKE_OSX_ARCHITECTURES "arm64;x86_64" CACHE STRING "macOS build archs" FORCE)
endif()

# A RELEASE KEEPS THE SYMBOLS OF WHAT IT SHIPPED — ORBITAMP_KEEP_SYMBOLS, on for the release workflow's
# builds and installer/release.sh's, off for every other. A crash report from a player's host names
# addresses in our binaries and nothing more, as a released binary carries no names of its own (A RELEASE
# BINARY CARRIES NO LOCAL SYMBOLS, below); it can be read, months later, only with the symbols of the build
# that made those very bytes. So a release compiles everything in its Release configuration with line tables
# — the functions, their lines and what was inlined where, nothing of the variables: `-gline-tables-only`
# (clang), `-g1` (gcc), `/Zi` (MSVC), none of which changes the code a compiler makes — and every format it
# ships keeps its symbols in <build>/symbols/<target>/ (strip_release): a .dSYM on the Mac, a .pdb on
# Windows, a .debug file on Linux, which the release uploads beside the run and never publishes. Said here,
# before any dependency is fetched, so every library linked into a shipped binary is compiled the same way;
# in each language's flags of the Release configuration, which reach the link line too (gcc writes the debug
# information of an optimised-at-link binary there) and no resource compiler is handed. (The amps' .mm
# sources are compiled as C++ here: no Objective-C language is enabled.)
option(ORBITAMP_KEEP_SYMBOLS "Keep every shipped binary's symbols in <build>/symbols, then strip it (a release)" OFF)
set(ORBITAMP_SYMBOLS_DIR "${CMAKE_BINARY_DIR}/symbols")
if(ORBITAMP_KEEP_SYMBOLS)
    if(MSVC)
        set(_oa_line_tables /Zi)
    elseif(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
        set(_oa_line_tables -g1)
    else()
        set(_oa_line_tables -gline-tables-only)
    endif()
    get_property(_oa_languages GLOBAL PROPERTY ENABLED_LANGUAGES)
    foreach(lang IN ITEMS C CXX OBJC OBJCXX)
        if(lang IN_LIST _oa_languages)
            string(APPEND CMAKE_${lang}_FLAGS_RELEASE " ${_oa_line_tables}")
        endif()
    endforeach()
    if(APPLE)
        find_program(ORBITAMP_DSYMUTIL dsymutil REQUIRED)
        find_program(ORBITAMP_DWARFDUMP dwarfdump REQUIRED)
        # Where the link keeps its link-time-optimised object, one an architecture (strip_release).
        set(ORBITAMP_LTO_OBJECTS_DIR "${CMAKE_BINARY_DIR}/lto-objects")
        file(MAKE_DIRECTORY "${ORBITAMP_LTO_OBJECTS_DIR}")
    elseif(UNIX AND NOT CMAKE_OBJCOPY)
        message(FATAL_ERROR "ORBITAMP_KEEP_SYMBOLS: no objcopy found (CMAKE_OBJCOPY) to keep the symbols with")
    endif()
    message(STATUS "Symbols: every shipped binary keeps its symbols in ${ORBITAMP_SYMBOLS_DIR} (${_oa_line_tables})")
endif()

include(FetchContent)

# ----------------------------------------------------------------------------
# JUCE — pinned tag, with a local-source-dir escape hatch. ORBITAMP_JUCE_DIR defaults to the
# JUCE tree another Felitronics project already fetched, so a first build here costs no second
# full clone — but only while that tree is the pinned version; any other tree is passed over and
# the pin is fetched, so a local build never quietly runs on a JUCE the CI does not. Bump the tag
# deliberately.
#
# CLAP format via the MIT clap-juce-extensions wrapper (native CLAP is slated for JUCE 9).
# Pinned like JUCE, by commit: upstream stopped tagging in 2022, so a commit hash is their de-facto
# release channel.
#
# BOTH ARE PATCHED, so that one binary holds several plug-ins: the family's VST3 and CLAP hold every
# amp of the release, each under the ids its own bundle always had (THE FAMILY'S PLUG-INS, below).
# cmake/PatchedWrappers.cmake declares the two from these pins and says what the patches change and
# what they leave alone; every target that defines no plug-in list builds as it did. The escape hatch
# still saves the clone: the local tree, when it is the pin, is COPIED into this build and the copy
# patched — another project's tree is never written to.
# ----------------------------------------------------------------------------
set(ORBITAMP_JUCE_TAG "8.0.17-security" CACHE STRING "JUCE git tag to build against")
set(ORBITAMP_JUCE_DIR "$ENV{HOME}/IdeaProjects/orbit-capture/app/tests/build/_deps/juce-src"
    CACHE PATH "Local JUCE source tree (copied and patched if it is the pinned version); else the pin is fetched")
set(ORBITAMP_CLAP_EXT_TAG "6bde108329ff9fc24404b79b8b397261a75cf6a8" CACHE STRING "clap-juce-extensions git commit to build against")
include(cmake/PatchedWrappers.cmake)

# ----------------------------------------------------------------------------
# felitronics-core — shared, JUCE-free, header-only DSP core (eq / dynamics / saturation /
# neural / ...). Nothing is linked yet: the chain stages land one at a time and each adds its
# module to target_link_libraries below. Wired now so that's a one-line change, not a rebuild
# of the dependency graph. Its self-tests do NOT build from here (guarded by PROJECT_IS_TOP_LEVEL).
# ----------------------------------------------------------------------------
# THE TAG THAT CARRIES THE GEOMETRY. core::BypassWire asks
# StreamResampler::pairDelayHostSamples() for the round-trip cost of a rate match, and v0.30.0 is the
# first release with it — v0.29.0 had neither that function nor the kernel behind it, still carrying
# the cubic and the ceil(3*h/m)+3 arithmetic this wire was written against and outgrew.
#
# That gap was not a footnote while it lasted: it is why this branch's CI was red BY CONSTRUCTION for
# its whole life, which was documented here rather than worked around. Measured twice, not assumed —
# replaying CI's own compile command with no sibling checkout failed on the missing symbol, and PR
# #32's first run failed the same way at the same line. The pin moves ONCE, here, inside the PR that
# needs it, so that landing the fix and landing its dependency are one commit and never a window
# where main builds against a core that cannot answer.
#
# ⚠️ AND IT IS THE TAG CI USES, NOT WHAT YOU SEE LOCALLY. The hybrid override below prefers a sibling
# ../felitronics-core checkout, so a local build shows that checkout's HEAD however this line reads.
# Proving anything about the pin means emptying the override — all six of them, not this one — and
# letting FetchContent take the tag.
#
# v0.51.0 is the first release felitronics-guitar-core accepts: nam, rigplayer and poweramp left core
# for that repository in it (see below). v0.60.0 is the first with felitronics::dehum, the HumRemover
# the input's HUM stage is built on. v0.61.0 is the first with felitronics::delay and
# felitronics::reverb — the echo and the room, which were this repository's own stages until they moved
# there, so nothing older builds here. Between v0.31.0 and
# v0.53.0, nothing this plugin calls plays differently INSIDE a running stream —
# the probe loops render bit-identically on both — and what moved is at a stream's edges: a re-prepared
# capture no longer answers with the previous stream's tail, its warm-up is counted at the new rate, a
# trim switched off stays off through the prepare. The cabinet hands CabConvolver taps already at the
# host's rate, so the v0.34.0 rate factor and the v0.32.0 edge fix have nothing to act on here, and the
# v0.53.0 glides are in stages this plugin does not link. Past v0.53.0 two things reach this graph, and
# neither plays here: WaveShaper gains four shapes while Asym — the only one the power amp's TubeStage
# sets — keeps its expressions, and eq's Tilt at slope 6 turns first-order, a band no block here builds.
#
# v0.61.0 DOES play differently, in the two stages it brings, and it was measured before they replaced
# ours: both renders side by side on the same program at 44.1, 48 and 96 kHz, in blocks of 64, 512 and a
# ragged run. At knobs that stand still the echo is within 2.4e-7 of ours and the five plain rooms within
# 3e-14; MODULATED is within 6.5e-5 at full mix on a hot program — its chorus reads its line at a position
# kept in double where ours rounded it to float, so that distance is the tail's slope times a rounding and
# halves with the level. With a knob moving, the echo's head now LANDS: ours parked short of a new time
# for good, the repeats 28 samples early at 1.5 s and 112 at 6 s (48 kHz), and the old echo is the new
# one read at that parked head to within 4e-8 — a time, not a level or a tone. A fresh room no longer
# leaks the dry into its first 10 ms, and an Intel build plays the arm64 sound: the framework's Freeverb
# under ours quantised its state on x86-64, up to 1e-6.
#
# v0.61.2 changes one thing here: the echo's and the room's `feed` — what the DELAY / REVERB switches stop — fades over 5 ms where it switched at one sample, which the repeats played back as ticks. Fed, both
# render bit for bit as on v0.61.0 (v0.61.1 touches only a wasm build of FlushToZero.h).
#
# v0.62.0 brings the bass amps' own: octave (Octaver), envfilter (EnvelopeFilter) and chorus (BassChorus) —
# OrbitBass's and RedGrooveBass's OCTAVE, ENVELOPE and CHORUS (src/core/OctaveTap.h, FilterTap.h, ChorusTap.h),
# which until then built from an unreleased branch of the core alone.
set(ORBITAMP_FCORE_TAG "v0.62.0" CACHE STRING "felitronics-core release tag (fetched when no local checkout)")

set(ORBITAMP_FCORE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../felitronics-core"
    CACHE PATH "Local felitronics-core checkout (used if present); else the pinned release is fetched")
if(ORBITAMP_FCORE_DIR AND EXISTS "${ORBITAMP_FCORE_DIR}/CMakeLists.txt")
    message(STATUS "felitronics-core: local checkout — ${ORBITAMP_FCORE_DIR}")
    FetchContent_Declare(felitronics_core SOURCE_DIR "${ORBITAMP_FCORE_DIR}")
else()
    message(STATUS "felitronics-core: fetching ${ORBITAMP_FCORE_TAG} from GitHub")
    FetchContent_Declare(felitronics_core
        GIT_REPOSITORY https://github.com/darwinscat/felitronics-core.git
        GIT_TAG        ${ORBITAMP_FCORE_TAG}
        GIT_SHALLOW    TRUE)
endif()
# The cabinet convolves through felitronics::convolution's CabConvolver, and its audio FFT is pffft
# (SIMD, BSD) — the backend OrbitCab ships. Set before core is made available so the fftpffft module
# is built; the convolution module then carries the definition to every target that links it, which
# is what keeps the choice uniform across translation units.
set(FELITRONICS_WITH_PFFFT ON CACHE BOOL "orbit-amp's cabinet convolver uses the pffft SIMD FFT" FORCE)

# The neural runtime — felitronics::nam, and the pack player over it, felitronics::rigplayer. Since core
# v0.51.0 both live in felitronics-guitar-core, made available right AFTER core below, by the same rule
# as core: a sibling checkout when present, the pinned tag otherwise. It builds them by default, so
# there is no switch to throw here any more (core refuses the old FELITRONICS_WITH_NAM outright). The
# NAM module fetches NeuralAmpModelerCore and the namz codec itself — the overrides below only spare a
# second clone of trees this machine already has, and fall back to the pins when they are gone. From v0.1.1
# it takes Eigen from Darwin's Cat's own mirror, github.com/darwinscat/eigen, instead of NeuralAmpModelerCore's
# submodule on gitlab.com: a build now asks GitHub alone.
#
# v0.7.0 makes a LOAD cheap and leaves what plays alone: a .namz is built straight into NAM through
# namz::decode instead of printed to JSON text and parsed back, a mono host gets one network per capture
# instead of two (a recurrent one still gets two), and a load handed out by the player skips NAM's prewarm
# of silence, since no slot is heard before live input has run through its receptive field. The seam this
# tree calls — takeLoadJob / run / deliver (src/core/CapturedBlock.h) — is unchanged; LoadJob::channels is
# new and takeLoadJob fills it in. It needs namz v4.4.0 (namz::decode, and the float16 .nam16z it widens),
# pinned with it below: move the two together. One load of a real capture, measured on x86-64 (gcc,
# Release): 25.5 ms on v0.1.1, 1.7 ms on v0.7.0 for a mono host and 3.3 ms for a stereo one; a copy held
# for a mono host 6.2 MiB → 3.2 MiB.
#
# Past v0.1.1 ONE thing reaches what plays, and it came in v0.3.0: a capture's sound fades in only once
# every capture the gain dial blends is ready, where it used to start rising while one of them was still
# on its way and let the dry input through. Measured on 48 sessions through CapturedBlock — the twelve
# packs of the set at 44.1, 48 and 96 kHz, mono and stereo, the dial turned SMOOTH and STEP and a switch
# turned while playing, every load landing mid-session: v0.1.1 and v0.7.0 differ in the eight blocks of
# the first fade-in alone — v0.7.0 silent through four blocks where v0.1.1 had begun to rise, then its own
# fade, four blocks later — and in nothing after them; v0.6.0 and v0.7.0 are the same bit for bit in all 48.
#
# v0.8.0 plays namz v5.0.0's packs, the `.orbitrig` schema 5 — a band's frequency taken from another knob
# (`hz_by`: a MIDDLE with its own FREQ) and a capture's own lag and polarity — and every schema-4 pack as
# before. It brings the crossover blend OrbitBass's BLEND rides (RigPlayer::setCrossover*): at amount 0 it is
# the player without it, byte for byte, for one atomic load a block. Its one change to what plays: a slot's
# alignment delay moves through a 10 ms crossfade while it is heard, where it used to wait for silence — the
# set's twelve packs carry no alignment, so for them nothing moves. It needs namz v5.0.0, pinned with it below.
set(ORBITAMP_GUITAR_TAG "v0.8.0" CACHE STRING "felitronics-guitar-core release tag (fetched when no local checkout)")
set(ORBITAMP_GUITAR_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../felitronics-guitar-core"
    CACHE PATH "Local felitronics-guitar-core checkout (used if present); else the pinned release is fetched")

# ...and a build directory configured before the move still carries the FELITRONICS_WITH_NAM=ON this
# file used to FORCE into its cache, which core now stops the configure on. We put it there; we take it
# out, so an existing build directory configures again instead of asking its owner for a -U.
unset(FELITRONICS_WITH_NAM CACHE)

set(ORBITAMP_NAM_CORE_SRC "$ENV{HOME}/IdeaProjects/orbit-nam-capture/app/build-hard/_deps/nam_core_src-src"
    CACHE PATH "Local NeuralAmpModelerCore checkout; empty fetches the pin")
set(ORBITAMP_NAMZ_SRC "$ENV{HOME}/IdeaProjects/namz"
    CACHE PATH "Local namz checkout; empty fetches the pin")

# The local NAM copy is a SHORTCUT, not a source of truth: the NAM module pins the engine, and a
# copy sitting on a different commit would silently build a different DSP than the pin says. So the
# shortcut is taken only when it agrees with the pin — read out of the NAM module's own CMakeLists (in
# felitronics-guitar-core since core v0.51.0), since the pin is not known to us until that is configured,
# which is after this must be decided.
if(EXISTS "${ORBITAMP_NAM_CORE_SRC}/.git")
    set(_oa_nam_pin "")
    if(EXISTS "${ORBITAMP_GUITAR_DIR}/modules/nam/CMakeLists.txt")
        file(READ "${ORBITAMP_GUITAR_DIR}/modules/nam/CMakeLists.txt" _oa_nam_cml)
        string(REGEX MATCH "FELITRONICS_NAM_CORE_TAG \"([^\"]+)\"" _oa_nam_match "${_oa_nam_cml}")
        set(_oa_nam_pin "${CMAKE_MATCH_1}")
    endif()

    # ...and a build directory that was configured before the pin moved keeps the OLD value in its
    # cache, because the NAM module declares the pin as a CACHE variable and a cache entry wins over a
    # new default. Same failure, one layer down: the build would still compile the engine we replaced.
    if(_oa_nam_pin AND DEFINED FELITRONICS_NAM_CORE_TAG AND NOT FELITRONICS_NAM_CORE_TAG STREQUAL _oa_nam_pin)
        message(STATUS "NeuralAmpModelerCore: cached pin ${FELITRONICS_NAM_CORE_TAG} is stale — the NAM module pins ${_oa_nam_pin}")
        set(FELITRONICS_NAM_CORE_TAG "${_oa_nam_pin}" CACHE STRING "" FORCE)
    endif()

    find_package(Git QUIET)
    set(_oa_nam_here "")
    if(GIT_EXECUTABLE AND _oa_nam_pin)
        execute_process(COMMAND "${GIT_EXECUTABLE}" rev-parse HEAD
            WORKING_DIRECTORY "${ORBITAMP_NAM_CORE_SRC}"
            OUTPUT_VARIABLE _oa_nam_here OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_QUIET)
        execute_process(COMMAND "${GIT_EXECUTABLE}" rev-parse "${_oa_nam_pin}^{commit}"
            WORKING_DIRECTORY "${ORBITAMP_NAM_CORE_SRC}"
            OUTPUT_VARIABLE _oa_nam_want OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_QUIET)
    endif()

    if(_oa_nam_here AND _oa_nam_want AND _oa_nam_here STREQUAL _oa_nam_want)
        message(STATUS "NeuralAmpModelerCore: local copy is on the pin (${_oa_nam_pin}) — using it")
        set(FELITRONICS_NAM_CORE_SRC "${ORBITAMP_NAM_CORE_SRC}" CACHE PATH "" FORCE)
        set(ORBITAMP_NAM_CORE_USED "${ORBITAMP_NAM_CORE_SRC}")
    else()
        message(STATUS "NeuralAmpModelerCore: local copy is NOT on the NAM module's pin (${_oa_nam_pin}) — fetching the pin instead")
        set(FELITRONICS_NAM_CORE_SRC "" CACHE PATH "" FORCE)
        set(ORBITAMP_NAM_CORE_USED "${CMAKE_BINARY_DIR}/_deps/nam_core_src-src")
    endif()
endif()
if(EXISTS "${ORBITAMP_NAMZ_SRC}/include/namz.h")
    set(FELITRONICS_NAMZ_SRC "${ORBITAMP_NAMZ_SRC}" CACHE PATH "" FORCE)
endif()

# ...and when there is NO local checkout — CI — the tag the NAM module would otherwise pin. The device
# page reads a pack's photograph and the box's own history (`Rig::picture`, `gear.year`,
# `serial_number`, `designed_in`, `made_in`), all of which were newer than the commit the NAM module
# carried. Pinned HERE rather than waited for: a library release exists to move the library's own code,
# and holding this behind one would leave the plugin unbuildable on CI for no reason of its own.
#
# THE TWO PINS MOVE TOGETHER. The tag here is FORCEd over the NAM module's own, so guitar-core's pin
# never reaches this build — and since guitar-core v0.7.0 a fetched namz is held to FELITRONICS_NAMZ_COMMIT,
# the commit of the tag the NAM module pins (v5.0.0's, 717ca2d, by default). This tag is guitar-core
# v0.8.0's own, so the two agree and the commit is left at its default. A guitar-core bump moves this tag
# to that release's namz pin in the same commit: a tag left behind stops the configure, naming both
# commits. A namz bump made HERE alone, ahead of guitar-core, FORCEs FELITRONICS_NAMZ_COMMIT to the new
# tag's commit beside it — a tag moved without its commit stops the configure the same way. The local
# checkout (ORBITAMP_NAMZ_SRC) is not held to either, and is taken whenever it exists: on a namz older
# than v5.0.0 the pack player stops compiling (no `input_lag_samples`, no `hz_by`) — keep it on v5.0.0 or
# later, or empty the override.
set(ORBITAMP_NAMZ_TAG "v5.0.0" CACHE STRING "namz release tag CI builds against (no local checkout)")
set(FELITRONICS_NAMZ_TAG "${ORBITAMP_NAMZ_TAG}" CACHE STRING "" FORCE)

FetchContent_MakeAvailable(felitronics_core)
if(ORBITAMP_GUITAR_DIR AND EXISTS "${ORBITAMP_GUITAR_DIR}/CMakeLists.txt")
    message(STATUS "felitronics-guitar-core: local checkout — ${ORBITAMP_GUITAR_DIR}")
    FetchContent_Declare(felitronics_guitar_core SOURCE_DIR "${ORBITAMP_GUITAR_DIR}")
else()
    message(STATUS "felitronics-guitar-core: fetching ${ORBITAMP_GUITAR_TAG} from GitHub")
    FetchContent_Declare(felitronics_guitar_core
        GIT_REPOSITORY https://github.com/darwinscat/felitronics-guitar-core.git
        GIT_TAG        ${ORBITAMP_GUITAR_TAG}
        GIT_SHALLOW    TRUE)
endif()
FetchContent_MakeAvailable(felitronics_guitar_core)

# ----------------------------------------------------------------------------
# felitronics-appkit — the family's shared app-side JUCE infrastructure (brand kit, update
# check, device glyphs). Header-only INTERFACE target: it never links JUCE itself, we supply
# the modules transitively. This is also where the faceplate render kit MOVES once it settles
# here (see CLAUDE.md — build it here first, move it later).
# ----------------------------------------------------------------------------
set(ORBITAMP_APPKIT_TAG "v0.23.0" CACHE STRING "felitronics-appkit release tag (fetched when no local checkout)")
set(ORBITAMP_APPKIT_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../felitronics-appkit"
    CACHE PATH "Local felitronics-appkit checkout (used if present); else the pinned release is fetched")
if(ORBITAMP_APPKIT_DIR AND EXISTS "${ORBITAMP_APPKIT_DIR}/CMakeLists.txt")
    message(STATUS "felitronics-appkit: local checkout — ${ORBITAMP_APPKIT_DIR}")
    FetchContent_Declare(felitronics_appkit SOURCE_DIR "${ORBITAMP_APPKIT_DIR}")
else()
    message(STATUS "felitronics-appkit: fetching ${ORBITAMP_APPKIT_TAG} from GitHub")
    FetchContent_Declare(felitronics_appkit
        GIT_REPOSITORY https://github.com/darwinscat/felitronics-appkit.git
        GIT_TAG        ${ORBITAMP_APPKIT_TAG}
        GIT_SHALLOW    TRUE)
endif()

# A pack ships its device's photograph as WebP (rig.json's `picture`), and an include path cannot
# carry a codec — appkit's opt-in half brings libwebp, pinned and fetched like JUCE. The capture
# app that WRITES the picture turns the same switch on; this is the reading end of it.
set(FELITRONICS_APPKIT_WEBP ON CACHE BOOL "" FORCE)

FetchContent_MakeAvailable(felitronics_appkit)

# ----------------------------------------------------------------------------
# cab-ir-generator — the bass's own cabinets: their synthesis (cabir::synth, JUCE-free), the panel and the
# miniature the CAB block draws (cabir::panel, JUCE views in our theme — CabWindow::useOurLook), and the
# table they read (CABIR_CABINETS). The same code is the cabinets' own app and web page.
# ----------------------------------------------------------------------------
set(ORBITAMP_CABIR_TAG "v0.4.0" CACHE STRING "cab-ir-generator release tag (fetched when no local checkout)")
set(ORBITAMP_CABIR_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../cab-ir-generator"
    CACHE PATH "Local cab-ir-generator checkout (used if present); else the ref is fetched")
if(ORBITAMP_CABIR_DIR AND EXISTS "${ORBITAMP_CABIR_DIR}/CMakeLists.txt")
    message(STATUS "cab-ir-generator: local checkout — ${ORBITAMP_CABIR_DIR}")
    FetchContent_Declare(cab_ir_generator SOURCE_DIR "${ORBITAMP_CABIR_DIR}")
else()
    message(STATUS "cab-ir-generator: fetching ${ORBITAMP_CABIR_TAG} from GitHub")
    FetchContent_Declare(cab_ir_generator
        GIT_REPOSITORY https://github.com/darwinscat/cab-ir-generator.git
        GIT_TAG        ${ORBITAMP_CABIR_TAG}
        GIT_SHALLOW    TRUE)
endif()
FetchContent_MakeAvailable(cab_ir_generator)

# ----------------------------------------------------------------------------
# OrbitAmpVersion.h — git-describe build stamp, baked into the binary (end users have no repo).
# Regenerated on EVERY build (the target is always out-of-date) so the stamp reflects the tree AT
# BUILD TIME; also generated once at configure so clangd + the first compile have the header. Never
# fails the build (missing git => "0.0.0-dev"/"unknown"). It feeds the footer's version stamp — the
# popover's commit / build / environment lines and the dependency rows.
# ----------------------------------------------------------------------------
find_package(Git QUIET)
set(ORBITAMP_GENERATED_DIR "${CMAKE_CURRENT_BINARY_DIR}/generated")
file(MAKE_DIRECTORY "${ORBITAMP_GENERATED_DIR}")
set(ORBITAMP_VERSION_HEADER "${ORBITAMP_GENERATED_DIR}/OrbitAmpVersion.h")

# Build architecture label for the stamp (Universal when a fat binary, else the single arch).
if(APPLE)
    list(LENGTH CMAKE_OSX_ARCHITECTURES _oa_narch)
    if(_oa_narch GREATER 1)
        set(_oa_arch "Universal")
    elseif(CMAKE_OSX_ARCHITECTURES)
        set(_oa_arch "${CMAKE_OSX_ARCHITECTURES}")
    else()
        set(_oa_arch "${CMAKE_SYSTEM_PROCESSOR}")
    endif()
else()
    set(_oa_arch "${CMAKE_SYSTEM_PROCESSOR}")
endif()

# Build OS label for the stamp.
if(APPLE)
    set(_oa_os "macOS")
elseif(WIN32)
    set(_oa_os "Windows")
elseif(UNIX)
    set(_oa_os "Linux")
else()
    set(_oa_os "${CMAKE_SYSTEM_NAME}")
endif()

# Mirror the felitronics-core FetchContent decision above so kCoreVersion names the checkout used.
if(ORBITAMP_FCORE_DIR AND EXISTS "${ORBITAMP_FCORE_DIR}/CMakeLists.txt")
    set(_oa_fcore_local ON)
else()
    set(_oa_fcore_local OFF)
endif()

# ...and the same for felitronics-guitar-core, where the NAM stage and the pack player come from.
if(ORBITAMP_GUITAR_DIR AND EXISTS "${ORBITAMP_GUITAR_DIR}/CMakeLists.txt")
    set(_oa_guitar_local ON)
else()
    set(_oa_guitar_local OFF)
endif()

# ...and the same for felitronics-appkit: the badge's dependency rows name what was actually built
# against, sibling or pin, never the other one.
if(ORBITAMP_APPKIT_DIR AND EXISTS "${ORBITAMP_APPKIT_DIR}/CMakeLists.txt")
    set(_oa_appkit_local ON)
else()
    set(_oa_appkit_local OFF)
endif()

# The engine's sources as the build ACTUALLY resolved them — the local copy only when it agreed
# with the NAM module's pin, the fetched pin otherwise (see the guard above). The stamp must name what
# was compiled, not what was nearby.
set(_oa_namcore_dir "${ORBITAMP_NAM_CORE_USED}")
if(NOT _oa_namcore_dir)
    set(_oa_namcore_dir "${CMAKE_BINARY_DIR}/_deps/nam_core_src-src")
endif()

# ...and namz, the codec the packs are written in — mirroring the override test above, which keys on
# the header rather than a CMakeLists (namz is consumed by felitronics-core's nam module, not by us).
if(ORBITAMP_NAMZ_SRC AND EXISTS "${ORBITAMP_NAMZ_SRC}/include/namz.h")
    set(_oa_namz_local ON)
else()
    set(_oa_namz_local OFF)
endif()

set(_oa_ver_args
    -DGIT_EXECUTABLE=${GIT_EXECUTABLE}
    -DSRC_DIR=${CMAKE_CURRENT_SOURCE_DIR}
    -DOUT_FILE=${ORBITAMP_VERSION_HEADER}
    -DARCH=${_oa_arch}
    -DOS=${_oa_os}
    -DFCORE_LOCAL=${_oa_fcore_local}
    -DFCORE_DIR=${ORBITAMP_FCORE_DIR}
    -DFCORE_TAG=${ORBITAMP_FCORE_TAG}
    -DGUITAR_LOCAL=${_oa_guitar_local}
    -DGUITAR_DIR=${ORBITAMP_GUITAR_DIR}
    -DGUITAR_TAG=${ORBITAMP_GUITAR_TAG}
    -DAPPKIT_LOCAL=${_oa_appkit_local}
    -DAPPKIT_DIR=${ORBITAMP_APPKIT_DIR}
    -DAPPKIT_TAG=${ORBITAMP_APPKIT_TAG}
    -DNAMZ_LOCAL=${_oa_namz_local}
    -DNAMZ_DIR=${ORBITAMP_NAMZ_SRC}
    -DNAMZ_TAG=${ORBITAMP_NAMZ_TAG}
    -DNAMCORE_DIR=${_oa_namcore_dir}
    -DNAMCORE_TAG=${FELITRONICS_NAM_CORE_TAG})

# Generate once at configure time too, so the header exists for IDEs / clangd before the first build.
execute_process(COMMAND ${CMAKE_COMMAND} ${_oa_ver_args}
    -P "${CMAKE_CURRENT_SOURCE_DIR}/cmake/GenerateOrbitAmpVersion.cmake")

add_custom_target(OrbitAmpVersionGen ALL
    COMMAND ${CMAKE_COMMAND} ${_oa_ver_args}
        -P "${CMAKE_CURRENT_SOURCE_DIR}/cmake/GenerateOrbitAmpVersion.cmake"
    BYPRODUCTS "${ORBITAMP_VERSION_HEADER}"
    COMMENT "OrbitAmp: baking OrbitAmpVersion.h build stamp"
    VERBATIM)

# ----------------------------------------------------------------------------
# THE FACTORY FOLDER: every file of data a Darwin's Cat amp plays — the packs, the cabinet shelf, each
# face's pictures — ONE copy of each on the machine. No amp carries any of it in its binary: three amps in
# four formats and two architectures made the same 26 MB into a release of 369 MB. The family's installer
# lays the folder out once, as a part of it the player cannot untick (installer/):
#
#   macOS    /Library/Application Support/Darwin's Cat/Factory
#   Windows  C:\ProgramData\Darwin's Cat\Factory
#   Linux    <share>/darwinscat-amps/Factory — ~/.local/share for the player alone, /usr/local/share for
#            every user (installer/linux/install.sh)
#
# Inside it the packs lie at its top (<pack>.orbitrig.zip), the cabinet shelf in IRs/<folder>/<file> as
# the cabinet catalog has it, and each face's pictures in Faces/<Name>/<file>. EACH AMP SEES ONLY WHAT ITS
# OWN LIST NAMES, sets/<Name>.txt, one path to the line (src/device/FactorySet.h): the folder is the
# family's, and what one amp plays is not every amp's.
#
# What an amp plays it says in its row of the table (add_amp: ART, SET, WHOLE_SHELF), and add_amp says it
# here (factory_carries). After the table, family_factory() makes of it the folder of every amp in the
# build tree, <build>/Factory — the target Family_Factory, which every amp and every gate that reads the
# folder waits for — and the folder of the amps installer/family.ini names and nothing else,
# <build>/Shipped/Factory (Family_ShippedFactory, part of Family_All), which every installer lays out.
#
# ORBITAMP_DEV_FACTORY: an amp built here reads <build>/Factory FIRST, where it is there, so it plays the
# files built with it whatever is installed. A release passes it OFF (.github/workflows/release.yml,
# installer/release.sh): its binaries leave the machine, and the macOS release is built on a working
# laptop, where the build folder is there. A gate reads <build>/Factory alone, whatever this says, and
# never the machine's (gate_reads_factory).
# ----------------------------------------------------------------------------
option(ORBITAMP_DEV_FACTORY "Amps read <build>/Factory first, where it is there (OFF for a release)" ON)

# ORBITAMP_LTO: the amps link with link-time optimisation, JUCE's recommended flags. A release passes it ON
# (.github/workflows/release.yml, installer/release.sh): its binaries are about 30 % smaller for it. Every
# other build leaves it OFF — it plays no faster for it (measured 25.10.2026 on the Mac, the family's VST3:
# DSP the same to the noise, the output bit for bit), and an amp relinks in seconds instead of a minute.
option(ORBITAMP_LTO "Amps link with link-time optimisation (ON for a release)" OFF)
set(ORBITAMP_FACTORY_DIR "${CMAKE_CURRENT_BINARY_DIR}/Factory")
set(ORBITAMP_SHIPPED_FACTORY_DIR "${CMAKE_CURRENT_BINARY_DIR}/Shipped/Factory")

# factory_carries(<Name> FILES <files...> AT <paths...>): <Name> plays each file, which lies in the folder
# at the path beside it. One path is one file: two files said for one path stop the configure, since the
# folder could hold only one of them. Paths have spaces in them, so each is kept under its hash.
function(factory_carries name)
    cmake_parse_arguments(PARSE_ARGV 1 FC "" "" "FILES;AT")
    list(LENGTH FC_FILES files)
    list(LENGTH FC_AT paths)
    if(NOT files EQUAL paths)
        message(FATAL_ERROR "factory_carries(${name}): ${files} files for ${paths} paths")
    endif()
    if(files EQUAL 0)
        return()
    endif()
    math(EXPR last "${files} - 1")
    foreach(i RANGE ${last})
        list(GET FC_FILES ${i} file)
        list(GET FC_AT ${i} at)
        string(MD5 key "${at}")
        get_property(from GLOBAL PROPERTY ORBITAMP_FACTORY_FROM_${key})
        if("${from}" STREQUAL "")
            set_property(GLOBAL PROPERTY ORBITAMP_FACTORY_FROM_${key} "${file}")
            set_property(GLOBAL APPEND PROPERTY ORBITAMP_FACTORY_PATHS "${at}")
        elseif(NOT "${from}" STREQUAL "${file}")
            message(FATAL_ERROR "The factory's ${at} would be two files: ${from} and ${file} (${name})")
        endif()
        get_property(own GLOBAL PROPERTY ORBITAMP_FACTORY_LIST_${name})
        if(NOT at IN_LIST own)
            set_property(GLOBAL APPEND PROPERTY ORBITAMP_FACTORY_LIST_${name} "${at}")
        endif()
    endforeach()
endfunction()

# family_factory(): the folder of what every amp said, after the table — one copy of each file, each amp's
# list beside them — and the release's, of the family's amps alone (FAMILY_AMPS, THE FAMILY'S RELEASE).
function(family_factory)
    set(shippedPaths "")
    foreach(amp IN LISTS FAMILY_AMPS)
        get_property(own GLOBAL PROPERTY ORBITAMP_FACTORY_LIST_${amp})
        foreach(at IN LISTS own)
            if(NOT at IN_LIST shippedPaths)
                list(APPEND shippedPaths "${at}")
            endif()
        endforeach()
    endforeach()

    get_property(paths GLOBAL PROPERTY ORBITAMP_FACTORY_PATHS)
    set(laid "")
    set(shipped "")
    foreach(at IN LISTS paths)
        string(MD5 key "${at}")
        get_property(from GLOBAL PROPERTY ORBITAMP_FACTORY_FROM_${key})
        set(into "${ORBITAMP_FACTORY_DIR}/${at}")
        list(APPEND laid "${into}")
        if(at IN_LIST shippedPaths)
            list(APPEND into "${ORBITAMP_SHIPPED_FACTORY_DIR}/${at}")
            list(APPEND shipped "${ORBITAMP_SHIPPED_FACTORY_DIR}/${at}")
        endif()
        foreach(to IN LISTS into)
            get_filename_component(folder "${to}" DIRECTORY)
            add_custom_command(OUTPUT "${to}"
                COMMAND "${CMAKE_COMMAND}" -E make_directory "${folder}"
                COMMAND "${CMAKE_COMMAND}" -E copy "${from}" "${to}"
                DEPENDS "${from}"
                VERBATIM)
        endforeach()
    endforeach()

    # The packs are zipped by the build (THE SET), by one target: these wait for it, rather than run the
    # zips' rules themselves and race it.
    add_custom_target(Family_Factory DEPENDS ${laid})
    add_dependencies(Family_Factory OrbitAmpSetPacks)
    add_custom_target(Family_ShippedFactory DEPENDS ${shipped})
    add_dependencies(Family_ShippedFactory OrbitAmpSetPacks)
    add_dependencies(Family_All Family_ShippedFactory)

    foreach(amp IN LISTS AMPS)
        get_property(own GLOBAL PROPERTY ORBITAMP_FACTORY_LIST_${amp})
        list(JOIN own "\n" lines)
        file(GENERATE OUTPUT "${ORBITAMP_FACTORY_DIR}/sets/${amp}.txt" CONTENT "${lines}\n")
        if(amp IN_LIST FAMILY_AMPS)
            file(GENERATE OUTPUT "${ORBITAMP_SHIPPED_FACTORY_DIR}/sets/${amp}.txt" CONTENT "${lines}\n")
        endif()
    endforeach()

    list(LENGTH paths every)
    list(LENGTH shippedPaths family)
    message(STATUS "The factory folder: ${every} files in the build's, ${family} of them in the release's")
endfunction()

# A GATE READS THE BUILD'S FACTORY FOLDER ALONE, never the machine's — or, given one, a folder that is not
# there (gate_reads_factory(<target> <folder>)), to play an amp with nothing installed.
function(gate_reads_factory target)
    set(folder "${ORBITAMP_FACTORY_DIR}")
    if(ARGC GREATER 1)
        set(folder "${ARGV1}")
    endif()
    target_compile_definitions(${target} PRIVATE ORBITAMP_GATE_FACTORY="${folder}")
    add_dependencies(${target} Family_Factory)
endfunction()

# ----------------------------------------------------------------------------
# THE FAMILY. Every Darwin's Cat amp this tree builds is one call of add_amp(), and the calls stand
# together further down as one table (THE AMPS): what tells an amp from the others is said in its row,
# and what they share is said once, here. Each amp is the same JUCE plug-in — VST3, AU and the
# Standalone, and a CLAP through clap-juce-extensions — over the same processor; what differs is its
# face, its name, its number and what it carries.
#
#   add_amp(<Name>  CODE <code>  [BY_NAME]  [ICON <Amp>]
#           SOURCES <files...>  LIBRARIES <targets...>  [ART <files...>]  [SET <packs...>]  [WHOLE_SHELF])
#
#   <Name>      the target, the PRODUCT_NAME and the stem of every bundle it builds; in lower case, its
#               bundle id and its CLAP id, com.darwinscat.<name>; and its icon, resources/icon/<Name>-*.
#               It is the name of the amp's Product too (src/Product.h), which the amp's own file says —
#               its settings, its presets and its update check go by it — and its plug-in's entry
#               (createPluginFilter, beside the Product, compiled in under ORBITAMP_PLUGIN_ENTRY) makes
#               a processor of that Product.
#   CODE        its 4-char plug-in code, unique per plugin (OrbitCab holds `Orbt`). LOCK it before the
#               first release: changing it afterwards makes hosts treat it as a different plugin. The
#               manufacturer code is the family's, Dcat (Darwin's Cat — >=1 uppercase, AU rule; same as
#               OrbitCab).
#   BY_NAME     not part of the default build (see below).
#   ICON        another amp's icon, worn until its own is drawn: resources/icon/<Amp>-* rather than <Name>'s.
#   SOURCES     what it is compiled from; LIBRARIES what it links, ahead of JUCE's recommended flags.
#   ART         its renders, in the factory folder's Faces/<Name>, each under its own file's name, where its
#               face reads them (src/face/Renders.h).
#   SET         the packs it plays, by their folders' names in the tree's set (THE SET), less `.orbitrig` —
#               at the factory folder's top, zipped.
#   WHOLE_SHELF the whole cabinet shelf, the folders the cabinet catalog gives OrbitAmp alone with Darwin's
#               Cat's own; without it, Darwin's Cat's own alone.
#   BASS        its chain is the bass's (src/Product.h, Product::chain — the two say one thing): it carries
#               the catalog's bass folders and none of the guitar's — a guitar amp's cabinets and a bass
#               amp's never cross (resources/cabinets.txt). Not with WHOLE_SHELF.
#
# Whatever it plays is in the family's factory folder and in its own list there (THE FACTORY FOLDER), never
# in its binary.
#
# Every amp's version is THE FAMILY'S, the project's (above): the amps are released together, so no row
# says a number of its own. What an amp was given is kept on its target, where its gates read it
# (amp_console): a gate is the amp compiled again, never a second copy of its lists.
# ----------------------------------------------------------------------------

# THE CODECS NO AMP READS: an amp opens WAV and AIFF — its demo loops, a player's IRs — and nothing else,
# but registerBasicFormats() (src/core/DemoPlayer.h) pulls in every codec JUCE builds, so the ones it would
# never be handed are not built: Ogg Vorbis, FLAC, and Windows Media. Said for every amp and its gates alike.
set(AMP_UNREAD_CODECS JUCE_USE_OGGVORBIS=0 JUCE_USE_FLAC=0 JUCE_USE_WINDOWS_MEDIA_FORMAT=0)

# WHAT KIND OF PLUG-IN AN AMP IS, to a host: its VST3 categories and its CLAP features. Said once, for an
# amp's own plug-in and for its entry in the family's (THE FAMILY'S PLUG-INS) alike.
set(AMP_VST3_CATEGORIES Fx Distortion)
set(AMP_CLAP_FEATURES audio-effect guitar amplifier)

# A RELEASE BINARY CARRIES NO LOCAL SYMBOLS — tens of thousands of internal names, a fifth of a face's
# binary. Its exports stay, which is all a host looks up (GetPluginFactory, the AU's factory, clap_entry):
# `ld -x` on the Mac, `-s` on Linux, at the link of every format, the CLAP's too. A crash report from a
# released amp shows addresses, not the names of its own functions. A Release build of MSVC's makes no
# symbols at all. For every format of an amp (add_amp) and of the family's plug-ins (THE FAMILY'S PLUG-INS).
#
# A RELEASE (ORBITAMP_KEEP_SYMBOLS, above) KEEPS THEM FIRST, from the very link that is shipped, into
# <build>/symbols/<target>/, which nothing that packs a release reads. The Mac and Linux link it whole and
# strip it after (cmake/KeepSymbols.cmake, a step after the build): the Mac's dsymutil makes the .dSYM of
# every architecture from what the link left, and `strip -S -x` then takes out what `ld -x` did — the
# debug map with it — and a bundle the strip unsealed is signed ad hoc again, as JUCE's own step signs it;
# Linux's objcopy keeps a .debug file, `strip --strip-all` takes out what `-s` did, and the binary is given
# a .gnu_debuglink naming its debug file. The link-time optimisation's object is where a Mac binary's lines
# are, and the linker throws it away unless told where to keep it: -object_path_lto, one path an
# architecture (`-Xarch_`), or the second architecture's link of a universal binary writes over the first's.
# On Windows the link writes the .pdb itself (/DEBUG) into the symbols folder, never beside the binary or
# inside a VST3's folder that the installer copies whole — and says /OPT:REF and /OPT:ICF, which /DEBUG
# would otherwise turn off, so the code it links is the code it linked before.
function(strip_release)
    foreach(target IN LISTS ARGN)
        if(ORBITAMP_KEEP_SYMBOLS)
            keep_symbols(${target})
        elseif(APPLE)
            target_link_options(${target} PRIVATE $<$<CONFIG:Release>:LINKER:-x>)
        elseif(UNIX)
            target_link_options(${target} PRIVATE $<$<CONFIG:Release>:-s>)
        endif()
    endforeach()
endfunction()

function(keep_symbols target)
    set(dir "${ORBITAMP_SYMBOLS_DIR}/${target}")
    if(MSVC)
        target_link_options(${target} PRIVATE "$<$<CONFIG:Release>:/DEBUG:FULL;/OPT:REF;/OPT:ICF;/INCREMENTAL:NO>")
        set_target_properties(${target} PROPERTIES PDB_OUTPUT_DIRECTORY_RELEASE "${dir}")
        return()
    endif()
    if(APPLE)
        foreach(arch IN LISTS CMAKE_OSX_ARCHITECTURES)
            target_link_options(${target} PRIVATE
                "$<$<CONFIG:Release>:SHELL:-Xarch_${arch} -Wl,-object_path_lto,${ORBITAMP_LTO_OBJECTS_DIR}/${target}-${arch}.o>")
        endforeach()
        set(tools "-DSTRIP=${CMAKE_STRIP}" "-DDSYMUTIL=${ORBITAMP_DSYMUTIL}" "-DDWARFDUMP=${ORBITAMP_DWARFDUMP}"
                  "-DBUNDLE=$<TARGET_BUNDLE_DIR:${target}>")
    else()
        set(tools "-DSTRIP=${CMAKE_STRIP}" "-DOBJCOPY=${CMAKE_OBJCOPY}" "-DREADELF=${CMAKE_READELF}")
    endif()
    add_custom_command(TARGET ${target} POST_BUILD
        COMMAND "${CMAKE_COMMAND}" "-DCONFIG=$<CONFIG>" "-DBINARY=$<TARGET_FILE:${target}>" "-DSYMBOLS=${dir}"
                ${tools} -P "${CMAKE_CURRENT_SOURCE_DIR}/cmake/KeepSymbols.cmake"
        COMMENT "${target}: keeping its symbols, then stripping it"
        VERBATIM)
endfunction()

# A PLUG-IN EXPORTS ITS ENTRY POINTS AND NOTHING ELSE — on Linux, where nothing else sees to it. A host that
# opens two of our binaries in one process — the family's VST3 and its CLAP, an amp's own bundle beside the
# family's, two amps' own bundles — holds two copies of everything an amp is made of, and each copy must stay
# its binary's own. JUCE is compiled with hidden visibility; the static libraries an amp links are not — NAM's
# code (felitronics-guitar-core's felitronics_nam), the core's, the codecs' — and gcc emits a static of theirs
# that must be one in a program (a registry, a function's static local) as a GNU_UNIQUE symbol, which the
# dynamic linker makes ONE for the whole process, RTLD_LOCAL or not. So the second binary to load registered
# its NAM models in the first's registry and stopped the process: "Config parser already registered for:
# SlimmableContainer". Every Linux binary of a plug-in is linked with a version script that names its format's
# entry points and makes every other symbol local, whatever library it came from and however that library was
# compiled: cmake/exports/vst3.ver (GetPluginFactory, ModuleEntry, ModuleExit — what a VST3 host looks up) and
# cmake/exports/clap.ver (clap_entry). Nothing of ours is in the process's symbol table for another binary to
# meet, and a binary with no GNU_UNIQUE symbol can be unloaded again, as on the other systems. The standalones
# are executables, which export nothing a host could meet, and are left alone. The Mac (two-level namespace)
# and Windows (a DLL exports what it names) keep each binary's symbols its own already and are left as they
# are. For every format of an amp (add_amp) and of the family's plug-ins (THE FAMILY'S PLUG-INS).
function(export_entry_points_only)
    if(APPLE OR NOT UNIX)
        return()
    endif()
    foreach(target IN LISTS ARGN)
        if(target MATCHES "_VST3$")
            set(script "${CMAKE_CURRENT_SOURCE_DIR}/cmake/exports/vst3.ver")
        elseif(target MATCHES "_CLAP$")
            set(script "${CMAKE_CURRENT_SOURCE_DIR}/cmake/exports/clap.ver")
        else()
            continue()
        endif()
        target_link_options(${target} PRIVATE "LINKER:--version-script=${script}")
        set_property(TARGET ${target} APPEND PROPERTY LINK_DEPENDS "${script}")   # an edited script relinks
    endforeach()
endfunction()

function(add_amp name)
    cmake_parse_arguments(PARSE_ARGV 1 AMP "BY_NAME;WHOLE_SHELF;BASS" "CODE;ICON" "SOURCES;LIBRARIES;ART;SET")
    string(TOLOWER "${name}" id)
    set(iconOf "${name}")
    if(AMP_ICON)
        set(iconOf "${AMP_ICON}")
    endif()

    # Its icon. macOS 26 sets any icon that is not its own rounded square on a grey plate — the family's
    # disc came out as a small disc on a light square — so the Mac wears the amp's mark on the rounded
    # square the system expects (824 of the 1024 canvas, margins and all), the violet round its edge, and
    # it is shown as drawn. Windows and Linux keep the disc, or the same square on the whole canvas.
    if(APPLE)
        set(icon "${CMAKE_CURRENT_SOURCE_DIR}/resources/icon/${iconOf}-macOS-1024.png")
    else()
        set(icon "${CMAKE_CURRENT_SOURCE_DIR}/resources/icon/${iconOf}-1024.png")
    endif()

    juce_add_plugin(${name}
        VERSION                     "${ORBITAMP_FAMILY_VERSION}"
        PRODUCT_NAME                "${name}"
        COMPANY_NAME                "Darwin's Cat"
        BUNDLE_ID                   "com.darwinscat.${id}"
        PLUGIN_MANUFACTURER_CODE    Dcat
        PLUGIN_CODE                 ${AMP_CODE}
        FORMATS                     VST3 AU Standalone
        VST3_CATEGORIES             ${AMP_VST3_CATEGORIES}
        AU_MAIN_TYPE                "kAudioUnitType_Effect"
        IS_SYNTH                    FALSE
        NEEDS_MIDI_INPUT            FALSE
        NEEDS_MIDI_OUTPUT           FALSE
        IS_MIDI_EFFECT              FALSE
        EDITOR_WANTS_KEYBOARD_FOCUS FALSE
        # Standalone is an effect → it needs the system audio INPUT. Under the macOS hardened
        # runtime that means NSMicrophoneUsageDescription in the app's Info.plist plus the
        # audio-input entitlement at signing time. Plug-in formats run in the host and don't.
        MICROPHONE_PERMISSION_ENABLED TRUE
        MICROPHONE_PERMISSION_TEXT  "${name} needs audio input to process your signal."
        # Bundle / executable icon. One 1024-square PNG is enough: juceaide builds the macOS .icns for
        # every bundle and the Windows .ico from it. No ICON_SMALL on purpose — see OrbitCab: juceaide
        # reads the pair small-then-big while JUCEUtils appends big-then-small, and passing both can
        # swap the slots.
        ICON_BIG                    "${icon}"
        COPY_PLUGIN_AFTER_BUILD     ${ORBITAMP_COPY_PLUGIN})

    target_sources(${name} PRIVATE ${AMP_SOURCES})

    # Wrap the same JUCE plugin as a CLAP (.clap) — one extra format, no source changes. The wrapper
    # links its own headers into the plug-in, ahead of everything the amp links below.
    clap_juce_extensions_plugin(TARGET ${name}
        CLAP_ID       "com.darwinscat.${id}"
        CLAP_FEATURES ${AMP_CLAP_FEATURES})

    # The CLAP wrapper ships its own default clap.icns (the generic CLAP logo) and JUCE's ICON_BIG
    # does not reach it. Overwrite it in place with the AppIcon.icns juceaide already generated for
    # the JUCE formats, keeping the wrapper's Info.plist CFBundleIconFile=clap.icns reference valid.
    # macOS only — the CLAP on Windows/Linux is a plain shared library, no icon resource.
    if(APPLE)
        add_custom_command(TARGET ${name}_CLAP POST_BUILD
            COMMAND "${CMAKE_COMMAND}" -E copy
                    "$<TARGET_PROPERTY:${name},JUCE_ICON_FILE>"
                    "$<TARGET_BUNDLE_DIR:${name}_CLAP>/Contents/Resources/clap.icns"
            VERBATIM)
    endif()

    # THE FAMILY'S version, not the plugin wrapper's. `JucePlugin_VersionString` exists only inside a
    # target juce_add_plugin built, and the headless gates compile the very same UI sources without it —
    # so a face that read it built as a plugin and failed as a test. This one is defined for everything
    # that compiles a face. Which amp it is, is not on the compiler's line: it is the Product the
    # processor is made with (src/Product.h), and only the plug-in's own entry is compiled here, in the
    # amp's own file — a gate, or a binary of several amps, makes its processors itself.
    target_compile_definitions(${name} PUBLIC
        ORBITAMP_VERSION="${ORBITAMP_FAMILY_VERSION}")
    target_compile_definitions(${name} PRIVATE ORBITAMP_PLUGIN_ENTRY=1)
    target_compile_definitions(${name} PUBLIC
        JUCE_WEB_BROWSER=0
        JUCE_USE_CURL=0
        JUCE_VST3_CAN_REPLACE_VST2=0
        JUCE_DISPLAY_SPLASH_SCREEN=0   # JUCE 8 has no splash requirement on any tier, incl. AGPLv3
        ${AMP_UNREAD_CODECS}           # ...nor a codec it never reads (above)
        $<$<PLATFORM_ID:Windows>:JUCE_ASIO=1>)   # the standalone offers ASIO beside WASAPI; JUCE carries the SDK

    target_include_directories(${name} PUBLIC "${ORBITAMP_GENERATED_DIR}")   # OrbitAmpVersion.h
    add_dependencies(${name} OrbitAmpVersionGen)                            # ...rebaked before every build

    # A RELEASE'S AMPS LINK WITH LINK-TIME OPTIMISATION (ORBITAMP_LTO), JUCE's recommended flags: the code a
    # face never calls goes, and the binary is smaller for it. Its gates link without it (amp_console), in
    # seconds rather than minutes, whatever this says.
    set(libraries ${AMP_LIBRARIES}
        juce::juce_recommended_config_flags
        juce::juce_recommended_warning_flags)
    if(ORBITAMP_LTO)
        list(APPEND libraries juce::juce_recommended_lto_flags)
    endif()
    target_link_libraries(${name} PRIVATE ${libraries})

    # WHAT IT PLAYS, in the family's factory folder (THE FACTORY FOLDER): its pictures, its packs and
    # its chain's cabinets — a guitar amp Darwin's Cat's own, and the shelf's other folders where it plays
    # the whole shelf; a bass amp the bass's folders, and none of the guitar's.
    set(files "")
    set(at "")
    foreach(render IN LISTS AMP_ART)
        get_filename_component(base "${render}" NAME)
        list(APPEND files "${render}")
        list(APPEND at "Faces/${name}/${base}")
    endforeach()
    foreach(pack IN LISTS AMP_SET)
        if(NOT pack IN_LIST ORBITAMP_SET_NAMES)
            message(FATAL_ERROR "${name} plays the pack ${pack}, which resources/set/Devices has not")
        endif()
        list(APPEND files "${ORBITAMP_SET_ZIPPED}/${pack}.orbitrig.zip")
        list(APPEND at "${pack}.orbitrig.zip")
    endforeach()
    if(AMP_BASS AND AMP_WHOLE_SHELF)
        message(FATAL_ERROR "${name} is a bass amp, and the whole shelf is the guitar's")
    elseif(AMP_BASS)
        list(APPEND files ${ORBITAMP_CABINETS_BASS})
        list(APPEND at ${ORBITAMP_CABINETS_BASS_AT})
    else()
        list(APPEND files ${ORBITAMP_CABINETS_GUITAR})
        list(APPEND at ${ORBITAMP_CABINETS_GUITAR_AT})
        if(AMP_WHOLE_SHELF)
            list(APPEND files ${ORBITAMP_CABINETS_ORBITAMP})
            list(APPEND at ${ORBITAMP_CABINETS_ORBITAMP_AT})
        endif()
    endif()
    factory_carries(${name} FILES ${files} AT ${at})
    add_dependencies(${name} Family_Factory)
    if(ORBITAMP_DEV_FACTORY)
        target_compile_definitions(${name} PRIVATE ORBITAMP_DEV_FACTORY="${ORBITAMP_FACTORY_DIR}")
    endif()

    # Every format the amp is built as on this platform — AU on the Mac alone.
    set(formats "")
    foreach(fmt IN ITEMS VST3 AU Standalone CLAP)
        if(TARGET ${name}_${fmt})
            list(APPEND formats ${name}_${fmt})
        endif()
    endforeach()

    strip_release(${formats})
    export_entry_points_only(${formats})

    # BY_NAME: not part of the default build. OrbitAmp's own build — a contributor's, a pull request's —
    # must never fail on a face. Whoever wants one asks for it by name: one format (`cmake --build build
    # --target CatpitAmp_Standalone`), or all of them — `--target CatpitAmp_All`; the family's release
    # asks for the Standalone of every amp it carries, and holds their plug-ins in its own (Family_All).
    if(AMP_BY_NAME)
        set_target_properties(${name} ${formats} PROPERTIES EXCLUDE_FROM_ALL TRUE)
    endif()

    # <Name>_All is every format: the CLAP joins it here, since its wrapper does not add itself.
    add_dependencies(${name}_All ${name}_CLAP)

    set_property(TARGET ${name} PROPERTY AMP_SOURCES ${AMP_SOURCES})
    set_property(TARGET ${name} PROPERTY AMP_LIBRARIES ${libraries})
    set_property(TARGET ${name} PROPERTY AMP_CODE ${AMP_CODE})
    set(AMPS ${AMPS} ${name} PARENT_SCOPE)
endfunction()

# AN AMP'S GATES are the amp compiled again under a main() of its own — its sources, its libraries, the
# family's version and its name, as add_amp was given them, and the build's factory folder for what it
# plays — and are built only when asked for by name. The gate makes its processors of the amp's Product,
# ORBITAMP_GATE_PRODUCT — orbitamp::products::<name> with its first letter small (src/Product.h).
# CHANNELS is how many channels the gate holds it to (GATE_CHANNELS), said apart from the amp's lineup.
# NO_FACTORY plays it with no factory folder at all.
function(amp_console target product amp main)
    cmake_parse_arguments(PARSE_ARGV 4 GATE "NO_FACTORY" "CHANNELS" "")
    get_target_property(sources ${amp} AMP_SOURCES)
    get_target_property(libraries ${amp} AMP_LIBRARIES)
    list(REMOVE_ITEM libraries juce::juce_recommended_lto_flags)   # a gate links in seconds, not minutes
    juce_add_console_app(${target} PRODUCT_NAME "${product}")
    target_sources(${target} PRIVATE ${main} ${sources})
    target_include_directories(${target} PRIVATE src "${ORBITAMP_GENERATED_DIR}")
    add_dependencies(${target} OrbitAmpVersionGen)
    string(SUBSTRING "${amp}" 0 1 first)
    string(SUBSTRING "${amp}" 1 -1 rest)
    string(TOLOWER "${first}" first)
    target_compile_definitions(${target} PRIVATE
        ORBITAMP_VERSION="${ORBITAMP_FAMILY_VERSION}"
        ORBITAMP_PRODUCT_NAME="${amp}"
        ORBITAMP_GATE_PRODUCT=orbitamp::products::${first}${rest})
    if(GATE_CHANNELS)
        target_compile_definitions(${target} PRIVATE GATE_CHANNELS=${GATE_CHANNELS})
    endif()
    target_compile_definitions(${target} PRIVATE JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 ${AMP_UNREAD_CODECS})
    target_link_libraries(${target} PRIVATE ${libraries})
    if(GATE_NO_FACTORY)
        gate_reads_factory(${target} "${CMAKE_CURRENT_BINARY_DIR}/no-factory/Factory")
    else()
        gate_reads_factory(${target})
    endif()
    set_target_properties(${target} PROPERTIES EXCLUDE_FROM_ALL TRUE)
endfunction()

# ----------------------------------------------------------------------------
# THE SET: every pack and every cabinet a Darwin's Cat amp plays, ONE copy of each in the tree —
# resources/set/Devices for the packs, under their own names, and resources/set/IRs for the cabinets
# (resources/set/IRs.md says what they are). Each product says which of them it plays, and no product
# keeps a folder of its own; the build lays them out in the factory folder (THE FACTORY FOLDER).
# ----------------------------------------------------------------------------
set(ORBITAMP_SET_DIR "${CMAKE_CURRENT_SOURCE_DIR}/resources/set")

# A PACK IS KEPT AS A FOLDER and carried as a zip. In the tree each pack is a folder,
# resources/set/Devices/<name>.orbitrig — its manifest, its models and its picture side by side, so a
# change to a pack is a change to its rig.json that git can show, not a new blob. Every build zips each
# folder into <name>.orbitrig.zip in the build tree — the file the factory folder holds, under the name it
# always had. .gitattributes keeps git's
# hands off the folders' line endings: what is zipped is the files byte for byte, on every system.
#
# The zip is made by a tool of our own (tools/PackZip.cpp, JUCE's zip writer), not by `cmake -E tar`:
# CMake's zip writer puts into every entry the access and change times the file has on disk, its
# owner, its permissions and a date in the machine's own time zone, whatever --mtime says — so the
# same folder made other bytes on another checkout, another day or another machine, and an unchanged
# pack would be a changed file in every release and every installed folder. Ours
# puts in the files' names and bytes and nothing else, in the order of their names, so the same folder
# makes the same zip on every build and every system.
#
# Each folder's files are listed by a glob, CONFIGURE_DEPENDS, so a file added to a pack, or a pack
# added to Devices, is zipped from the next build on; the list is also written out, and rewritten only
# when it changes, so a file taken out of a pack makes the zip again too (as JUCE's binary data does).
# A name with a leading dot is the Finder's (.DS_Store), not the pack's. Every zip is made by one
# target, OrbitAmpSetPacks, which the factory folder waits for: a rule that several targets ran would
# race itself in a parallel build.
juce_add_console_app(orbitamp_pack_zip PRODUCT_NAME "OrbitAmpPackZip")
target_sources(orbitamp_pack_zip PRIVATE tools/PackZip.cpp)
target_compile_definitions(orbitamp_pack_zip PRIVATE JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)
target_link_libraries(orbitamp_pack_zip PRIVATE
    juce::juce_core
    juce::juce_recommended_config_flags
    juce::juce_recommended_warning_flags)

set(ORBITAMP_SET_ZIPPED "${CMAKE_CURRENT_BINARY_DIR}/set/Devices")
file(GLOB ORBITAMP_SET_FOLDERS LIST_DIRECTORIES true CONFIGURE_DEPENDS "${ORBITAMP_SET_DIR}/Devices/*.orbitrig")
set(ORBITAMP_SET_PACKS "")
set(ORBITAMP_SET_NAMES "")       # each pack's name, its folder's less `.orbitrig`
foreach(folder IN LISTS ORBITAMP_SET_FOLDERS)
    if(NOT IS_DIRECTORY "${folder}")
        continue()
    endif()
    get_filename_component(pack "${folder}" NAME)
    string(REGEX REPLACE "\\.orbitrig$" "" name "${pack}")
    list(APPEND ORBITAMP_SET_NAMES "${name}")
    file(GLOB files LIST_DIRECTORIES false CONFIGURE_DEPENDS "${folder}/*")
    list(FILTER files EXCLUDE REGEX "/\\.[^/]*$")
    list(SORT files)

    set(listed "${ORBITAMP_SET_ZIPPED}/${pack}.files")
    list(JOIN files "\n" lines)
    set(before "")
    if(EXISTS "${listed}")
        file(READ "${listed}" before)
    endif()
    if(NOT before STREQUAL lines)
        file(WRITE "${listed}" "${lines}")
    endif()

    add_custom_command(OUTPUT "${ORBITAMP_SET_ZIPPED}/${pack}.zip"
        COMMAND orbitamp_pack_zip "${listed}" "${ORBITAMP_SET_ZIPPED}/${pack}.zip"
        DEPENDS orbitamp_pack_zip "${listed}" ${files}
        COMMENT "Zipping ${pack}"
        VERBATIM)
    list(APPEND ORBITAMP_SET_PACKS "${ORBITAMP_SET_ZIPPED}/${pack}.zip")
endforeach()
add_custom_target(OrbitAmpSetPacks DEPENDS ${ORBITAMP_SET_PACKS})

# THE BASS'S PACKS, which no guitar amp plays — a guitar amp's packs and a bass amp's never cross, as their
# cabinets do not (resources/cabinets.txt). OrbitBass plays them and opens on the first; RedGrooveBass's two
# channels, B15 and SVT, are the SGT-DI's two voices (src/redgroove/RedGrooveLineup.cpp).
set(ORBITBASS_SET   "Ampeg SGT-DI")
set(REDGROOVEBASS_SET "Ampeg SGT-DI")

# WHAT ORBITAMP PLAYS: every pack in resources/set/Devices but the bass's — every folder there, zipped — the
# X88-IR's, the IR-X's, the ReVolt's and the V4's, each one file in the family's folder whichever amps play it. A
# guitar pack added there is OrbitAmp's from the next build on, with nobody to remember to list it; a pack the
# tree keeps but OrbitAmp should not play has no place in resources/set/Devices, or is a bass amp's.
set(ORBITAMP_PLAYS ${ORBITAMP_SET_NAMES})
list(REMOVE_ITEM ORBITAMP_PLAYS ${ORBITBASS_SET} ${REDGROOVEBASS_SET})

# WHAT EACH OTHER AMP PLAYS of the set, said once — its row in THE AMPS names it by these.
set(CATPITAMP_SET   "Soldano X88-IR Normal" "Soldano X88-IR Altered" "Soldano X88-IR Crunch" "Soldano X88-IR Overdrive")
set(REDPAWAMP_SET   "Friedman IR-X Ch1 PowerAmp" "Friedman IR-X Ch2 PowerAmp")
set(FROSTPAWAMP_SET "Two Notes ReVolt Clean PowerAmp" "Two Notes ReVolt Crunch PowerAmp" "Two Notes ReVolt Lead PowerAmp")
set(AMBERPAWAMP_SET "Victory V4 Copper (clean)" "Victory V4 Sheriff (crunch)" "Victory V4 Kraken (hi-gain)")

# THE FAMILY A BUILD RELEASES: installer/family.ini, the amps, unless -DFAMILY_INI= names another —
# installer/bass.ini, the basses (the owner, 06.11: a package of their own). Everything below that says
# "family.ini" reads this one: the release's amps, its bundle, its factory folder.
set(FAMILY_INI "${CMAKE_CURRENT_SOURCE_DIR}/installer/family.ini" CACHE FILEPATH
    "The family this build releases: installer/family.ini (the amps) or installer/bass.ini (the basses)")
get_filename_component(FAMILY_INI "${FAMILY_INI}" ABSOLUTE BASE_DIR "${CMAKE_CURRENT_SOURCE_DIR}")
if(NOT EXISTS "${FAMILY_INI}")
    message(FATAL_ERROR "FAMILY_INI names ${FAMILY_INI}, which is no file")
endif()
# ...and its version: its own `version=` where it keeps one (the basses), else the tree's — every amp's, its bundle's
# and the update check's number in this build (installer/version.sh reads the same).
file(STRINGS "${FAMILY_INI}" ORBITAMP_FAMILY_VERSION REGEX "^version=")
string(REGEX REPLACE "^version=" "" ORBITAMP_FAMILY_VERSION "${ORBITAMP_FAMILY_VERSION}")
string(STRIP "${ORBITAMP_FAMILY_VERSION}" ORBITAMP_FAMILY_VERSION)
if(NOT ORBITAMP_FAMILY_VERSION)
    set(ORBITAMP_FAMILY_VERSION "${PROJECT_VERSION}")
endif()

# A RELEASE SHIPS NO PACK OF AN AMP IT LEAVES OUT. A release (ORBITAMP_DEV_FACTORY OFF) carries the amps
# installer/family.ini names; the packs only an amp it leaves out plays — today AmberPawAmp's V4 — are not
# OrbitAmp's there either, so they wait for their own amp. Built here, OrbitAmp
# plays them all — and in a release that leaves OrbitAmp out too (the basses, installer/bass.ini): nothing of
# OrbitAmp ships there (the release's folder holds its amps' lists alone), and the gates, which play every amp,
# hear OrbitAmp as it is built here.
file(STRINGS "${FAMILY_INI}" ORBITAMP_RELEASED REGEX "^amps=")
string(REGEX REPLACE "^amps=" "" ORBITAMP_RELEASED "${ORBITAMP_RELEASED}")
separate_arguments(ORBITAMP_RELEASED)
if(NOT ORBITAMP_DEV_FACTORY AND "OrbitAmp" IN_LIST ORBITAMP_RELEASED)
    set(kept "")
    set(left "")
    foreach(amp CatpitAmp RedPawAmp FrostPawAmp AmberPawAmp)
        string(TOUPPER "${amp}" key)
        if(amp IN_LIST ORBITAMP_RELEASED)
            list(APPEND kept ${${key}_SET})
        else()
            list(APPEND left ${${key}_SET})
        endif()
    endforeach()
    foreach(pack IN LISTS left)
        if(NOT pack IN_LIST kept)
            list(REMOVE_ITEM ORBITAMP_PLAYS "${pack}")
        endif()
    endforeach()
endif()
list(LENGTH ORBITAMP_PLAYS ORBITAMP_SET_COUNT)
message(STATUS "OrbitAmp Devices: ${ORBITAMP_SET_COUNT} in the factory folder")
# Which of the rovers' devices OrbitAmp plays here, for its set gate: the ReVolt with FrostPawAmp, the V4 with
# AmberPawAmp — each in a release only when its amp is.
foreach(amp FROSTPAWAMP AMBERPAWAMP)
    list(GET ${amp}_SET 0 first)
    if(first IN_LIST ORBITAMP_PLAYS)
        set(${amp}_PACKS_IN_ORBITAMP 1)
    else()
        set(${amp}_PACKS_IN_ORBITAMP 0)
    endif()
endforeach()

# ----------------------------------------------------------------------------
# Embedded assets. The display FACE is not among them: appkit carries Michroma itself, whole, as
# code, so a product that embedded it too was putting a second copy of the same font in every
# binary and parsing both at startup. The mark still comes from appkit's assets/ — referenced
# there, NOT copied here, so there is one copy of the file in the ecosystem.
# felitronics_appkit_SOURCE_DIR is set by FetchContent above and points at whichever source won
# (local checkout or fetched release).
# ----------------------------------------------------------------------------

# THE CABINET CATALOG (resources/cabinets.txt): every cabinet IR the family carries, each said once — its
# number, its name, the folder of the shelf it lies in and its file. cmake/CabinetCatalog.cmake reads it
# into the files the factory folder holds, in the order of their numbers — Darwin's Cat's own, which every
# guitar amp plays, the folders OrbitAmp alone plays (add_amp: WHOLE_SHELF), and the bass's, which every
# bass amp plays and no guitar amp (add_amp: BASS; none yet) — and into the table the code
# plays them by, generated/CabinetCatalog.h: the `cab_ir` parameter's names and default (src/Parameters.h)
# and the shelf's folders (src/device/FactoryShelf.h). A cabinet joining the shelf is a line there, and its
# file; nothing here or in the code lists one. What compiles Parameters.h links OrbitAmpCabinetCatalog for
# the table — whatever links OrbitAmpData has it already.
include("${CMAKE_CURRENT_SOURCE_DIR}/cmake/CabinetCatalog.cmake")
orbitamp_cabinet_catalog("${CMAKE_CURRENT_SOURCE_DIR}/resources/cabinets.txt"
                         "${CMAKE_CURRENT_SOURCE_DIR}/resources"
                         "${ORBITAMP_GENERATED_DIR}/CabinetCatalog.h")
add_library(OrbitAmpCabinetCatalog INTERFACE)
target_include_directories(OrbitAmpCabinetCatalog INTERFACE "${ORBITAMP_GENERATED_DIR}")   # CabinetCatalog.h

# THE BASS'S DOZEN: twelve of cab-ir-generator's factory presets, the most unlike of its punk, rock, metal and modern ones
# (the owner, 06.11), the biggest box first — the cabinets RedGrooveBass plays, and OrbitBass's list. The presets' files
# ride in the binary as cab-ir-generator writes them; BassDozen.h names them in this order (src/device/BassCabinets.h).
set(ORBITAMP_BASS_CABINETS
    rock-03-8x10-stack rock-09-6x10-wall rock-08-4x10-crunch modern-02-4x10-sheen metal-14-2x12-torque
    punk-07-2x10-gutter rock-14-1x15-thump modern-18-1x15-extended punk-17-1x12-squat rock-17-1x12-club
    punk-19-4x6-box modern-13-4x6-neo)
set(_orbitamp_bass_stems "")
foreach(stem IN LISTS ORBITAMP_BASS_CABINETS)
    set(file "${cab_ir_generator_SOURCE_DIR}/data/presets/${stem}.toml")
    if(NOT EXISTS "${file}")
        message(FATAL_ERROR "The bass's dozen names ${stem}, which cab-ir-generator (${cab_ir_generator_SOURCE_DIR}) has no preset of")
    endif()
    string(APPEND _orbitamp_bass_stems "    \"${stem}\",\n")
endforeach()
# ...AND ALL OF THEM (the owner, 06.11): every factory preset of cab-ir-generator's and its typical cabinets — the IR
# packs' 190 — OrbitBass's CABINETS › ALL, by style and by size. The dozen is among them; they ride in the binary instead.
file(GLOB ORBITAMP_BASS_PRESET_FILES CONFIGURE_DEPENDS
    "${cab_ir_generator_SOURCE_DIR}/data/presets/*.toml" "${cab_ir_generator_SOURCE_DIR}/data/typical/*.toml")
list(SORT ORBITAMP_BASS_PRESET_FILES)   # the styles' by name and number, then the typical ones
set(_orbitamp_bass_all_stems "")
foreach(file IN LISTS ORBITAMP_BASS_PRESET_FILES)
    get_filename_component(stem "${file}" NAME_WE)
    string(APPEND _orbitamp_bass_all_stems "    \"${stem}\",\n")
endforeach()
file(CONFIGURE OUTPUT "${ORBITAMP_GENERATED_DIR}/BassDozen.h" @ONLY CONTENT
"// Written by CMakeLists.txt (THE BASS'S DOZEN): cab-ir-generator's presets the bass plays, by their files' stems, in order —
// and all of them, the styles' and the typical ones.
#pragma once
namespace orbitamp
{
inline constexpr const char* bassCabinets[] =
{
@_orbitamp_bass_stems@};
inline constexpr const char* bassPresets[] =
{
@_orbitamp_bass_all_stems@};
}
")

juce_add_binary_data(OrbitAmpData
    SOURCES
        "${felitronics_appkit_SOURCE_DIR}/assets/catlogo.svg"

        # The trademark notice, as text rather than as a string literal: it is a legal sentence that
        # the README carries word for word, and a file can be diffed against that one.
        "${CMAKE_CURRENT_SOURCE_DIR}/resources/notice.txt"
        "${CMAKE_CURRENT_SOURCE_DIR}/resources/disclaimer.txt"   # ...and its long form, with the list

        # The bass's cabinets, as cab-ir-generator's synthesis renders them live with the mics where the player put them.
        "${CABIR_CABINETS}"
        ${ORBITAMP_BASS_PRESET_FILES}       # ...and all of them, its dozen among them (THE BASS'S DOZEN)
)
# ...and the table the cabinet shelf is played by: its IRs themselves lie in the factory folder.
target_link_libraries(OrbitAmpData INTERFACE OrbitAmpCabinetCatalog)

# THE GUITAR'S CABINETS (the owner, 08.11): Orbit Guitar Cab Builder's table and every one of its presets, rendered live
# as the bass's are — its TOP 12 first, the cabinets the guitar amps play (GuitarDozen.h, in their numbers' order), then
# all of them, its styles' (TOP 12 among them) and its typical ones. A data target of its own, GuitarCabData: the
# guitar's typical presets share their files' names with the bass's, and its table is cabinets.txt too.
file(GLOB ORBITAMP_GUITAR_TOP_FILES CONFIGURE_DEPENDS "${cab_ir_generator_SOURCE_DIR}/data/guitar/presets/top12-*.toml")
list(SORT ORBITAMP_GUITAR_TOP_FILES)
list(LENGTH ORBITAMP_GUITAR_TOP_FILES _orbitamp_guitar_top_count)
if(NOT _orbitamp_guitar_top_count EQUAL 12)
    message(FATAL_ERROR "The guitar's TOP 12 is ${_orbitamp_guitar_top_count} presets in cab-ir-generator (${cab_ir_generator_SOURCE_DIR}), not 12")
endif()
set(_orbitamp_guitar_stems "")
foreach(file IN LISTS ORBITAMP_GUITAR_TOP_FILES)
    get_filename_component(stem "${file}" NAME_WE)
    string(APPEND _orbitamp_guitar_stems "    \"${stem}\",\n")
endforeach()
file(GLOB ORBITAMP_GUITAR_PRESET_FILES CONFIGURE_DEPENDS
    "${cab_ir_generator_SOURCE_DIR}/data/guitar/presets/*.toml" "${cab_ir_generator_SOURCE_DIR}/data/guitar/typical/*.toml")
list(SORT ORBITAMP_GUITAR_PRESET_FILES)
set(_orbitamp_guitar_all_stems "")
foreach(file IN LISTS ORBITAMP_GUITAR_PRESET_FILES)
    get_filename_component(stem "${file}" NAME_WE)
    string(APPEND _orbitamp_guitar_all_stems "    \"${stem}\",\n")
endforeach()
file(CONFIGURE OUTPUT "${ORBITAMP_GENERATED_DIR}/GuitarDozen.h" @ONLY CONTENT
"// Written by CMakeLists.txt (THE GUITAR'S CABINETS): cab-ir-generator's guitar presets the guitar amps play, its TOP 12,
// by their files' stems, in order — and all of them, the styles' and the typical ones.
#pragma once
namespace orbitamp
{
inline constexpr const char* guitarCabinets[] =
{
@_orbitamp_guitar_stems@};
inline constexpr const char* guitarPresets[] =
{
@_orbitamp_guitar_all_stems@};
}
")
configure_file("${cab_ir_generator_SOURCE_DIR}/data/guitar/cabinets.txt" "${ORBITAMP_GENERATED_DIR}/guitar-cabinets.txt" COPYONLY)
juce_add_binary_data(OrbitAmpGuitarCabData HEADER_NAME GuitarCabData.h NAMESPACE GuitarCabData
    SOURCES "${ORBITAMP_GENERATED_DIR}/guitar-cabinets.txt" ${ORBITAMP_GUITAR_PRESET_FILES})
target_link_libraries(OrbitAmpData INTERFACE OrbitAmpGuitarCabData)

# ----------------------------------------------------------------------------
# THE SHADERS: every GLSL program the faces draw with — the windscreens' worlds and the cockpit's sky —
# as files in resources/shaders, a folder a world and what several share in common/, put together by
# src/shaders/Shaders.h. One copy of each, as files rather than string literals, so that whatever else
# draws these views — the site, the same C++ in WebAssembly — reads the very same text. Built into the
# binary of every target that compiles a renderer; a file put there is carried from the next build on,
# with nobody to remember to list it. Binary data knows a file by its name alone, and the worlds' files
# share names (plains/sky.frag, ice/sky.frag), so their paths are written beside it in the same order.
# ----------------------------------------------------------------------------
set(ORBITAMP_SHADER_DIR "${CMAKE_CURRENT_SOURCE_DIR}/resources/shaders")
file(GLOB_RECURSE ORBITAMP_SHADER_FILES CONFIGURE_DEPENDS
    "${ORBITAMP_SHADER_DIR}/*.glsl" "${ORBITAMP_SHADER_DIR}/*.vert" "${ORBITAMP_SHADER_DIR}/*.frag")
list(SORT ORBITAMP_SHADER_FILES)
set(_orbitamp_shader_paths "")
foreach(file IN LISTS ORBITAMP_SHADER_FILES)
    file(RELATIVE_PATH path "${ORBITAMP_SHADER_DIR}" "${file}")
    string(APPEND _orbitamp_shader_paths "    \"${path}\",\n")
endforeach()
file(CONFIGURE OUTPUT "${ORBITAMP_GENERATED_DIR}/ShaderPaths.h" @ONLY CONTENT
"// Written by CMakeLists.txt (THE SHADERS): the paths in resources/shaders of the files ShaderData carries, in its order.
#pragma once
namespace orbitamp::shaders
{
inline constexpr const char* embeddedPaths[] =
{
@_orbitamp_shader_paths@};
}
")
juce_add_binary_data(OrbitAmpShaders
    NAMESPACE   ShaderData
    HEADER_NAME ShaderData.h
    SOURCES     ${ORBITAMP_SHADER_FILES})
target_include_directories(OrbitAmpShaders INTERFACE "${ORBITAMP_GENERATED_DIR}")   # ShaderPaths.h
set_target_properties(OrbitAmpShaders PROPERTIES EXCLUDE_FROM_ALL TRUE)   # OrbitAmp itself draws none

# BAKE-ART — the faces' pictures as they ship (tools/bake-art/BakeArt.cpp): each face's renders as painted,
# in resources/<face>/source, corrected and cut once into the lossless WebP its product carries, in
# resources/<face>. No product builds it or waits for it: it is run by hand, on a Mac, when a render or a
# number it was measured to changes — `--target orbitamp_bake_art`, then the tool, or the tool --check.
juce_add_console_app(orbitamp_bake_art PRODUCT_NAME "OrbitAmpBakeArt")
target_sources(orbitamp_bake_art PRIVATE
    tools/bake-art/BakeArt.cpp
    tools/bake-art/Rover.cpp
    tools/bake-art/Cockpit.cpp
    tools/bake-art/Walker.cpp
    src/face/Renders.cpp)
target_include_directories(orbitamp_bake_art PRIVATE src)
target_compile_definitions(orbitamp_bake_art PRIVATE
    ORBITAMP_RESOURCES_DIR="${CMAKE_CURRENT_SOURCE_DIR}/resources"
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0)
target_link_libraries(orbitamp_bake_art PRIVATE
    felitronics::appkit_webp
    juce::juce_gui_basics
    juce::juce_recommended_config_flags
    juce::juce_recommended_warning_flags)
set_target_properties(orbitamp_bake_art PROPERTIES EXCLUDE_FROM_ALL TRUE)

# ----------------------------------------------------------------------------
# WHAT THE AMPS ARE MADE OF — the lists their rows in THE AMPS take up, each said once.
# ----------------------------------------------------------------------------
# The engine every amp plays through, and what each part of it is for.
set(AMP_ENGINE_LIBRARIES
    felitronics::analysis            # spectrum taps + panes behind the EQ curves
    felitronics::appkit              # shared app-side kit (header-only; JUCE comes from us)
    felitronics::appkit_webp         # juce::Image <- WebP, for the picture a pack ships
    felitronics::core                # core::BypassWire reads the resampler's delay geometry
    felitronics::dehum               # the hum off the input, ahead of the trim
    felitronics::delay               # the echo (TapeDelay) and its knob law — sync, DARK, ranges
    felitronics::reverb              # the room (AmpReverb), and the reverb face's picture of it
    felitronics::dynamics            # the noise gate (felitronics::dynamics::NoiseGate)
    felitronics::eq                  # matched biquads behind the tone stack (core::ToneStack)
    felitronics::lineareq            # the tone curve read off the player's grid (core::CapturedBlock)
    felitronics::convolution         # the cabinet's convolver (core::CabinetIr → CabConvolver, pffft)
    felitronics::measurement         # reference-unity IR normalization (core::CabinetIr)
    felitronics::nam                 # NAM inference — the captured devices actually play
    felitronics::rigplayer           # the pack player: captures, their crossfade, tone, alignment
    felitronics::limiter             # the safety at the door: a true-peak limiter with lookahead
    felitronics::octave              # the bass's OCTAVE (Octaver) and its slider's law
    felitronics::envfilter           # the bass's FILTER (EnvelopeFilter, keyed) and its slider's law
    felitronics::chorus              # the bass's CHORUS (BassChorus) and its slider's law
    cabir::panel                     # the bass's own cabinets: synthesis, panel, miniature (cab-ir-generator)
    juce::juce_audio_utils           # pulls audio_processors / audio_basics / gui_basics ...
    juce::juce_dsp                   # the chain stages will build on this
    juce::juce_data_structures)      # ValueTree behind the workspace / presets

# OrbitAmp — the player: the processor, its face (src/ui), and OrbitAmp itself — its Product, its first
# start, its plug-in's entry (OrbitAmpStart.cpp).
set(ORBITAMP_SOURCES
    src/PluginProcessor.cpp
    src/PluginEditor.cpp
    src/OrbitAmpStart.cpp
    src/Parameters.cpp
    src/ui/Theme.cpp
    src/ui/FaceplateView.cpp
    src/ui/CapturedBlockPanel.cpp
    src/ui/CabinetBlock.cpp
    src/ui/CabWindow.cpp
    src/ui/EqSection.cpp
    src/ui/DelayBlock.cpp
    src/ui/ReverbBlock.cpp
    src/ui/Chrome.cpp
    src/ui/DemoStrip.cpp
    src/ui/Footer.cpp
    src/ui/SetupPanel.cpp
    src/ui/WebFaceplate.cpp
    src/device/Cabinets.cpp
    src/device/CabTables.cpp
    src/ui/library/DeviceListView.cpp
    src/ui/library/IrTreeView.cpp
    src/face/Controls.cpp)           # the family's controls — the AMP's channel lever is a face::DetentLever

# OrbitBass — the bass's workstation: OrbitAmp's processor and face, and OrbitBass itself — its Product, its
# plug-in's entry (OrbitBassStart.cpp) — in place of OrbitAmp's.
set(ORBITBASS_SOURCES ${ORBITAMP_SOURCES})
list(REMOVE_ITEM ORBITBASS_SOURCES src/OrbitAmpStart.cpp)
list(APPEND ORBITBASS_SOURCES src/OrbitBassStart.cpp)

# A FACE is the family's console (src/face) over the family's channels (src/channels), on the same
# processor: what the cockpit and every rover are compiled from before their own.
set(FACE_SOURCES
    src/PluginProcessor.cpp
    src/Parameters.cpp
    src/ui/Theme.cpp
    src/core/ProcessMemory.cpp
    src/channels/Channels.cpp
    src/channels/Engine.cpp
    src/device/Cabinets.cpp
    src/device/CabTables.cpp
    src/channels/Presets.cpp
    src/channels/Set.cpp
    src/face/Cabs.cpp
    src/face/Console.cpp
    src/face/Controls.cpp
    src/face/Midi.cpp
    src/face/Monitor.cpp
    src/face/Picture.cpp
    src/face/Renders.cpp
    src/face/Sheet.cpp
    src/face/Standalone.cpp
    src/face/WebImages.cpp)

# CatpitAmp — the cockpit: a second face over the same processor (src/catpit), one processor and a face
# for each product, which the product names (src/Product.h). Its renders are in resources/catpit, as
# bake-art made them, and lie in its own folder of the factory, Faces/CatpitAmp. What the cockpit is made
# of is said once, for the plug-in and for its gates, which are the cockpit compiled again under a main()
# of their own.
set(CATPITAMP_RENDERS
    cockpit.webp lamp-0.webp lamp-1.webp lamp-2.webp lamp-3.webp midi.txt knob-drive.webp knob-tone.webp socket.webp
    throttle-grip.webp guard-closed.webp guard-open.webp guard-on.webp fader-cap.webp sky-clean.jpg
    sky-edge.jpg sky-crunch.jpg sky-hi-gain.jpg mark.svg)
list(TRANSFORM CATPITAMP_RENDERS PREPEND "${CMAKE_CURRENT_SOURCE_DIR}/resources/catpit/")
set(CATPITAMP_SOURCES
    ${FACE_SOURCES}
    src/catpit/CatpitArt.cpp
    src/catpit/CatpitControls.cpp
    src/catpit/CatpitLineup.cpp
    src/catpit/CatpitSpace.cpp
    src/catpit/CatpitGlSky.cpp
    src/catpit/CatpitSkyGl.cpp
    src/catpit/CatpitEditor.cpp
    src/shaders/GpuLog.cpp
    src/shaders/Shaders.cpp)

# THE WORLDS a windscreen looks out on — views that take values and no processor, so they stand on their
# own. RedPawAmp's is the drive across Mars (src/redpaw/view); FrostPawAmp's the same windscreen looking
# out on an ice moon (src/frostpaw/view), the drive handed to it as an IceDrive; AmberPawAmp's the same
# windscreen as a helicopter's canopy over Titan's methane sea (src/amberpaw/view), the drive handed to
# it as a TitanDrive. Each rover takes up its world's sources with the windscreen's own.
set(REDPAW_VIEW_SOURCES
    src/redpaw/view/Mars1993.cpp
    src/redpaw/view/PlainsWorld.cpp
    src/redpaw/view/PlainsGl.cpp
    src/redpaw/view/Windscreen.cpp
    src/shaders/GpuLog.cpp
    src/shaders/Shaders.cpp)
set(FROSTPAW_VIEW_SOURCES
    src/frostpaw/view/IceWorld.cpp
    src/frostpaw/view/IceGl.cpp)
set(AMBERPAW_VIEW_SOURCES
    src/amberpaw/view/TitanWorld.cpp
    src/amberpaw/view/TitanGl.cpp)
# RedGrooveBass's: the walker's dome over the glowing forest (src/redgroove/view), the walk handed to it as a
# WalkerDrive. Its world is matched to its prototype to the last bit, which a fused multiply-add would undo:
# compiled without contraction (MSVC contracts nothing unless asked).
set(REDGROOVE_VIEW_SOURCES
    src/redgroove/view/WalkerWorld.cpp
    src/redgroove/view/WalkerGl.cpp)
if(NOT MSVC)
    set_source_files_properties(src/redgroove/view/WalkerWorld.cpp PROPERTIES COMPILE_OPTIONS "-ffp-contract=off")
endif()

# A world's demo: a bare window with the windscreen in it over one world — the sea's in the canopy's
# shape — for looking at it and measuring it. Built only when asked for by name. No audio.
function(view_demo target product)
    cmake_parse_arguments(PARSE_ARGV 2 DEMO "" "" "SOURCES;DEFINITIONS")
    juce_add_gui_app(${target} PRODUCT_NAME "${product}")
    target_sources(${target} PRIVATE src/redpaw/view/WindscreenDemo.cpp ${DEMO_SOURCES})
    target_include_directories(${target} PRIVATE src)
    target_compile_definitions(${target} PRIVATE ${DEMO_DEFINITIONS} JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)
    target_link_libraries(${target} PRIVATE
        OrbitAmpShaders
        juce::juce_gui_extra
        juce::juce_opengl
        juce::juce_recommended_config_flags
        juce::juce_recommended_warning_flags)
    set_target_properties(${target} PROPERTIES EXCLUDE_FROM_ALL TRUE)
endfunction()
view_demo(redpaw_view_demo   "RedPawViewDemo"   SOURCES ${REDPAW_VIEW_SOURCES})
view_demo(frostpaw_view_demo "FrostPawViewDemo" SOURCES ${REDPAW_VIEW_SOURCES} ${FROSTPAW_VIEW_SOURCES}
    DEFINITIONS ORBITAMP_VIEW_DEMO_ICE=1)
view_demo(amberpaw_view_demo "AmberPawViewDemo" SOURCES ${REDPAW_VIEW_SOURCES} ${AMBERPAW_VIEW_SOURCES}
    DEFINITIONS ORBITAMP_VIEW_DEMO_TITAN=1)
view_demo(walker_view_demo   "WalkerViewDemo"   SOURCES ${REDPAW_VIEW_SOURCES} ${REDGROOVE_VIEW_SOURCES}
    DEFINITIONS ORBITAMP_VIEW_DEMO_WALKER=1)

# The sea's CPU half against the prototype it was ported from: the start, five scripted flights, the
# gears, Saturn, the wipers' panes. JUCE-free, links only the world.
add_executable(titan_world_test tests/TitanWorldTests.cpp src/amberpaw/view/TitanWorld.cpp)
target_include_directories(titan_world_test PRIVATE src)
target_compile_features(titan_world_test PRIVATE cxx_std_20)

# The walker's world against its prototype, walker-world.js, to the last bit: the noise, the meshes, the forest,
# the walks at every gear free and on the beat, the bass, the steering, three dense clusters, the wrap — compared
# with the prototype's own dump (tests/fixtures/walker). JUCE-free, links only the world.
add_executable(walker_world_test tests/WalkerWorldTests.cpp src/redgroove/view/WalkerWorld.cpp)
target_include_directories(walker_world_test PRIVATE src)
target_compile_features(walker_world_test PRIVATE cxx_std_20)
target_compile_definitions(walker_world_test PRIVATE
    WALKER_FIXTURE="${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/walker/walker-world.txt")

# THE ROVER'S FACE IS WORN BY MORE THAN ONE PRODUCT (src/redpaw/RedPawSkin.h): what every rover is made
# of is said once here — the renders by the file names the face asks for, as bake-art made them, the
# sources, the libraries — and each product adds its own skin's file and its own renders. The lamps a
# dashboard paints lit, cut out of it, are a rover's own too: there where its picture paints them.
set(ROVER_RENDERS
    dashboard.webp midi.txt mark.svg knob-drive.webp knob-tone.webp socket.webp key-frame-left.webp
    key-frame-cell.webp key-frame-right.webp lever.webp lever-glow.webp
    slider-cap.webp fader-cap.webp fader-cap-light.webp toggle-up.webp toggle-down.webp key-up.webp
    key-down.webp turbo-up.webp turbo-down.webp)
set(ROVER_LAMPS lamp-0.webp lamp-1.webp lamp-2.webp lamp-3.webp)

set(REDPAWAMP_RENDERS ${ROVER_RENDERS} ${ROVER_LAMPS})     # ...and its lamps
list(TRANSFORM REDPAWAMP_RENDERS PREPEND "${CMAKE_CURRENT_SOURCE_DIR}/resources/redpaw/")
# ...and the STILL it ships, one frame of its world, where there is one: never another rover's.
file(GLOB REDPAWAMP_STILL CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/resources/redpaw/still.jpg")
list(APPEND REDPAWAMP_RENDERS ${REDPAWAMP_STILL})

# Every other rover's renders are in resources/<face>, under the rover's names; one that is not there
# yet is RedPawAmp's. So a render of its own is a file dropped in there and nothing more: the folder is
# looked at again on every build. ...and renders a rover may carry or not — the maker's mark raised in
# its own metal, instead of engraved: there when the file is, and nothing in its place when it is not.
# Never RedPawAmp's: its rust on frosted steel would be a patch.
function(rover_renders out face)
    set(folder "${CMAKE_CURRENT_SOURCE_DIR}/resources/${face}")
    file(GLOB own CONFIGURE_DEPENDS "${folder}/*")
    set(renders "")
    foreach(render IN LISTS ROVER_RENDERS)
        if("${folder}/${render}" IN_LIST own)
            list(APPEND renders "${folder}/${render}")
        else()
            list(APPEND renders "${CMAKE_CURRENT_SOURCE_DIR}/resources/redpaw/${render}")
        endif()
    endforeach()
    foreach(render IN ITEMS emblem.webp still.jpg ${ROVER_LAMPS})
        if("${folder}/${render}" IN_LIST own)
            list(APPEND renders "${folder}/${render}")
        endif()
    endforeach()
    set(${out} "${renders}" PARENT_SCOPE)
endfunction()
rover_renders(FROSTPAWAMP_RENDERS frostpaw)
rover_renders(AMBERPAWAMP_RENDERS amberpaw)

# What a rover is made of — for the plug-in and for its gates, which are the rover compiled again
# under a main() of their own — before its skin and its world.
set(ROVER_SOURCES
    ${FACE_SOURCES}
    src/redpaw/RedPawArt.cpp
    src/redpaw/RedPawControls.cpp
    src/redpaw/RedPawLineup.cpp
    src/redpaw/RedPawEditor.cpp
    ${REDPAW_VIEW_SOURCES})
set(ROVER_LIBRARIES
    OrbitAmpData
    OrbitAmpShaders                  # the windscreens' shaders
    ${AMP_ENGINE_LIBRARIES}
    juce::juce_opengl)               # the windscreen, on the GPU

# THE WALKER'S FACE (src/redgroove): the family's console on the walker's dashboard under its glass dome. Its
# renders by the file names the face asks for, from resources/redgroove; a render it has not drawn yet is the
# helicopter's, from resources/amberpaw, until its own is dropped in — the folder is looked at again on every
# build. Its still is its own or none: never another face's world.
set(REDGROOVEBASS_RENDERS "")
file(GLOB redgroove_own CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/resources/redgroove/*")
foreach(render IN ITEMS dashboard.webp mark.svg midi.txt knob-drive.webp knob-tone.webp fader-cap.webp)
    if("${CMAKE_CURRENT_SOURCE_DIR}/resources/redgroove/${render}" IN_LIST redgroove_own)
        list(APPEND REDGROOVEBASS_RENDERS "${CMAKE_CURRENT_SOURCE_DIR}/resources/redgroove/${render}")
    else()
        list(APPEND REDGROOVEBASS_RENDERS "${CMAKE_CURRENT_SOURCE_DIR}/resources/amberpaw/${render}")
    endif()
endforeach()
if("${CMAKE_CURRENT_SOURCE_DIR}/resources/redgroove/still.jpg" IN_LIST redgroove_own)
    list(APPEND REDGROOVEBASS_RENDERS "${CMAKE_CURRENT_SOURCE_DIR}/resources/redgroove/still.jpg")
endif()
set(REDGROOVEBASS_SOURCES
    ${FACE_SOURCES}
    src/redgroove/RedGrooveArt.cpp
    src/redgroove/RedGrooveControls.cpp
    src/redgroove/RedGrooveEditor.cpp
    src/redgroove/RedGrooveLineup.cpp
    src/ui/CabWindow.cpp             # the bass's cabinets, drawn — OrbitBass's window, Ampeg's pile
    ${REDPAW_VIEW_SOURCES}           # the windscreen the rovers look through ...
    ${REDGROOVE_VIEW_SOURCES})       # ... looking out on the walker's forest

# ----------------------------------------------------------------------------
# THE AMPS — the family's table, one row an amp (THE FAMILY says what a row says).
#
# The amps are RELEASED TOGETHER, as Darwin's Cat Amps: one version, the project's, and one tag, vX.Y.Z,
# for every amp installer/family.ini names (.github/workflows/release.yml). Until 0.8.0 the cockpit had a
# version and tags of its own, catpit-vX.Y.Z; from 0.8.0 on every amp's update check reads the family's.
# ----------------------------------------------------------------------------

# OrbitAmp — the player of the whole library, and the default build. It plays THE SET whole — in a release
# but the packs of an amp the release leaves out (ORBITAMP_PLAYS, above) — and the whole cabinet shelf.
add_amp(OrbitAmp      CODE Oamp
    SOURCES   ${ORBITAMP_SOURCES}
    LIBRARIES
        OrbitAmpData                 # the mark, the notice, the disclaimer — BinaryData::*
        ${AMP_ENGINE_LIBRARIES}
    SET       ${ORBITAMP_PLAYS}
    WHOLE_SHELF)

# CatpitAmp — the cockpit. Out of the tree's set it plays what its four channels play: the X88-IR's four
# packs — a channel finds its own by the capture it holds, not by the file's name. The cabinets CAB steps
# through are Darwin's Cat's own of the family's shelf. All of it lies in the factory folder, under the
# cockpit's own list there (src/channels/Set.h); without it, the cockpit would play only what the player
# puts in the Devices folder.
add_amp(CatpitAmp     CODE Ctpt    BY_NAME
    ART       ${CATPITAMP_RENDERS}
    SOURCES   ${CATPITAMP_SOURCES}
    LIBRARIES
        OrbitAmpData
        OrbitAmpShaders              # the sky's shaders
        ${AMP_ENGINE_LIBRARIES}
        juce::juce_opengl            # the sky, on the GPU
    SET       ${CATPITAMP_SET})

# RedPawAmp — the rover: a third face over the same processor (src/redpaw), the dashboard of a Mars rover
# with the drive across Mars in its windscreen. Four channels — the Friedman IR-X's two, each with its
# Boost off and on — picked as two gears and TURBO. Built like the cockpit: the family's console over the
# family's channels, its own renders in resources/redpaw, and its own set — the packs its channels play,
# the IR-X's two, each found by the capture it holds.
add_amp(RedPawAmp     CODE Rdpw    BY_NAME
    ART       ${REDPAWAMP_RENDERS}
    SOURCES   ${ROVER_SOURCES} src/redpaw/RedPawSkin.cpp
    LIBRARIES ${ROVER_LIBRARIES}
    SET       ${REDPAWAMP_SET})

# FrostPawAmp — the ice moon's rover: a fourth face over the same processor, RedPawAmp's dashboard worn
# over a picture of its own (src/frostpaw/FrostPawSkin.cpp) — frosted stainless steel, amber lamps,
# ice-blue rings. The same controls, the gears and TURBO: the rover's, shared, not copied — over channels of
# its own, six on the ReVolt Guitar's three packs in three gears, and the rovers' cabinets; its set under
# its own list in the family's folder (src/channels/Set.h), where a file another product plays too is one
# file. In the family's release from 0.9.0 (installer/family.ini).
add_amp(FrostPawAmp   CODE Frpw    BY_NAME
    ART       ${FROSTPAWAMP_RENDERS}
    SOURCES   ${ROVER_SOURCES} ${FROSTPAW_VIEW_SOURCES} src/frostpaw/FrostPawSkin.cpp
    LIBRARIES ${ROVER_LIBRARIES}
    SET       ${FROSTPAWAMP_SET})

# AmberPawAmp — a helicopter over Titan's methane sea: a fifth face over the same processor, the rovers'
# dashboard worn over a cockpit of its own (src/amberpaw/AmberPawSkin.cpp) — dark gunmetal under a canopy
# of three panes, its tuner a gauge, its meters dots — and out of its canopy, the flight over the sea.
# The same controls, the gears and TURBO: the rovers', shared, not copied — over the V4's six channels in three
# gears, the V4's six packs until it has captures of its own, and the rovers' cabinets. Not in
# the family's release yet (installer/family.ini).
add_amp(AmberPawAmp   CODE Ambp    BY_NAME
    ART       ${AMBERPAWAMP_RENDERS}
    SOURCES   ${ROVER_SOURCES} ${AMBERPAW_VIEW_SOURCES} src/amberpaw/AmberPawSkin.cpp
    LIBRARIES ${ROVER_LIBRARIES}
    SET       ${AMBERPAWAMP_SET})

# OrbitBass — the bass's workstation: OrbitAmp's frame and blocks over the bass's chain (src/Product.h,
# Chain::bass) — mono, no delay, no reverb. It plays bass packs alone, ORBITBASS_SET's, and the bass's cabinets
# alone (BASS), which the catalog has none of yet: no guitar cabinet, and the player's own out of `Bass IRs`
# (device/IrLibrary.h). Not in the family's release (installer/family.ini), and asked for by name. Its icon its own
# (the owner, 02.11): OrbitAmp's orbit doubled, a second ring inside it.
add_amp(OrbitBass     CODE Obas    BY_NAME    BASS
    SOURCES   ${ORBITBASS_SOURCES}
    LIBRARIES
        OrbitAmpData                 # the mark, the notice, the disclaimer — BinaryData::*
        ${AMP_ENGINE_LIBRARIES}
    SET       ${ORBITBASS_SET})

# RedGrooveBass — the walker: a bass amp in a cabin, the walker's glass dome over a glowing mushroom forest
# (src/redgroove) — the family's console over the bass's chain (Chain::bass), driven as channels: two, B15 and
# SVT, its two gears, over REDGROOVEBASS_SET's packs; Darwin's Cat's own cabinets. Not in the family's release
# (installer/family.ini), and asked for by name.
add_amp(RedGrooveBass CODE Rgrv    BY_NAME    BASS
    ART       ${REDGROOVEBASS_RENDERS}
    SOURCES   ${REDGROOVEBASS_SOURCES}
    LIBRARIES
        OrbitAmpData                 # the family's mark, the notice, the disclaimer — BinaryData::*
        OrbitAmpShaders              # the dome's shaders
        ${AMP_ENGINE_LIBRARIES}
        juce::juce_opengl            # the dome, on the GPU
    SET       ${REDGROOVEBASS_SET})

# ----------------------------------------------------------------------------
# THE FACES' GATES — in the gates binary, with every other (THE GATES BINARY, below); amp_console builds an amp
# again under a main() of its own, for what is not a gate.
# ----------------------------------------------------------------------------
# The cockpit's memory probe — not a gate, a measuring instrument: what the cockpit holds with its
# window built, and with it SHUT, which is the figure that matters in a host and the one the
# standalone cannot give.
amp_console(catpitamp_memory_probe  "CatpitAmpMemoryProbe"  CatpitAmp  tests/MemoryProbe.cpp)
# The bass's click probe — not a gate either: a DI take through OrbitBass, left alone and then its switches flipped,
# and every jump in the output and every block over its budget read out (tests/ClickProbe.cpp).
amp_console(orbitbass_click_probe   "OrbitBassClickProbe"   OrbitBass  tests/ClickProbe.cpp)
target_compile_definitions(orbitbass_click_probe PRIVATE JUCE_MODAL_LOOPS_PERMITTED=1)

# THE FAMILY'S SOURCES: every amp's, each once, and their libraries — what a plug-in of several amps is made
# of (THE FAMILY'S PLUG-INS), and the gates binary with it (below). An amp that defined something under a name
# another defines too would not link.
set(family_sources "")
set(family_libraries "")
foreach(amp IN LISTS AMPS)
    get_target_property(sources ${amp} AMP_SOURCES)
    get_target_property(libraries ${amp} AMP_LIBRARIES)
    list(APPEND family_sources ${sources})
    list(APPEND family_libraries ${libraries})
endforeach()
list(REMOVE_DUPLICATES family_sources)
list(REMOVE_DUPLICATES family_libraries)
list(REMOVE_ITEM family_libraries juce::juce_recommended_lto_flags)    # a gate links in seconds, not minutes

# ----------------------------------------------------------------------------
# THE GATES BINARY: most gates of tests/gates.txt are ONE program, orbitamp_gates, run one gate at a time —
# `orbitamp_gates <gate>`, or with ORBITAMP_GATE=<gate> in its environment, as tools/run-gates.sh runs it (THE
# GATES, below, says so for every gate the list gives it). They were a program each, and each compiled JUCE
# and the amps' sources again: 29 programs, 867 compiles of 100 files. Here the family's sources and JUCE are
# compiled once, and each gate adds its own file — compiled once for every amp it runs as, under a main() of
# its own name (tests/GateMain.h), with what it is told said at the head of a file the build writes for it,
# <build>/gates-src/<gate>.cpp; tests/Gates.cpp runs the one asked for.
#
#   gate_in_binary(<gate> <file> [PRODUCT <Amp>] [CHANNELS <n>] [NO_FACTORY | MACHINE_FACTORY] [DEFINES <NAME=value>...])
#
#   PRODUCT     runs it as that amp: ORBITAMP_PRODUCT_NAME, and ORBITAMP_GATE_PRODUCT — orbitamp::products::<name>
#               with its first letter small (src/Product.h)
#   CHANNELS    how many channels it holds the amp to (GATE_CHANNELS), said apart from the amp's lineup
#   NO_FACTORY  it reads a factory folder that is not there
#   MACHINE_FACTORY
#               it reads the machine's, where the installer lays it, as an amp does — as the gates that were
#               never told a folder did when each was a program of its own. Every other gate reads the
#               build's own (src/device/FactorySet.h, ORBITAMP_GATES_BINARY).
#   DEFINES     whatever else its file is told
#
# Nothing a gate's file says may be one definition the linker keeps for all of them — a file compiled for
# several amps keeps what reads the amp in an anonymous namespace (tests/AmpGate.h does).
#
# Apart, each a program of its own still: the chain's gate, which counts every allocation of the process with
# an operator new of its own, which would be every gate's here; the hum's, built with HUM switched on, which no
# amp ships (src/Features.h) — one program cannot hold the processor built both ways; and the gates with no
# JUCE in them (eqlink, tuner, gatelearn, titan-world), which cost nothing kept apart.
# ----------------------------------------------------------------------------
set(ORBITAMP_GATES_SRC "${CMAKE_BINARY_DIR}/gates-src")
set_property(GLOBAL PROPERTY ORBITAMP_GATES_IN_BINARY "")
set_property(GLOBAL PROPERTY ORBITAMP_GATES_FILES "")
set_property(GLOBAL PROPERTY ORBITAMP_GATES_TABLE "")

function(gate_in_binary gate file)
    cmake_parse_arguments(PARSE_ARGV 2 GATE "NO_FACTORY;MACHINE_FACTORY" "PRODUCT;CHANNELS" "DEFINES")
    get_property(held GLOBAL PROPERTY ORBITAMP_GATES_IN_BINARY)
    if(gate IN_LIST held)
        message(FATAL_ERROR "gate_in_binary: ${gate} is in the gates binary twice")
    endif()
    string(MAKE_C_IDENTIFIER "${gate}" id)
    set(text "// The gate ${gate} (tests/gates.txt) in the gates binary — written by the build (CMakeLists.txt:\n// THE GATES BINARY), never by hand.\n")
    if(GATE_PRODUCT)
        string(SUBSTRING "${GATE_PRODUCT}" 0 1 first)
        string(SUBSTRING "${GATE_PRODUCT}" 1 -1 rest)
        string(TOLOWER "${first}" first)
        string(APPEND text "#define ORBITAMP_PRODUCT_NAME \"${GATE_PRODUCT}\"\n"
                           "#define ORBITAMP_GATE_PRODUCT orbitamp::products::${first}${rest}\n")
    endif()
    if(GATE_CHANNELS)
        string(APPEND text "#define GATE_CHANNELS ${GATE_CHANNELS}\n")
    endif()
    foreach(define IN LISTS GATE_DEFINES)
        if(NOT define MATCHES "^([A-Za-z_][A-Za-z0-9_]*)=(.*)$")
            message(FATAL_ERROR "gate_in_binary: ${gate}'s \"${define}\" is no NAME=value")
        endif()
        string(APPEND text "#define ${CMAKE_MATCH_1} ${CMAKE_MATCH_2}\n")
    endforeach()
    string(APPEND text "#define ORBITAMP_GATE_MAIN orbitamp_gate_${id}\n"
                       "#include \"${CMAKE_CURRENT_SOURCE_DIR}/${file}\"\n")
    file(CONFIGURE OUTPUT "${ORBITAMP_GATES_SRC}/${id}.cpp" CONTENT "${text}" @ONLY)   # written again only when it changes
    if(GATE_NO_FACTORY)
        set(factory GateFactory::none)
    elseif(GATE_MACHINE_FACTORY)
        set(factory GateFactory::machine)
    else()
        set(factory GateFactory::build)
    endif()
    set_property(GLOBAL APPEND PROPERTY ORBITAMP_GATES_IN_BINARY "${gate}")
    set_property(GLOBAL APPEND PROPERTY ORBITAMP_GATES_FILES "${ORBITAMP_GATES_SRC}/${id}.cpp")
    set_property(GLOBAL APPEND PROPERTY ORBITAMP_GATES_TABLE "${gate}|${id}|${factory}")
endfunction()

# The family as one program: all five side by side in one process, each a processor of its own Product, two of
# them at once — each its own name, its own list in the factory folder, its own channels and settings.
gate_in_binary(family            tests/FamilyTests.cpp)
# The input's level: unity at every amp's input control, the pack's own level feeding the model, and a cockpit's
# or a rover's state of 0.8.0's, absolute, feeding it and gating as it did.
gate_in_binary(input-level       tests/InputLevelTests.cpp)
# The boost's level: while an amp's boost is on — OrbitAmp's BOOST key, the rovers' TURBO, the cockpit's TURBO
# push — the amp leaves that much louder, ramped, exactly, ahead of the limiter; with it off not at all.
gate_in_binary(boost-level       tests/BoostLevelTests.cpp)

# AN AMP'S GATES, the same two for the cockpit and every rover, run as that amp — what tells one amp from
# another, the gates read in tests/AmpGate.h. Its channels with no window at all — as many as CHANNELS says,
# each with its own memory and what it opens on, moved by CHANNEL the way a host moves it; the rover's gears and
# the Boost each holds, the cockpit's DRIVE on its dial — and its set as the build lays it out in the factory
# folder, under its own list, whole and nothing else.
gate_in_binary(catpit-channel    tests/AmpChannelTests.cpp  PRODUCT CatpitAmp    CHANNELS 4)
gate_in_binary(catpit-set        tests/AmpSetTests.cpp      PRODUCT CatpitAmp    CHANNELS 4)
gate_in_binary(redpaw-channel    tests/AmpChannelTests.cpp  PRODUCT RedPawAmp    CHANNELS 4)
gate_in_binary(redpaw-set        tests/AmpSetTests.cpp      PRODUCT RedPawAmp    CHANNELS 4)
gate_in_binary(frostpaw-channel  tests/AmpChannelTests.cpp  PRODUCT FrostPawAmp  CHANNELS 6)
gate_in_binary(frostpaw-set      tests/AmpSetTests.cpp      PRODUCT FrostPawAmp  CHANNELS 6)
gate_in_binary(amberpaw-channel  tests/AmpChannelTests.cpp  PRODUCT AmberPawAmp  CHANNELS 6)
gate_in_binary(amberpaw-set      tests/AmpSetTests.cpp      PRODUCT AmberPawAmp  CHANNELS 6)
gate_in_binary(redgroove-channel tests/AmpChannelTests.cpp  PRODUCT RedGrooveBass CHANNELS 2)
gate_in_binary(redgroove-set     tests/AmpSetTests.cpp      PRODUCT RedGrooveBass CHANNELS 2)
# ...and the walker's face, its window made and never shown: what its own controls turn, and the tone left alone.
gate_in_binary(redgroove-face    tests/RedGrooveFaceTests.cpp PRODUCT RedGrooveBass)

# ORBITBASS'S CHAIN, headless: where a fresh one stands (the gate off, the HPF on at 25 Hz, the LPF off, mono,
# its one temporary pack), the strip's arrows in its order (GATE, AMP, CAB, LIMIT), the delay and the reverb
# out of its sound whatever their switches say, one signal to both outputs, OrbitAmp's links in OrbitAmp's
# order less those two, and its tuner down to 25 Hz while every guitar amp's stays at 40.
gate_in_binary(orbitbass         tests/OrbitBassTests.cpp   PRODUCT OrbitBass
               DEFINES "ORBITBASS_STEP2B=\"${CMAKE_CURRENT_SOURCE_DIR}/tests/golden/orbitbass-step2b.f32\"")

# AN AMP WITH NO FACTORY FOLDER — copied off a zip without it, or the folder deleted: it plays, and says where
# the folder belongs instead of opening an empty face (src/ui/FactoryMissing.h). OrbitAmp, the cockpit and the
# rovers' dashboard, which FrostPawAmp and AmberPawAmp wear too.
gate_in_binary(nofactory         tests/NoFactoryTests.cpp   PRODUCT OrbitAmp     NO_FACTORY)
gate_in_binary(catpit-nofactory  tests/NoFactoryTests.cpp   PRODUCT CatpitAmp    NO_FACTORY)
gate_in_binary(redpaw-nofactory  tests/NoFactoryTests.cpp   PRODUCT RedPawAmp    NO_FACTORY)
gate_in_binary(redgroove-nofactory tests/NoFactoryTests.cpp  PRODUCT RedGrooveBass NO_FACTORY)

# ORBITAMP'S FACE AS THE SITE GETS IT (src/ui/WebFaceplate.h): a fresh OrbitAmp writes the kit, and the kit
# builds the face back — its own format, every place on the stage, the hull the poster less its places.
gate_in_binary(webface           tests/WebFaceTests.cpp     PRODUCT OrbitAmp)

# HUM SWITCHED OFF (src/Features.h), the processor built as every amp ships it: with the machine's settings on
# AUTO — as a machine that chose AUTO before keeps them — the stage is never prepared and never runs, the mode
# in force is OFF with no LEARN, and a hummed input passes bit for bit. The same file as the hum's own gate
# (orbitamp_hum_test, below), which runs only this part of itself when the switch is off.
gate_in_binary(hum-off           tests/HumTests.cpp)

# Reading an .orbitrig pack and playing it through the block the plug-in plays it with — every pack the build
# lays out sounds, the dial mixes without a step, a linked position is fed softer, a tone knob of either form
# reaches the audio, and OURS parks the device's own. The build's packs, not the machine's: a CI runner has
# none installed, and there this gate checked nothing at all.
gate_in_binary(captured          tests/CapturedBlockTests.cpp)
# The library manager's FILE WORK — imports, zip unpacking, renames, and the guards that keep every destructive
# operation inside the library — in a temp folder, the set's manifests read in place.
gate_in_binary(library           tests/LibraryTests.cpp     MACHINE_FACTORY  DEFINES "ORBITAMP_SET_DIR=\"${ORBITAMP_SET_DIR}\"")
# OrbitAmp's set as the build lays it out in the factory folder — every pack OrbitAmp plays, under a name the
# device list tells apart, every pack of the tree's set (a release leaves the unreleased amps' packs out), and
# the whole cabinet shelf in its folders; the list it reads is the build's own, <build>/Factory/sets/OrbitAmp.txt.
gate_in_binary(set               tests/OrbitAmpSetTests.cpp
    DEFINES ORBITAMP_PLAYS_REVOLT=${FROSTPAWAMP_PACKS_IN_ORBITAMP} ORBITAMP_PLAYS_V4=${AMBERPAWAMP_PACKS_IN_ORBITAMP})
# The family's factory folder with more than one product reading it — two products of make-believe in one
# folder, each seeing what its own list names and nothing else. In a temp folder.
gate_in_binary(factory           tests/FactorySetTests.cpp  MACHINE_FACTORY  DEFINES "ORBITAMP_SET_DIR=\"${ORBITAMP_SET_DIR}\"")
# felitronics::reverb's AmpReverb, the room every amp plays.
gate_in_binary(reverb            tests/ReverbStageTests.cpp  MACHINE_FACTORY)
# The waveform picture's MEMORY — what it recorded must not be rewritten later.
gate_in_binary(ribbon            tests/WaveRibbonTests.cpp  MACHINE_FACTORY)
# The GPU's refusals, written down: the line a world sent to the CPU leaves in the family's log, and its cap.
gate_in_binary(gpu-log           tests/GpuLogTests.cpp  MACHINE_FACTORY)
# The pictures of a face's kit for the site: WebP, alpha only where there is a hole, the three sizes, sprites/.
gate_in_binary(web-images        tests/WebImagesTests.cpp  MACHINE_FACTORY)

get_property(gates_files GLOBAL PROPERTY ORBITAMP_GATES_FILES)
get_property(gates_table GLOBAL PROPERTY ORBITAMP_GATES_TABLE)
set(table "// The gates of the gates binary (CMakeLists.txt: THE GATES BINARY) — written by the build, never by hand.\n#pragma once\n\n")
set(rows "")
foreach(row IN LISTS gates_table)
    string(REPLACE "|" ";" row "${row}")
    list(GET row 0 gate)
    list(GET row 1 id)
    list(GET row 2 factory)
    string(APPEND table "int orbitamp_gate_${id}();\n")
    string(APPEND rows "    { \"${gate}\", &orbitamp_gate_${id}, ${factory} },\n")
endforeach()
string(APPEND table "\nenum class GateFactory { build, none, machine };\n\nstruct GateEntry\n{\n    const char* name;\n    int (*run)();\n    GateFactory factory;\n};\n\n"
                    "inline constexpr GateEntry gateTable[]\n{\n${rows}};\n")
file(CONFIGURE OUTPUT "${ORBITAMP_GATES_SRC}/GatesTable.h" CONTENT "${table}" @ONLY)

juce_add_console_app(orbitamp_gates PRODUCT_NAME "OrbitAmpGates")
set(gates_sources tests/Gates.cpp ${family_sources} ${gates_files}
    src/channels/Set.cpp src/shaders/GpuLog.cpp src/face/WebImages.cpp)
list(REMOVE_DUPLICATES gates_sources)
target_sources(orbitamp_gates PRIVATE ${gates_sources})
target_include_directories(orbitamp_gates PRIVATE src tests "${ORBITAMP_GENERATED_DIR}" "${ORBITAMP_GATES_SRC}")
add_dependencies(orbitamp_gates OrbitAmpVersionGen Family_Factory)
target_compile_definitions(orbitamp_gates PRIVATE
    ORBITAMP_VERSION="${ORBITAMP_FAMILY_VERSION}"
    ORBITAMP_GATES_BINARY=1
    JUCE_MODAL_LOOPS_PERMITTED=1     # a gate may run the message loop until what lands there has (a drawn cabinet)
    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 ${AMP_UNREAD_CODECS})
set_source_files_properties(tests/Gates.cpp PROPERTIES COMPILE_DEFINITIONS
    "ORBITAMP_GATES_FACTORY=\"${ORBITAMP_FACTORY_DIR}\";ORBITAMP_GATES_NO_FACTORY=\"${CMAKE_CURRENT_BINARY_DIR}/no-factory/Factory\"")
target_link_libraries(orbitamp_gates PRIVATE
    ${family_libraries}
    OrbitAmpCabinetCatalog           # the family's cabinet shelf, by the catalog's table
    felitronics::appkit_webp         # the site kit's pictures (web-images)
    juce::juce_recommended_config_flags
    juce::juce_recommended_warning_flags)
set_target_properties(orbitamp_gates PROPERTIES EXCLUDE_FROM_ALL TRUE)


# ----------------------------------------------------------------------------
# THE FAMILY'S RELEASE: `--target Family_All` builds what the family's installers pack — the family's
# plug-ins, ONE bundle per format that holds every amp installer/family.ini names (THE FAMILY'S PLUG-INS,
# below), each of those amps' Standalone, and the release's factory folder — so what is built for the
# release and what is packed are one list, said in one place (build-family-pkg.sh, darwinscat-amps.iss,
# build-family-linux.sh, build-family-zip.sh read nothing else). The file is read the way those read it, by
# its `amps=`, `bundle=` and `bundle_target=` lines, and is looked at again when it changes; a name there
# that is no amp here stops the configure, since an installer would go looking for what nothing builds.
# ----------------------------------------------------------------------------
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${FAMILY_INI}")   # FAMILY_INI: THE FAMILY A BUILD RELEASES

# One `key=value` line of family.ini, its value as the installers read it.
function(family_ini key out)
    file(STRINGS "${FAMILY_INI}" value REGEX "^${key}=")
    string(REGEX REPLACE "^${key}=" "" value "${value}")
    string(STRIP "${value}" value)
    set(${out} "${value}" PARENT_SCOPE)
endfunction()

family_ini(amps FAMILY_AMPS)
string(REGEX MATCHALL "[^ \t\r]+" FAMILY_AMPS "${FAMILY_AMPS}")
family_ini(bundle FAMILY_BUNDLE)
family_ini(bundle_target FAMILY_BUNDLE_TARGET)
family_ini(bundle_code FAMILY_BUNDLE_CODE)   # the bundle's own code and id, which no plug-in a host is shown carries
family_ini(bundle_id FAMILY_BUNDLE_ID)
if(NOT FAMILY_AMPS OR NOT FAMILY_BUNDLE OR NOT FAMILY_BUNDLE_TARGET OR NOT FAMILY_BUNDLE_CODE OR NOT FAMILY_BUNDLE_ID)
    message(FATAL_ERROR "${FAMILY_INI} names no amps, bundle, bundle_target, bundle_code or bundle_id")
endif()
add_custom_target(Family_All)
foreach(amp IN LISTS FAMILY_AMPS)
    if(NOT amp IN_LIST AMPS)
        message(FATAL_ERROR "${FAMILY_INI} names ${amp}, which is no amp of this tree (${AMPS})")
    endif()
    add_dependencies(Family_All ${amp}_Standalone)
endforeach()
list(JOIN FAMILY_AMPS ", " family_amps_said)
message(STATUS "The family's release (Family_All): ${FAMILY_BUNDLE} (${FAMILY_BUNDLE_TARGET}) holding ${family_amps_said}, and their standalones")

# ----------------------------------------------------------------------------
# THE FAMILY'S PLUG-INS — ONE binary per format, "Darwin's Cat Amps" (family.ini's `bundle=`), built by the
# target family.ini names (`bundle_target=`, DarwinsCatAmps): every amp of the release in one VST3, one CLAP
# and, on the Mac, one AU, each under the ids its own bundle has always had — its VST3 classes made of the
# family's manufacturer code, Dcat, and its own CODE, its Audio Unit aufx/<CODE>/Dcat, and its CLAP id,
# com.darwinscat.<name> — so a session saved with an amp's own bundle opens it from the family's unchanged.
# The wrappers are patched to hold a list (cmake/PatchedWrappers.cmake). The binary's own code and CLAP id —
# family.ini's bundle_code and bundle_id, Dcam and com.darwinscat.amps; the basses' Dcbs and com.darwinscat.bass —
# name no plug-in a host is shown: the list names those.
#
# THE LIST IS WRITTEN HERE, at configure time, into <build>/generated/family: FamilyPluginList.h, what the
# wrappers read (JUCE_PLUGIN_LIST_HEADER) — each amp's name, its CODE, its CLAP id, and the categories and
# features every amp has (AMP_VST3_CATEGORIES, AMP_CLAP_FEATURES), in family.ini's order —
# FamilyProducts.h, the Product each entry is made with, orbitamp::products::<name> with its first letter
# small (src/Product.h), and the AU's Info.plist (THE AU'S COMPONENTS, below). All of them come from
# family.ini's `amps=` and each amp's row in THE AMPS, never from a second list kept by hand; a name with no
# Product does not compile. The binary's entry, createPluginFilter (const juce::PluginListEntry&), is
# src/FamilyPlugin.cpp.
#
# IT IS EVERY AMP'S OWN PLUG-IN, COMPILED ONCE: the sources of every amp of the release, each once, and their
# libraries — as the family's gate links them (EVERY AMP IN ONE BINARY) — built as add_amp builds an amp:
# the family's version, the same definitions, link-time optimisation, no codec an amp never reads, no local
# symbols in a release, and the build's factory folder first (ORBITAMP_DEV_FACTORY). No amp's own entry is
# compiled in (ORBITAMP_PLUGIN_ENTRY): the list's makes them all. Nor is ASIO: a plug-in opens no device.
#
# An amp's own VST3, AU and CLAP (add_amp) stay, for development — OrbitAmp's in the default build, every
# other amp's by name — and the release never builds them: it ships these and each amp's Standalone
# (Family_All), and a host that found an amp's own bundle beside the family's would see the amp twice, under
# one id. For the same reason the family's bundles are never copied into the user's plug-in folders after a
# build: ORBITAMP_COPY_PLUGIN copies an amp's own.
# ----------------------------------------------------------------------------
set(FAMILY_GENERATED_DIR "${ORBITAMP_GENERATED_DIR}/family")
list(JOIN AMP_VST3_CATEGORIES "|" family_categories)
set(family_features "")
foreach(feature IN LISTS AMP_CLAP_FEATURES)
    string(APPEND family_features "\"${feature}\", ")
endforeach()
set(family_entries "")
set(family_products "")
set(family_plugin_sources "")
set(family_plugin_libraries "")
foreach(amp IN LISTS FAMILY_AMPS)
    get_target_property(code ${amp} AMP_CODE)
    string(LENGTH "${code}" length)
    if(NOT length EQUAL 4)
        message(FATAL_ERROR "${amp}'s CODE, '${code}', is not four characters")
    endif()
    string(TOLOWER "${amp}" id)
    string(SUBSTRING "${amp}" 0 1 first)
    string(SUBSTRING "${amp}" 1 -1 rest)
    string(TOLOWER "${first}" first)
    string(APPEND family_entries
        "    { \"${amp}\", \"${code}\", \"com.darwinscat.${id}\", \"${family_categories}\", familyClapFeatures },\n")
    string(APPEND family_products "    { \"${code}\", &products::${first}${rest} },\n")

    get_target_property(sources ${amp} AMP_SOURCES)
    get_target_property(libraries ${amp} AMP_LIBRARIES)
    list(APPEND family_plugin_sources ${sources})
    list(APPEND family_plugin_libraries ${libraries})
endforeach()
list(REMOVE_DUPLICATES family_plugin_sources)
list(REMOVE_DUPLICATES family_plugin_libraries)

file(CONFIGURE OUTPUT "${FAMILY_GENERATED_DIR}/FamilyPluginList.h" @ONLY CONTENT [=[
// WRITTEN BY THE BUILD (CMakeLists.txt: THE FAMILY'S PLUG-INS) from installer/family.ini's `amps=` and each
// amp's row in THE AMPS — never edited. The plug-ins the family's one VST3, CLAP and AU hold, in the order
// hosts show them, each under its own ids (juce_PluginList.h, which the patched JUCE carries). Plain data,
// nothing of JUCE: the VST3 manifest helper compiles it too.
#pragma once

#include <juce_audio_plugin_client/juce_PluginList.h>

inline constexpr const char* familyClapFeatures[] { @family_features@nullptr };

inline constexpr juce::PluginListEntry jucePluginList[]
{
@family_entries@};
]=])

file(CONFIGURE OUTPUT "${FAMILY_GENERATED_DIR}/FamilyProducts.h" @ONLY CONTENT [=[
// WRITTEN BY THE BUILD (CMakeLists.txt: THE FAMILY'S PLUG-INS), beside FamilyPluginList.h and from the same
// rows — never edited. The Product each plug-in of the family's list is made with, by its code
// (src/FamilyPlugin.cpp); a name with no Product (src/Product.h) does not compile.
#pragma once

#include "Product.h"

namespace orbitamp::family
{
struct Plugin
{
    const char* code;
    const Product& (*product)();
};

inline constexpr Plugin plugins[]
{
@family_products@};
} // namespace orbitamp::family
]=])

# Its icon: the family's own, resources/icon/<bundle_target>-*.png, where there is one — and until there is,
# its first amp's, family.ini's first: what a bundle's own icon is shown as, and nothing a host lists.
list(GET FAMILY_AMPS 0 family_first)
foreach(stem IN ITEMS ${FAMILY_BUNDLE_TARGET} ${family_first})
    if(APPLE)
        set(family_icon "${CMAKE_CURRENT_SOURCE_DIR}/resources/icon/${stem}-macOS-1024.png")
    else()
        set(family_icon "${CMAKE_CURRENT_SOURCE_DIR}/resources/icon/${stem}-1024.png")
    endif()
    if(EXISTS "${family_icon}")
        break()
    endif()
endforeach()

juce_add_plugin(${FAMILY_BUNDLE_TARGET}
    VERSION                     "${ORBITAMP_FAMILY_VERSION}"
    PRODUCT_NAME                "${FAMILY_BUNDLE}"
    COMPANY_NAME                "Darwin's Cat"
    BUNDLE_ID                   "${FAMILY_BUNDLE_ID}"
    PLUGIN_MANUFACTURER_CODE    Dcat
    PLUGIN_CODE                 ${FAMILY_BUNDLE_CODE}
    FORMATS                     VST3 AU               # AU on the Mac alone, as an amp's own (add_amp)
    VST3_CATEGORIES             ${AMP_VST3_CATEGORIES}
    AU_MAIN_TYPE                "kAudioUnitType_Effect"
    IS_SYNTH                    FALSE
    NEEDS_MIDI_INPUT            FALSE
    NEEDS_MIDI_OUTPUT           FALSE
    IS_MIDI_EFFECT              FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    ICON_BIG                    "${family_icon}"
    COPY_PLUGIN_AFTER_BUILD     FALSE)

# The code every format links, a library no one ships, named without the bundle's apostrophe. JUCE calls
# it "<PRODUCT_NAME>_SharedCode", and the Visual Studio generator's MSBuild (VS 18's Microsoft.CppBuild
# targets) quotes a format's whole list of link inputs in single quotes inside a condition — where the
# apostrophe in "Darwin's Cat Amps" ends the string and stops the link of the VST3 and the CLAP
# (MSB4100). Ninja never quotes it, which is why the pull request's Windows build did not see it.
set_target_properties(${FAMILY_BUNDLE_TARGET} PROPERTIES OUTPUT_NAME "${FAMILY_BUNDLE_TARGET}_SharedCode")

clap_juce_extensions_plugin(TARGET ${FAMILY_BUNDLE_TARGET}
    CLAP_ID       "${FAMILY_BUNDLE_ID}"
    CLAP_FEATURES ${AMP_CLAP_FEATURES})

# The CLAP's icon, as an amp's own (add_amp): the wrapper's generic clap.icns overwritten with the bundle's.
if(APPLE)
    add_custom_command(TARGET ${FAMILY_BUNDLE_TARGET}_CLAP POST_BUILD
        COMMAND "${CMAKE_COMMAND}" -E copy
                "$<TARGET_PROPERTY:${FAMILY_BUNDLE_TARGET},JUCE_ICON_FILE>"
                "$<TARGET_BUNDLE_DIR:${FAMILY_BUNDLE_TARGET}_CLAP>/Contents/Resources/clap.icns"
        VERBATIM)
endif()

# THE AU'S COMPONENTS. A host finds an Audio Unit in its bundle's Info.plist, one AudioComponents entry per
# plug-in, before it loads the binary — and JUCE writes one entry, the binary's own (PLUGIN_CODE, named as
# the bundle). Here that entry is the pattern of one for every amp of the list, in family.ini's order: the
# amp's name in it, "<company>: <Amp>", as an amp's own build names its AU, its description, <Amp>, and its
# CODE as the subtype — and the rest as JUCE wrote it: the type, the manufacturer, the version, the resource
# usage, and the one factory function the binary exports for them all. So each is the entry the amp's own
# AU had, but for that function; the binary's own entry is gone, as its VST3 and CLAP name no plug-in of
# their own either. The patched wrapper makes the amp whose CODE is the subtype of the component a host
# opened. Written at configure time beside the list's headers, and the bundle's plist from then on.
if(TARGET ${FAMILY_BUNDLE_TARGET}_AU)
    get_target_property(family_au_juce_plist ${FAMILY_BUNDLE_TARGET}_AU MACOSX_BUNDLE_INFO_PLIST)
    get_target_property(family_au_code ${FAMILY_BUNDLE_TARGET} JUCE_PLUGIN_CODE)
    file(READ "${family_au_juce_plist}" family_au_plist)
    set(family_au_space "[ \t\r\n]*")

    # JUCE's AudioComponents: the key, the array's opening, its one entry and what closes it.
    string(FIND "${family_au_plist}" "<key>AudioComponents</key>" family_au_at)
    if(family_au_at LESS 0)
        message(FATAL_ERROR "JUCE wrote no AudioComponents into ${family_au_juce_plist}")
    endif()
    string(SUBSTRING "${family_au_plist}" ${family_au_at} -1 family_au_rest)
    string(FIND "${family_au_rest}" "</array>" family_au_length)
    string(SUBSTRING "${family_au_rest}" 0 ${family_au_length} family_au_components)
    string(CONCAT family_au_one "^(<key>AudioComponents</key>${family_au_space}<array>)"
                                "(${family_au_space})(<dict>.*</dict>)(${family_au_space})$")
    if(NOT family_au_components MATCHES "${family_au_one}")
        message(FATAL_ERROR "The AudioComponents JUCE wrote are not one entry: ${family_au_components}")
    endif()
    set(family_au_open "${CMAKE_MATCH_1}")
    set(family_au_indent "${CMAKE_MATCH_2}")
    set(family_au_pattern "${CMAKE_MATCH_3}")
    set(family_au_close "${CMAKE_MATCH_4}")

    # The pattern is the binary's own entry, named "<company>: <bundle>", or this reads JUCE wrong.
    set(family_au_name_at "(<key>name</key>${family_au_space}<string>)([^<]*)(</string>)")
    set(family_au_description_at "(<key>description</key>${family_au_space}<string>)([^<]*)(</string>)")
    set(family_au_subtype_at "(<key>subtype</key>${family_au_space}<string>)([^<]*)(</string>)")
    string(REGEX MATCH "${family_au_name_at}" ignored "${family_au_pattern}")
    set(family_au_name "${CMAKE_MATCH_2}")
    string(REGEX MATCH "${family_au_description_at}" ignored "${family_au_pattern}")
    set(family_au_description "${CMAKE_MATCH_2}")
    string(REGEX MATCH "${family_au_subtype_at}" ignored "${family_au_pattern}")
    set(family_au_subtype "${CMAKE_MATCH_2}")
    string(LENGTH "${family_au_name}" family_au_name_length)
    string(LENGTH "${FAMILY_BUNDLE}" family_au_bundle_length)
    math(EXPR family_au_prefix_length "${family_au_name_length} - ${family_au_bundle_length}")
    set(family_au_named "")
    if(family_au_prefix_length GREATER 0)
        string(SUBSTRING "${family_au_name}" 0 ${family_au_prefix_length} family_au_prefix)
        string(SUBSTRING "${family_au_name}" ${family_au_prefix_length} -1 family_au_named)
    endif()
    if(NOT family_au_named STREQUAL FAMILY_BUNDLE OR NOT family_au_description STREQUAL FAMILY_BUNDLE
       OR NOT family_au_subtype STREQUAL family_au_code)
        message(FATAL_ERROR "JUCE's AudioComponents entry is not the binary's own: ${family_au_pattern}")
    endif()

    # One entry per amp, from the list's rows.
    set(family_au_entries "")
    foreach(amp IN LISTS FAMILY_AMPS)
        get_target_property(code ${amp} AMP_CODE)
        set(entry "${family_au_pattern}")
        string(REGEX REPLACE "${family_au_name_at}" "\\1${family_au_prefix}${amp}\\3" entry "${entry}")
        string(REGEX REPLACE "${family_au_description_at}" "\\1${amp}\\3" entry "${entry}")
        string(REGEX REPLACE "${family_au_subtype_at}" "\\1${code}\\3" entry "${entry}")
        string(APPEND family_au_entries "${family_au_indent}${entry}")
    endforeach()

    string(LENGTH "${family_au_components}" family_au_length)
    math(EXPR family_au_after_at "${family_au_at} + ${family_au_length}")
    string(SUBSTRING "${family_au_plist}" 0 ${family_au_at} family_au_before)
    string(SUBSTRING "${family_au_plist}" ${family_au_after_at} -1 family_au_after)
    set(family_au_info "${FAMILY_GENERATED_DIR}/AU/Info.plist")
    file(WRITE "${family_au_info}"
        "${family_au_before}${family_au_open}${family_au_entries}${family_au_close}${family_au_after}")
    set_target_properties(${FAMILY_BUNDLE_TARGET}_AU PROPERTIES MACOSX_BUNDLE_INFO_PLIST "${family_au_info}")
endif()

target_sources(${FAMILY_BUNDLE_TARGET} PRIVATE src/FamilyPlugin.cpp ${family_plugin_sources})

# The list's header is the shared code's, PUBLIC like every definition here: the VST3 manifest helper is
# compiled with the shared code's definitions and include path, and reads the list to write moduleinfo.json.
# The products' header finds src/Product.h on the path too.
target_include_directories(${FAMILY_BUNDLE_TARGET} PUBLIC "${ORBITAMP_GENERATED_DIR}" "${FAMILY_GENERATED_DIR}")
target_include_directories(${FAMILY_BUNDLE_TARGET} PRIVATE src)
add_dependencies(${FAMILY_BUNDLE_TARGET} OrbitAmpVersionGen)
target_compile_definitions(${FAMILY_BUNDLE_TARGET} PUBLIC
    JUCE_PLUGIN_LIST_HEADER="FamilyPluginList.h"
    ORBITAMP_VERSION="${ORBITAMP_FAMILY_VERSION}"
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
    JUCE_DISPLAY_SPLASH_SCREEN=0
    ${AMP_UNREAD_CODECS})
target_link_libraries(${FAMILY_BUNDLE_TARGET} PRIVATE ${family_plugin_libraries})   # the LTO flags among them
add_dependencies(${FAMILY_BUNDLE_TARGET} Family_Factory)
if(ORBITAMP_DEV_FACTORY)
    target_compile_definitions(${FAMILY_BUNDLE_TARGET} PRIVATE ORBITAMP_DEV_FACTORY="${ORBITAMP_FACTORY_DIR}")
endif()
set(family_formats ${FAMILY_BUNDLE_TARGET}_VST3 ${FAMILY_BUNDLE_TARGET}_CLAP)
if(TARGET ${FAMILY_BUNDLE_TARGET}_AU)
    list(APPEND family_formats ${FAMILY_BUNDLE_TARGET}_AU)
endif()
strip_release(${family_formats})
export_entry_points_only(${family_formats})

# Faces are in it, so it is built by name, as they are: `--target DarwinsCatAmps_All` (VST3, CLAP and the
# Mac's AU), or with the rest of the release, Family_All.
set_target_properties(${FAMILY_BUNDLE_TARGET} ${family_formats} PROPERTIES EXCLUDE_FROM_ALL TRUE)
add_dependencies(${FAMILY_BUNDLE_TARGET}_All ${FAMILY_BUNDLE_TARGET}_CLAP)
add_dependencies(Family_All ${FAMILY_BUNDLE_TARGET}_All)

# THE FAMILY'S PLUG-INS AS A HOST OPENS THEM (tests/BundleHost.cpp): the VST3, the CLAP and, on the Mac, the AU
# beside the VST3 held to the ids each amp's own bundle shipped with, each amp its own in them, two and more
# alive at once — and, given a build where the amps' own VST3s were built, each held to its own. Not a gate:
# it opens built bundles, which no gate waits for; built by name, run by hand or by the CI after Family_All:
#
#   <build>/orbitamp_bundle_host_artefacts/Release/orbitamp_bundle_host \
#       "<build>/DarwinsCatAmps_artefacts/Release/VST3/Darwin's Cat Amps.vst3" \
#       "<build>/DarwinsCatAmps_artefacts/Release/CLAP/Darwin's Cat Amps.clap" [<build>]
string(JOIN " " family_amps_line ${FAMILY_AMPS})
set(bundle_host_au FALSE)
if(APPLE)
    set(bundle_host_au TRUE)   # JUCE's AU host, and the framework its views need
endif()
juce_add_console_app(orbitamp_bundle_host PRODUCT_NAME "OrbitAmpBundleHost" PLUGINHOST_AU ${bundle_host_au})
target_sources(orbitamp_bundle_host PRIVATE tests/BundleHost.cpp)
target_include_directories(orbitamp_bundle_host PRIVATE "${clap-juce-extensions_SOURCE_DIR}/clap-libs/clap/include")
target_compile_definitions(orbitamp_bundle_host PRIVATE
    ORBITAMP_VERSION="${ORBITAMP_FAMILY_VERSION}"
    ORBITAMP_FAMILY_AMPS="${family_amps_line}"
    ORBITAMP_FAMILY_CODE="${FAMILY_BUNDLE_CODE}"   # the bundle's own code, which no entry of its list carries
    JUCE_PLUGINHOST_VST3=1
    JUCE_MODAL_LOOPS_PERMITTED=1
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_DISPLAY_SPLASH_SCREEN=0)
target_link_libraries(orbitamp_bundle_host PRIVATE
    juce::juce_audio_processors
    juce::juce_recommended_config_flags)
set_target_properties(orbitamp_bundle_host PROPERTIES EXCLUDE_FROM_ALL TRUE)

# ...and the factory folder of every amp, and of the family's alone (THE FACTORY FOLDER).
family_factory()

# ----------------------------------------------------------------------------
# Headless acceptance gate for the EQ link. JUCE-free — it links only felitronics::eq, which is
# the point of keeping core::EqLink free of JUCE: the DSP is testable without a host, a GUI, or
# an audio device. Non-zero exit on any failure.
# ----------------------------------------------------------------------------
# Diagnostics, not gates: what the stage sees in packs, how hot the chain runs, and offline
# listening renders — the instruments that caught the fuzz.
function(orbitamp_probe target product main)
    juce_add_console_app(${target} PRODUCT_NAME "${product}")
    target_sources(${target} PRIVATE ${main})
    target_include_directories(${target} PRIVATE src)
    target_compile_definitions(${target} PRIVATE JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)
    target_link_libraries(${target} PRIVATE
        felitronics::lineareq felitronics::nam felitronics::rigplayer felitronics::limiter
        felitronics::delay felitronics::reverb   # Parameters.h names the delay's ladder and the room's characters from them
        OrbitAmpCabinetCatalog                   # ...and the cabinets from the catalog's table
        juce::juce_dsp juce::juce_events juce::juce_gui_basics juce::juce_audio_formats juce::juce_audio_processors
        juce::juce_recommended_config_flags juce::juce_recommended_warning_flags)
endfunction()
orbitamp_probe(orbitamp_pack_probe    "OrbitAmpPackProbe"    tests/PackProbe.cpp)
orbitamp_probe(orbitamp_render_probe  "OrbitAmpRenderProbe"  tests/RenderProbe.cpp)
orbitamp_probe(orbitamp_level_probe   "OrbitAmpLevelProbe"   tests/LevelProbe.cpp)

# The NAM bench — not a gate, a measuring instrument: ns/frame through the shipping stage.
add_executable(orbitamp_nam_bench tests/NamBench.cpp)
target_link_libraries(orbitamp_nam_bench PRIVATE felitronics::nam juce::juce_dsp juce::juce_core)
# WEB_BROWSER/CURL off like every other juce-linking gate: without it juce_core reaches for
# curl/curl.h, which a bare Linux CI runner does not have — the first Linux build found it.
target_compile_definitions(orbitamp_nam_bench PRIVATE JUCE_STANDALONE_APPLICATION=1
                                                       JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)

add_executable(orbitamp_eqlink_test tests/EqLinkTests.cpp)
target_include_directories(orbitamp_eqlink_test PRIVATE src)
target_link_libraries(orbitamp_eqlink_test PRIVATE felitronics::eq)
target_compile_features(orbitamp_eqlink_test PRIVATE cxx_std_20)

# Same gate for the tuner's ear, and JUCE-free for the same reason: signals with a KNOWN pitch go
# in, the cents error comes out — and the strobe's stripes. Links nothing but threads — core::PitchTracker,
# TunerEar and TunerStrobe are plain C++.
add_executable(orbitamp_tuner_test tests/TunerTests.cpp)
target_include_directories(orbitamp_tuner_test PRIVATE src)
target_compile_features(orbitamp_tuner_test PRIVATE cxx_std_20)
find_package(Threads REQUIRED)   # the strobe's tap is read while another thread laps it
target_link_libraries(orbitamp_tuner_test PRIVATE Threads::Threads)

# Same gate for the polyphonic tuner's analysis: synthetic strums with a KNOWN detune per string go
# in — every tuning, three rates, a muted string, one far off, mains hum, a single pluck — and each
# string's cents come out. core::PolyTuner is plain C++ too.
add_executable(orbitamp_polytuner_test tests/PolyTunerTests.cpp)
target_include_directories(orbitamp_polytuner_test PRIVATE src)
target_compile_features(orbitamp_polytuner_test PRIVATE cxx_std_20)

# ... and against strings that are NOT the analysis's model: partials off the formula, two planes of vibration,
# two-stage decay, the pick, a slow settle, mains hum to the 12th — every reading of the timer judged.
add_executable(orbitamp_polytuner_hard_test tests/PolyTunerHardTests.cpp)
target_include_directories(orbitamp_polytuner_hard_test PRIVATE src)
target_compile_features(orbitamp_polytuner_hard_test PRIVATE cxx_std_20)

# The tuner on a BASS, the same way: every string a bassist tunes, through the processor's own path
# (tap, 30 Hz ear, default floor and reference). A characterisation — it prints the tables and
# passes whatever they say; it fails only if the harness stops hearing a guitar's A2.
add_executable(orbitamp_bass_tuner_test tests/BassTunerTests.cpp)
target_include_directories(orbitamp_bass_tuner_test PRIVATE src)
target_compile_features(orbitamp_bass_tuner_test PRIVATE cxx_std_20)

# Same gate for the gate's LEARN: known traces in, the threshold out — and the arithmetic held to
# what OrbitAmp's GateConsole did before the faces came to share it. core::GateLearn is plain C++.
add_executable(orbitamp_gatelearn_test tests/GateLearnTests.cpp)
target_include_directories(orbitamp_gatelearn_test PRIVATE src)
target_compile_features(orbitamp_gatelearn_test PRIVATE cxx_std_20)

# ----------------------------------------------------------------------------
# Standalone code signing (macOS, dev loop).
#
# JUCE ad-hoc signs the app, and an ad-hoc signature is recomputed from the binary's contents — so
# every rebuild is a DIFFERENT app as far as macOS is concerned, and TCC cannot remember the
# microphone grant. Result: the permission dialog on every single launch.
#
# Signing with a stable Developer ID fixes that: the grant is keyed to the identity + bundle ID, so
# it is asked once and remembered across rebuilds. The plug-ins are untouched — they run inside a
# host, which owns the audio input.
#
# The identity is a PREFIX, not a full name: codesign resolves it against the login keychain, so no
# personal identity is baked into this public repo. If no Developer ID is installed (CI, a clean
# machine) the step is skipped and the ad-hoc build still works — it just keeps asking.
# ----------------------------------------------------------------------------
if(APPLE)
    set(ORBITAMP_SIGN_IDENTITY "Developer ID Application" CACHE STRING
        "codesign identity (prefix match) for the standalone; empty disables signing")

    if(ORBITAMP_SIGN_IDENTITY)
        execute_process(COMMAND security find-identity -v -p codesigning
                        OUTPUT_VARIABLE ORBITAMP_CODESIGN_IDS ERROR_QUIET)
        string(FIND "${ORBITAMP_CODESIGN_IDS}" "${ORBITAMP_SIGN_IDENTITY}" ORBITAMP_ID_FOUND)
    else()
        set(ORBITAMP_ID_FOUND -1)
    endif()

    if(ORBITAMP_ID_FOUND GREATER -1)
        message(STATUS "Standalone signing: '${ORBITAMP_SIGN_IDENTITY}' — the mic prompt is asked once, not per build")
        # --options runtime turns the hardened runtime on, which is what makes the entitlement
        # REQUIRED rather than advisory — the same posture a released build ships with.
        # --timestamp=none keeps the dev loop offline; notarization would need a real timestamp.
        # Every amp's standalone asks for the same microphone.
        foreach(amp IN LISTS AMPS)
            if(TARGET ${amp}_Standalone)
                add_custom_command(TARGET ${amp}_Standalone POST_BUILD
                    COMMAND codesign --force --options runtime --timestamp=none
                            --entitlements "${CMAKE_CURRENT_SOURCE_DIR}/installer/standalone.entitlements"
                            --sign "${ORBITAMP_SIGN_IDENTITY}"
                            "$<TARGET_BUNDLE_DIR:${amp}_Standalone>"
                    COMMENT "${amp}: signing the standalone so macOS remembers the mic grant"
                    VERBATIM)
            endif()
        endforeach()
    else()
        message(STATUS "Standalone signing: no '${ORBITAMP_SIGN_IDENTITY}' identity — staying ad-hoc (mic prompt every launch)")
    endif()

    # A REBUILD NEVER MOVES THE BUNDLE'S OWN DATE — only what is inside it changes — and that date is
    # what macOS keys its icon cache on. A bundle first built before it had an icon kept the blank
    # placeholder in the Dock and the app switcher for good, with the right icon sitting inside it.
    # So the bundle is touched after every build, and the system looks again.
    foreach(amp IN LISTS AMPS)
        if(TARGET ${amp}_Standalone)
            add_custom_command(TARGET ${amp}_Standalone POST_BUILD
                COMMAND ${CMAKE_COMMAND} -E touch_nocreate "$<TARGET_BUNDLE_DIR:${amp}_Standalone>"
                VERBATIM)
        endif()
    endforeach()
endif()

# ----------------------------------------------------------------------------
# Gate for the ASSEMBLED plugin: move a control, hear the output change. Links the plugin's own
# sources rather than a stage of it, because what this checks is the wiring between them.
# ----------------------------------------------------------------------------
juce_add_console_app(orbitamp_chain_test PRODUCT_NAME "OrbitAmpChainTest")
target_sources(orbitamp_chain_test PRIVATE tests/ChainTests.cpp ${ORBITAMP_SOURCES}   # it plays OrbitAmp with no first start
    src/OrbitBassStart.cpp)          # ...and OrbitBass, for its allocations
target_include_directories(orbitamp_chain_test PRIVATE src)
target_include_directories(orbitamp_chain_test PRIVATE "${ORBITAMP_GENERATED_DIR}")   # the same faces, the same stamp
add_dependencies(orbitamp_chain_test OrbitAmpVersionGen)
target_compile_definitions(orbitamp_chain_test PRIVATE ORBITAMP_VERSION="${PROJECT_VERSION}"
                                                      JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)
target_link_libraries(orbitamp_chain_test PRIVATE
    OrbitAmpData
    ${AMP_ENGINE_LIBRARIES}
    juce::juce_recommended_config_flags
    juce::juce_recommended_warning_flags)
gate_reads_factory(orbitamp_chain_test)   # OrbitAmp's whole shelf, and its packs: the gate plays every number of it

# ----------------------------------------------------------------------------
# Gate for the hum at the input, heard through the processor's own input path — the tuner's tap,
# which listens after the trim: AUTO takes a mains hum off; an INPUT trim moved mid-stream does not
# bring it back, because the stage sits ahead of the trim; OFF hands the input on bit for bit; and a
# demo loop with no hum in it passes untouched. Needs no pack: the input path is ahead of every block.
#
# HUM is switched off in every amp for now (src/Features.h), so the gate is built twice from the one
# file. This one throws the switch (ORBITAMP_FEATURE_HUM=1) and tests the stage, which has to stay ready
# for the day HUM comes back; the gates binary's hum-off (THE GATES BINARY) is built as the products are
# and holds the switch itself.
# ----------------------------------------------------------------------------
juce_add_console_app(orbitamp_hum_test PRODUCT_NAME "OrbitAmpHumTest")
target_sources(orbitamp_hum_test PRIVATE tests/HumTests.cpp ${ORBITAMP_SOURCES})       # ...and so does this one
target_include_directories(orbitamp_hum_test PRIVATE src)
target_include_directories(orbitamp_hum_test PRIVATE "${ORBITAMP_GENERATED_DIR}")
add_dependencies(orbitamp_hum_test OrbitAmpVersionGen)
target_compile_definitions(orbitamp_hum_test PRIVATE ORBITAMP_VERSION="${PROJECT_VERSION}"
                                                    ORBITAMP_FEATURE_HUM=1
                                                    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)
target_link_libraries(orbitamp_hum_test PRIVATE
    OrbitAmpData
    ${AMP_ENGINE_LIBRARIES}
    juce::juce_recommended_config_flags
    juce::juce_recommended_warning_flags)
gate_reads_factory(orbitamp_hum_test)     # OrbitAmp's processor, its whole shelf with it

# ----------------------------------------------------------------------------
# THE GATES — tests/gates.txt is the one list, read here the way tools/run-gates.sh reads it. Every target
# it names must be one (a gate nobody builds is a gate that never runs), and `--target Family_Gates` builds
# them all, the faces' too, which no other build asks for. What the runner needs to find each — its name,
# the binary as THIS build placed it, its environment — is written out per configuration, to
# <build>/gates/<config>.txt: no runner guesses where a generator put an executable. A gate the list skips
# on this system is left out of both.
# ----------------------------------------------------------------------------
set(GATES_TXT "${CMAKE_CURRENT_SOURCE_DIR}/tests/gates.txt")
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${GATES_TXT}")
if(APPLE)
    set(_gate_system macos)
elseif(WIN32)
    set(_gate_system windows)
else()
    set(_gate_system linux)
endif()
file(STRINGS "${GATES_TXT}" _gate_lines ENCODING UTF-8 REGEX "^[^#]")
add_custom_target(Family_Gates)
set(_gate_manifest "")
set(_gates_listed "")
foreach(line IN LISTS _gate_lines)
    string(REGEX MATCHALL "[^ \t\r]+" fields "${line}")
    list(LENGTH fields n)
    if(n EQUAL 0)
        continue()
    endif()
    if(n LESS 2)
        message(FATAL_ERROR "tests/gates.txt: \"${line}\" names no target")
    endif()
    list(GET fields 0 gate)
    list(GET fields 1 target)
    set(rest "")
    if(n GREATER 2)
        list(SUBLIST fields 2 -1 rest)
    endif()
    set(env "")
    set(skipped OFF)
    foreach(field IN LISTS rest)
        if(field MATCHES "^skip=(.*)$")
            string(REPLACE "," ";" systems "${CMAKE_MATCH_1}")
            if(_gate_system IN_LIST systems)
                set(skipped ON)
            endif()
        elseif(field MATCHES "^[A-Za-z_][A-Za-z0-9_]*=")
            list(APPEND env "${field}")
        else()
            message(FATAL_ERROR "tests/gates.txt: \"${field}\" in gate ${gate} is neither VAR=value nor skip=")
        endif()
    endforeach()
    if(NOT TARGET ${target})
        message(FATAL_ERROR "tests/gates.txt: gate ${gate} names ${target}, which is no target of this tree")
    endif()
    list(APPEND _gates_listed "${gate}")
    if(target STREQUAL "orbitamp_gates")   # THE GATES BINARY: it runs the gate its environment names
        get_property(held GLOBAL PROPERTY ORBITAMP_GATES_IN_BINARY)
        if(NOT gate IN_LIST held)
            message(FATAL_ERROR "tests/gates.txt: gate ${gate} names orbitamp_gates, which holds no ${gate} (gate_in_binary)")
        endif()
        list(APPEND env "ORBITAMP_GATE=${gate}")
    endif()
    if(skipped)
        message(STATUS "Gate ${gate} is skipped on ${_gate_system} (tests/gates.txt)")
        continue()
    endif()
    add_dependencies(Family_Gates ${target})
    # A GATE'S STACK IS THE ONE IT HAS ON A MAC AND ON LINUX, 8 MB: Windows gives a program 1 MB, and the gates keep
    # what they test on the stack — the tuner's strobe tests some 4 MB there (MSVC's /analyze) — so the tuner and
    # the chain gates died on MSVC's runners of a stack overflow (0xC00000FD), the chain before its first line.
    # The amps' own binaries keep Windows' default.
    if(MSVC)
        target_link_options(${target} PRIVATE /STACK:8388608)
    endif()
    list(JOIN env " " env)
    string(APPEND _gate_manifest "${gate}\t$<TARGET_FILE:${target}>\t${env}\n")
endforeach()
# ...and a gate the gates binary holds that the list does not name would never run.
get_property(held GLOBAL PROPERTY ORBITAMP_GATES_IN_BINARY)
foreach(gate IN LISTS held)
    if(NOT gate IN_LIST _gates_listed)
        message(FATAL_ERROR "the gates binary holds ${gate}, which tests/gates.txt does not name")
    endif()
endforeach()
# UNIX line ends on every system: on Windows CMake writes \r\n, bash's `read` keeps the \r on the last field,
# and the gates binary was asked for "captured\r" — a gate it does not hold.
file(GENERATE OUTPUT "${CMAKE_BINARY_DIR}/gates/$<CONFIG>.txt" CONTENT "${_gate_manifest}" NEWLINE_STYLE UNIX)
