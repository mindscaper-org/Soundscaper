// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "CabinetBlock.h"

#include "../PluginProcessor.h"
#include "../device/Cabinets.h"
#include "../device/IrLibrary.h"
#include "BassControls.h"
#include "CabWindow.h"
#include "Prefs.h"
#include "OnFirst.h"

namespace orbitamp
{

struct CabinetBlock::BassRow
{
    explicit BassRow (AmpProcessor& p) : di (*p.apvts.getParameter (params::cabMix), 0.0f, 100.0f) {}

    /** DI/CAB, A FADER as every BLEND and MIX on the bass's face (the owner, 01.11): its name over it, its percent under
        it, typed there, a double click its default, one undo step a drag. No switch of its own, as the AMP's BLEND: moved, it mixes
        and nothing else. */
    GuardRail di;

    void addTo (CabinetBlock& owner, AmpProcessor& p)
    {
        // The cuts are not here: the bass has ONE pair, on the AMP's switches (EqSection::setStandard). DI/CAB is the
        // cabinet's — with the cabinet out there is nothing to mix — and stands by with it.
        owner.addAndMakeVisible (di);
        bass::asBassFader (di, "MIX", [] (float v) { return juce::String (juce::roundToInt (v)) + "%"; });   // percent already
        bass::hint (di, "MIX: WET/DRY");
        di.onGesture = [&p] (bool begin) { if (begin) p.history.beginGesture(); else p.history.endGesture(); };
        di.onMenu    = [&owner] (juce::Point<int>) { if (owner.onBlockMenu != nullptr) owner.onBlockMenu(); };   // the CAB's menu
    }
};

CabinetBlock::CabinetBlock (AmpProcessor& processor)
    // CAB: what it plays is mostly its own cabinets, drawn, and an IR only when the player brings one — the bass's and,
    // since 08.11, the guitar's too.
    : BlockFrame ("Cab", BlockFrame::Kind::captured), amp (processor),
      cabs (device::Cabinets::of (processor.product().chain == Chain::bass ? device::CabKind::bass : device::CabKind::guitar))
{
    CabWindow::useOurLook();   // the miniature over the IR, in our theme
    // The panel draws this amp's builder's boxes — the sketch over the picture, the window (device/CabTables.h).
    device::drawCabinetsOf (processor.product().chain == Chain::bass ? device::CabKind::bass : device::CabKind::guitar);
    startTimerHz (30);
    attachPower (*amp.apvts.getParameter (params::cabOn));

    if (processor.product().chain == Chain::bass)
    {
        bassRow = std::make_unique<BassRow> (processor);
        bassRow->addTo (*this, processor);

    }

    // The IR's name on the border beside the block's, set like a name and in the block's colour.
    // The combo shows one entry — whatever plays — and opens a menu this block builds.
    ir.fontHeight = 16.0f;
    ir.tracking   = 0.15f;
    ir.boxed      = false;
    ir.tint       = theme::orange;
    addAndMakeVisible (ir);

    irAtt = std::make_unique<juce::ParameterAttachment> (
        *amp.apvts.getParameter (params::cabIr),
        [this] (float) { refreshIr (false, true); });

    // THE ONE LIST (the owner, 10.11; OrbitBass's as OrbitAmp's, 11.11): the twelve on their slider, the player's own IRs
    // after them on a slider of their own, and the same list on the name. No CABINETS, no window: the builder app edits
    // cabinets, and one made there comes here as an IR.
    {
        ir.opens = true;
        ir.onOpen = [this] { showIrMenu(); };
        slots.notches = (int) cabs.dozen().size();
        slots.notch = [this]
        {
            const int at = listAt();
            return at < (int) cabs.dozen().size() ? at : -1;
        };
        slots.onMove  = [this] (int i) { amp.requestCabSynth (cabs.dozen()[(size_t) i].state, true); };
        slots.onLetGo = [this] (int i) { pickAt (i); };
        addAndMakeVisible (slots);
        stepBack.by = -1;
        for (auto* s : { &stepBack, &stepOn })
        {
            s->onStep = [this] (int by) { stepList (false, by); };
            addAndMakeVisible (*s);
        }

        // The player's own IRs on a slider of their own over the twelve's, while there are any (lookAtLibrary). One heard
        // where the hand lets go: each read on the way would stay in the store.
        ownSlots.notch  = [this] { const int at = listAt() - (int) cabs.dozen().size(); return at >= 0 ? at : -1; };
        ownSlots.onLetGo = [this] (int i) { pickAt ((int) cabs.dozen().size() + i); };
        ownBack.by = -1;
        for (auto* s : { &ownBack, &ownOn })
            s->onStep = [this] (int by) { stepList (true, by); };
        for (juce::Component* c : { (juce::Component*) &ownSlots, (juce::Component*) &ownBack, (juce::Component*) &ownOn })
            addChildComponent (*c);
        lookAtLibrary();
    }

    // The picture: the IR, the cuts' curve and the trim's handle drawn on it, in the block's colour. Its line under it
    // short and its cabinet the box alone at its right (the owner, 10.11: Sketch::boxOnly).
    wave.shortMetrics = true;
    sketch.boxOnly = true;
    wave.setAccent (theme::orange);
    wave.waveTint = theme::violet;   // the impulse itself in violet — the curve keeps the orange voice
    // The handle exists only in MANUAL — pushToWave keeps this current with the combo's mode.
    wave.setEqVisible (true);

    // The spectra behind the impulse, in the consoles' own hand: what walks into the IR as the
    // ground, what leaves it as the line — the same liquid columns, the same tilt, one renderer.
    wave.paintSpectrumUnder = [this] (juce::Graphics& g, juce::Rectangle<float> r)
    {
        if (! prefs::spectraShown (amp.product()))
            return;

        felitronics::analysis::PlotMap pm;
        pm.width      = r.getWidth();
        pm.height     = r.getHeight();
        pm.plotBottom = r.getHeight();
        pm.freqMin    = 20.0;
        pm.freqMax    = 20000.0;
        pm.specTop    = 0.0;
        pm.specBottom = -90.0;

        const double fs = juce::jmax (8000.0, amp.currentSampleRate());

        const auto draw = [&] (felitronics::analysis::SpectrumPane& pane, juce::Colour tint,
                               float fillTop, float fillBottom, float line)
        {
            juce::Path fill, peak;
            fill.startNewSubPath (r.getX(), r.getBottom());
            bool first = true;

            pane.buildColumns (pm, fs, 4.5, 1000.0,
                               [&] (int, float x, float yFill, float yPeak)
                               {
                                   fill.lineTo (r.getX() + x, r.getY() + yFill);

                                   if (first) { peak.startNewSubPath (r.getX() + x, r.getY() + yPeak); first = false; }
                                   else       peak.lineTo (r.getX() + x, r.getY() + yPeak);
                               });

            fill.lineTo (r.getRight(), r.getBottom());
            fill.closeSubPath();

            g.setGradientFill (juce::ColourGradient (tint.withAlpha (fillTop),
                                                     0.0f, r.getY() + r.getHeight() * 0.30f,
                                                     tint.withAlpha (fillBottom),
                                                     0.0f, r.getBottom(), false));
            g.fillPath (fill);
            g.setColour (tint.withAlpha (line));
            g.strokePath (peak, juce::PathStrokeType (1.0f));
        };

        draw (panes[0], theme::spectrum, 0.14f, 0.02f, 0.30f);   // the door: the consoles' quiet ground
        draw (panes[1], theme::orange,   0.18f, 0.02f, 0.55f);   // the exit: the cabinet's own voice
    };

    addAndMakeVisible (wave);
    addAndMakeVisible (sketch);   // over the picture

    // A handle dragged on the picture writes its parameter; the parameter's echo redraws it.
    wave.onHpfChanged  = [this] (bool, float hz) { hpfHzAtt->setValueAsCompleteGesture (hz); };
    wave.onLpfChanged  = [this] (bool, float hz) { lpfHzAtt->setValueAsCompleteGesture (hz); };
    wave.onTrimChanged = [this] (float f)        { trimAtt->setValueAsCompleteGesture (f); };
    // The picture's right-click menu IS the trim combo's menu — one story, two doors.
    wave.onMenuRequested = [this]                { showTrimMenu(); };

    // The vertical half of a cut drag: the consoles' slope ladder, one notch per step.
    const auto stepSlope = [this] (const char* id, juce::ParameterAttachment& att, int steps)
    {
        auto* p = amp.apvts.getParameter (id);
        const int next = juce::jlimit (0, params::eqSlopes.size() - 1,
                                       juce::roundToInt (p->convertFrom0to1 (p->getValue())) + steps);
        att.setValueAsCompleteGesture ((float) next);
    };
    wave.onHpfSlopeStep = [this, stepSlope] (int n) { stepSlope (params::cabHpfSlope, *hpfSlopeAtt, n); };
    wave.onLpfSlopeStep = [this, stepSlope] (int n) { stepSlope (params::cabLpfSlope, *lpfSlopeAtt, n); };

    const auto follow = [this] (const char* id) -> std::unique_ptr<juce::ParameterAttachment>
    {
        return std::make_unique<juce::ParameterAttachment> (*amp.apvts.getParameter (id),
                                                            [this] (float) { pushToWave(); });
    };

    hpfHzAtt    = follow (params::cabHpfHz);
    lpfHzAtt    = follow (params::cabLpfHz);
    trimAtt     = follow (params::cabTrim);
    trimOnAtt   = follow (params::cabTrimOn);
    hpfSlopeAtt = follow (params::cabHpfSlope);
    lpfSlopeAtt = follow (params::cabLpfSlope);

    trimCombo.getText = [this]
    {
        switch (trimMode)
        {
            case TrimMode::fixed:  return "TRIM " + juce::String (juce::roundToInt (trimModeMs));
            case TrimMode::manual: return juce::String ("TRIM MAN");
            case TrimMode::off:
            default:               return juce::String ("TRIM OFF");
        }
    };
    trimCombo.onOpen = [this] { showTrimMenu(); };
    // The cabinets' doors stand in its row (the bass trims nothing; the guitar's trim is on the picture's right click).
    addChildComponent (trimCombo);

    // The switches, each the truth of its parameter and nothing of its own.
    const char* ids[]    = { params::cabHpfOn, params::cabLpfOn, params::cabPhase };
    const char* names[]  = { "HPF", "LPF", "\xc3\x98" };

    for (size_t i = 0; i < switches.size(); ++i)
    {
        auto& s = switches[i];
        // Each cut wears its line's colour, the consoles' grammar — orange HPF, violet LPF;
        // the trim and the phase stay the block's own orange.
        s.sw.accent = ids[i] == params::cabLpfOn ? theme::violet : theme::orange;

        // The two CUTS stand on the panel; the PHASE does not. A cut is worked — you turn it on
        // and then drag its corner along the curve — so its switch belongs where the curve is.
        // The phase is set once a session and left, and a permanent seat for it cost the trim its
        // air. It keeps its object (the parameter attachment lives here, and the menu flips it
        // through this switch); it simply never appears.
        if (i == 2) addChildComponent (s.sw);
        else        addAndMakeVisible  (s.sw);

        s.label.setText (juce::String::fromUTF8 (names[i]), juce::dontSendNotification);
        s.label.setFont (theme::displayFont (12.0f));
        s.label.setColour (juce::Label::textColourId, theme::txDim);
        s.label.setJustificationType (juce::Justification::centredLeft);
        s.label.setInterceptsMouseClicks (false, false);

        if (i == 2) addChildComponent (s.label);
        else        addAndMakeVisible  (s.label);

        s.att = std::make_unique<juce::ParameterAttachment> (
            *amp.apvts.getParameter (ids[i]),
            [this, i] (float v)
            {
                switches[i].sw.setOn (v > 0.5f, false);
                pushToWave();
            });

        s.sw.onChange = [this, i] (bool on) { switches[i].att->setValueAsCompleteGesture (on ? 1.0f : 0.0f); };
        s.att->sendInitialUpdate();
    }

    refreshIr (true);
    pushToWave();
}

CabinetBlock::~CabinetBlock() = default;

void CabinetBlock::refreshIr (bool force, bool keepTrimWord)
{
    const auto choice = amp.cabChoice();

    // The NAME is part of what is shown: two files with the same bytes are one sound and two names.
    if (! force && choice.identity() + "|" + choice.name == shownIr)
        return;

    shownIr = choice.identity() + "|" + choice.name;

    // ...and a number the product does not play (Product::playsCabIr) is no cabinet: a bass amp with none of
    // its own plays no IR at all, and says so rather than a guitar cabinet's name. One of the bass's cabinets says
    // the mics heard too (CabWindow::labelOf).
    const auto synth = AmpProcessor::cabSynthOf (choice);
    const bool factoryPlays = ! choice.isUser() && amp.product().playsCabIr (choice.factory);
    juce::String shown = choice.isUser() ? choice.name : factoryPlays ? juce::String (params::cabIrNames[choice.factory]) : juce::String (noIr);
    if (synth.valid)   // the dozen's by its number, a player's own by its name, else its box and its mics — the one picked
    {
        const auto own = savedCabinets();
        const auto named = nameOf (whichPlays (synth.state, own), own);
        shown = named.isNotEmpty() ? named : CabWindow::labelOf (synth);
    }
    slots.refresh();
    ownSlots.refresh();
    shownText = shown;
    ir.setEntries ({ { shown, 0, false } });
    ir.setSelection (0);

    // The sketch of the bass's cabinet over the IR says which plays, and where its mics stand; none for any other IR. The
    // window's picture follows the state on its own (CabWindow).
    {
        const auto [cab, setup] = CabWindow::drawnOf (synth);
        sketch.cab = cab;
        sketch.setup = setup;
        sketch.repaint();
    }

    // The same bytes the engine convolves, whichever shelf they came off.
    if (choice.isUser())
        wave.setFromMemory (choice.bytes->getData(), choice.bytes->getSize());
    else
    {
        const auto& bytes = AmpProcessor::cabIrBytes (amp.product(), choice.factory);
        wave.setFromMemory (bytes.data, (size_t) bytes.size);
    }

    // A fixed window keeps its WORD across an IR swap: the parameter is a fraction of the shot's
    // length, so 50 ms of the old cab is not 50 ms of the new — re-assert the milliseconds.
    // A shot too short to hold the window shows all of itself and keeps the word anyway — see the
    // STILL OURS test in `deriveTrimMode`, which is what makes that survive the swap.
    //
    // ONLY WHEN A PICK ASKS. A recall — a register, an undo, a preset — brings its own trim with it,
    // and an IR of the player's own arrives without a parameter to call anyone: the timer finds it
    // after the recall has landed, and a write from there would carry the OLD shot's milliseconds
    // over the recalled fraction, and leave an undo step nobody made.
    if (keepTrimWord && trimMode == TrimMode::fixed && wave.lengthMs() > 0.0)
        trimAtt->setValueAsCompleteGesture (
            (float) juce::jlimit (0.001, 1.0, trimModeMs / wave.lengthMs()));

    pushToWave();
    resized();   // the name on the border is as wide as the name
}

namespace
{
    int irsBeneath (const device::IrLibrary::Node& n)
    {
        if (! n.folder)
            return 1;

        int total = 0;
        for (const auto& c : n.children)
            total += irsBeneath (c);
        return total;
    }
}

void CabinetBlock::lookAtLibrary()
{
    // The player's own IRs after the twelve on the slider, as the library stands — looked at now and then, the player
    // adding them in SETUP, renaming them, moving them about.
    std::vector<juce::File> now;
    for (const auto& f : device::IrLibrary::listed (device::IrLibrary::directory (amp.product().irsFolder())))
        now.push_back (f);
    if (now == ownIrs)
        return;

    ownIrs = std::move (now);
    ownSlots.notches = (int) ownIrs.size();
    ownSlots.refresh();
    ownSlots.repaint();
    const bool any = ! ownIrs.empty();
    if (any != ownSlots.isVisible())
    {
        for (juce::Component* c : { (juce::Component*) &ownSlots, (juce::Component*) &ownBack, (juce::Component*) &ownOn })
            c->setVisible (any);
        resized();   // the row over the twelve's comes, or goes and gives the picture its height
    }
}

void CabinetBlock::Step::paint (juce::Graphics& g)
{
    // A small solid triangle pointing its way, dim, orange under the hand.
    const auto c = getLocalBounds().toFloat().getCentre();
    const float w = 5.0f, h = 4.5f;
    juce::Path t;
    const float d = (float) by * w * 0.5f;
    t.addTriangle (c.x + d, c.y, c.x - d, c.y - h, c.x - d, c.y + h);
    g.setColour (isMouseOver() ? theme::orange : theme::txDim);
    g.fillPath (t);
}

juce::PopupMenu CabinetBlock::irMenu (const AmpProcessor& amp, std::vector<juce::File>& files,
                                      std::vector<device::Cabinets::Cabinet>* saves)
{
    const auto choice  = amp.cabChoice();
    const auto library = device::IrLibrary::scan (device::IrLibrary::directory (amp.product().irsFolder()));
    const auto root    = library.file;

    const auto itemFor = [] (const juce::String& name, int id, bool ticked)
    {
        juce::PopupMenu::Item item (name);
        item.itemID   = id;
        item.colour   = theme::orange;
        item.isTicked = ticked;
        return item;
    };

    // THE TWELVE (the owner, 10.11; the bass's as the guitar's, 11.11): the TOP 12, or the bass's dozen, in place of the
    // shelf, the one that plays ticked.
    juce::PopupMenu menu;
    const auto& cabinets = device::Cabinets::of (amp.product().chain == Chain::bass ? device::CabKind::bass : device::CabKind::guitar);
    {
        const auto& twelve = cabinets.dozen();
        const auto synth = AmpProcessor::cabSynthOf (choice);
        const int plays = synth.valid ? cabinets.dozenOf (synth.state) : -1;
        for (int i = 0; i < (int) twelve.size(); ++i)
            menu.addItem (itemFor (twelve[(size_t) i].name, firstOfTwelve + i, i == plays));
    }

    // THE BUILDER'S (the owner, 11.11): its menu as the builder app opens it, but for DEFAULT, SAVE AS... and SHOW MY
    // PRESETS — its presets by style, by style then name, then MY PRESETS, what the player saved there, while there are
    // any. None of its typical cabinets, which its menu has not either; unticked, as the app's.
    {
        const auto& every = cabinets.all();
        std::vector<int> order;
        for (int i = 0; i < (int) every.size(); ++i)
            if (! every[(size_t) i].style.equalsIgnoreCase ("Typical"))
                order.push_back (i);
        std::sort (order.begin(), order.end(), [&every] (int a, int b)
        {
            const auto& x = every[(size_t) a];
            const auto& y = every[(size_t) b];
            return x.style != y.style ? x.style < y.style : x.name < y.name;
        });

        juce::PopupMenu builder, group;
        juce::String style;
        const auto flush = [&]
        {
            if (group.getNumItems() > 0)
                builder.addSubMenu (style.toUpperCase(), group);
            group = {};
        };
        for (const int i : order)
        {
            if (every[(size_t) i].style != style)
            {
                flush();
                style = every[(size_t) i].style;
            }
            group.addItem (itemFor (every[(size_t) i].name, firstOfBuilder + i, false));
        }
        flush();

        auto mine = cabinets.builderSaves();
        mine.resize (juce::jmin (mine.size(), (size_t) (firstFile - firstOfSaved)));
        if (! mine.empty())
        {
            builder.addSeparator();
            builder.addSectionHeader ("MY PRESETS");
            for (size_t i = 0; i < mine.size(); ++i)
                builder.addItem (itemFor (mine[i].name, firstOfSaved + (int) i, false));
        }
        if (saves != nullptr)
            *saves = std::move (mine);

        if (builder.getNumItems() > 0)
        {
            menu.addSeparator();
            menu.addSubMenu ("BUILDER", builder);
        }
    }

    // The player's files are numbered from firstFile, in the order the tree lists them.
    files.clear();

    if (irsBeneath (library) > 0)
    {
        // The twelve keep their place however the library grows — the top — and the library is laid
        // out below them the way SETUP shows it: folders first, each a submenu, then the files. A
        // folder with nothing playable anywhere under it is a shelf with nothing on it, and stays
        // out. A folder holding what plays wears the tick too, so the way to it can be followed.
        if (menu.getNumItems() > 0)
            menu.addSeparator();

        std::function<bool (juce::PopupMenu&, const device::IrLibrary::Node&)> addTree =
            [&] (juce::PopupMenu& into, const device::IrLibrary::Node& folder)
        {
            bool holdsChoice = false;

            for (const auto& n : folder.children)
            {
                if (n.folder)
                {
                    if (irsBeneath (n) == 0)
                        continue;

                    juce::PopupMenu sub;
                    const bool inside = addTree (sub, n);
                    into.addSubMenu (n.name(), sub, true, nullptr, inside);
                    holdsChoice = holdsChoice || inside;
                }
                else
                {
                    const auto from = n.file.getRelativePathFrom (root).replaceCharacter ('\\', '/');
                    const bool ticked = choice.isUser() && from == choice.from;

                    files.push_back (n.file);
                    into.addItem (itemFor (n.file.getFileNameWithoutExtension(),
                                           firstFile + (int) files.size() - 1, ticked));
                    holdsChoice = holdsChoice || ticked;
                }
            }

            return holdsChoice;
        };

        addTree (menu, library);
    }

    return menu;
}

void CabinetBlock::showIrMenu()
{
    lookAtLibrary();   // the slider the same list as the menu, at once
    auto files = std::make_shared<std::vector<juce::File>>();
    auto saves = std::make_shared<std::vector<device::Cabinets::Cabinet>>();
    auto menu = irMenu (amp, *files, saves.get());

    onfirst::show (menu, this, juce::PopupMenu::Options().withTargetComponent (&ir),
                        [safe = juce::Component::SafePointer<CabinetBlock> (this), files, saves] (int r)
                        {
                            if (safe == nullptr || r <= 0)
                                return;

                            if (r >= firstFile)
                            {
                                if ((size_t) (r - firstFile) < files->size())
                                    safe->amp.chooseCabFile ((*files)[(size_t) (r - firstFile)]);
                                safe->refreshIr (false, true);
                            }
                            else if (r >= firstOfSaved)
                            {
                                if (const auto i = (size_t) (r - firstOfSaved); i < saves->size())
                                    safe->pickCabinet ({ Pick::own, -1, (*saves)[i].file }, (*saves)[i].state);
                            }
                            else if (r >= firstOfBuilder)
                            {
                                if (const auto i = (size_t) (r - firstOfBuilder); i < safe->cabs.all().size())
                                    safe->pickCabinet ({ Pick::all, (int) i, {} }, safe->cabs.all()[i].state);
                            }
                            else if (r >= firstOfTwelve)
                                safe->pickAt (r - firstOfTwelve);
                        });
}

int CabinetBlock::listAt() const
{
    const auto choice = amp.cabChoice();
    if (const auto playing = AmpProcessor::cabSynthOf (choice); playing.valid)
    {
        // One of the twelve, or a cabinet of none of them a session or a preset kept: off the list.
        const auto which = whichPlays (playing.state, {});
        return which.list == Pick::dozen ? which.at : -1;
    }
    if (choice.isUser())
    {
        const auto root = device::IrLibrary::directory (amp.product().irsFolder());
        for (size_t i = 0; i < ownIrs.size(); ++i)
            if (ownIrs[i].getRelativePathFrom (root).replaceCharacter ('\\', '/') == choice.from)
                return (int) (cabs.dozen().size() + i);
    }
    return -1;
}

void CabinetBlock::pickCabinet (const Pick& p, const cabir::State& state)
{
    lastPick = p;
    amp.requestCabSynth (state);
    refreshIr (true);   // one the same as the last changes no sound, and the name must follow all the same
}

void CabinetBlock::pickAt (int at)
{
    const auto& twelve = cabs.dozen();
    if (at >= 0 && at < (int) twelve.size())
    {
        lastPick = { Pick::dozen, at, {} };
        amp.requestCabSynth (twelve[(size_t) at].state);
        refreshIr (true);   // one the same as the last changes no sound, and the name must follow all the same
    }
    else if (const auto i = (size_t) (at - (int) twelve.size()); at >= 0 && i < ownIrs.size())
    {
        amp.chooseCabFile (ownIrs[i]);
        refreshIr (false, true);
    }
}

bool CabinetBlock::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (const auto& f : files)
        if (device::IrLibrary::looksLikeImport (juce::File (f)))
            return true;
    return false;
}

void CabinetBlock::fileDragEnter (const juce::StringArray&, int, int) { dropOver = true;  repaint(); }
void CabinetBlock::fileDragExit  (const juce::StringArray&)           { dropOver = false; repaint(); }

void CabinetBlock::filesDropped (const juce::StringArray& files, int, int)
{
    dropOver = false;
    repaint();

    // Into the library's top, as the IR editor's + puts them; the first of them that landed, in the editor's order, plays.
    const auto root = device::IrLibrary::directory (amp.product().irsFolder());
    const auto before = device::IrLibrary::listed (root);
    int landed = 0;
    for (const auto& f : files)
        landed += device::IrLibrary::importPath (juce::File (f), root);
    if (landed == 0)
        return;

    lookAtLibrary();
    for (size_t i = 0; i < ownIrs.size(); ++i)
        if (! before.contains (ownIrs[i]))
            return pickAt ((int) (cabs.dozen().size() + i));
}

void CabinetBlock::paintOverChildren (juce::Graphics& g)
{
    // IRs held over the block: an orange line round it, where they will land.
    if (! dropOver)
        return;
    g.setColour (theme::orange);
    g.drawRoundedRectangle (getLocalBounds().toFloat().reduced (1.5f), 6.0f, 2.0f);
}

void CabinetBlock::stepList (bool own, int by)
{
    // Round the one list, the twelve's or the player's own: from where it plays, or into it from its first (its last, back).
    lookAtLibrary();
    const int twelve = (int) cabs.dozen().size();
    const int count = own ? (int) ownIrs.size() : twelve;
    if (count == 0)
        return;
    const int at = listAt();
    const int here = own ? (at >= twelve ? at - twelve : -1) : (at >= 0 && at < twelve ? at : -1);
    const int next = here < 0 ? (by > 0 ? 0 : count - 1) : ((here + by) % count + count) % count;
    pickAt ((own ? twelve : 0) + next);
}

void CabinetBlock::stepCabinet (int by)
{
    // The slider that plays: the player's own while one of them does, else the twelve.
    stepList (listAt() >= (int) cabs.dozen().size(), by);
}

std::vector<device::Cabinets::Cabinet> CabinetBlock::savedCabinets() const
{
    auto saved = cabs.own();
    for (auto& c : cabs.builderSaves())
        saved.push_back (std::move (c));
    return saved;
}

CabinetBlock::Pick CabinetBlock::whichPlays (const cabir::State& state, const std::vector<device::Cabinets::Cabinet>& own) const
{
    const auto& twelve = cabs.dozen();
    const auto& whole = cabs.all();
    switch (lastPick.list)   // the one picked, while it still sounds as it did
    {
        case Pick::dozen:
            if (lastPick.at >= 0 && lastPick.at < (int) twelve.size() && twelve[(size_t) lastPick.at].state == state)
                return lastPick;
            break;
        case Pick::all:
            if (lastPick.at >= 0 && lastPick.at < (int) whole.size() && whole[(size_t) lastPick.at].state == state)
                return lastPick;
            break;
        case Pick::own:   // by its file: its place in the list moves as the player's own are added and renamed
            for (size_t i = 0; i < own.size(); ++i)
                if (own[i].file == lastPick.file && own[i].state == state)
                    return { Pick::own, (int) i, own[i].file };
            break;
        case Pick::none:
            break;
    }
    if (const int i = cabs.dozenOf (state); i >= 0)
        return { Pick::dozen, i, {} };
    if (const int i = cabs.allOf (state); i >= 0)
        return { Pick::all, i, {} };
    for (size_t i = 0; i < own.size(); ++i)
        if (own[i].state == state)
            return { Pick::own, (int) i, own[i].file };
    return {};
}

juce::String CabinetBlock::nameOf (const Pick& p, const std::vector<device::Cabinets::Cabinet>& own) const
{
    switch (p.list)
    {
        case Pick::dozen: return cabs.dozen()[(size_t) p.at].name;
        case Pick::all:   return cabs.all()[(size_t) p.at].name;
        case Pick::own:   return own[(size_t) p.at].name;
        case Pick::none:  break;
    }
    return {};
}

void CabinetBlock::pushToWave()
{
    // The PARAMETERS, not the atomics: an attachment callback runs before the atomic is written,
    // and reading it there leaves the picture exactly one change behind for good.
    const auto plain = [this] (const char* id)
    {
        auto* p = amp.apvts.getParameter (id);
        return p->convertFrom0to1 (p->getValue());
    };

    const auto slopeDb = [&] (const char* id)
    { return params::eqSlopeValues[juce::jlimit (0, (int) std::size (params::eqSlopeValues) - 1,
                                                 juce::roundToInt (plain (id)))]; };

    wave.setFilters (plain (params::cabHpfOn) > 0.5f, plain (params::cabHpfHz), params::cabHpfMinHz, params::cabHpfMaxHz,
                     plain (params::cabLpfOn) > 0.5f, plain (params::cabLpfHz), params::cabLpfMinHz, params::cabLpfMaxHz);
    wave.setSlopes (slopeDb (params::cabHpfSlope), slopeDb (params::cabLpfSlope));
    // The VALUE first, then the switch. Turning the trim on is what puts the handle under the view
    // window's rule, and that rule WRITES: `setTrimEnabled` calls `clampTrimToWindow`, which pulls
    // a handle standing outside the window onto its edge through `onTrimChanged` — a real gesture
    // on the parameter. Enabled first, the clamp judged the OLD fraction and could overwrite the
    // one arriving a line later.
    const bool trimOn = plain (params::cabTrimOn) > 0.5f;

    wave.setTrimFraction (plain (params::cabTrim));
    deriveTrimMode();

    // Coming ON from OUTSIDE — a preset, a register, an automation lane — the picture is still
    // wearing whatever window the last look left, and the clamp above would judge the recalled
    // length against it and write the window's edge over it. Give the window the mode's own answer
    // first and the clamp has nothing to pull. Only on the edge: setting it on every push would
    // fight the servo that zooms under a dragging hand. A menu pick sets its own window and holds
    // the mode, so it is not this code's business either.
    // ...and only once there IS a shot. Until the IR lands there is nothing to frame and nothing
    // worth remembering: an editor opening on a saved trim runs through here first with a length
    // of zero, and latching the switch's state there spent the edge on nothing — the picture then
    // stayed on the whole shot with the trim a sliver at the far edge, which is the very thing the
    // framing law exists to prevent.
    if (wave.lengthMs() > 0.0)
    {
        if (trimOn && ! trimWasOn && ! modeIsHeld)
            wave.frameTrim();

        trimWasOn = trimOn;
    }

    wave.setTrimEnabled (trimOn);

    wave.setTrimInteractive (trimMode == TrimMode::manual);

    trimCombo.repaint();
}

void CabinetBlock::deriveTrimMode()
{
    // Something already SAID what the mode is; re-deriving it from half-written values is how it
    // used to be lost. See `modeIsHeld`.
    if (modeIsHeld)
        return;

    auto* on = amp.apvts.getParameter (params::cabTrimOn);

    if (on->convertFrom0to1 (on->getValue()) < 0.5f)
    {
        trimMode = TrimMode::off;
        return;
    }

    // NOTHING TO DERIVE FROM is not a verdict. With no shot loaded there are no milliseconds to
    // compare: every mark misses, the answer is MANUAL, and MANUAL sticks. The editor opens that
    // way — the switches' initial updates all run through here before the IR arrives, since
    // `irAtt->sendInitialUpdate()` is the last of them — so a clean 100 MS used to come back as
    // TRIM MAN on every single open. Say nothing and wait for the shot.
    if (wave.lengthMs() <= 0.0)
        return;

    // ...and the same when the shot on show is not yet the one the state names: a recall moves the
    // trim first and the IR of the player's own a tick later, and milliseconds read off the
    // outgoing picture would latch a window nobody chose.
    if (shownIr.upToFirstOccurrenceOf ("|", false, false) != amp.cabChoice().identity())
        return;

    // An explicitly chosen MANUAL stays MANUAL even when the magnet lands the handle exactly on
    // a mark — a handle that vanished under the hand would be a bug wearing a rule's clothes.
    if (trimMode == TrimMode::manual)
        return;

    auto* tp = amp.apvts.getParameter (params::cabTrim);
    const double ms = (double) tp->convertFrom0to1 (tp->getValue()) * wave.lengthMs();

    // STILL OURS: the window already worn, measured on THIS shot. A fixed pick too long for a
    // short cab shows the whole thing, and the whole thing is not a mark — but the pick has not
    // changed, and reading it as MANUAL here is what used to lose it for good on the next
    // unrelated repaint, an HPF toggle being enough. Compare against the pick clamped to the shot
    // and a 500 ms window survives a 183 ms cab and comes back whole on the next long one.
    if (trimMode == TrimMode::fixed
        && std::abs (ms - juce::jmin (trimModeMs, wave.lengthMs())) < 1.0)
        return;

    for (const double mark : { 25.0, 50.0, 100.0, 200.0, 500.0 })
        if (std::abs (ms - mark) < 1.0)
        {
            trimMode   = TrimMode::fixed;
            trimModeMs = mark;
            return;
        }

    // A NUMBER NOBODY CLAIMED is a fixed window on its own number. It used to be read as MANUAL,
    // and that was the last place a mode could be invented rather than found: a session saved
    // mid-drag came back manual, the same session saved on a mark came back fixed, and which one
    // you got depended on where the hand happened to stop. The mode is not stored anywhere — the
    // two parameters are the whole truth — so the only honest reading is the one that says the
    // same thing every time.
    //
    // The combo shows the number, no window in the menu is ticked (none IS chosen), and the
    // handle waits for MANUAL to be asked for. One click, and the sound never moved: the value is
    // already exactly where it was saved.
    trimMode   = TrimMode::fixed;
    trimModeMs = ms;
}

/** The trim menu's ids: OFF, then one per fixed mark, then MANUAL well clear of them, and the
    block's own switches from 10 up. Named because the marks grow and the ones after them must
    not have to be renumbered by hand every time one does. */
static constexpr int itemOff = 1, itemFirstMark = 2, itemManual = 7;

void CabinetBlock::showTrimMenu()
{
    // The groups are NAMED. This menu carries the block's cuts and its phase as well, so a bare
    // OFF at the top has no owner and reads as the whole cabinet standing down — which is the
    // strip's arrow, not this. A header costs one row and says whose switch each one is.
    juce::PopupMenu m;
    // TRIM is ONE thing with a line through it, not two named things. Above the line, who decides
    // — nobody, or your own hand. Below it, the answer when neither does. A second header there
    // would promise a second subject; the line says "still the trim, other half" and costs a row
    // instead of a name.
    m.addSectionHeader ("TRIM");
    m.addItem (itemOff,    "OFF",    true, trimMode == TrimMode::off);
    m.addItem (itemManual, "MANUAL", true, trimMode == TrimMode::manual);
    m.addSeparator();

    const double marks[]  = { 25.0, 50.0, 100.0, 200.0, 500.0 };
    const char* labels[] = { "25 MS", "50 MS - DRY", "100 MS", "200 MS - WET", "500 MS" };

    // A window has to be shorter than the shot BY A MARGIN to be worth offering. The old test was
    // simply "shorter", so on a 501 ms cab the 500 ms window came alive to cut one millisecond
    // nobody can hear — a live item that does nothing is worse than a grey one, because grey at
    // least says why. A tenth of the shot is the least that reads as a cut.
    //
    // GREY, never gone: a window that does not fit this cabinet still exists, and a row that
    // vanishes says nothing about why. It is also the only way to see a window that IS chosen and
    // does not fit — carried over from a longer cab, it stands grey and ticked at once: this is
    // what is set, and here it does not go.
    constexpr double roomNeeded = 0.9;

    for (int i = 0; i < (int) std::size (marks); ++i)
        m.addItem (itemFirstMark + i, labels[i], marks[i] < wave.lengthMs() * roomNeeded,
                   trimMode == TrimMode::fixed && juce::approximatelyEqual (trimModeMs, marks[i]));

    // Only what has no face on the panel. The cuts stand out there in plain sight and answer to
    // their own switches; listing them again here would be a second door to a room already open,
    // and a menu that repeats the panel teaches nobody where anything lives.
    //
    // One item needs no heading over it — a heading for a single line is a heading that says the
    // line twice. Another rule, and the line names itself.
    m.addSeparator();
    m.addItem (10, juce::String::fromUTF8 ("\xc3\x98 INVERT PHASE"), true, switches[2].sw.isOn());

    onfirst::show (m, this, juce::PopupMenu::Options().withMousePosition(),
                     [safe = juce::Component::SafePointer<CabinetBlock> (this)] (int r)
                     {
                         if (safe != nullptr && r > 0)
                             safe->applyTrimPick (r);
                     });
}

void CabinetBlock::applyTrimPick (int itemId)
{
    // The switch section: flips through the switch, so the attachment writes the parameter and
    // the echo redraws face and picture alike.
    if (itemId >= 10)
    {
        switches[itemId == 10 ? 2 : itemId == 11 ? 0 : 1].sw.toggle();
        return;
    }

    // From here down the MODE is chosen, not derived: the two writes below echo back through
    // `pushToWave` as they land, and a half-written pair is no basis for reading a mode off.
    const juce::ScopedValueSetter<bool> held (modeIsHeld, true);

    // pushToWave runs LAST, unconditionally: a pick that writes a value the parameter already has
    // echoes nothing, and the combo and the handle would be left telling yesterday's story.
    //
    // ONE ORDER for all three: the VALUE, then the FRAME, then the SWITCH — and the switch last
    // because turning the trim on is what makes the window rule the handle. `setTrimEnabled` and
    // `setViewWindow` both call `clampTrimToWindow`, which pulls a handle standing outside the
    // window onto its edge AND WRITES THAT — a real gesture on the parameter, through
    // `onTrimChanged`. Turn the switch on while the old value and a stale window are still in
    // place and the clamp fires on numbers nobody asked for: it used to cost MANUAL its
    // remembered spot outright, and a fixed pick a spurious write into the host's automation.
    // With the value and the window already what the pick says, the clamp has nothing to pull.
    if (itemId == itemOff)
    {
        // Nothing is being cut, so the law has no trim to frame: the whole shot, which is what
        // there is to look at.
        trimMode = TrimMode::off;
        wave.setViewWindow (0.0);
        trimOnAtt->setValueAsCompleteGesture (0.0f);
    }
    else if (itemId == itemManual)
    {
        // MANUAL takes the trim WHERE IT STANDS. Coming off a fixed window the handle appears on
        // that window's own edge, so you carry on from what you are hearing — nothing jumps, and
        // there is no earlier place to be sent back to. Which also means the pick writes no value
        // at all: the number is already right, only the hand it answers to changes.
        trimMode = TrimMode::manual;

        wave.frameTrim();
        trimOnAtt->setValueAsCompleteGesture (1.0f);
    }
    else
    {
        const double marks[] = { 25.0, 50.0, 100.0, 200.0, 500.0 };
        trimMode   = TrimMode::fixed;
        trimModeMs = marks[itemId - itemFirstMark];

        if (wave.lengthMs() > 0.0)
            trimAtt->setValueAsCompleteGesture (
                (float) juce::jlimit (0.001, 1.0, trimModeMs / wave.lengthMs()));

        wave.frameTrim();
        trimOnAtt->setValueAsCompleteGesture (1.0f);
    }

    pushToWave();
}

void CabinetBlock::TrimCombo::paint (juce::Graphics& g)
{
    if (getText == nullptr)
        return;

    const auto r = getLocalBounds().toFloat();

    g.setColour (theme::txDim);
    theme::drawTracked (g, getText(), r.withTrimmedRight (11.0f), theme::displayFont (12.0f), 0.04f,
                        juce::Justification::centredLeft);

    // The chevron that says "this opens" — the consoles' SlopeCombo grammar.
    juce::Path v;
    const float cx = r.getRight() - 9.0f, cy = r.getCentreY() - 1.0f;
    v.startNewSubPath (cx - 3.0f, cy);
    v.lineTo (cx, cy + 3.0f);
    v.lineTo (cx + 3.0f, cy);
    g.strokePath (v, juce::PathStrokeType (1.2f));
}

void CabinetBlock::layOutContent (juce::Rectangle<int> area)
{
    // A narrow tile gives its border to the IR's name alone — the orange frame already says
    // what kind of block this is, and "CAB IR" was spending the name's room.
    showTitle = area.getWidth() >= 300;

    // The IR's name on the border, sized to itself and centred in the run.
    {
        const auto slot = borderSlotArea();
        ir.setBounds (slot.withSizeKeepingCentre (juce::jmin (slot.getWidth(), ir.idealWidth()), slot.getHeight()));
        borderSlotUsed = ir.getBounds();
    }

    // THE BASS'S DI/CAB at the block's right edge, the content's whole height, as COMP's BLEND stands in its block.
    if (bassRow != nullptr)
    {
        bassRow->di.setBounds (area.removeFromRight (bassRow->di.columnWidth));
        area.removeFromRight (gap);
    }

    // The bottom row: HPF holds the left wall and LPF the right — each cut on its own side of the
    // spectrum, the way they stand on the curve — with the trim combo centred between them. Three
    // things, evenly. The phase used to make it four, and a row of four turned the trim, the one
    // control here that is actually worked, into just another item in a list.
    //
    // A NARROW tile drops the cuts' words; the switches whisper them under the mouse instead.
    const bool narrow = area.getWidth() < 300;

    switches[0].label.setVisible (! narrow);
    switches[1].label.setVisible (! narrow);
    switches[0].sw.setTooltip (narrow ? "HPF" : juce::String());
    switches[1].sw.setTooltip (narrow ? "LPF" : juce::String());

    auto row = area.removeFromBottom (switchRow);
    const auto wholeRow = row;   // the bass's slider takes it edge to edge: its cuts' seats stand empty
    area.removeFromBottom (gap);

    // A slider with a step at each end of it (the owner, 10.11).
    const auto placeSteps = [] (Step& back, CabinetSlots& slider, Step& on, juce::Rectangle<int> r)
    {
        back.setBounds (r.removeFromLeft (stepW));
        on.setBounds (r.removeFromRight (stepW));
        slider.setBounds (r);
    };
    const auto placeSlider = [this, placeSteps] (juce::Rectangle<int> r) { placeSteps (stepBack, slots, stepOn, r); };

    // The player's own IRs on a row of their own over the twelve's, the block's whole width, while there are any (the
    // owner, 10.11): with none, the picture has the row. The guitar's inset as its cuts' row, the bass's edge to edge as its.
    if (ownSlots.isVisible())
    {
        const auto own = area.removeFromBottom (switchRow);
        placeSteps (ownBack, ownSlots, ownOn, guitar() ? own.reduced (gap, 0) : own);
        area.removeFromBottom (gap);
    }

    if (narrow)
    {
        switches[0].sw.setBounds (row.removeFromLeft (30).withSizeKeepingCentre (30, 16));
        switches[1].sw.setBounds (row.removeFromRight (30).withSizeKeepingCentre (30, 16));
    }
    else
    {
        const auto place = [] (Switch& sw, juce::Rectangle<int> cell)
        {
            sw.sw.setBounds (cell.removeFromLeft (30).withSizeKeepingCentre (30, 16));
            cell.removeFromLeft (6);
            sw.label.setBounds (cell);
        };

        place (switches[0], row.removeFromLeft (70));    // HPF
        place (switches[1], row.removeFromRight (70));   // LPF
    }

    // The bass: no cut words (its one pair is the AMP's).
    if (bassRow != nullptr)
        for (int i = 0; i < 2; ++i)
        {
            switches[(size_t) i].sw.setVisible (false);
            switches[(size_t) i].label.setVisible (false);
        }

    trimCombo.setBounds (row.withSizeKeepingCentre (juce::jmin (90, row.getWidth() - 12),
                                                    row.getHeight()));

    // The row where the trim stood: the twelve's slider — the guitar's between its cuts (the owner, 10.11), the bass's
    // edge to edge, its cuts being the AMP's (11.11).
    placeSlider (guitar() ? row.reduced (gap, 0) : wholeRow);

    wave.setBounds (area);

    // The cabinet's sketch over the whole picture, drawn at its right (CabPicker::paintSketch) — over the time and dB
    // marks there and the IR's line, the tolex letting them through.
    sketch.setBounds (area);
}

void CabinetBlock::paintContent (juce::Graphics&) {}

GuardRail* CabinetBlock::diRail() noexcept { return bassRow != nullptr ? &bassRow->di : nullptr; }

/** The consoles' feeding rule, twice: a fresh window into its pane, a starve when the audio
    stopped — then one repaint, and the hook above draws both. */
void CabinetBlock::timerCallback()
{
    refreshIr();   // before the early return: what plays is shown whether or not the block is on

    if (isShowing() && --libraryLook <= 0)
    {
        libraryLook = 90;   // three seconds
        lookAtLibrary();
    }

    if (! isBlockOn() || ! wave.isShowing())
        return;

    bool moved = false;

    for (int i = 0; i < 2; ++i)
    {
        auto& pane = panes[(size_t) i];
        int order = 0;

        if (amp.cabSpectrumTap[(size_t) i].tryPull (pane.frameInput(), order)
            && order == AmpProcessor::eqSpectrumOrder)
            pane.ingest (order);
        else
            pane.starve();

        moved = true;
    }

    if (moved)
        wave.repaint();
}

} // namespace orbitamp
