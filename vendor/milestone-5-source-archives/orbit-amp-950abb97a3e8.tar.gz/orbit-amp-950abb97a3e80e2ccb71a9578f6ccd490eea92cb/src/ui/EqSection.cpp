// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "EqSection.h"
#include "BassControls.h"

#include "EqDisplay.h"

#include "Prefs.h"

#include "Theme.h"
#include "OnFirst.h"

namespace orbitamp
{

//==============================================================================
EqSection::EqSection (juce::AudioProcessorValueTreeState& s, int eqLink,
                      felitronics::analysis::RollingSpectrumTap& spectrumTap,
                      felitronics::analysis::RollingSpectrumTap& inSpectrumTap,
                      std::function<double()> sampleRateGetter)
    : state (s), link (eqLink), tap (spectrumTap), inTap (inSpectrumTap),
      sampleRate (std::move (sampleRateGetter))
{
    display.prepare (displayRate, 1);

    // The spectra behind everything: the signal is the ground the response stands on — and it is
    // a PAIR now, the cabinet picture's grammar: what the console eats as the quiet grey ground,
    // what it made in the block's own colour over it.
    curve.paintSpectrum = [this] (juce::Graphics& g, juce::Rectangle<float> r)
    {
        if (spectraShown != nullptr && ! spectraShown->load (std::memory_order_relaxed))
            return;

        felitronics::analysis::PlotMap pm;
        pm.width      = r.getWidth();
        pm.height     = r.getHeight();
        pm.plotBottom = r.getHeight();
        pm.freqMin    = 20.0;
        pm.freqMax    = 20000.0;
        pm.specTop    = 0.0;
        pm.specBottom = -90.0;

        const auto draw = [&] (felitronics::analysis::SpectrumPane& p, juce::Colour tint,
                               float fillTop, float fillBottom, float line)
        {
            juce::Path fill, peak;
            fill.startNewSubPath (r.getX(), r.getBottom());
            bool first = true;

            p.buildColumns (pm, sampleRate(), 4.5, 1000.0,
                            [&] (int, float x, float yFill, float yPeak)
                            {
                                fill.lineTo (r.getX() + x, r.getY() + yFill);

                                if (first) { peak.startNewSubPath (r.getX() + x, r.getY() + yPeak); first = false; }
                                else       peak.lineTo (r.getX() + x, r.getY() + yPeak);
                            });

            fill.lineTo (r.getRight(), r.getBottom());
            fill.closeSubPath();

            g.setGradientFill (juce::ColourGradient (tint.withAlpha (fillTop),
                                                     0.0f, r.getY() + r.getHeight() * 0.30f,
                                                     tint.withAlpha (fillBottom),
                                                     0.0f, r.getBottom(), false));
            g.fillPath (fill);
            g.setColour (tint.withAlpha (line));
            g.strokePath (peak, juce::PathStrokeType (1.0f));
        };

        draw (inPane, theme::spectrum, 0.14f, 0.02f, 0.30f);   // before: the quiet ground
        draw (pane,   theme::orange,   0.18f, 0.02f, 0.55f);   // after: the console's own voice
    };

    buildBands (ourBands());

    // The gesture-bearing attachments: frequencies per handle, Qs, slopes, and B3's pair.
    freqAtt[hLo]  = attach (params::eqLoHz (link));
    freqAtt[hB1]  = attach (params::eqBellHz (link, 0));
    freqAtt[hB2]  = attach (params::eqBellHz (link, 1));
    freqAtt[hB3]  = attach (params::eqBellHz (link, 2));
    freqAtt[hHi]  = attach (params::eqHiHz (link));
    freqAtt[hHpf] = attach (params::eqHpfHz (link));
    freqAtt[hLpf] = attach (params::eqLpfHz (link));

    for (int b = 0; b < 3; ++b)
        qAtt[b] = attach (params::eqBellQ (link, b));

    hpfSlopeAtt = attach (params::eqHpfSlope (link));
    lpfSlopeAtt = attach (params::eqLpfSlope (link));
    b3OnAtt     = attach (params::eqB3On (link));
    b3DbAtt     = attach (params::eqBellDb (link, 2));

    // The cut switches carry their own attachments; the curve refreshes off ours. Each cut wears
    // its line's colour — orange HPF, violet LPF — so switch, dashed line and combo read as one.
    hpfSw.accent = theme::orange;
    lpfSw.accent = theme::violet;
    hpfSw.attach (*state.getParameter (params::eqHpfOn (link)));
    lpfSw.attach (*state.getParameter (params::eqLpfOn (link)));
    refreshAtts.push_back (attach (params::eqHpfOn (link)));
    refreshAtts.push_back (attach (params::eqLpfOn (link)));

    for (auto* l : { &hpfLabel, &lpfLabel })
    {
        l->setFont (theme::displayFont (13.0f));
        l->setColour (juce::Label::textColourId, theme::txDim);
        l->setJustificationType (juce::Justification::centred);
        l->setInterceptsMouseClicks (false, false);
    }

    hpfSlopeBox.getIndex = [this] { return juce::roundToInt (raw (params::eqHpfSlope (link))); };
    lpfSlopeBox.getIndex = [this] { return juce::roundToInt (raw (params::eqLpfSlope (link))); };
    hpfSlopeBox.setIndex = [this] (int i) { hpfSlopeAtt->setValueAsCompleteGesture ((float) i); };
    lpfSlopeBox.setIndex = [this] (int i) { lpfSlopeAtt->setValueAsCompleteGesture ((float) i); };

    // The curve's right click and its empty click are the well's (onCurveMenu, onCurveClick); asked when they happen,
    // so the block may hand them over after it built the console.
    curve.onContextMenu = [this] (juce::Point<int> at)
    {
        if (onCurveMenu != nullptr)
            onCurveMenu (at);
        else
            showResetMenu (at);
    };
    curve.onEmptyClick = [this]
    {
        if (onCurveClick != nullptr)
            onCurveClick();
    };

    curve.onHandleDrag       = [this] (int i, double hz, double db) { handleDragged (i, hz, db); };
    curve.onDragActive       = [this] (int i, bool a) { handleDragActive (i, a); };
    curve.onHandleWheel      = [this] (int i, float d) { handleWheel (i, d); };
    curve.onHandleStep       = [this] (int i, int n) { stepSlope (i, n); };
    curve.onCurveDoubleClick = [this] (double hz) { curveDoubleClicked (hz); };
    curve.onHandleDoubleClick = [this] (int i) { handleDoubleClicked (i); };

    refreshCurve();
}

EqSection::~EqSection() = default;

/** Short names on purpose: six cells across half a panel leave about sixty design units each, and
    "LO MID" at reading size ran straight into its neighbour. The colour carries the identity the
    name had to give up — the knob wears the same one as its point on the curve. */
std::vector<EqSection::Band> EqSection::ourBands() const
{
    // The bass's three, the SGT-DI's: TREBLE wears HI's colour, the same hand as its point on the curve.
    if (bassStandard())
        return { { "BASS",   theme::eqNode[0], params::eqLoDb (link) },
                 { "MIDDLE", theme::eqNode[1], params::eqBellDb (link, 0) },
                 { "TREBLE", theme::eqNode[3], params::eqHiDb (link) } };

    return { { "LO",    theme::eqNode[0], params::eqLoDb (link) },
             { "L MID", theme::eqNode[1], params::eqBellDb (link, 0) },
             { "H MID", theme::eqNode[2], params::eqBellDb (link, 1) },
             { "HI",    theme::eqNode[3], params::eqHiDb (link) } };
}

/** Puts a set of bands on the row: a knob each, attached to whatever parameter the band names.

    Rebuildable on purpose. The four this console has today are ours and fixed, but the next set is
    a pack's own tone controls — one to three of whatever that device happened to have — and the one
    after that is a classical stack's three. A row that can only be built once is a row that can
    only ever hold ours. */
void EqSection::buildBands (std::vector<Band> newBands)
{
    // Attachments first, and in this order: a SliderAttachment reaches for its slider in its own
    // destructor, so a knob freed before its attachment is a knob freed from under it.
    bandAtts.clear();
    bandKnobs.clear();

    bands = std::move (newBands);

    pairName.setVisible (false);
    for (size_t i = 0; i < bands.size(); ++i)
    {
        const auto& b = bands[i];
        const bool pairs = i + 1 < bands.size() && pairedFader (i + 1), paired = pairedFader (i);
        auto k = std::make_unique<Knob> (pairs || paired ? juce::String() : b.label, b.colour, b.notches);

        // Every band's number under its dial, typed there too (Oleh, 24.10): ours in decibels, a
        // device's on the amp-panel's 0-10, the scale its GAIN reads in — its parameter is a
        // normalised place on the device's dial.
        if (b.reading != nullptr)
        {
            k->textForValue = b.reading;
            k->setHint (b.label + ":   where the band it moves stands, in Hz");
        }
        else if (b.showsDb)
        {
            k->textForValue = [] (double v) { return (v > 0.0 ? "+" : "") + juce::String (v, 1); };
            k->setHint (b.label + ":   the band's gain, in dB");
        }
        else
        {
            k->textForValue = [] (double v) { return juce::String (v * 10.0, 1); };
            k->valueForText = [] (const juce::String& t) { return t.retainCharacters ("+-.0123456789").getDoubleValue() / 10.0; };
            k->setHint (b.label + ":   the device's own control, as captured, 0 to 10");
        }

        k->valueInDial = false;
        k->setValueRowShown (! paired);
        k->setFader (paired);
        if (pairs || paired)
            pairName.setVisible (host != nullptr);

        k->onValueChange   = [this, paired] { refreshCurve(); if (paired) namePair(); };
        k->labelFontHeight = 13.0f;   // the face's floor for anything read
        k->labelRowHeight  = labelRowH;

        bandAtts.push_back (std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
            state, b.param, *k));

        if (host != nullptr)
            host->addAndMakeVisible (*k);

        bandKnobs.push_back (std::move (k));
    }
    namePair();

    if (host != nullptr)
        host->resized();
}

/** The pair's one name: the dial's band's, and the frequency the fader puts it at. */
void EqSection::namePair()
{
    for (size_t i = 1; i < bands.size(); ++i)
        if (pairedFader (i) && i < bandKnobs.size())
        {
            pairName.text = bands[i - 1].label.toUpperCase() + " " + bands[i].reading (bandKnobs[i]->getValue());   // kHz as it is written
            pairName.repaint();
            return;
        }
}

void EqSection::PairName::paint (juce::Graphics& g)
{
    // As a knob writes its name over its dial (Knob::paint), across the two.
    g.setColour (theme::txDim);
    theme::drawTracked (g, text, getLocalBounds().toFloat(), theme::displayFont (13.0f), 0.15f, juce::Justification::centred);
}

/** THE DIALS ACROSS `row`, an even share each — a FREQ fader and its dial in one share between them, close together and
    centred in it, so they never drift apart however wide the row is. */
void EqSection::layBands (juce::Rectangle<int> row)
{
    int shares = 0;
    for (size_t i = 0; i < bandKnobs.size(); ++i)
        shares += pairedFader (i) ? 0 : 1;
    const int shareW = row.getWidth() / juce::jmax (1, shares);

    for (size_t i = 0; i < bandKnobs.size(); ++i)
    {
        if (pairedFader (i))
            continue;
        const auto cell = row.removeFromLeft (shareW);
        if (i + 1 >= bandKnobs.size() || ! pairedFader (i + 1))
        {
            bandKnobs[i]->setBounds (cell);
            continue;
        }
        auto& dial = *bandKnobs[i];
        auto& fader = *bandKnobs[i + 1];
        constexpr int gap = 4;
        const int under = Knob::valueRowH - dial.valueLift;
        const int dialW = juce::jlimit (1, juce::jmax (1, cell.getWidth() - gap - Knob::faderW), cell.getHeight() - dial.labelRowHeight - under);
        auto pair = cell.withSizeKeepingCentre (dialW + gap + Knob::faderW, cell.getHeight());
        pairName.setBounds (pair.withHeight (dial.labelRowHeight).expanded (40, 0));
        dial.setBounds (pair.removeFromLeft (dialW));
        pair.removeFromLeft (gap);
        fader.labelRowHeight = dial.labelRowHeight;
        fader.setBounds (pair);     // the whole height under the name (the owner, 03.11)
    }
}

void EqSection::setModes (int selected, bool nativeAvailable)
{
    // NO CHOICE, NO CHOOSER — and since the choice moved to the well's menu, no chooser on the curve
    // at all. The button that stood in the curve's corner and wore DEVICE TONE was a second way of
    // getting round the same pictures, and the owner wanted one: the page's own name says whose tone
    // sounds, EQ RIG or EQ, and the view menu is where it is changed.
    modeIndex     = juce::jlimit (0, params::eqModes.size() - 1, selected);
    nativeOffered = nativeAvailable;
}

/** RESET closes every list it stands in — the console's own knobs back to flat, and, through the
    block, the device's slots back to where the pack starts them. */
void EqSection::reset()
{
    resetLink();
    if (onReset != nullptr)
        onReset();
}

/** Where the block keeps no menu of pages for the curve, its right click is still worth something:
    RESET alone, as it always was there. */
void EqSection::showResetMenu (juce::Point<int> screenPos)
{
    juce::PopupMenu m;
    m.addItem (100, "RESET");

    onfirst::show (m, &curve, juce::PopupMenu::Options()
                         .withTargetScreenArea ({ screenPos.x, screenPos.y, 1, 1 }),
                     [safe = juce::Component::SafePointer<juce::Component> (&curve), this] (int r)
                     {
                         if (safe != nullptr && r == 100)
                             reset();
                     });
}

void EqSection::setBandDb (size_t index, double db)
{
    if (index >= bandKnobs.size())
        return;

    // Through the KNOB, not the parameter: the knob is the parameter's face here, and writing past
    // it would leave the dial showing the value the curve no longer has.
    bandKnobs[index]->setValue (juce::jlimit (-(double) params::toneRangeDb,
                                              (double) params::toneRangeDb, db),
                                juce::sendNotificationSync);
}

void EqSection::setSpectrumRunning (bool shouldRun)
{
    if (shouldRun)
        startTimerHz (30);
    else
        stopTimer();
}

void EqSection::timerCallback()
{
    // Pull a frame if one is waiting; a mismatched order is discarded (another consumer switched
    // resolutions — cannot happen while everyone agrees on spectrumOrder, but the contract stands).
    const auto pull = [] (felitronics::analysis::RollingSpectrumTap& t,
                          felitronics::analysis::SpectrumPane& p)
    {
        int order = 0;

        if (t.tryPull (p.frameInput(), order) && order == spectrumOrder)
            p.ingest (order);
        else
            p.starve();
    };

    pull (tap,   pane);
    pull (inTap, inPane);

    curve.repaint();
}

float EqSection::raw (const juce::String& id) const
{
    // The PARAMETER, not the apvts atomic: listener lists notify newest-first, so an attachment
    // callback can run before the atomic cache updates — reading the cache there left this face
    // exactly one click behind. The parameter object itself is written before anyone is told.
    auto* p = state.getParameter (id);
    return p->convertFrom0to1 (p->getValue());
}

std::unique_ptr<juce::ParameterAttachment> EqSection::attach (const juce::String& id)
{
    return std::make_unique<juce::ParameterAttachment> (*state.getParameter (id),
                                                        [this] (float) { refreshCurve(); });
}

juce::StringArray EqSection::linkParamIds() const
{
    // Everything the link owns — except the power: that is the frame's.
    return {
        params::eqHpfOn (link),  params::eqHpfHz (link),  params::eqHpfSlope (link),
        params::eqLoDb (link),   params::eqLoHz (link),
        params::eqBellDb (link, 0), params::eqBellHz (link, 0), params::eqBellQ (link, 0),
        params::eqBellDb (link, 1), params::eqBellHz (link, 1), params::eqBellQ (link, 1),
        params::eqB3On (link),
        params::eqBellDb (link, 2), params::eqBellHz (link, 2), params::eqBellQ (link, 2),
        params::eqHiDb (link),   params::eqHiHz (link),
        params::eqLpfOn (link),  params::eqLpfHz (link),  params::eqLpfSlope (link),
    };
}

void EqSection::resetLink()
{
    // Back to default in one sweep — a reset that also switched you off would be a reset that
    // argues, hence no power here.
    for (const auto& id : linkParamIds())
    {
        if (auto* p = state.getParameter (id))
        {
            p->beginChangeGesture();
            p->setValueNotifyingHost (p->getDefaultValue());
            p->endChangeGesture();
        }
    }
}

void EqSection::addTo (juce::Component& parent)
{
    parent.addAndMakeVisible (curve);
    host = &parent;

    for (auto& k : bandKnobs)
        parent.addAndMakeVisible (*k);
    parent.addAndMakeVisible (hpfSw);
    parent.addAndMakeVisible (lpfSw);
    parent.addAndMakeVisible (hpfLabel);
    parent.addAndMakeVisible (lpfLabel);
    parent.addAndMakeVisible (hpfSlopeBox);
    parent.addAndMakeVisible (lpfSlopeBox);
    parent.addChildComponent (strLine);
    parent.addChildComponent (fingLine);
    parent.addChildComponent (pairName);
    pairName.setInterceptsMouseClicks (false, false);
    for (size_t i = 1; i < bands.size(); ++i)
        if (pairedFader (i))
            pairName.setVisible (true);

    for (auto& k : bandKnobs)
        parent.addAndMakeVisible (*k);
}

void EqSection::setCurveVisible (bool v)
{
    // The console's clock rides the CURVE's visibility, and this is the ONLY place that starts it.
    //
    // It used to be started by the block that drew the EQ back when the EQ had a block of its own;
    // that block is gone, nothing took the job over, and the spectrum behind the curve quietly
    // stopped existing. The curve kept redrawing on every parameter move, which is exactly why it
    // took a while to notice — a live line over a dead ground. Now that the curve is one page of the
    // picture well, the clock stops with the page: the TONE picture reads the same tap, and two
    // readers on one mailbox starve each other.
    setSpectrumRunning (v);

    curve.setVisible (v);
}

void EqSection::setRowVisible (bool v)
{
    hpfSw.setVisible (v);
    lpfSw.setVisible (v);
    hpfLabel.setVisible (v);
    lpfLabel.setVisible (v);
    hpfSlopeBox.setVisible (v);
    lpfSlopeBox.setVisible (v);

    for (auto& k : bandKnobs)
        k->setVisible (v);
    bool paired = false;
    for (size_t i = 1; i < bands.size(); ++i)
        paired = paired || pairedFader (i);
    pairName.setVisible (v && paired);
}

void EqSection::refreshCurve()
{
    auto s = eqSettingsFor (state, link);   // the one reading every face shares
    if (bassStandard())
    {
        // THE BASS'S CUTS on its curve (the owner, 01.11): not the guitar's — its own one HPF's main cut and its LPF at
        // the frequencies their positions choose, 12 dB/oct as core::BassCuts runs them.
        const bool four = juce::roundToInt (raw (params::bassHpf)) == (int) params::BassHpf::four;
        const bool slap = juce::roundToInt (raw (params::bassLpf)) == (int) params::BassLpf::slap;
        s.hpfOn    = raw (params::bassHpfOn) > 0.5f;
        s.hpfHz    = (double) raw (four ? params::bassHpfHz4 : params::bassHpfHz5);
        s.hpfSlope = 12;
        s.lpfOn    = raw (params::bassLpfOn) > 0.5f;
        s.lpfHz    = (double) raw (slap ? params::bassLpfHzSlap : params::bassLpfHzFingers);
        s.lpfSlope = 12;

        // ...and its tone the SGT-DI's, as the processor plays it: MIDDLE in its span, the second bell and the scalpel out.
        s.b1Hz = juce::jlimit ((double) params::bassMidMinHz, (double) params::bassMidMaxHz, s.b1Hz);
        s.b2Db = 0.0;
        s.b3On = false;
        s.b3Db = 0.0;
    }

    display.setSettings (s);
    refreshHandles();

    hpfSlopeBox.repaint();
    lpfSlopeBox.repaint();
    curve.repaint();
}

void EqSection::setStandard (params::EqStandard standard, BlockFrame& owner)
{
    eqStandard = standard;
    if (! bassStandard())
        return;   // the guitar's is what the console was built as

    // THE TONE: the SGT-DI's three on the row (ourBands asks the standard).
    buildBands (ourBands());

    // THE CUTS: the switches become the bass's one pair, the combos under them its choices.
    hpfSw.attach (*state.getParameter (params::bassHpfOn));
    lpfSw.attach (*state.getParameter (params::bassLpfOn));
    for (const char* id : { params::bassHpf, params::bassLpf, params::bassHpfOn, params::bassLpfOn, params::bassHpfHz4,
                            params::bassHpfHz5, params::bassLpfHzFingers, params::bassLpfHzSlap })
        refreshAtts.push_back (attach (id));
    hpfSlopeBox.getText  = [this] { return bass::hpfWord (juce::roundToInt (raw (params::bassHpf))); };
    lpfSlopeBox.getText  = [this] { return bass::lpfWord (juce::roundToInt (raw (params::bassLpf))); };
    hpfSlopeBox.openMenu = [this] { bass::showHpfMenu (state, &hpfSlopeBox); };
    // FINGERS is a wider word than a slope's "12 DB": the choices write it up to their chevron and may run left of their
    // cell, into the room the console leaves there.
    hpfSlopeBox.setPaintingIsUnclipped (true);
    lpfSlopeBox.setPaintingIsUnclipped (true);
    lpfSlopeBox.openMenu = [this] { bass::showLpfMenu (state, &lpfSlopeBox); };

    // ...and as the walker has them, for a row that holds a pack's switches too: one line each, the cut always in.
    for (auto* line : { &strLine, &fingLine })
    {
        line->oneLine    = true;
        line->walkerLook = true;
    }
    strLine.setItems ("STR", { "4", "5" }, 1);
    fingLine.setItems ("STYL", { "F", "S" }, 0);
    strLine.setTooltip (bass::strHint);
    fingLine.setTooltip (bass::stylHint);
    strLine.onMenu  = [this] { bass::showHpfMenu (state, &strLine); };     // the frequencies each position stands for
    fingLine.onMenu = [this] { bass::showLpfMenu (state, &fingLine); };
    strAtt = std::make_unique<juce::ParameterAttachment> (*state.getParameter (params::bassHpf), [this] (float v)
    {
        strLine.setSelectedIndex (juce::roundToInt (v) == (int) params::BassHpf::four ? 0 : 1, juce::dontSendNotification);
    });
    fingAtt = std::make_unique<juce::ParameterAttachment> (*state.getParameter (params::bassLpf), [this] (float v)
    {
        fingLine.setSelectedIndex (juce::roundToInt (v), juce::dontSendNotification);
    });
    strLine.onChange = [this] (int i)
    {
        holdOn (params::bassHpfOn);
        strAtt->setValueAsCompleteGesture ((float) (i == 0 ? (int) params::BassHpf::four : (int) params::BassHpf::five));
    };
    fingLine.onChange = [this] (int i)
    {
        holdOn (params::bassLpfOn);
        fingAtt->setValueAsCompleteGesture ((float) i);
    };
    strAtt->sendInitialUpdate();
    fingAtt->sendInitialUpdate();

    // ...and they work across the chain, so they stay live with the block they stand on standing by.
    for (auto* c : { (juce::Component*) &hpfSw, (juce::Component*) &lpfSw, (juce::Component*) &hpfLabel, (juce::Component*) &lpfLabel,
                     (juce::Component*) &hpfSlopeBox, (juce::Component*) &lpfSlopeBox })
        owner.keepOutsideStandby (*c);

    refreshCurve();
}

void EqSection::SlopeCombo::paint (juce::Graphics& g)
{
    if (getIndex == nullptr && getText == nullptr)
        return;

    const auto r = getLocalBounds().toFloat();

    // "12 DB", not "12 DB/OCT". A cut cell inside a half-panel block is about sixty design units
    // wide, and the per-octave part was clipping its own first digit off — a slope that reads "2"
    // when it is twelve is worse than one that does not say the unit. Everyone reading a filter
    // slope knows what it is per.
    const auto text = getText != nullptr ? getText()
                                         : params::eqSlopes[juce::jlimit (0, params::eqSlopes.size() - 1, getIndex())]
                                               + juce::String (" DB");

    g.setColour (theme::txDim);
    if (getText != nullptr)
    {
        const auto font = theme::displayFont (13.0f);
        const float w   = theme::trackedWidth (text, font, 0.04f) + 2.0f;
        const auto  box = juce::Rectangle<float> (w, r.getHeight()).withRightX (r.getRight() - 12.0f).withY (r.getY());
        theme::drawTracked (g, text, box.getWidth() < r.getWidth() - 12.0f ? r.withTrimmedRight (11.0f) : box, font, 0.04f,
                            juce::Justification::centred);
    }
    else
        theme::drawTracked (g, text, r.withTrimmedRight (11.0f), theme::displayFont (13.0f), 0.04f,
                            juce::Justification::centred);

    // The chevron that says "this opens".
    juce::Path v;
    const float cx = r.getRight() - 9.0f, cy = r.getCentreY() - 1.0f;
    v.startNewSubPath (cx - 3.0f, cy);
    v.lineTo (cx, cy + 3.0f);
    v.lineTo (cx + 3.0f, cy);
    g.strokePath (v, juce::PathStrokeType (1.2f));
}

void EqSection::SlopeCombo::mouseDown (const juce::MouseEvent& e)
{
    if (openMenu != nullptr)
    {
        openMenu();
        return;
    }
    if (getIndex == nullptr || setIndex == nullptr)
        return;

    juce::PopupMenu m;
    for (int i = 0; i < params::eqSlopes.size(); ++i)
        m.addItem (i + 1, params::eqSlopes[i] + " dB/oct", true, i == getIndex());

    onfirst::show (m, this, juce::PopupMenu::Options()
                         .withTargetScreenArea ({ e.getScreenPosition().x,
                                                  e.getScreenPosition().y, 1, 1 }),
                     [safe = juce::Component::SafePointer<SlopeCombo> (this)] (int r)
                     {
                         if (r > 0 && safe != nullptr)
                             safe->setIndex (r - 1);
                     });
}

void EqSection::refreshHandles()
{
    using H = EqCurve::Handle;

    juce::Array<H> h;
    h.resize (numHandles);

    const auto& s = display.getSettings();

    // OUR bands only while the console is wearing them. In the device's own set the parametric is
    // out of the signal by definition — its points would be writing to something nobody can hear —
    // so the same five slots carry the DEVICE's dots instead: one per measured knob, pinned at the
    // frequency where that knob acts hardest, riding the composite, draggable only up and down.
    const bool ours = nativeDb == nullptr;

    if (ours)
    {
        curve.setMarkers ({});   // a device's dots do not survive the switch back to our own set

        h.getReference (hLo) = { s.loHz, s.loDb, H::Freedom::both, true,   theme::eqNode[0] };
        h.getReference (hB1) = { s.b1Hz, s.b1Db, H::Freedom::both, true,   theme::eqNode[1] };
        h.getReference (hB2) = { s.b2Hz, s.b2Db, H::Freedom::both, true,   theme::eqNode[2] };
        h.getReference (hB3) = { s.b3Hz, s.b3Db, H::Freedom::both, s.b3On, theme::eqNode[4] };
        h.getReference (hHi) = { s.hiHz, s.hiDb, H::Freedom::both, true,   theme::eqNode[3] };

        // The bass has BASS, MIDDLE and TREBLE only: no second bell, no scalpel to summon. MIDDLE's point moves sideways
        // — its frequency, 200 Hz … 3 kHz, the SGT-DI's swept mid (the owner, 01.11: the point is the control, no rail);
        // BASS and TREBLE stand at their frequencies, up and down only.
        if (bassStandard())
        {
            h.getReference (hB2).visible = h.getReference (hB3).visible = false;
            h.getReference (hLo).freedom = h.getReference (hHi).freedom = H::Freedom::gain;
        }
    }
    else
    {
        // The device's own tone is not ours to grab. Its points are MARKERS — they say where each
        // knob acts hardest, and the knob in the row below is the hand. A dot was a poor hand
        // anyway: its drag converted decibels into knob travel through a single measured swing,
        // and the code said so out loud — "the floor keeps the hand in charge without lying much".
        // As an indicator the anchor is honest; as a control it was not.
        juce::Array<EqCurve::Marker> markers;

        for (size_t j = 0; j < bands.size(); ++j)
            if (bands[j].anchorHz > 0.0)
                markers.add ({ bands[j].anchorHz, bands[j].colour });

        curve.setMarkers (std::move (markers));

        // And the five slots those dots used to occupy are hidden BY NAME. `Handle::visible`
        // defaults to true, so merely not filling them in would leave five default handles
        // standing at 1 kHz — grabbable, and wired to our parametric, which in this mode is not
        // even in the signal. That is the hidden-band bug, back through the door it left by.
        for (int slot : { hLo, hB1, hB2, hB3, hHi })
            h.getReference (slot).visible = false;
    }

    // The cuts only exist while they are switched on — a handle for a filter that is not in the
    // chain would be a control over nothing. Orange HPF, violet LPF, same as their switches.
    h.getReference (hHpf) = { s.hpfHz, 0.0, H::Freedom::freq, s.hpfOn, theme::orange };
    h.getReference (hLpf) = { s.lpfHz, 0.0, H::Freedom::freq, s.lpfOn, theme::violet };
    // The bass's cuts are drawn, not dragged here: their frequencies are their switches' menus' steps.
    if (bassStandard())
        h.getReference (hHpf).visible = h.getReference (hLpf).visible = false;

    curve.setHandles (std::move (h));
}

void EqSection::handleDragged (int index, double hz, double db)
{
    const auto clampDb = [] (double v) { return juce::jlimit (-15.0, 15.0, v); };

    switch (index)
    {
        // The handles and the row are the same four bands in the same order, so the index IS the
        // band. A curve that knew four names would be a second place to keep the list.
        case hLo: setBandDb (0, db); break;
        case hB1: setBandDb (1, db); break;
        case hB2: setBandDb (2, db); break;
        case hHi: setBandDb (bassStandard() ? 2 : 3, db); break;   // the bass's TREBLE is its third
        case hB3: b3DbAtt->setValueAsPartOfGesture ((float) clampDb (db)); break;
        default: break;
    }

    if (bassStandard() && index == hB1)
        hz = juce::jlimit ((double) params::bassMidMinHz, (double) params::bassMidMaxHz, hz);   // MID FREQ's span

    freqAtt[index]->setValueAsPartOfGesture ((float) hz);
    refreshCurve();
}

void EqSection::handleDragActive (int index, bool active)
{
    // One drag is ONE undoable move. The gain knobs bracket their own gestures; the frequencies
    // (and B3's gain, which has no knob) are bracketed here.
    if (active)
    {
        freqAtt[index]->beginGesture();
        if (index == hB3) b3DbAtt->beginGesture();
    }
    else
    {
        freqAtt[index]->endGesture();
        if (index == hB3) b3DbAtt->endGesture();
    }
}

void EqSection::handleWheel (int index, float delta)
{
    // Over a bell the wheel is Q; over a wall it is the slope ladder.
    if (index == hB1 || index == hB2 || index == hB3)
    {
        const int b = index == hB1 ? 0 : index == hB2 ? 1 : 2;
        const float q = raw (params::eqBellQ (link, b));
        qAtt[b]->setValueAsCompleteGesture (q * std::pow (1.6f, delta * 4.0f));
        return;
    }

    if (index == hHpf || index == hLpf)
        stepSlope (index, delta > 0 ? 1 : -1);
}

void EqSection::stepSlope (int index, int steps)
{
    if (index != hHpf && index != hLpf)
        return;

    auto& att = index == hHpf ? hpfSlopeAtt : lpfSlopeAtt;
    const auto id = index == hHpf ? params::eqHpfSlope (link) : params::eqLpfSlope (link);
    const int next = juce::jlimit (0, params::eqSlopes.size() - 1,
                                   juce::roundToInt (raw (id)) + steps);
    att->setValueAsCompleteGesture ((float) next);
}

void EqSection::curveDoubleClicked (double hz)
{
    // Only in OUR set. Wearing the device's tone the parametric is out of the signal entirely, so
    // summoning the scalpel there was a gesture with no consequence — and now that the device's
    // dots are markers, a double-click ON one of them reads as a double-click on empty curve,
    // which would have made that silent gesture easy to trip over by accident.
    if (nativeDb != nullptr || bassStandard())   // the bass has no scalpel
        return;

    // The surgical bell lands where you asked for it, switched on, flat — pull it down.
    freqAtt[hB3]->setValueAsCompleteGesture ((float) hz);
    b3OnAtt->setValueAsCompleteGesture (1.0f);
}

void EqSection::handleDoubleClicked (int index)
{
    if (index == hB3)
        b3OnAtt->setValueAsCompleteGesture (0.0f);
}

void EqSection::layOutRow (juce::Rectangle<int> row)
{
    // The control row: [HPF sw][LO][B1][B2][HI][LPF sw], gain knobs only, and under each switch its
    // slope combo.
    //
    // The frequencies used to be written out under every cell and are not any more. Keeping the
    // numbers meant either shrinking the type below what can be read at 1x or taking the room from
    // the curve, and the curve IS the readout — a node's frequency is where the node is standing.
    // Dragging it sideways was always the way to set one.
    //
    // ONE LINE OF NAMES. HPF, LO, L MID, H MID, HI, LPF all begin at the row's top edge, because
    // six labels at three different heights read as three groups rather than one row of controls.
    // A knob draws its own name in the first `labelRowHeight` of its bounds, so the knobs are set
    // flush with the top of the row rather than centred in their cells — then the cuts' labels,
    // given the same height, land on the same baseline for free.
    //
    // The cut cells are narrower than the knob cells on purpose: a switch and "12 DB" need less
    // width than a dial does, and what they give up goes into the dials, which is the only place
    // in this row where extra width becomes something you can aim at.
    // The cut cells are a fixed width and the bands share what is left, however many there are: a
    // device that measured one Tone control gets one big centred dial rather than one dial and
    // three holes where our other three used to be.
    // A block's own switches stand inside the cuts, where it asked for room (setInnerCells): HPF, the first, the dials,
    // the second, LPF.
    const int n     = juce::jmax (1, (int) bandKnobs.size());

    // ON THE BASS WITH A PACK'S SWITCHES, every switch on ONE LINE as the walker has them, two a side of the dials (the
    // owner, 02.11 and 03.11): STR 4 / 5 over the pack's first left of them, FING / SLAP over its second right of them,
    // each side's slots in one column. The cuts are always in there, as on the walker — opened so by the processor where
    // its pack has switches (OrbitBassStart.cpp), never written by a layout: a window coming up moves no parameter.
    if (bassStandard() && (innerW[0] > 0 || innerW[1] > 0))
    {
        walkerLines = true;
        for (juce::Component* c : { (juce::Component*) &hpfSw, (juce::Component*) &lpfSw, (juce::Component*) &hpfLabel,
                                    (juce::Component*) &lpfLabel, (juce::Component*) &hpfSlopeBox, (juce::Component*) &lpfSlopeBox })
            c->setVisible (false);
        strLine.setVisible (true);
        fingLine.setVisible (true);

        constexpr int lineH = ToggleSwitch::slotH + 4;
        const auto sideOf = [] (const ToggleSwitch& top, const ToggleSwitch* under)
        {
            float left = top.leftPart(), right = top.rightPart();
            if (under != nullptr)
            {
                left  = juce::jmax (left, under->leftPart());
                right = juce::jmax (right, under->rightPart());
            }
            return std::pair { left, right };
        };
        const auto [l0, r0] = sideOf (strLine, innerToggles[0]);
        const auto [l1, r1] = sideOf (fingLine, innerToggles[1]);
        const int leftW  = juce::roundToInt (std::ceil (l0 + (float) ToggleSwitch::slotW + r0)) + 2;
        const int rightW = juce::roundToInt (std::ceil (l1 + (float) ToggleSwitch::slotW + r1)) + 2;
        const auto left  = row.removeFromLeft (leftW);
        const auto right = row.removeFromRight (rightW);
        layBands (row);

        const auto lineOf = [] (juce::Rectangle<int> side, int which)
        {
            const int centre = side.getY() + (which == 0 ? side.getHeight() / 3 : 2 * side.getHeight() / 3);
            return juce::Rectangle<int> (side.getX(), centre - lineH / 2, side.getWidth(), lineH);
        };
        strLine.slotAt  = l0;
        fingLine.slotAt = l1;
        strLine.setBounds (lineOf (left, 0));
        fingLine.setBounds (lineOf (right, 0));
        if (innerToggles[0] != nullptr) innerToggles[0]->slotAt = l0;
        if (innerToggles[1] != nullptr) innerToggles[1]->slotAt = l1;
        innerCells[0] = innerW[0] > 0 ? lineOf (left, 1) : juce::Rectangle<int>();
        innerCells[1] = innerW[1] > 0 ? lineOf (right, 1) : juce::Rectangle<int>();
        return;
    }

    if (walkerLines)
    {
        walkerLines = false;
        strLine.setVisible (false);
        fingLine.setVisible (false);
        for (juce::Component* c : { (juce::Component*) &hpfSw, (juce::Component*) &lpfSw, (juce::Component*) &hpfLabel,
                                    (juce::Component*) &lpfLabel, (juce::Component*) &hpfSlopeBox, (juce::Component*) &lpfSlopeBox })
            c->setVisible (true);
    }

    const auto hpfCell = row.removeFromLeft (cutW);
    innerCells[0] = row.removeFromLeft (innerW[0]);
    const auto lpfCell = row.removeFromRight (cutW);
    innerCells[1] = row.removeFromRight (innerW[1]);

    // The whole cell, not a square of it: the name over the dial is 13 px now, and MIDDLE at that
    // size is wider than the dial under it. The knob draws its dial at the smaller of the two
    // sides that are left, centred, so the dial is the size it was.
    const juce::Rectangle<int> firstCell = row.withWidth (row.getWidth() / n);
    layBands (row);

    // The cuts hang off the first knob's geometry, so an empty row still has to put them somewhere.
    const auto first = bandKnobs.empty() ? firstCell : bandKnobs.front()->getBounds();
    const int labelH  = bandKnobs.empty() ? labelRowH : bandKnobs.front()->labelRowHeight;

    // A cut's cell is a stack — the name, the switch, the slope — standing on the SAME bottom
    // line as the dials: the slope combo's underside is the dials' underside, so the row is as
    // tall as a dial and not a combo taller. The switch rides just above the slope.
    const auto switchCell = [&] (juce::Rectangle<int> cell, ZoneSwitch& sw, juce::Label& label,
                                 SlopeCombo& combo)
    {
        label.setBounds (cell.removeFromTop (labelH));

        combo.setBounds (juce::Rectangle<int> (cell.getX(), first.getBottom() - 18, cell.getWidth(), 18));
        sw.setBounds (juce::Rectangle<int> (cell.getX(), combo.getY() - 4 - 16, cell.getWidth(), 16)
                          .withSizeKeepingCentre (juce::jmin (cell.getWidth(), 30), 16));
    };

    switchCell (hpfCell, hpfSw, hpfLabel, hpfSlopeBox);
    switchCell (lpfCell, lpfSw, lpfLabel, lpfSlopeBox);

    // The block's own switches from the names' line down to the cuts' switches' foot: the line under is the cuts'
    // choices', which may run over them (FINGERS).
    for (auto& cell : innerCells)
        if (! cell.isEmpty())
            cell.setBottom (hpfSw.getBottom());

    // The bass's choices may run left of their cells (FINGERS): over the knob beside them, not under it.
    if (bassStandard())
    {
        hpfSlopeBox.toFront (false);
        lpfSlopeBox.toFront (false);
    }

}

void EqSection::holdOn (const char* paramId)
{
    if (auto* p = state.getParameter (paramId); p != nullptr && p->getValue() < 0.5f)
    {
        p->beginChangeGesture();
        p->setValueNotifyingHost (1.0f);
        p->endChangeGesture();
    }
}

void EqSection::layOutCurve (juce::Rectangle<int> area)
{
    // The curve is the whole well it was given; whose tone it wears is the page's name, in the well's corner.
    curve.setBounds (area);
}

} // namespace orbitamp
