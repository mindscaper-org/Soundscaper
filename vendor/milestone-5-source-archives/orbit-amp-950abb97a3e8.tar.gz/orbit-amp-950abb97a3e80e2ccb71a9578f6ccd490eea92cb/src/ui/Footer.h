// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#pragma once

#include "Theme.h"

#include <felitronics/appkit/VersionBadge.h>
#include <felitronics/appkit/chrome/FlatButtons.h>
#include <juce_audio_processors/juce_audio_processors.h>

namespace orbitamp
{

class AmpProcessor;

/** The bottom strip: facts about the RUN rather than about the sound.

    Oversampling, the host's sample rate, and what the plugin is costing. None of these belong on a
    block — a block says what the amp is, and this says what the machine is doing. It is the same
    shape as the sibling EQ's footer: flat items whose menus open upward, and readouts beside them.

    Sample rate and load are polled rather than pushed: the audio thread should not be reaching into
    a view, and nobody needs either number sooner than a few times a second. */
class Footer final : public juce::Component,
                     private juce::Timer
{
public:
    explicit Footer (AmpProcessor&);
    ~Footer() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    /** One line at the house floor of 13: the facts stand in the right half of the tuner's row,
        which centres them on the tuner. */
    static constexpr int designHeight = 26;

    /** The version window — the build stamp, the licence, the short trademark notice and the tip
        jar — opened by a click on the stamp itself. It used to have a second door in the gear's
        menu, and the menu is a window now; nothing was lost, because the door that remains is the
        one that was always right: the words the page is ABOUT. */
    void showAbout() { versionBadge.showAbout(); }

    /** DEVICES & TRADEMARKS was reached from the gear's menu, and the gear is a window now. Its
        door belongs down here anyway: the page is a LIST of what is installed on this machine,
        which is a fact about the run, like the sample rate and the load beside it — and it ends
        up next to the build stamp, the other page that is only ever read. */
    std::function<void()> onDevices;

private:
    juce::Component::SafePointer<juce::CallOutBox> loadBox;   // the load window up now (openLoadBreakdown)
    void timerCallback() override;
    void showLoadBreakdown();

    /** Where every fact stands — one answer for paint() and resized(), which must never disagree.
        One line across the whole half: each fact as wide as its LONGEST reading (so a number that
        moves never moves its neighbours), the room left over shared out evenly between them. */
    struct Places { juce::Rectangle<int> stereo, rate, load, devices, stamp; };
    Places places() const;

    int stereoSlotW = 0;   // the stereo item's place: its longest word, MONO | STEREO | STEREO SPACE

    AmpProcessor& amp;

    felitronics::appkit::chrome::FlatItem stereo;

    /** Numbers on this strip are doors: an invisible target over the painted text, and the click
        opens what the number is about. The DSP figure opens the per-stage breakdown; the stamp
        opens appkit's version popover. */
    struct ClickTarget final : public juce::Component,
                              public juce::SettableTooltipClient
    {
        std::function<void()> onClick;
        void mouseDown  (const juce::MouseEvent&) override { if (onClick) onClick(); }

        // The painted text lives in the parent, so the parent is what repaints: the strip lifts the
        // words under the cursor, which is the only thing here that says they can be pressed.
        void mouseEnter (const juce::MouseEvent&) override { if (auto* p = getParentComponent()) p->repaint(); }
        void mouseExit  (const juce::MouseEvent&) override { if (auto* p = getParentComponent()) p->repaint(); }
    };

    ClickTarget loadBadge;
    ClickTarget devicesBadge;
    ClickTarget stampBadge;

    /** A LINK'S BOX (the bass, the owner 01.11): OCTAVE, ENVELOPE or CHORUS in the plug-in or out — a short word in a
        box, violet while in, see-through while out; its whole name a hint. Out, the block leaves the face and the strip and makes no sound (its `*_present`); a click is one undo
        step. They stand where the guitar's MONO | STEREO does — the bass has none. */
    struct PresenceBox final : public juce::Component,
                               public juce::SettableTooltipClient
    {
        PresenceBox (AmpProcessor& processor, const char* paramId, const juce::String& word, const juce::String& hint);
        void paint (juce::Graphics&) override;
        void mouseDown  (const juce::MouseEvent&) override;
        void mouseEnter (const juce::MouseEvent&) override { repaint(); }
        void mouseExit  (const juce::MouseEvent&) override { repaint(); }
        bool on() const;

        AmpProcessor& amp;
        juce::RangedAudioParameter& param;
        const juce::String word;
        std::unique_ptr<juce::ParameterAttachment> att;
    };

    std::vector<std::unique_ptr<PresenceBox>> presence;
    static constexpr int boxW = 36, boxGap = 4;

    /** appkit's version badge, kept INVISIBLE and only for its window — the whole build stamp, the
        opt-in update check and the family's tip jar, one `showPopup()` away (public since appkit
        v0.11.3). Its own face paints two lines, which is right for a toolbar corner and wrong for
        one line of this block. So this strip paints the stamp itself, in its own voice — and the
        badge stays as the popover's anchor, sized to that text so the callout points at it.

        The strip, not the toolbar, for the reason everything else on this line is here: it is a fact
        about the RUN, not about the sound — and the toolbar has no room to spare either. */
    felitronics::appkit::VersionBadge versionBadge;

    std::unique_ptr<juce::ParameterAttachment> stereoAttachment;

    juce::String rateText, loadText;
    juce::String stampText;            // "V0.2.0 · STANDALONE" — fixed for the life of the window
    bool  updateDot  = false;          // a stored release is newer than this build
    float loadPercent = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Footer)
};

} // namespace orbitamp
