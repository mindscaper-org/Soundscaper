// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "ReverbBlock.h"

#include "../Parameters.h"
#include "Prefs.h"
#include "../PluginProcessor.h"
#include "OnFirst.h"

#include <felitronics/analysis/PlotMap.h>

namespace orbitamp
{

namespace
{
    constexpr float kFMin = 20.0f, kFMax = 20000.0f;

    float xForFreq (juce::Rectangle<float> r, float f)
    {
        return r.getX() + r.getWidth() * std::log (f / kFMin) / std::log (kFMax / kFMin);
    }

    float freqForX (juce::Rectangle<float> r, float x)
    {
        const float t = juce::jlimit (0.0f, 1.0f, (x - r.getX()) / juce::jmax (1.0f, r.getWidth()));
        return kFMin * std::pow (kFMax / kFMin, t);
    }
}

ReverbBlock::ReverbBlock (AmpProcessor& processor)
    : BlockFrame ("Reverb", BlockFrame::Kind::dsp), amp (processor)
{
    startTimerHz (30);
    (void) display.prepare (displayRate, (int) (displayRate * tailSeconds), 2);   // 48 kHz, two channels: cannot refuse

    addAndMakeVisible (character);
    addAndMakeVisible (view);
    addAndMakeVisible (mix);
    addAndMakeVisible (decay);
    addAndMakeVisible (pre);
    addAndMakeVisible (lowCut);
    attachPower (*amp.apvts.getParameter (params::reverbOn));

    // The character IS the block's name: PLATE or HALL on the border where REVERB stood, set like
    // a name and in the block's colour. A quarter-width block has no room for both, and the
    // colour already says which kind of block this is.
    showTitle = false;
    {
        juce::Array<VoicingSelector::Entry> entries;
        for (const auto& name : params::reverbCharacters)
            entries.add ({ name, 0, false });
        character.setEntries (std::move (entries));
    }
    character.fontHeight = 16.0f;
    character.tracking   = 0.15f;
    character.boxed      = false;
    character.tint       = theme::lilac;

    mix.textForValue   = [] (double v) { return juce::String (juce::roundToInt (v)) + "%"; };
    decay.textForValue = [] (double v) { return juce::String (v, 1) + "x"; };
    pre.textForValue   = [] (double v) { return juce::String (juce::roundToInt (v)); };
    lowCut.textForValue = [] (double v) { return juce::String (juce::roundToInt (v)); };
    mix.setHint    ("MIX:   how much of the room rides over the dry");
    decay.setHint  ("DECAY:   how long the tail rings, times the character's own");
    pre.setHint    ("PRE:   the tail held back so the attack stays dry, in ms");
    lowCut.setHint ("LOW CUT:   the tail's lows cut away so the room never booms, in Hz: the dashed line on the picture");

    mix.setFader (true);

    for (auto* k : { &mix, &decay, &pre, &lowCut })
    {
        k->labelFontHeight = Knob::fxLabelH;   // the delay's names, the delay's size
        k->labelTracking   = Knob::fxLabelTracking;
        k->labelRowHeight  = Knob::fxLabelRowH;
        k->valueInDial     = false;
        k->setValueRowShown (true);
    }

    mix.onValueChange   = [this] { refreshTail(); };
    decay.onValueChange = [this] { refreshTail(); };
    pre.onValueChange   = [this] { refreshTail(); };

    characterAttachment = std::make_unique<juce::ParameterAttachment> (
        *amp.apvts.getParameter (params::reverbType),
        [this] (float v)
        {
            character.setSelection (juce::roundToInt (v));
            refreshTail();
            resized();   // the name on the border is as wide as the name
        });

    character.onPick = [this] (int i) { characterAttachment->setValueAsCompleteGesture ((float) i); };

    mixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        amp.apvts, params::reverbMix, mix);
    decayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        amp.apvts, params::reverbDecay, decay);
    preAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        amp.apvts, params::reverbPredelay, pre);
    lowCutAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        amp.apvts, params::reverbHpfHz, lowCut);

    // The tail's HPF: the consoles' cut, at home in the reverb and ALWAYS in — the dashed
    // vertical is the handle, the curve is what it does, and there is nothing to switch.
    hpfHzAtt = std::make_unique<juce::ParameterAttachment> (
        *amp.apvts.getParameter (params::reverbHpfHz), [this] (float) { view.repaint(); });

    const auto plain = [this] (const char* id)
    {
        auto* p = amp.apvts.getParameter (id);
        return p->convertFrom0to1 (p->getValue());
    };

    view.hitCut = [this, plain] (juce::Point<float> pos)
    {
        return std::abs (pos.x - xForFreq (view.getLocalBounds().toFloat(),
                                           plain (params::reverbHpfHz))) < 14.0f;
    };

    // Right-click: the block's own gear — the current reverb back to what it ships as. The
    // character stays; a reset is "clean the room", not "move house".
    view.onMenu = [this]
    {
        juce::PopupMenu m;
        m.addItem (1, "RESET TO DEFAULT");
        onfirst::show (m, this, juce::PopupMenu::Options().withMousePosition(),
                         [safe = juce::Component::SafePointer<ReverbBlock> (this)] (int rr)
                         {
                             if (safe == nullptr || rr != 1)
                                 return;

                             for (const char* id : { params::reverbMix, params::reverbDecay,
                                                     params::reverbPredelay, params::reverbHpfHz })
                                 if (auto* p = safe->amp.apvts.getParameter (id))
                                 {
                                     p->beginChangeGesture();
                                     p->setValueNotifyingHost (safe->amp.engineDefault (*p));
                                     p->endChangeGesture();
                                 }
                         });
    };

    view.onCut = [this] (float x, int phase)
    {
        if (phase == 0) hpfHzAtt->beginGesture();

        auto* p = amp.apvts.getParameter (params::reverbHpfHz);
        const auto range = amp.apvts.getParameterRange (params::reverbHpfHz);
        juce::ignoreUnused (p);
        hpfHzAtt->setValueAsPartOfGesture (
            juce::jlimit (range.start, range.end,
                          freqForX (view.getLocalBounds().toFloat(), x)));

        if (phase == 2) hpfHzAtt->endGesture();
    };

    view.paintBody = [this, plain] (juce::Graphics& g, juce::Rectangle<float> r)
    {
        // The ground and its bones: a dark well and the decade lines.
        g.setColour (juce::Colour (0xff101016));
        g.fillRoundedRectangle (r, theme::radiusSm);

        for (const float f : { 100.0f, 1000.0f, 10000.0f })
        {
            const float x = xForFreq (r, f);
            g.setColour (juce::Colour (0x14ffffff));
            g.drawVerticalLine ((int) x, r.getY() + 2.0f, r.getBottom() - 2.0f);
            g.setColour (juce::Colour (0x55b0b0b0));
            g.setFont (theme::displayFont (8.5f));
            g.drawText (f < 1000.0f ? "100" : f < 10000.0f ? "1K" : "10K",
                        juce::Rectangle<float> (x + 3.0f, r.getBottom() - 13.0f, 30.0f, 11.0f),
                        juce::Justification::topLeft, false);
        }

        // The pair: the door as the quiet grey ground, the ADDED tail in the block's violet —
        // and the decay is how long the violet keeps glowing after the note.
        felitronics::analysis::PlotMap pm;
        pm.width      = r.getWidth();
        pm.height     = r.getHeight();
        pm.plotBottom = r.getHeight();
        pm.freqMin    = (double) kFMin;
        pm.freqMax    = (double) kFMax;
        pm.specTop    = 0.0;
        pm.specBottom = -90.0;

        const double fs = juce::jmax (8000.0, amp.currentSampleRate());

        const bool spectraOn = prefs::spectraShown (amp.product());   // the gear's one switch for every analyser

        const auto draw = [&] (felitronics::analysis::SpectrumPane& pane, juce::Colour tint,
                               float fillTop, float fillBottom, float line)
        {
            juce::Path fill, peak;
            fill.startNewSubPath (r.getX(), r.getBottom());
            bool first = true;

            pane.buildColumns (pm, fs, 4.5, 1000.0,
                               [&] (int, float x, float yFill, float yPeak)
                               {
                                   fill.lineTo (r.getX() + x, r.getY() + yFill);

                                   // At the floor the comb LEAVES through it instead of crawling
                                   // along it: a point pinned to the plot's bottom is pushed past
                                   // the component's edge, and the clip swallows the run between
                                   // two sunken points — both flanks vanish under the floor.
                                   const float yp = yPeak >= r.getHeight() - 1.5f
                                                        ? r.getBottom() + 4.0f
                                                        : r.getY() + yPeak;

                                   if (first) { peak.startNewSubPath (r.getX() + x, yp); first = false; }
                                   else       peak.lineTo (r.getX() + x, yp);
                               });

            fill.lineTo (r.getRight(), r.getBottom());
            fill.closeSubPath();

            g.setGradientFill (juce::ColourGradient (tint.withAlpha (fillTop),
                                                     0.0f, r.getY() + r.getHeight() * 0.30f,
                                                     tint.withAlpha (fillBottom),
                                                     0.0f, r.getBottom(), false));
            g.fillPath (fill);
            g.setColour (tint.withAlpha (line));
            g.strokePath (peak, juce::PathStrokeType (1.0f));
        };

        if (spectraOn)
        {
            draw (panes[0], theme::spectrum, 0.14f, 0.02f, 0.30f);   // the door
            draw (panes[1], theme::orange,   0.18f, 0.02f, 0.55f);   // what the room adds — the cab's own pairing
        }

        // The decay envelope over it all — the reverb's signature silhouette, an impulse's peak
        // level over time. Another axis on purpose: it is a STAMP, not a second plot — the one
        // shape that says how long this room breathes.
        // Only where the room sounds: from its first bucket over the floor to its last — the predelay's silence and the
        // died-away tail draw nothing, and a bucket of the noisy end that falls under the floor lies ON it, not thrown
        // through it in a long end (Oleh, 03.11).
        const auto up = [this] (size_t i) { return juce::jlimit (0.0f, 1.0f, (tailEnv[i] + 60.0f) / 60.0f); };
        size_t from = 0, to = tailEnv.size();
        while (from < to && up (from) <= 0.001f) ++from;
        while (to > from && up (to - 1) <= 0.001f) --to;

        if (to - from >= 2)
        {
            const auto inner = r.reduced (4.0f);

            // The stroke is the envelope's TOP alone — a closed path drew its own floor and read
            // as an axis nobody asked for. The fill still closes along the bottom, quietly.
            juce::Path line;
            const auto xAt = [&] (size_t i) { return inner.getX() + inner.getWidth() * (float) i / (float) (tailEnv.size() - 1); };

            for (size_t i = from; i < to; ++i)
            {
                const float y = inner.getBottom() - up (i) * inner.getHeight();
                if (i == from) line.startNewSubPath (xAt (i), y);
                else           line.lineTo (xAt (i), y);
            }

            juce::Path tp = line;
            tp.lineTo (xAt (to - 1), inner.getBottom());
            tp.lineTo (xAt (from),   inner.getBottom());
            tp.closeSubPath();

            g.setColour (theme::violet.withAlpha (0.10f));
            g.fillPath (tp);
            g.setColour (theme::violet.withAlpha (0.60f));
            g.strokePath (line, juce::PathStrokeType (1.2f));

            // In the top corner: the bottom one is where the frequencies are written, and the
            // seconds sat on the 10K (Oleh, 24.10).
            g.setColour (theme::txFaint);
            theme::drawTracked (g, juce::String (tailSeconds, 1) + " S", r.reduced (8.0f, 5.0f),
                                theme::displayFont (7.5f), 0.1f, juce::Justification::topRight);
        }

        // The tail's HPF, always in: the second-order curve and its dashed vertical — the
        // consoles' cut grammar, one Q, no ladder, no switch.
        {
            const float fc = plain (params::reverbHpfHz);

            // The cab picture's own placement: the passband rides low (0.62 of the height) and the
            // dive leaves through the floor — the curve is a hint under the spectra, not a plot
            // pinned to the ceiling.
            juce::Path curve;
            const int w = juce::jmax (2, (int) r.getWidth());
            const float top = r.getY() + r.getHeight() * 0.62f;
            const float bot = r.getY() + r.getHeight() * 1.30f;
            for (int px = 0; px < w; ++px)
            {
                const float f   = freqForX (r, r.getX() + (float) px);
                const float rr  = fc / juce::jmax (1.0f, f);
                const float mag = 1.0f / std::sqrt (1.0f + rr * rr * rr * rr);
                const float y   = bot - (bot - top) * mag;
                if (px == 0) curve.startNewSubPath (r.getX(), y);
                else         curve.lineTo (r.getX() + (float) px, y);
            }

            g.setColour (theme::orange.withAlpha (0.8f));
            g.strokePath (curve, juce::PathStrokeType (1.5f, juce::PathStrokeType::curved,
                                                       juce::PathStrokeType::rounded));

            const float x = xForFreq (r, fc);
            const float dashes[] = { 5.0f, 4.0f };
            g.setColour (theme::orange.withAlpha (view.dragging ? 1.0f : 0.65f));
            g.drawDashedLine ({ x, r.getY() + 2.0f, x, r.getBottom() - 2.0f },
                              dashes, 2, view.dragging ? 2.2f : 1.4f);
        }

        g.setColour (theme::hair2);
        g.drawRoundedRectangle (r.reduced (0.5f), theme::radiusSm, 1.0f);
    };

    characterAttachment->sendInitialUpdate();
}

ReverbBlock::~ReverbBlock() = default;

void ReverbBlock::refreshTail()
{
    const int index = juce::jlimit (0, params::reverbCharacters.size() - 1, character.getSelection());

    display.setCharacter (static_cast<felitronics::reverb::Character> (index));
    display.setMix ((float) mix.getValue() * 0.01f);
    display.setDecay ((float) decay.getValue());
    display.setPredelayMs ((float) pre.getValue());
    // A restart lands the room on its new setting at once — no ramp to run in before the impulse,
    // so the tail measured is the one the setting makes.
    display.reset();

    const int n = (int) (displayRate * tailSeconds);
    std::vector<float> left ((size_t) n, 0.0f), right ((size_t) n, 0.0f);
    float* channels[2] = { left.data(), right.data() };

    left[0] = right[0] = 1.0f;
    (void) display.process (channels, 2, n);   // prepared, two channels: cannot refuse

    // The stage ADDS the wet and leaves the dry alone — so the impulse itself is still sitting at
    // sample zero, and measured it would spike the envelope to 0 dB before the room says a word.
    // The silhouette is the TAIL's; take the dry back out.
    left[0] = right[0] = 0.0f;

    // Peak per bucket, in dB — the shape of the decay, not its every wiggle.
    std::vector<float> env ((size_t) tailBuckets, -60.0f);
    const int per = juce::jmax (1, n / tailBuckets);

    for (int b = 0; b < tailBuckets; ++b)
    {
        float peak = 0.0f;
        for (int i = b * per; i < juce::jmin (n, (b + 1) * per); ++i)
            peak = juce::jmax (peak, std::abs (left[(size_t) i]));

        env[(size_t) b] = peak > 1.0e-5f ? juce::Decibels::gainToDecibels (peak) : -60.0f;
    }

    // ...and from its loudest bucket on, the decay's top: never rising again, so the tail's wiggles about the floor
    // are not spikes thrown down to it (Oleh, 03.11).
    if (! env.empty())
    {
        const auto loudest = (size_t) (std::max_element (env.begin(), env.end()) - env.begin());
        for (auto i = env.size() - 1; i > loudest; --i)
            env[i - 1] = std::max (env[i - 1], env[i]);
    }

    tailEnv = std::move (env);
    view.repaint();
}

void ReverbBlock::timerCallback()
{
    if (! isBlockOn() || ! view.isShowing())
        return;

    for (size_t i = 0; i < panes.size(); ++i)
    {
        int order = 0;

        if (amp.reverbSpectrumTap[i].tryPull (panes[i].frameInput(), order)
            && order == AmpProcessor::eqSpectrumOrder)
            panes[i].ingest (order);
        else
            panes[i].starve();
    }

    view.repaint();
}

void ReverbBlock::layOutContent (juce::Rectangle<int> area)
{
    // The character on the border where the name would stand: at the left, sized to itself.
    {
        const auto slot = borderSlotArea();
        character.setBounds (slot.withWidth (juce::jmin (slot.getWidth(), character.idealWidth())));
        borderSlotUsed = character.getBounds();
    }

    // MIX a fader the box's whole height at the left, its number under it; at the right DECAY, PRE and
    // LOW CUT in even shares of a row, each number tucked up under its cap; the picture under them — the
    // delay's arrangement to the unit (DelayBlock::layOutContent; Oleh, 24.10).
    mix.setBounds (area.removeFromLeft (Knob::faderW));
    area.removeFromLeft (Knob::faderGap);

    const int lift = Knob::snugLift (Knob::fxSide);
    auto miniRow = area.removeFromTop (Knob::fxLabelRowH + Knob::fxSide + Knob::valueRowH - lift);
    const int cell = miniRow.getWidth() / 3;

    for (auto* k : { &decay, &pre, &lowCut })
        k->valueLift = lift;

    decay.setBounds  (miniRow.removeFromLeft (cell));
    pre.setBounds    (miniRow.removeFromLeft (cell));
    lowCut.setBounds (miniRow);

    area.removeFromTop (6);
    view.setBounds (area);
}

} // namespace orbitamp
