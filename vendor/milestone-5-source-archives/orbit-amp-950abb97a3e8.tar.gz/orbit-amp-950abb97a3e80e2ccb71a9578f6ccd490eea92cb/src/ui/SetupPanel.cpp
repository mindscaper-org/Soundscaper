// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "SetupPanel.h"

#include "../PluginProcessor.h"
#include "Prefs.h"
#include "Theme.h"

namespace orbitamp
{

SetupPanel::SetupPanel (AmpProcessor& processor)
    : amp (processor), preampDevices (processor.product().name, device::DeviceLibrary::ampSlot),
      irs (processor.product().irsFolder())
{
    setWantsKeyboardFocus (true);

    preampDevices.onChanged = [this]
    {
        if (onDevicesChanged)
            onDevicesChanged();
    };

    closeButton.onClick = [this] { setVisible (false); };

    // ---- LIBRARY: the two lists behind their own sub-tabs, and the one switch that is about
    //      the packs rather than about the window. ----
    // It is a HOLDER, not a surface: its own sub-tabs are painted by the panel behind it, so a
    // click in that strip has to fall through to the panel or the tabs cannot be picked at all.
    libraryPage.setInterceptsMouseClicks (false, true);
    addAndMakeVisible (libraryPage);
    for (auto* v : { (juce::Component*) &preampDevices, (juce::Component*) &irs })
        libraryPage.addAndMakeVisible (*v);
    libraryPage.addAndMakeVisible (packSwitches);

    libraries.push_back ({ "AMP", &preampDevices, [this] { preampDevices.rebuild(); }, {} });
    libraries.push_back ({ "IR",  &irs,           [this] { irs.rebuild(); },           {} });

    {
        auto* p = amp.apvts.getParameter (params::packLevelComp);

        packSwitches.setRows ({ { "PACK LEVEL COMP",
                                  "honour each capture's own level trim - travels with the preset",
                                  [p] { return p->getValue() > 0.5f; },
                                  [p] (bool on)
                                  {
                                      p->beginChangeGesture();
                                      p->setValueNotifyingHost (on ? 1.0f : 0.0f);
                                      p->endChangeGesture();
                                  },
                                  {}, false, {}, {}, {} } });
    }

    buildViewPage();

    viewView.setScrollBarsShown (true, false);
    viewView.setScrollBarThickness (8);
    viewView.setViewedComponent (&viewPage, false);
    addAndMakeVisible (viewView);

    buildTunerPage();
    addAndMakeVisible (tunerPage);

    pages.push_back ({ "LIBRARY", &libraryPage, [this] { libraries[(size_t) currentLibrary].refresh(); }, {} });
    pages.push_back ({ "VIEW",    &viewView,    [this] { buildViewPage(); }, {} });
    pages.push_back ({ "TUNER",   &tunerPage,   [this] { buildTunerPage(); }, {} });

    addAndMakeVisible (closeButton);
    selectLibrary (0);
    selectPage (0);
}

void SetupPanel::buildViewPage()
{
    std::vector<SettingsList::Row> rows;

    // A ROW'S GETTER IS POLLED, so it has to be cheap, and `prefs::getBool` is not: every call
    // takes the family's inter-process lock, reads the JSON off disk and parses it. Five rows at
    // ten a second is fifty locked file reads a second on the message thread, and a contended
    // lock can hold that thread for as long as its timeout. The value is read once, here, and
    // again whenever this window writes it.
    //
    // The trade, stated: a SECOND instance that has this page open at the same time will not see
    // the change until its own page is reopened, since `open()` and `selectPage()` rebuild these
    // rows. Two Setup windows side by side is a rarer thing than a locked file read fifty times a
    // second, and the stale one is a checkbox, not a sound.
    const auto add = [&] (juce::String name, juce::String note, juce::Identifier key, bool fallback)
    {
        auto held = std::make_shared<bool> (prefs::getBool (amp.product(), key, fallback));

        rows.push_back ({ std::move (name), std::move (note),
                          [held] { return *held; },
                          [this, key, held] (bool on)
                          {
                              *held = on;
                              prefs::setBool (amp.product(), key, on);
                              if (onViewChanged)
                                  onViewChanged();
                          },
                          {}, false, {}, {}, {} });
    };

    rows.push_back ({ "SHOW SPECTRA", "the analyser behind every curve and picture",
                      [this] { return prefs::spectraShown (amp.product()); },
                      [this] (bool on) { prefs::setSpectraShown (amp.product(), on); if (onViewChanged) onViewChanged(); },
                      {}, false, {}, {}, {} });

    if (params::demoLoopsPresent (amp.product().chain == Chain::bass))   // no loops on disk: no player, and no offer of one
        add ("SHOW DEMO PLAYER", "the audition strip under the footer", prefs::showDemo, false);

    add ("EQ HANDS OVER THE CURVE", "the console's row of knobs sits above its picture, not below",
         prefs::eqRowOnTop, false);

    add ("SHOW DEVICE GLYPHS", "the device-glyph review strip", prefs::showGlyphs, false);

    viewPage.setRows (std::move (rows));
}

void SetupPanel::buildTunerPage()
{
    std::vector<SettingsList::Row> rows;

    {
        SettingsList::Row floor;
        floor.name = "LEVEL FLOOR";
        floor.note = "the quietest the tuner still reads, dBFS - raise it if hum shows as a note";

        for (const int db : prefs::tunerFloors)
            floor.choices.add (juce::String (db));

        floor.chosen = [this]
        {
            for (int k = 0; k < (int) std::size (prefs::tunerFloors); ++k)
                if (prefs::tunerFloors[k] == prefs::tunerFloor (amp.product()))
                    return k;
            return -1;
        };
        floor.choose = [this] (int k) { prefs::setTunerFloor (amp.product(), prefs::tunerFloors[k]); };
        rows.push_back (std::move (floor));
    }

    {
        SettingsList::Row display;
        display.name = "DISPLAY";
        display.note = prefs::tunerPolyOffered ? "a needle; a strobe; poly - every string of a strum; auto - the needle, poly for a strum"
                                               : "a needle, or a strobe";
        display.choices.add ("NEEDLE");
        display.choices.add ("STROBE");
        if (prefs::tunerPolyOffered)
        {
            display.choices.add ("POLY");
            display.choices.add ("AUTO");
        }
        display.chosen = [this] { return (int) prefs::tunerDisplay (amp.product()); };
        display.choose = [this] (int k) { prefs::setTunerDisplay (amp.product(), (prefs::TunerDisplay) k); };
        rows.push_back (std::move (display));
    }

    {
        // The product's own tunings: a guitar amp's the guitar's, a bass amp's the bass's.
        const auto own = core::polyTunings (prefs::tunesBass (amp.product()));
        SettingsList::Row tuning;
        tuning.name = "TUNING";
        tuning.note = "the open strings poly reads";
        for (const auto& t : own)
            tuning.choices.add (core::polyTuningName (t).pill);
        tuning.chosen = [this, own]
        {
            for (size_t k = 0; k < own.size(); ++k)
                if (&own[k] == &prefs::tunerTuning (amp.product()))
                    return (int) k;
            return -1;
        };
        tuning.choose = [this, own] (int k) { prefs::setTunerTuning (amp.product(), own[(size_t) k]); };
        if (prefs::tunerPolyOffered)
            rows.push_back (std::move (tuning));
    }

    tunerPage.setRows (std::move (rows));
}

void SetupPanel::open()
{
    pages[(size_t) currentPage].refresh();

    setVisible (true);
    toFront (false);
    grabKeyboardFocus();
}

void SetupPanel::selectPage (int index)
{
    currentPage = index;

    for (int i = 0; i < (int) pages.size(); ++i)
        pages[(size_t) i].view->setVisible (i == currentPage);

    pages[(size_t) currentPage].refresh();
    resized();
    repaint();
}

void SetupPanel::selectLibrary (int index)
{
    currentLibrary = index;

    for (int i = 0; i < (int) libraries.size(); ++i)
        libraries[(size_t) i].view->setVisible (i == currentLibrary);

    libraries[(size_t) currentLibrary].refresh();
    resized();
    repaint();
}

void SetupPanel::layOutTabs (juce::Rectangle<int>& header, std::vector<Tab>& tabs, float height)
{
    const auto font = theme::displayFont (height);

    for (auto& tab : tabs)
    {
        const int w = juce::roundToInt (theme::trackedWidth (tab.title, font, 0.15f)) + 22;
        tab.area = header.removeFromLeft (w);
    }
}

void SetupPanel::resized()
{
    // FITS, always. The editor shrinks with its layout, and the one window a player uses to put
    // the missing rows back is the last thing that may go off the top edge.
    panel = getLocalBounds().withSizeKeepingCentre (juce::jmin (getWidth()  - 24, panelW),
                                                    juce::jmin (getHeight() - 24, panelH));

    auto r = panel.reduced (16, 12);

    auto header = r.removeFromTop (headerH);
    closeButton.setBounds (header.removeFromRight (24).withSizeKeepingCentre (22, 22));

    header.removeFromLeft (juce::roundToInt (
        theme::trackedWidth ("SETUP", theme::displayFont (13.0f), 0.15f)) + 28);

    layOutTabs (header, pages, 13.0f);

    r.removeFromTop (6);

    for (auto& page : pages)
        page.view->setBounds (r);

    // The scrolled pages are as tall as their rows; the viewport is the window onto them.
    viewPage.setSize (r.getWidth() - 10, viewPage.getHeight());

    // LIBRARY's own body: its sub-tabs, then whichever list they picked, then the pack switch.
    {
        auto lib = libraryPage.getLocalBounds();
        auto sub = lib.removeFromTop (subHeaderH);
        layOutTabs (sub, libraries, 13.0f);

        auto packRow = lib.removeFromBottom (SettingsList::rowH);
        packSwitches.setBounds (packRow);

        for (auto& tab : libraries)
            tab.view->setBounds (lib);
    }
}

void SetupPanel::paintTabs (juce::Graphics& g, const std::vector<Tab>& tabs, int current,
                            float height, juce::Point<int> offset) const
{
    const auto font = theme::displayFont (height);

    for (int i = 0; i < (int) tabs.size(); ++i)
    {
        const auto& tab = tabs[(size_t) i];
        const bool active = i == current;
        const auto area = tab.area.translated (offset.x, offset.y);

        g.setColour (active ? theme::tx : theme::txDim);
        theme::drawTracked (g, tab.title, area.toFloat(), font, 0.15f, juce::Justification::centred);

        if (active)
        {
            g.setColour (theme::violet);
            g.fillRect (area.withTrimmedTop (area.getHeight() - 2).reduced (4, 0));
        }
    }
}

void SetupPanel::paint (juce::Graphics& g)
{
    // The scrim IS the modality: the device stays visible but unmistakably behind.
    g.fillAll (theme::ground.withAlpha (0.78f));

    const auto p = panel.toFloat();
    g.setColour (theme::panel);
    g.fillRoundedRectangle (p, theme::radiusLg);
    g.setColour (theme::hair2);
    g.drawRoundedRectangle (p.reduced (0.75f), theme::radiusLg, 1.5f);

    const auto header = panel.reduced (16, 12).removeFromTop (headerH);
    g.setColour (theme::tx);
    theme::drawTracked (g, "SETUP", header.toFloat(), theme::displayFont (13.0f), 0.15f,
                        juce::Justification::centredLeft);

    paintTabs (g, pages, currentPage, 13.0f);

    // Which lifetime this page has, said quietly under its own tabs rather than left to be
    // discovered when somebody's preset rearranges somebody else's window.
    // LIBRARY is the page with two answers — the folders are this machine's, the one switch on it
    // rides in the preset — and saying NOTHING was the worst of the answers: a page with no note
    // reads as a page nobody thought about, not as a page whose answer is "both".
    const juce::String lifetime = currentPage == 1 ? juce::String ("THIS MACHINE ONLY")
                                                   : juce::String ("FOLDERS: THIS MACHINE");

    {
        auto note = panel.reduced (16, 12).removeFromTop (headerH).removeFromRight (330)
                         .withTrimmedRight (30);
        g.setColour (theme::txFaint);
        theme::drawTracked (g, lifetime, note.toFloat(), theme::displayFont (13.0f), 0.15f,
                            juce::Justification::centredRight);
    }

    if (currentPage == 0)
        paintTabs (g, libraries, currentLibrary, 13.0f, libraryPage.getPosition());
}

void SetupPanel::mouseDown (const juce::MouseEvent& e)
{
    for (int i = 0; i < (int) pages.size(); ++i)
        if (pages[(size_t) i].area.contains (e.getPosition()))
        {
            selectPage (i);
            return;
        }

    if (currentPage == 0)
        for (int i = 0; i < (int) libraries.size(); ++i)
            if (libraries[(size_t) i].area.translated (libraryPage.getX(), libraryPage.getY())
                    .contains (e.getPosition()))
            {
                selectLibrary (i);
                return;
            }

    if (! panel.contains (e.getPosition()))
        setVisible (false);
}

bool SetupPanel::keyPressed (const juce::KeyPress& k)
{
    if (k == juce::KeyPress::escapeKey)
    {
        setVisible (false);
        return true;
    }

    return false;
}

} // namespace orbitamp
