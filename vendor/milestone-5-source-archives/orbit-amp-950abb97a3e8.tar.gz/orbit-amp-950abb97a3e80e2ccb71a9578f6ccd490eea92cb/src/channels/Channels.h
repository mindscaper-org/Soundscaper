// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#pragma once

#include "Lineup.h"
#include "../PluginProcessor.h"

#include <array>
#include <optional>
#include <vector>

namespace orbitamp::channels
{

/** THE CHANNELS, AND WHAT EACH REMEMBERS. To the hand a product's channels are so many amps — the
    cockpit's throttle has four detents, the rover three gears: leaving one leaves its DRIVE, its tone,
    its keys, TURBO, the reverb, the delay and the cabinet as they stood, and coming back finds them
    there. How many there are and what each plays is the product's to say (Lineup.h) — and whether
    they go in pairs over one memory, two packs to one gear.

    The engine has ONE set of those parameters, and whichever channel is playing owns it. The others
    wait as records in the processor's state tree, under one node of the product's own. Being in
    that tree is the whole design: the state is what a session saves, what undo steps through and what
    each of the A/B/C/D registers holds — so the memory travels with all three, and none of them had to
    be taught about it. The record of the channel that is PLAYING is stale by definition; the live
    parameters are its truth until it is left.

    The same node carries the controls that have no parameter yet: the pack's four layers are
    remembered here, and will reach the sound when the packs carry them (layerPlayable).

    No widgets in here, and nothing the audio thread reads. Message thread only. It belongs to the
    product's half of the engine (Engine.h), so it is there with the window shut. */
class Channels
{
public:
    Channels (AmpProcessor&, const Lineup&);

    const Lineup& lineup() const noexcept { return line; }
    int count() const noexcept { return line.count(); }

    /** WHAT A CHANNEL OPENS ON, until the player sets it otherwise — a channel never pulled, and every
        one of them after INIT: its own room and its own share of delay, as the lineup gives them; its
        pack's switches and tones where the pack starts them (a tone of positions on its reference one).
        Everything else a channel keeps opens on its parameter's own default. */
    float defaultOf (int channel, const juce::String& paramId) const;

    /** THE TONE KNOBS ARE THE PACK'S TONES, as many as it has and in its order: knob i is the i-th tone
        of the pack's list (rig.json's `chain[].tone[]`), under that tone's name — the X88-IR's Bass,
        Middle, Treble; the V4 Copper's Tone, Treble, Middle, Bass, Bass cut; the ReVolt's Clean Bass and
        Treble, its Crunch Bass, Mid, Treble — and the engine plays each list's controls by their places
        in it (params::preampMeasured), so knob i turns place i. No knob is matched to a tone by its name
        (a MIDI tone controller alone finds its knob so — toneNamed, below): a face shows as many knobs
        as the playing pack has tones, each labelled with its tone's name
        (face::Console lays them out). At most maxTones, the places the engine has; a pack's tones past
        them have no knob. toneOf is empty for a knob past the pack's list, and for every knob of a
        channel whose pack is not installed; toneId is the parameter a knob turns on the channel that
        is playing.
        ...BUT ON A PRODUCT WHOSE CONSOLE IS THE BASS'S STANDARD (Product::eqStandard) the knobs are the pack's DIALS
        alone, where its pack states a tone: its swept tones that are not a frequency knob — the SGT-DI's Bass, Mid and
        Treble — its frequency knob (Freq, moving Mid's band) and its tone switches (Ultra Lo, Ultra Hi) each asked for
        apart (frequencyOf, toneSwitchOf), since a bass face stands them elsewhere than its knobs. On a pack with no tone
        of its own the knobs are the standard's three: Bass, Middle and Treble — the AMP's console's low shelf, first
        bell and high shelf — and tonesOf is empty, since none of them is a tone the pack states. */
    static constexpr int maxTones = params::preampNumMeasured;
    juce::StringArray toneNamesOf (int channel) const;
    std::vector<namz::rig::Tone> tonesOf (int channel) const;      // ...and the tones themselves, as the pack states them
    juce::String toneId (int knob) const { return toneOf (active(), knob); }
    juce::String toneOf (int channel, int knob) const;

    /** ON THE BASS, THE PACK'S FREQUENCY KNOB — the tone a dial's band names as its frequency (`hz_by`), the SGT-DI's
        Freq — as the tone slot it plays from (params::preampMeasured), and the tone itself; empty, and false, where
        its pack has none or the console is not the bass's. */
    juce::String frequencyOf (int channel) const;
    bool frequencyToneOf (int channel, namz::rig::Tone& out) const;

    /** ON THE BASS, THE PACK'S TONE SWITCHES — its tones of positions, no sweep, in its order: the SGT-DI's Ultra Lo
        and Ultra Hi — the `which`-th as the tone slot it plays from, and the tone itself; empty, and false, past the
        pack's list or where the console is not the bass's. */
    juce::String toneSwitchOf (int channel, int which) const;
    bool toneSwitchToneOf (int channel, int which, namz::rig::Tone& out) const;

    /** THE KNOB A MIDI TONE CONTROLLER TURNS — the one place a tone is found by its NAME, so the MIDI list
        (`midi.txt`: 24 BASS, 25 MIDDLE, 26 TREBLE) is true on every pack whatever order it lists them in:
        the knob whose tone is called Bass, Middle (or Mid), Treble, case aside. -1 where the channel's pack
        has no tone of that name — the Copper's Tone and Bass cut, the Sheriff's Bright have no controller,
        and on the ReVolt's Clean CC 25 turns nothing. */
    enum class Band { bass, middle, treble };
    int toneNamed (int channel, Band) const;

    /** THE PACK'S SWITCHES: its controls that pick a capture and are not the gain dial, in the order the
        pack lists them — the IR-X Ch1's Boost and three-way Bright, the Ch2's Tight/Fat and Boost; most
        packs have none. Each is played from a selector slot of the preamp's (params::selectorId), the
        same reading the block itself makes of the pack, and a channel keeps where each stands. A channel
        never pulled opens on the pack's own position; the one the channel HOLDS (Lineup::Channel::held)
        stands where the lineup puts it, always, and is no hand's to throw. Empty when the channel's pack
        is not installed. */
    struct PackSwitch
    {
        int  slot = 0;              // params::selectorId (preampId, slot)
        juce::String name;
        juce::StringArray values;   // its positions, in the pack's order — the panel's
        int  opening = 0;           // where a channel never pulled has it, as an index into values
        bool held = false;
    };
    std::vector<PackSwitch> switchesOf (int channel) const;

    /** The controls kept in the node rather than in a parameter. */
    enum Flag { fat, bright, depth, presence, numFlags };

    /** WHICH LAYERS THE PACKS CARRY — none of them yet, so a hand on a layer's key would change nothing
        it could hear. Until a version of the packs brings a layer, the face keeps its key where it
        stands and does not let it be thrown; what a state already says about it is left alone, only not
        shown. One word each, in Flag's order, turns a key back on. */
    static constexpr std::array<bool, numFlags> layerPlayable {{
        false,      // FAT
        false,      // BRIGHT
        false,      // DEPTH
        false,      // PRESENCE
    }};

    /** Whether the state carries the product's node at all. One that does not is a state the product has
        never seen — a session saved before it existed, or a fresh instance. */
    bool adopted() const { return node().isValid(); }

    /** Makes the state the product's, if it is not yet: the channel is the one whose pack a hand has set
        playing, the first otherwise — and the first for a fresh instance or an INIT, whose device is
        the engine's starting one. True when there was nothing of ours in it before. */
    bool adopt();

    /** The channel the state says is playing. */
    int  active() const;

    /** Leaves the playing channel as it stands, switches to `channel`'s pack and puts back what that
        channel was left with — its defaults, the first time it is visited. False, and nothing touched,
        when that channel's pack is not installed: a channel that cannot be played is not claimed.
        To the other of the playing pair (Lineup::pairs) only the pack changes: everything else stands
        as it is, the tones on their knobs. */
    bool select (int channel);

    /** THE PAIR A CHANNEL IS IN, where the lineup has pairs: the first of the two, whose record keeps
        their one memory — the channel itself where it has none. */
    int memoryOf (int channel) const noexcept;

    /** Which of its pair a channel's memory was left playing — the first, where it was never left on
        the other — and for the pair that is playing, the one playing. */
    int leftOn (int channel) const;

    bool flag (Flag) const;
    void setFlag (Flag, bool);

    /** The pack a channel plays, as an index into the preamp's library; -1 when it is not installed.
        A channel's pack is the CAPTURE it plays, known by the `rig_id` in its manifest and not by what
        its file is called, wherever the device library finds it — among the packs the build carries
        first, as the library itself orders them. A file renamed is the same channel's pack still. */
    int  packFor (int channel) const;

    /** THE PRODUCT'S OWN CABINETS: every IR file in its two places — the ones the build carries, laid
        out in the family's factory folder under the product's own list (Set.h; another product's
        cabinets beside them are not among them), folder by folder of the shelf, and the player's own
        IRs folder — in the order of their names, so a leading number is how the order is chosen. Read when the
        engine is built and again each time the face opens: the folder is the player's to add to
        between two looks. CAB has as many positions as there are of them. */
    const juce::Array<juce::File>& cabinets() const noexcept { return irs; }
    void readCabinets();

    /** How many of cabinets() are the build's own. They stand first and the player's after them: what
        a player adds never lands among the factory ones, whatever it is called. */
    int factoryCabinets() const noexcept { return factory; }

    /** THE CABINET, OUT OF THE SOUND ALTOGETHER — for an amp played into a real one, or into an IR
        loaded somewhere else. One switch for every channel, and the sound's own: a session and a
        preset keep it, undo steps over it, INIT throws it back on. Off, each channel still remembers
        its cabinet. */
    bool cabinetOn() const;
    void setCabinetOn (bool);

    /** THE CABINET A CHANNEL OPENS ON, until the player picks another — a channel never pulled, every
        one of them after INIT, and one whose own cabinet is not here any more: the build's own of the
        name the lineup gives, found wherever it stands in the list, as an index into cabinets(). The
        first in the list where the build carries none of that name; -1 with none at all. */
    int defaultCabinet() const;

    /** TAKING FILES IN — IRs themselves, folders of them, zips — into the player's own IRs folder, the
        way OrbitAmp's library takes them, and reading the cabinets again. How many cabinets that made,
        the first of them as an index into cabinets(), and the files refused, by name: an IR too big to
        be kept inside a session cannot be a cabinet here. */
    struct Added
    {
        int cabinets = 0;
        int first = -1;
        juce::StringArray refused;
    };
    Added importCabinets (const juce::StringArray& paths);

    /** A cabinet of the player's own under another name — the file's, where it lies — or gone, to the
        Trash. Every channel that was left on a renamed cabinet goes with it. False, and nothing
        touched, for one of the build's own, a name already taken, or a file that would not move.
        Neither is an edit of the sound: the caller says so to the history. */
    bool renameCabinet (int index, const juce::String& name);
    bool removeCabinet (int index);

    /** The one that is playing, as an index into cabinets(); -1 when the sound's cabinet is none of them. */
    int  cabinet() const;
    void chooseCabinet (int index);

    /** THE FOLDER OF THE FACTORY SHELF a cabinet of the build's own lies in — `Orange PPC212V`, `Other`
        (device/FactoryShelf.h) — as the panel heads its lists by them; empty for one at the top of the
        shelf, and for a cabinet of the player's. */
    juce::String cabinetFolder (int index) const;

    /** A cabinet's name as the panel says it: the file's, without its leading number. */
    static juce::String cabinetName (const juce::File&);

    /** ...and as a file would carry it: the same, with the file's own dashes and no extension. */
    static juce::String cabinetStem (const juce::File&);

    /** True when the cabinet that is playing wears the name of one of the product's and is not that
        file: a state carries its cabinet's bytes, and one saved before the file was replaced under its
        name would go on sounding the old one, under a plate that names the new. And true the other
        way round — the file it is, under a name the file has since lost. align() cures both. */
    bool cabinetIsStale() const;

    /** Makes the sound agree with what the state says about itself: the playing channel's pack, and a
        cabinet that is one of the product's — the file of that name as it is now. The folders are the
        player's to change between sessions, and a state remembers a pack by a name and a cabinet by
        its bytes — either may be one the product no longer has. Writes; the caller decides whether
        that is an edit. */
    void align();

    /** DRAWN CABINETS' SLOTS (Lineup::drawnCabinets, Lineup::cabinets): how many; the one the playing channel stands at;
        and what one holds, as a `from` (AmpProcessor::cabSynthOf) — the player's, kept in the state, or the lineup's. */
    int cabinetSlots() const noexcept { return (int) line.cabinets.size(); }
    int cabinetSlot() const;
    juce::String slotFrom (int slot) const;
    /** A slot's name where it holds one of cab-ir-generator's presets — "8x10 STACK", the preset's own without its style —
        and empty where it holds a box the player sets. */
    juce::String slotName (int slot) const;

    /** A slot heard and not kept — the hand on its way along the slider; the playing channel moved to a slot, its
        cabinet rendered and kept; and the slot it stands at given what the window kept. */
    void hearSlot (int slot);
    void chooseSlot (int slot);
    void keepInSlot (const juce::String& from);

    /** The type of the product's node in the state tree. */
    juce::Identifier nodeType() const { return line.nodeType; }

    /** A note kept on the node beside the channels — it travels wherever they do. */
    juce::var tag (const juce::Identifier&) const;
    void setTag (const juce::Identifier&, const juce::var&);

    /** Every channel written out in full, as a tree of their own: the playing one from the live
        controls, the others from their records, a channel never visited from its defaults — a pair as
        one, with which of the two it plays or was left on. Two states
        that would sound the same on every detent give the same tree — which the node itself does not,
        since the playing channel's record there is stale and an unvisited one is missing. */
    juce::ValueTree whole() const;

private:
    AmpProcessor& amp;
    const Lineup& line;
    juce::StringArray kept;      // the parameters a channel remembers
    juce::StringArray tones;     // ...of them, the places every channel's pack has its tones in
    std::vector<namz::rig::Tone> packTonesOf (int channel) const;   // the pack's whole list, place i its tone i
    juce::Array<juce::File> irs; // the product's cabinets, in order
    int factory = 0;             // how many of them, from the front, are the build's own
    void  hold (int channel);                                           // its held switch where the lineup puts it
    mutable std::vector<std::optional<juce::String>> irKeys;    // each file's content key, read when first asked for; empty if it would not read
    juce::String keyOfFile (int index) const;

    juce::String cabinetPlaying() const;                  // its file's name without the extension; empty when none of ours
    void nameCabinet (const juce::File&);                 // writes the playing cabinet's name down as that file's
    void chooseCabinetNamed (const juce::String& stem);   // ...or the one a channel opens on, when that one is not here

    // DRAWN CABINETS (Lineup::drawnCabinets): the one playing as its `from` says it — or the one asked for and still
    // rendering — and a slot's, rendered and kept.
    juce::String drawnPlaying() const;
    void playDrawn (const juce::String& from);
    mutable juce::String drawnAsked, drawnOver;           // the one asked for, and the state's `from` when it was asked

    juce::ValueTree node() const;
    juce::ValueTree ensureNode();
    void  store (juce::ValueTree record) const;
    void  recall (int channel, const juce::ValueTree& record);
    using Knobs = std::array<std::optional<float>, maxTones>;
    Knobs knobs() const;                                // where the tone knobs stand on the pack playing; none for a knob past its list
    void  turnKnobs (int channel, const Knobs&);        // ...stood so on `channel`'s pack, its other places — and a knob that stood nowhere — where it opens them
    int   knobAt (int channel, const juce::String& paramId) const;      // which knob a place is on `channel`'s pack; -1 for none
    float plain (const juce::String& paramId) const;
    void  set (const juce::String& paramId, float plainValue);
};

} // namespace orbitamp::channels
