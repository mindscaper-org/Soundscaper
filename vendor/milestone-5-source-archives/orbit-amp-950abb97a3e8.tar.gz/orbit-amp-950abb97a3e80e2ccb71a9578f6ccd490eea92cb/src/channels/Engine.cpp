// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "Engine.h"

#include "../Parameters.h"

namespace orbitamp::channels
{

namespace
{
    constexpr int preampConsole = 0;        // the preamp's universal console: kept flat, the tones are the pack's

    using Suppress = felitronics::appkit::CompareHistory::ScopedSuppress;
}

//==============================================================================
void Engine::addParameters (juce::AudioProcessorValueTreeState::ParameterLayout& layout, const Lineup& lineup)
{
    // The names the channels wear, as a host would write them.
    juce::StringArray names;
    for (const auto& c : lineup.channels)
        names.add (c.name);
    layout.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { lineup.parameterId, 1 }, "Channel", names, lineup.opensAt));
}

void Engine::opening (const Lineup& lineup, params::Opening& o)
{
    // A fresh instance opens on the first channel (Channels::adopt) and setUpChain gives it that
    // channel's room and delay (Channels::defaultOf) — said here before there is an instance to say it to.
    jassert (! lineup.channels.empty());
    if (lineup.channels.empty())
        return;

    const auto& first = lineup.opener();
    o.capture  = first.capture;
    o.reverb   = first.reverb;
    o.delayMix = first.delayMix;
    if (first.reverbMix.has_value())
        o.reverbMix = *first.reverbMix;
    if (lineup.boostLevel.has_value())
        o.boostLevel = *lineup.boostLevel;

    // ...and what the lineup holds where it is, said where the Opening has a place for it (Lineup::pinned) — the
    // rest of what it pins is held where the parameter opens anyway.
    for (const auto& pin : lineup.pinned)
    {
        if (pin.param == params::compAmount) o.compAmount = pin.value;
        if (pin.param == params::bassLpfOn)  o.bassLpfOn  = pin.value > 0.5f;
    }
}

Engine& Engine::of (AmpProcessor& p)
{
    jassert (dynamic_cast<Engine*> (p.productEngine.get()) != nullptr);
    return static_cast<Engine&> (*p.productEngine);

}

/** Built while the processor is still building itself, before its history has taken a baseline: what
    is settled here is how the amp starts, not an edit of it. */
Engine::Engine (AmpProcessor& p, const Lineup& lineup)
    : channels (p, lineup), amp (p), channel (p.apvts.getParameter (lineup.parameterId))
{
    jassert (channel != nullptr);

    makeOwn();
    channels.align();
    say (channels.active());
    lastAsked = asked();
}

int Engine::asked() const
{
    return channel != nullptr ? juce::jlimit (0, channels.count() - 1, juce::roundToInt (channel->convertFrom0to1 (channel->getValue())))
                              : channels.active();
}

void Engine::say (int playing)
{
    if (channel != nullptr && asked() != playing)
        channel->setValueNotifyingHost (channel->convertTo0to1 ((float) playing));
}

bool Engine::go (int to)
{
    const bool went = channels.select (to);
    say (channels.active());
    lastAsked = asked();
    return went;
}

bool Engine::makeOwn()
{
    const bool unseen = ! channels.adopted();
    if (unseen)
        setUpChain (channels.adopt());
    return unseen;
}

void Engine::stateLanded()
{
    lastAsked = asked();
}

void Engine::pump()
{
    bool moved = false;

    if (! channels.adopted())
    {
        // A state the product has not seen — a session from before it existed, a preset's INIT — with
        // no window open to take it in.
        const Suppress settling (amp.history);
        makeOwn();
        channels.align();
        say (channels.active());
        moved = true;
    }
    else if (const int want = asked(); want != lastAsked)
    {
        // The parameter moved: a host's automation, a controller the host has bound to it.
        if (want != channels.active())
        {
            go (want);
            moved = true;
        }
    }
    else if (want != channels.active())
    {
        // The state moved under it: an undo, a register, a preset whose channel is not the one the
        // parameter arrived on — a state from before there was a parameter says nothing for it at all.
        // The parameter follows the sound.
        const Suppress quiet (amp.history);
        say (channels.active());
        moved = true;
    }

    lastAsked = asked();

    if (moved && onChange)
        onChange();
}

void Engine::setParam (const juce::String& paramId, float value)
{
    // Only a move is told to the host (as Channels::set): the chain set up again on every opening of the face must
    // not write automation points for parameters already where they stand.
    if (auto* p = amp.apvts.getParameter (paramId))
        if (const float to = p->convertTo0to1 (value); ! juce::approximatelyEqual (to, p->getValue()))
            p->setValueNotifyingHost (to);
}

void Engine::setUpChain (bool firstTime)
{
    if (firstTime)                            // the tuner listens until the player switches it off
        setParam (params::tunerOn,   1.0f);
    setParam (params::preampOn,      1.0f);
    setParam (params::delayOn,       1.0f);
    setParam (params::delaySync,      1.0f);  // the delay keeps time, always: the host's when there is one...
    setParam (params::delayHostTempo, 1.0f);  // ...and its own BPM when there is not
    setParam (params::reverbOn,      1.0f);
    if (firstTime)                            // after that the reverb is the player's to choose
    {
        setParam (params::reverbType, channels.defaultOf (channels.active(), params::reverbType));
        if (channels.lineup().channels[(size_t) channels.active()].reverbMix.has_value())
            setParam (params::reverbMix, channels.defaultOf (channels.active(), params::reverbMix));
    }
    if (firstTime)                            // after that, whether the cabinet plays is the player's to say
        setParam (params::cabOn,     1.0f);

    // A state the product has never seen starts with TURBO off, wherever it was left.
    if (firstTime)
        setParam (params::preampBoost, 0.0f);

    // ...and with as much delay as its channel opens on, not as much as the engine does — and its pack's
    // switches where the pack opens them, the one the channel holds where it holds it.
    if (firstTime)
    {
        setParam (params::delayMix, channels.defaultOf (channels.active(), params::delayMix));
        for (int s = 0; s < params::numSelectors; ++s)
            setParam (params::selectorId (params::preampId, s),
                      channels.defaultOf (channels.active(), params::selectorId (params::preampId, s)));
    }

    // BASS / MIDDLE / TREBLE are the pack's own tone stack. The universal console's three bands they
    // used to ride stand flat behind it: a pack with no tone of its own falls to that console, and
    // must not find a setting there that no knob on the face shows.
    // ...BUT ON THE BASS'S STANDARD those three bands ARE the knobs (Channels::toneOf), the tone the chain
    // plays whatever the pack, and left where the player put them — every time the face opens.
    if (amp.product().eqStandard() != params::EqStandard::bass)
    {
        setParam (params::blockEqMode (params::preampId), (float) params::eqModes.indexOf ("Device Tone"));
        setParam (params::eqLoDb (preampConsole), 0.0f);
        setParam (params::eqBellDb (preampConsole, 0), 0.0f);
        setParam (params::eqHiDb (preampConsole), 0.0f);
    }

    // HPF / LPF are on-off: the corners and slopes stay where OrbitCab puts them until set by ear.
    setParam (params::cabHpfHz, params::cabHpfDefaultHz);
    setParam (params::cabLpfHz, params::cabLpfDefaultHz);

    // ...and what the product holds where it is, whatever the state said (Lineup::pinned).
    for (const auto& pin : channels.lineup().pinned)
        setParam (pin.param, pin.value);
}

} // namespace orbitamp::channels
