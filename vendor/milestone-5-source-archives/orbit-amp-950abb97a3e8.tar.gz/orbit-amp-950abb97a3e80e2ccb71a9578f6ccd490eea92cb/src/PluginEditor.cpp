// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "PluginEditor.h"

#include "ui/HumMenu.h"
#include "ui/HumTuning.h"
#include "ui/Prefs.h"
#include "ui/WebFaceplate.h"

namespace orbitamp
{

std::vector<LayoutStrip::Row> AmpEditor::stripRows (const AmpProcessor& p)
{
    // The layout strip: the chain, FIXED — every block's arrow is its STANDBY/ON, and nothing is
    // ever taken off the panel. The two ends and the tuner are not arrows: their columns and their
    // strip are always on the face. A link the product's chain does not hold (the bass's delay and
    // reverb) has no arrow at all.
    std::vector<LayoutStrip::Row> rows;

    for (int i = 0; i < params::numChainRows; ++i)
    {
        const auto& link = params::chainLinks[(size_t) i];

        LayoutStrip::Row row { link.name, link.captured ? theme::orange : theme::violet };
        row.present = link.onParam != nullptr && i != params::rowTuner && p.chainHolds ((params::ChainRow) i)
                      && p.linkShown ((params::ChainRow) i);   // OrbitBass's checklist: a link out of the strip has no arrow
        rows.push_back (std::move (row));
    }

    return rows;
}

AmpEditor::AmpEditor (AmpProcessor& p)
    : juce::AudioProcessorEditor (&p), minDesignWidth (minDesignWidthFor (p)), amp (p), chrome (p), faceplate (p),
      inColumn  (VolumeColumn::Side::in,  p.gateKeyDb, p.inClip,
                 *p.apvts.getParameter (params::inTrim)),
      outColumn (VolumeColumn::Side::out, p.outDb,     p.outClip,
                 *p.apvts.getParameter (params::outTrim)),
      gateConsole (p.apvts, p.gateKeyDb),
      humLearner (p.product(), p.humLearn, p.gateKeyDb, p.humTuned.quietHz),
      tunerStrip (p.tunerEar, p.tunerStrobe, p.tunerPoly), footer (p), demoStrip (p), setup (p)
{
    setWantsKeyboardFocus (true);

    addAndMakeVisible (chrome);
    addAndMakeVisible (faceplate);

    // The hints wear the panel's own colours, not the stock yellow.
    tooltips.setColour (juce::TooltipWindow::backgroundColourId, theme::panel2);
    tooltips.setColour (juce::TooltipWindow::textColourId, theme::txDim);
    tooltips.setColour (juce::TooltipWindow::outlineColourId, theme::hair2);
    addAndMakeVisible (inColumn);
    addAndMakeVisible (outColumn);

    // THE GUARDS' MENUS open from their blocks on the panel (GuardBlock); a look clears the dot that
    // said the guard worked unseen.
    gateConsole.offersReset = amp.product().chain == Chain::bass;   // RESET at the foot of every menu (the owner, 01.11)
    faceplate.gateBlock().onMenu  = [this] (juce::Point<int> pos) { amp.gateWorked.store (false);    gateConsole.showMenu (pos, gateOnAt()); };
    faceplate.limitBlock().onMenu = [this] (juce::Point<int> pos) { amp.limiterWorked.store (false); showLimiterMenu (pos); };
    if constexpr (features::hum)   // the input column's menu is HUM's in the build that has it (Features.h)
        inColumn.onMenu = [this] (juce::Point<int> pos) { showInputMenu (pos); };
    addAndMakeVisible (tunerStrip);
    tunerStrip.isMuted = [&p] { return p.apvts.getRawParameterValue (params::tunerMute)->load() > 0.5f; };
    tunerStrip.onMenu  = [this] (juce::Point<int> pos) { showTunerMenu (pos); };
    addAndMakeVisible (footer);
    // The two TEMPORARY strips under the footer, off unless this player asked for them (the gear).
    // The demo needs its loops on disk — a machine without them has no player to show.
    showDemo   = params::demoLoopsPresent (amp.product().chain == Chain::bass) && prefs::getBool (amp.product(), prefs::showDemo, false);
    showGlyphs = prefs::getBool (amp.product(), prefs::showGlyphs, false);

    faceplate.setEqRowOnTop (prefs::getBool (amp.product(), prefs::eqRowOnTop, false));


    addChildComponent (demoStrip);
    addChildComponent (glyphs);
    addChildComponent (setup);       // hidden until the toolbar's gear opens it
    addChildComponent (devices);     // ...and DEVICES & TRADEMARKS, from the same menu

    // THE GEAR IS THE WINDOW. It used to drop a popup with a door to Setup, two doors to pages
    // nobody sets anything on, and four switches — which is how a settings menu becomes a place
    // things are hidden. One window, two pages, and the two pages that are only read reached
    // from where they are ABOUT: the version stamp and DEVICES, both at the bottom.
    chrome.onGear = [this] (juce::Point<int>) { setup.open(); };

    footer.onDevices = [this] { devices.open(); };

    setup.onViewChanged = [this] { applyViewPrefs(); };

    // FULL SCREEN, the honest kind: the aspect is locked, so a native fullscreen would only
    // letterbox the device in black. Instead the button jumps to the biggest fit the display
    // holds — the standalone window centred on its screen — and jumps BACK to where you were
    // on the second press.
    chrome.onFullScreen = [this]
    {
        auto* tl = getTopLevelComponent();
        const auto& displays = juce::Desktop::getInstance().getDisplays();
        const auto* display  = tl != nullptr ? displays.getDisplayForRect (tl->getScreenBounds())
                                             : displays.getPrimaryDisplay();
        if (display == nullptr)
            return;

        // The whole display: the zoom from its height (or from its width, on a display narrower than
        // the design), the width then as much of the display as the range allows.
        const auto area = display->userArea;
        const float fit = juce::jlimit (AmpProcessor::minScale, AmpProcessor::maxScale,
                                        juce::jmin ((float) area.getWidth() / (float) minBaseWidth,
                                                    (float) (area.getHeight() - titleBarAllowance)
                                                        / (float) baseHeight()));
        const int fullH = juce::roundToInt ((float) baseHeight() * fit);
        const int fullW = juce::jlimit (juce::roundToInt ((float) minBaseWidth * fit),
                                        juce::roundToInt ((float) (maxDesignWidth() + margin * 2) * fit),
                                        area.getWidth());

        if (! sizeBeforeFull.isEmpty() && std::abs (getHeight() - fullH) <= 1 && std::abs (getWidth() - fullW) <= 1)
        {
            setSize (sizeBeforeFull.getWidth(), sizeBeforeFull.getHeight());
            sizeBeforeFull = {};
        }
        else
        {
            sizeBeforeFull = getLocalBounds();
            setSize (fullW, fullH);
        }

        if (auto* window = dynamic_cast<juce::ResizableWindow*> (tl))
            window->setCentrePosition (area.getCentre());
    };

    layoutStrip = std::make_unique<LayoutStrip> (stripRows (amp));

    layoutStrip->onToggle = [this] (int i, bool on)
    {
        // THE switch: the arrow writes the link's own parameter, so the save, the history, and
        // the registers all carry the click — the panel follows through the echo below.
        if (const char* id = params::chainLinks[(size_t) i].onParam)
            if (auto* p = amp.apvts.getParameter (id))
            {
                p->beginChangeGesture();
                p->setValueNotifyingHost (on ? 1.0f : 0.0f);
                p->endChangeGesture();
            }
    };

    // The echo that makes it ONE fact: wherever a link's switch moves — the strip, an undo, a
    // loaded preset, a register switch, host automation — the arrow follows. The blocks dim
    // themselves: each binds its own switch.
    for (int i = 0; i < params::numChainRows; ++i)
    {
        const auto& link = params::chainLinks[(size_t) i];

        if (link.onParam != nullptr && i != params::rowTuner && amp.chainHolds ((params::ChainRow) i))
            blockRowAtts.push_back (std::make_unique<juce::ParameterAttachment> (
                *amp.apvts.getParameter (link.onParam),
                [this, i] (float v) { layoutStrip->setRowOn (i, v > 0.5f); }));
    }

    for (auto& att : blockRowAtts)
        att->sendInitialUpdate();

    // THE CHECKLIST, where the product has links a player may take out of the strip (OrbitBass's effects): at the
    // strip's right end; and whoever moves one of them — the checklist, an undo, a preset, a register, a host — the
    // strip, the face and the window follow.
    for (int i = 0; i < params::numChainRows; ++i)
        if (amp.linkRemovable ((params::ChainRow) i))
            presenceAtts.push_back (std::make_unique<juce::ParameterAttachment> (
                *amp.apvts.getParameter (params::chainLinks[(size_t) i].presentParam), [this] (float) { applyPresence(); }));
    if (! presenceAtts.empty())
        layoutStrip->setChecklist ([this] (juce::Component& anchor) { showChecklist (anchor); });

    addAndMakeVisible (*layoutStrip);

    // The badges' clicks mean MENU — the whole device in one pick. There is nowhere to "open" any
    // more and nothing to open TO: every block wears its own face on the panel, and the gate's own
    // controls, position included, live in this menu.

    // The measurement, projected: the overlay reads the strip's own trace.
    // The hum's LEARN on the same overlay, in its own words and with no threshold to walk; only one of
    // the two runs at a time — starting either cancels the other.
    gateConsole.onLearnBegin = [this]
    {
        humLearner.cancel();
        learnOverlay.title      = "LEARN";
        learnOverlay.trace      = &gateConsole.learnTraceRef();
        learnOverlay.totalTicks = GateConsole::learnTotalTicks;
        learnOverlay.ticksNow   = nullptr;
        learnOverlay.pendingDb  = [this] { return gateConsole.learnPendingDb(); };
        learnOverlay.begin();
    };
    gateConsole.onLearnDone  = [this] (const juce::String& v) { learnOverlay.finish (v); };
    humLearner.onBegin = [this]
    {
        learnOverlay.title      = "HUM LEARN";
        learnOverlay.trace      = &humLearner.trace();
        learnOverlay.ticksNow   = [this] { return humLearner.ticksPlanned(); };
        learnOverlay.pendingDb  = nullptr;
        learnOverlay.begin();
    };
    humLearner.onDone = [this] (const HumLearner::Take& take) { learnOverlay.finish (HumLearner::words (take).toUpperCase()); };

    addChildComponent (learnOverlay);

    // The rulers the runners summon: IN's stands right of its column, OUT's and the ceiling's
    // left of theirs — over whatever lives there, gone the moment the hand opens.
    const auto trimLadder = []
    {
        std::vector<DragRuler::Mark> m;
        for (int db = -24; db <= 24; db += 3)
            m.push_back ({ (float) db, db % 6 == 0 });
        return m;
    }();

    const auto trimYOf = [] (juce::Rectangle<float> r, float db)
    {
        return r.getCentreY() - db / params::inTrimRangeDb * (r.getHeight() * 0.5f - 6.0f);
    };

    inRuler.ticksOnLeft  = true;
    outRuler.ticksOnLeft = false;
    inRuler.marks  = trimLadder;
    outRuler.marks = trimLadder;
    inRuler.yOfDb  = trimYOf;
    outRuler.yOfDb = trimYOf;
    inRuler.currentDb  = [this] { auto* p = amp.apvts.getParameter (params::inTrim);
                                  return p->convertFrom0to1 (p->getValue()); };
    outRuler.currentDb = [this] { auto* p = amp.apvts.getParameter (params::outTrim);
                                  return p->convertFrom0to1 (p->getValue()); };

    addChildComponent (inRuler);    // went missing with the ceiling's ruler: a ladder with no
    addChildComponent (outRuler);   // parent cannot be shown, however often it is asked

    inColumn.showGuard  (*p.apvts.getParameter (params::gateThreshold),  *p.apvts.getParameter (params::gateOn));
    outColumn.showGuard (*p.apvts.getParameter (params::limiterCeiling), *p.apvts.getParameter (params::limiterOn));

    inColumn.onTrimDrag  = [this] (bool a) { inRuler.setVisible (a); if (a) inRuler.toFront (false); };
    outColumn.onTrimDrag = [this] (bool a) { outRuler.setVisible (a); if (a) outRuler.toFront (false); };

    // Devices came or went while the window was open: the engine re-reads the folder, then the
    // captured blocks rebuild their selectors from the lists that changed under them.
    setup.onDevicesChanged = [this]
    {
        amp.rescanDevices();
        faceplate.deviceChanged();
    };

    // The corner sets the zoom AND the width: the height decides the factor, and the aspect is free
    // between the design's own and `maxAspect` (AspectRange), the width laid out across.
    setConstrainer (&aspect);
    setResizable (true, true);
    applySizeLimits();

    // As large as the screen allows, up to the size the plugin WANTS to open at. Asking for 2x on a
    // display that cannot hold it does not give 2x — it gives whatever the window manager shrinks it
    // to, and reading that back as the next window's wish is how a plugin walks itself down to the
    // minimum over a few launches.
    float s = AmpProcessor::preferredScale;

    if (const auto* display = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay())
    {
        const auto area = display->userArea;
        const float fits = juce::jmin ((float) area.getWidth()  / (float) minBaseWidth,
                                       (float) (area.getHeight() - titleBarAllowance) / (float) baseHeight());
        s = juce::jlimit (AmpProcessor::minScale, s, fits);
        amp.setEditorScale (s);
    }

    // It opens at the design's own width; the corner widens it from there.
    zoomNow = s;
    setSize (juce::roundToInt (minBaseWidth * s), juce::roundToInt (baseHeight() * s));

    // The one place this plugin may reach the network without a click, and only because a player
    // ticked the switch in the version popover: once a day at most, on the message thread, never in
    // a constructor a scanner runs. Not ticked, or checked already today — nothing happens at all.
    amp.updateChecker().checkIfDue();

    // THE SITE'S KIT: OrbitAmp's own face written out for darwinscat.com, when the environment names a
    // folder for it (WebFaceplate.h). A player never sets it, and without it nothing here happens.
    if (const auto folder = juce::SystemStats::getEnvironmentVariable ("ORBITAMP_WEB_EXPORT", {}); folder.isNotEmpty())
        WebFaceplate::exportAfterOpening (*this, juce::File (folder));

    // A live still of the face for a product page (WebFaceplate.h) — a dev tool, like the kit above.
    if (const auto folder = juce::SystemStats::getEnvironmentVariable ("ORBITAMP_LIVE_SHOT", {}); folder.isNotEmpty())
        WebFaceplate::liveShotAfterOpening (*this, juce::File (folder),
                                            juce::File (juce::SystemStats::getEnvironmentVariable ("ORBITAMP_LIVE_SHOT_DI", {})));
}

std::vector<std::pair<params::ChainRow, bool>> AmpEditor::checklistRows() const
{
    std::vector<std::pair<params::ChainRow, bool>> list;
    for (int i = 0; i < params::numChainRows; ++i)
        if (amp.linkRemovable ((params::ChainRow) i))
            list.emplace_back ((params::ChainRow) i, amp.linkShown ((params::ChainRow) i));
    return list;
}

void AmpEditor::setLinkPresent (params::ChainRow row, bool present)
{
    const char* id = params::chainLinks[(size_t) row].presentParam;
    auto* p = id != nullptr && amp.linkRemovable (row) ? amp.apvts.getParameter (id) : nullptr;
    if (p == nullptr)
        return;
    amp.history.beginGesture();
    p->beginChangeGesture();
    p->setValueNotifyingHost (present ? 1.0f : 0.0f);
    p->endChangeGesture();
    amp.history.endGesture();
}

void AmpEditor::showChecklist (juce::Component& anchor)
{
    juce::PopupMenu m;
    m.addSectionHeader ("IN THE STRIP");
    const auto rows = checklistRows();
    for (size_t k = 0; k < rows.size(); ++k)
        m.addItem ((int) k + 1, params::chainLinks[(size_t) rows[k].first].name, true, rows[k].second);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&anchor),
                     [safe = juce::Component::SafePointer<AmpEditor> (this), rows] (int r)
                     {
                         if (safe != nullptr && r >= 1 && r <= (int) rows.size())
                             safe->setLinkPresent (rows[(size_t) r - 1].first, ! rows[(size_t) r - 1].second);
                     });
}

void AmpEditor::applyPresence()
{
    for (int i = 0; i < params::numChainRows; ++i)
        if (amp.linkRemovable ((params::ChainRow) i))
            layoutStrip->setRowPresent (i, amp.linkShown ((params::ChainRow) i));

    faceplate.resized();
    faceplate.repaint();

    // The least width as the strip now stands; a window narrower than it widens, at the zoom it has.
    minDesignWidth = minDesignWidthFor (amp);
    minBaseWidth   = minDesignWidth + margin * 2;
    applySizeLimits();
    const int wanted = juce::jlimit (minDesignWidth, maxDesignWidth(), designW);
    if (wanted != designW)
    {
        designW = wanted;
        setSize (juce::roundToInt ((float) baseW() * zoomNow), getHeight());
    }
}

void AmpEditor::applyStripChoice()
{
    // The zoom and the width the window already has; only the height follows the rows.
    applySizeLimits();
    designW = juce::jlimit (minDesignWidth, maxDesignWidth(), designW);
    setSize (juce::roundToInt ((float) baseW() * zoomNow), juce::roundToInt ((float) baseHeight() * zoomNow));
}

void AmpEditor::applySizeLimits()
{
    const int h = baseHeight();

    aspect.lowAspect  = (double) minBaseWidth / (double) h;
    aspect.highAspect = juce::jmax (aspect.lowAspect, (double) (maxDesignWidth() + margin * 2) / (double) h);
    aspect.setSizeLimits (juce::roundToInt ((float) minBaseWidth * AmpProcessor::minScale),
                          juce::roundToInt ((float) h * AmpProcessor::minScale),
                          juce::roundToInt ((float) (maxDesignWidth() + margin * 2) * AmpProcessor::maxScale),
                          juce::roundToInt ((float) h * AmpProcessor::maxScale));
}

void AmpEditor::paint (juce::Graphics& g)
{
    g.fillAll (theme::ground);
}

bool AmpEditor::keyPressed (const juce::KeyPress& key)
{
    // Escape is the way out of anything that took the room over. The whole-screen theatre has
    // always answered it — it holds the keyboard while it runs — and the face-wide picture only
    // had its own fold glyph, which is a way out you have to go looking for.
    if (key == juce::KeyPress::escapeKey)
        return faceplate.foldPicture();

    // Space is the demo player's transport, like everywhere else sound is judged — but ONLY while
    // the player is on show. Hidden, it is not ours: in a DAW space is the host's play/stop, and a
    // plugin window that has the focus must not eat it — nor start a loop nobody can see, which
    // would replace the guitar at the input. Unclaimed, the key goes on to the host. Text editors
    // keep their spaces — a focused editor consumes the key before it ever reaches us.
    if (key == juce::KeyPress::spaceKey && showDemo)
    {
        amp.demo.setPlaying (! amp.demo.isPlaying());
        return true;
    }

    // H: the hum, OFF and back (prefs::humFlip) — Р under a Russian layout, the same key. G: the
    // gate's On, the sound's switch and so an undo step, as its menu sets it — П. H only while the build
    // has HUM (Features.h); without it the key is not ours, and goes on to the host.
    if (! key.getModifiers().isAnyModifierKeyDown())
    {
        const auto letter = juce::CharacterFunctions::toUpperCase ((juce::juce_wchar) key.getKeyCode());
        if (features::hum && (letter == 'H' || letter == 0x0420))
        {
            prefs::setHum (amp.product(), prefs::humFlip (amp.product()));
            return true;
        }
        if (letter == 'G' || letter == 0x041f)
        {
            if (auto* on = amp.apvts.getParameter (params::gateOn))
            {
                on->beginChangeGesture();
                on->setValueNotifyingHost (on->getValue() > 0.5f ? 0.0f : 1.0f);
                on->endChangeGesture();
            }
            return true;
        }

        // A B C D, or 1 2 3 4: the registers, as their buttons switch them (the owner, 08.11: to hear one against
        // another) — Ф И С В under a Russian layout, the same keys.
        static constexpr juce::juce_wchar latin[] { 'A', 'B', 'C', 'D' }, cyrillic[] { 0x0424, 0x0418, 0x0421, 0x0412 };
        for (int i = 0; i < 4 && i < amp.history.numRegisters(); ++i)
            if (letter == latin[i] || letter == cyrillic[i] || key.getKeyCode() == '1' + i)
            {
                amp.history.switchTo (i);
                return true;
            }

        // LEFT and RIGHT: the cabinet before or after the one that plays.
        if (key.getKeyCode() == juce::KeyPress::leftKey || key.getKeyCode() == juce::KeyPress::rightKey)
        {
            faceplate.stepCabinet (key.getKeyCode() == juce::KeyPress::leftKey ? -1 : 1);
            return true;
        }
    }

    return false;
}

void AmpEditor::applyViewPrefs()
{
    faceplate.setEqRowOnTop (prefs::getBool (amp.product(), prefs::eqRowOnTop, false));
    showDemo   = params::demoLoopsPresent (amp.product().chain == Chain::bass) && prefs::getBool (amp.product(), prefs::showDemo, false);
    showGlyphs = prefs::getBool (amp.product(), prefs::showGlyphs, false);
    applyStripChoice();
    resized();
    repaint();
}

juce::PopupMenu AmpEditor::limiterMenu() const
{
    auto* on   = amp.apvts.getParameter (params::limiterOn);
    auto* ceil = amp.apvts.getParameter (params::limiterCeiling);

    const bool  isOn = on->getValue() > 0.5f;
    const float c    = ceil->convertFrom0to1 (ceil->getValue());

    const auto matches = [&] (float v) { return isOn && std::abs (c - v) < 0.05f; };

    juce::PopupMenu m;
    // ON first, ruled off (the owner, 01.11: every menu): its strip arrow's switch, the ceiling kept. It stands for the OFF
    // that stood under the header while the limiter was on.
    m.addItem (limiterOnItem, "ON", true, isOn);
    m.addSeparator();
    // The number in the header, for the same reason the gate's carries one: the ceiling is
    // continuous and these are three points on it, so a value from a preset or an automation lane
    // can sit between them with no item ticked and nothing anywhere to say what it is.
    m.addSectionHeader (isOn ? "LIMITER  " + juce::String (c, 1) + " DB"
                             : juce::String ("LIMITER  OFF"));
    // A ceiling picked below switches it on (Oleh, 24.10).
    m.addItem (2, "SAFETY  -0.3",  true, matches (-0.3f));
    m.addItem (3, "NORMAL  -1.0",  true, matches (-1.0f));
    m.addItem (4, "TIGHT   -3.0",  true, matches (-3.0f));
    // RESET at the foot, ruled off (OrbitBass, the owner 01.11): the ceiling back to its default, the switch kept.
    if (amp.product().chain == Chain::bass)
    {
        m.addSeparator();
        m.addItem (limiterResetItem, "RESET");
    }
    return m;
}

void AmpEditor::applyLimiter (juce::RangedAudioParameter& on, juce::RangedAudioParameter& ceil, int r)
{
    if (r == 0)
        return;

    const auto set = [] (juce::RangedAudioParameter& p, float plain)
    {
        p.beginChangeGesture();
        p.setValueNotifyingHost (p.convertTo0to1 (plain));
        p.endChangeGesture();
    };

    if (r == limiterResetItem)
    {
        set (ceil, ceil.convertFrom0to1 (ceil.getDefaultValue()));
        return;
    }

    // ON (OrbitBass): turned over, as the strip's arrow turns it.
    if (r == limiterOnItem)
    {
        set (on, on.getValue() > 0.5f ? 0.0f : 1.0f);
        return;
    }

    set (on, 1.0f);
    set (ceil, r == 2 ? -0.3f : r == 3 ? -1.0f : -3.0f);
}

void AmpEditor::pickLimiter (int item)
{
    applyLimiter (*amp.apvts.getParameter (params::limiterOn), *amp.apvts.getParameter (params::limiterCeiling), item);
}

/** THE TUNER STRIP'S MENU (the owner, 01.11): MUTE alone, ticked while the output is muted — the tuner needs no ON
    here. One undo step a pick. */
void AmpEditor::showTunerMenu (juce::Point<int> screenPos)
{
    auto* mute = amp.apvts.getParameter (params::tunerMute);
    juce::PopupMenu m;
    m.addItem (1, "MUTE", true, mute->getValue() > 0.5f);

    // How it shows the note — the needle, a strobe, or every string of a strum — and the strings the polyphonic one
    // reads, in its menu as on the faces (the owner, 03.11: switched with a right click), as well as in SETUP.
    using Display = prefs::TunerDisplay;
    const auto& product = amp.product();
    const auto shown = prefs::tunerDisplay (product);
    const std::array<std::pair<Display, const char*>, 4> displays { { { Display::needle, "Needle" }, { Display::strobe, "Strobe" },
                                                                      { Display::poly, "Poly" }, { Display::automatic, "Auto" } } };
    juce::PopupMenu display;
    for (size_t i = 0; i < displays.size(); ++i)
        if (prefs::tunerPolyOffered || (displays[i].first != Display::poly && displays[i].first != Display::automatic))
            display.addItem (100 + (int) i, displays[i].second, true, shown == displays[i].first);
    m.addSubMenu (juce::String ("Display  ") + displays[(size_t) shown].second, display);

    const auto& tuned = prefs::tunerTuning (product);
    const auto tunings = core::polyTunings (prefs::tunesBass (product));
    juce::PopupMenu tuning;
    for (size_t i = 0; i < tunings.size(); ++i)
        tuning.addItem (200 + (int) i, core::polyTuningName (tunings[i]).menu, true, &tunings[i] == &tuned);
    if (prefs::tunerPolyOffered)
        m.addSubMenu (juce::String ("Tuning  ") + core::polyTuningName (tuned).menu, tuning);

    m.showMenuAsync (juce::PopupMenu::Options().withTargetScreenArea ({ screenPos.x, screenPos.y, 1, 1 }),
                     [safe = juce::Component::SafePointer<AmpEditor> (this), mute, displays, tunings] (int r)
                     {
                         if (safe == nullptr)
                             return;
                         const auto& own = safe->amp.product();
                         if (r >= 100 && r < 100 + (int) displays.size())
                         {
                             prefs::setTunerDisplay (own, displays[(size_t) (r - 100)].first);
                             return;
                         }
                         if (r >= 200 && r < 200 + (int) tunings.size())
                         {
                             prefs::setTunerTuning (own, tunings[(size_t) (r - 200)]);
                             return;
                         }
                         if (r != 1)
                             return;
                         auto* p = mute;
                         safe->amp.history.beginGesture();
                         p->beginChangeGesture();
                         p->setValueNotifyingHost (p->getValue() > 0.5f ? 0.0f : 1.0f);
                         p->endChangeGesture();
                         safe->amp.history.endGesture();
                     });
}

void AmpEditor::showLimiterMenu (juce::Point<int> screenPos)
{
    auto* on   = amp.apvts.getParameter (params::limiterOn);
    auto* ceil = amp.apvts.getParameter (params::limiterCeiling);

    limiterMenu().showMenuAsync (juce::PopupMenu::Options()
                                     .withTargetScreenArea ({ screenPos.x, screenPos.y, 1, 1 }),
                                 // The parameters outlive this window — the processor owns them — but the
                                 // editor does not: closing it with the menu open would leave the RESET branch
                                 // reaching through a dead `this`. Guarded the way the gear's menu already is.
                                 [safe = juce::Component::SafePointer<AmpEditor> (this), on, ceil] (int r)
                                 {
                                     applyLimiter (*on, *ceil, r);
                                 });
}

float AmpEditor::gateOnAt() { return faceplate.gateBlock().valueRail().lowestValue(); }

juce::PopupMenu AmpEditor::gateMenu() { return gateConsole.menu (gateOnAt()); }

void AmpEditor::pickGate (int item) { gateConsole.pick (item, gateOnAt()); }

/** A RIGHT CLICK ON THE INPUT COLUMN: the hum the input carries, and what to take off it. It is the
    machine's, not the sound's (prefs::hum) — a preset neither carries it nor moves it, undo steps over
    it, and every window and engine of this product follow it from their next look and their next
    block. AUTO's line says what it decided, once it has. */
void AmpEditor::showInputMenu (juce::Point<int> screenPos)
{
    // The switch, then the modes (ui/HumMenu.h), in this menu's capitals.
    const int  heard = amp.humHeard();
    const auto lines = prefs::humMenu (amp.product(), heard, humLearner.isLearning());

    juce::PopupMenu m;
    m.addSectionHeader ("HUM  " + prefs::humState (amp.product(), heard).toUpperCase());
    for (size_t i = 0; i < lines.size(); ++i)
        m.addItem ((int) i + 1, lines[i].text.toUpperCase(), true, lines[i].ticked);

    // How hard it works — TEMPORARY, for tuning by ear (ui/HumTuning.h): each a submenu, its value in
    // its title; knob k's values answer as 100 (k + 1) + their index.
    const auto knobs = prefs::humtune::knobs (amp.product());
    for (size_t k = 0; k < knobs.size(); ++k)
    {
        juce::PopupMenu values;
        for (int i = 0; i < knobs[k].count; ++i)
            values.addItem (100 * ((int) k + 1) + i, knobs[k].say (knobs[k].values[i]).toUpperCase(), true,
                            juce::exactlyEqual (knobs[k].values[i], knobs[k].now));
        m.addSubMenu ((juce::String (knobs[k].name) + "  " + knobs[k].say (knobs[k].now)).toUpperCase(), values);
    }

    // The answer reaches this window only to start the hum's LEARN, and through a SafePointer: a window
    // closed under the open menu is left alone.
    m.showMenuAsync (juce::PopupMenu::Options()
                         .withTargetScreenArea ({ screenPos.x, screenPos.y, 1, 1 }),
                     [safe = juce::Component::SafePointer<AmpEditor> (this), lines, knobs, &product = amp.product()] (int r)
                     {
                         if (r > 0 && r <= (int) lines.size() && lines[(size_t) r - 1].isLearn)
                         {
                             if (safe != nullptr)
                             {
                                 safe->gateConsole.cancel();
                                 safe->humLearner.start();
                             }
                         }
                         else if (r > 0 && r <= (int) lines.size())
                             prefs::humPick (product, lines[(size_t) r - 1]);
                         else if (const int k = r / 100 - 1, i = r % 100;
                                  k >= 0 && k < (int) knobs.size() && i < knobs[(size_t) k].count)
                             knobs[(size_t) k].choose (knobs[(size_t) k].values[i]);
                     });
}

void AmpEditor::resized()
{
    // The HEIGHT is the zoom; the width, in design units, is what is left to lay out across.
    const float s = (float) getHeight() / (float) baseHeight();
    amp.setEditorScale (s);
    zoomNow = s;
    designW = juce::jlimit (minDesignWidth, maxDesignWidth(),
                            juce::roundToInt ((float) getWidth() / s) - margin * 2);

    // Bounds stay in design units; the transform does all the scaling, margins included.
    const auto zoom = juce::AffineTransform::scale (s);

    chrome.setBounds (margin, margin, designW, Chrome::designHeight);
    chrome.setTransform (zoom);

    // The gate's IN sliver takes the faceplate row's left edge; the faceplate wears the rest.
    const int faceplateY = margin + Chrome::designHeight + headerGap;

    // The layout strip: the chain laid flat on the header's second line, beside the brand's marks,
    // always there. In front of the header, whose component spans both lines. Its first arrow's
    // tail stands under the wordmark's first letter: no lane inset, the strip that tail's air left.
    // The last arrow's point ends under the gear, the first line's last button.
    {
        layoutStrip->leftPad = 0;
        const int x = chrome.secondLineX() - LayoutStrip::tailAir;
        layoutStrip->arrowsEndX = chrome.gearBounds().reduced (2).getRight() - x;
        if (layoutStrip->hasChecklist())   // OrbitBass: the checklist under the gear, the arrows ending before it
        {
            layoutStrip->menuCentreX = chrome.gearBounds().getCentreX() - x;
            layoutStrip->arrowsEndX  = layoutStrip->menuCentreX - LayoutStrip::menuW / 2 - LayoutStrip::menuGap;
        }
        layoutStrip->setBounds (margin + x, margin + Chrome::firstLineH, designW - x,
                                LayoutStrip::designHeight);
        layoutStrip->setTransform (zoom);
        if (layoutStrip->hasChecklist())
            layoutStrip->resized();   // its checklist follows the gear even where the strip kept its size
    }

    // The faceplate is only as tall as its LAYOUT stands it — a collapsed row is not here.
    const int faceplateH = faceplate.currentHeight();

    // The gutters stand between the SAME two lines the blocks' frames do, not between the
    // faceplate's own edges — a block is inset inside the lane and its box starts lower still,
    // under the switch that rides the top border.
    const int gutterY = faceplateY + FaceplateView::contentTop;
    // Never negative: with every block stood down the panel closes up, and a column asked for a
    // negative height is a component with no honest size.
    const int gutterH = juce::jmax (0, faceplateH - FaceplateView::contentTop
                                                  - FaceplateView::contentBottom);

    // The side columns always stand, the panel's full height: the way in and the way out. The guards
    // are blocks on the panel now (FaceplateView), not rails beside these.
    const int edgeInset = 12;
    const int sideW = VolumeColumn::designWidth;
    const int colL  = sideW + chromeGap;
    const int colR  = sideW + chromeGap;
    const int railH = gutterH;

    inColumn.setBounds (margin, gutterY, VolumeColumn::designWidth, railH);
    inColumn.setTransform (zoom);

    outColumn.setBounds (margin + designW - VolumeColumn::designWidth, gutterY,
                        VolumeColumn::designWidth, railH);
    outColumn.setTransform (zoom);

    faceplate.setBounds (margin + colL, faceplateY,
                         designW - colL - colR, faceplateH);
    faceplate.setTransform (zoom);

    // The bottom row: the always-on needle in the left half, the footer's facts in the right. Both
    // stand off the window's edges the way the rails above them do.
    const int badgeInset = edgeInset;
    const int rowY   = faceplateY + faceplateH + chromeGap;
    const int rowW   = designW - 2 * badgeInset;
    const int tunerW = (rowW - chromeGap) / 2;

    tunerStrip.setBounds (margin + badgeInset, rowY + (bottomRowH - TunerStrip::designHeight) / 2,
                          tunerW, TunerStrip::designHeight);
    tunerStrip.setTransform (zoom);

    // The summoned rulers: the same vertical extent as their columns, standing toward the centre.
    inRuler.setBounds (margin + sideW + 2, gutterY, 56, railH);
    inRuler.setTransform (zoom);
    outRuler.setBounds (margin + designW - sideW - 58, gutterY, 56, railH);
    outRuler.setTransform (zoom);

    // The learn sheet: half the plugin, centred over the faceplate.
    learnOverlay.setBounds (margin + designW / 6, faceplateY + 60,
                            designW * 2 / 3, 330);
    learnOverlay.setTransform (zoom);

    footer.setBounds (margin + badgeInset + tunerW + chromeGap, rowY + (bottomRowH - Footer::designHeight) / 2,
                      rowW - tunerW - chromeGap, Footer::designHeight);
    footer.setTransform (zoom);

    // TEMPORARY — the audition player and the glyph review strip, under the bottom row, each only
    // when this player switched it on; the window is as tall as what it shows.
    int stripY = rowY + bottomRowH + chromeGap;

    demoStrip.setVisible (showDemo);
    if (showDemo)
    {
        demoStrip.setBounds (margin, stripY, designW, DemoStrip::designHeight);
        demoStrip.setTransform (zoom);
        stripY += DemoStrip::designHeight;
    }

    glyphs.setVisible (showGlyphs);
    if (showGlyphs)
    {
        glyphs.setBounds (margin, stripY, designW, GlyphPreview::designHeight);
        glyphs.setTransform (zoom);
    }

    // The overlay covers the whole editor, margins included, in the same design units.
    setup.setBounds (0, 0, baseW(), baseHeight());
    setup.setTransform (zoom);
    devices.setBounds (0, 0, baseW(), baseHeight());
    devices.setTransform (zoom);

}

// OrbitAmp itself — its name, this face, its first start — is said in OrbitAmpStart.cpp.

} // namespace orbitamp

