// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#pragma once

#include "../PluginProcessor.h"
#include "../channels/Engine.h"
#include "../channels/Presets.h"
#include "Controls.h"
#include "LearnGlass.h"
#include "Picture.h"
#include "Sheet.h"
#include "WebImages.h"

#include <felitronics/appkit/VersionBadge.h>

#include <array>
#include <functional>
#include <map>
#include <memory>
#include <vector>

namespace orbitamp::face
{

using channels::Engine;
using channels::Channels;
using channels::Presets;

/** The keys under the tone knobs: the two filters, painted on every face — a face has room for a short
    name under each, the full one shows on hover — and right of them a group of as many as the playing
    pack has switches a hand may throw (Console::rightKeysOf), laid by code (Strip.h): at most
    maxRightKeys, and as many as the face's row shows of them. */
struct Switch { const char* name; const char* shortName; };
enum { btHpf, btLpf, btFirstRight };
inline constexpr std::array<Switch, 2> switches {{
    { "HIGHPASS", "HPF" },
    { "LOWPASS",  "LPF" },
}};
inline constexpr int maxRightKeys = 6;
inline constexpr int numKeys = btFirstRight + maxRightKeys;
inline constexpr float keyTracking = 0.04f;

/** The lilac the words printed on a face are written in. */
inline const juce::Colour labelLilac { 0xffc9b8f5 };

/** The keys in the holes of the roof, in hole order: the history on the left of the divider, the four
    registers — four whole amps to compare, each with a history of its own — on the right. */
enum { ovUndo, ovRedo, ovFirstRegister };
inline constexpr int numRegisterKeys = 4;

/** The lamps a face lights itself over its picture: the input's overload and the output's, the gate's
    and the limiter's. */
enum LampId { inClipLamp, outClipLamp, gateLamp, limiterLamp, numLamps };

/** A turning arrow — three quarters of a circle with a head on its open end. Forward turns clockwise
    (redo); back is its mirror (undo). */
void drawTurnArrow (juce::Graphics&, juce::Point<float> centre, float radius, bool back, juce::Colour);

/** A picture written for the site (Console::exportForWeb), as every picture of its kit is (web::write):
    a WebP, its alpha kept where it has a hole; nothing for an invalid one. */
void writeForWeb (const juce::File&, const juce::Image&);

//==============================================================================
/** A CONSOLE: the face of a product with channels, over OrbitAmp's processor. What every such face has
    — DRIVE, the three tones and the six keys under them, the history and the four registers in the
    roof, REVERB, DELAY and CAB on their plates, the INPUT and OUTPUT columns with their meters and
    lamps, GATE and LIMITER, the tuner's glass, the emblem, the version, CPU and MEM, PRESET, and every
    menu and window behind them — is here, bound to the engine, laid out where the product says (Places)
    and drawn with what the product hands it (Look). What is a face's own — its picture, how it picks a
    channel, what TURBO is on it, what shows through its window — the product's editor adds over this.

    Everything is laid out in the picture's own 1672 x 941 space on one stage (Stage.h), and the stage is
    scaled to the window as a whole. */
class Console : public juce::AudioProcessorEditor,
                public juce::FileDragAndDropTarget,
                private juce::Timer
{
public:
    /** WHERE EVERYTHING STANDS, in the stage's space — measured off the product's picture. */
    struct Places
    {
        juce::Rectangle<float> drive;                       // the knob's box
        /** THE TONE KNOBS' ROW (Strip.h): as many knobs as the playing pack has tones, each `toneKnob`
            across at the row's nominal size, the socket under it the row's `size`; each knob's name over
            it, in the row at `toneNameY`, written `toneNameEm` and set condensed into the room its pitch
            leaves (layStrips). */
        Strip toneStrip;
        float toneKnob = 0.0f;
        float toneNameY = 0.0f, toneNameEm = 13.0f;
        float toneSignDrop = 5.0f;                          // each knob's sign this much under its name's row: nearer its knob
        float toneSignHeight = toneSignSize.y;              // ...and this tall
        /** THE KEYS: the two filters' centres, painted where they are; and the right group's row (Strip.h)
            — each key `keySize` across at the row's nominal size, in a frame with these caps at its ends
            where the face draws one (a size of nought: none), its name over or under it (the first under,
            then by turns where `keyNamesAlternate`), or on its face where `keyNamesOnKeys`. */
        std::array<juce::Point<float>, 2> keys;             // HPF, LPF
        float keySize = 34.0f;
        float filterKeyWidth = 0.0f;                        // ...HPF's and LPF's width, where wider than they are tall; else square
        float filterKeyHeight = 0.0f;                       // ...and their height, where taller than the other keys; else keySize
        Strip keyStrip;
        float keyCapLeft = 0.0f, keyCapRight = 0.0f, keyFrameHeight = 0.0f;
        float keyNameOverY = 0.0f, keyNameUnderY = 0.0f, keyNameRoom = 120.0f;
        bool keyNamesAlternate = false, keyNamesOnKeys = false;
        std::array<juce::Point<float>, 6> holes;            // the roof keys' centres
        float holeKeySize = 40.0f;
        /** A ROOF KEY'S OWN BOX, where a face's key is not the square `holeKeySize` across round its hole —
            RedGrooveBass's, wider than tall, the history's wider than the registers'. Empty: the square. */
        std::array<juce::Rectangle<float>, 6> holeKeys {};
        /** WHAT OF THE CONSOLE'S OWN A FACE HAS NO PLACE FOR. Every face but RedGrooveBass has both:
            - `plates`: REVERB, DELAY and CAB on their plates, with their words. Without them none is on the
              stage and REVERB's and DELAY's levels are bound to nothing; CAB's slider is still kept unseen —
              the console reads the cabinet that is playing off it — and its plate's box, sliderNames[2], is
              still where a dropped IR's tag stands and where a right click opens the cabinets' window.
            - `filterKeys`: HPF and LPF, the cabinet's cuts, under the tones. Without them neither key is on the
              stage or in the rows (Strips), and neither is bound to the cuts. */
        bool plates = true;
        bool filterKeys = true;
        std::array<juce::Rectangle<float>, 3> sliders;      // REVERB, DELAY, CAB
        std::array<juce::Rectangle<float>, 3> sliderNames;  // the row each plate's words stand in
        float sliderCapAngle = juce::MathConstants<float>::halfPi;  // how the sliders' caps lie (PlateSlider)
        float sliderCapLength = 0.0f;
        float faderCapLength = 0.0f;                        // ...and the columns' (ColumnFader)
        float faderCapSquash = 1.0f;                        // ...their height a share of the render's (ColumnFader::capSquash)
        juce::Rectangle<float> inMeter, inFader, outMeter, outFader;
        SegmentMeter::Dots meterDots {};                    // the meters as dots the picture paints, where there is a count
        float lampDot = 0.0f;                               // a lamp the picture does not paint lit, drawn by code this wide (Lamp::dot)
        juce::Rectangle<float> tuner;
        std::array<juce::Rectangle<float>, numLamps> lamps;
        std::vector<juce::Point<float>> emblemFace;         // the plate the mark is on, the hand's target
        juce::Rectangle<float> emblemMark;                  // the box the mark is cut in
        juce::Rectangle<float> version, load, memory, preset, gateDoor, limiterDoor;
        float gateDoorAngle = 0.0f, limiterDoorAngle = 0.0f;    // GATE and LIMITER turned about their middles, radians
        bool doorsFit = false;                              // ...set condensed into their boxes, as tall, where wider (Legend::fit)
        const char* limiterWord = "LIMITER";                // what LIMITER's door says: RedGrooveBass's says LIMIT, as its plate has room for
        float readingPx = stage::px11;                      // what CPU and MEM are written at...
        bool readingsFit = false;                           // ...set condensed into their boxes, as tall, where wider (Legend::fit)
        bool tunerStrip = false;                            // the tuner in one low line (TunerFace::setStrip)...
        TunerFace::Dial tunerDial {};                       // ...or a needle over a dial the picture paints, where it has a reach
        bool tunerMenuOnClick = false;                      // ...and a click on it opens its menu, rather than switching it
    };

    /** WHAT IT IS DRAWN WITH: the product's renders, and its words. */
    struct Look
    {
        const juce::Image& driveKnob;
        ArtKnob::Pointer drivePointer;
        const juce::Image& toneKnob;
        ArtKnob::Pointer tonePointer;
        const juce::Image& cap;                             // the plate sliders' cap
        const juce::Image& faderCap;                        // ...and the columns' faders'
        std::array<const juce::Image*, numLamps> lampsLit;  // each lamp as its render painted it lit
        juce::String mark;                                  // the product's mark, as SVG: the build window wears it
        juce::String midiCommands;                          // what the MIDI window lists (Midi.h)
        juce::Colour handLight {};                          // a light round a slider's or a fader's cap under the hand; none if transparent
        Ink ink {};                                         // what the words on the panel are written in
        juce::Colour emblemLamp {};                         // the lamp under the cat's glass under the hand (Emblem); none if transparent
    };

    Console (AmpProcessor&, std::unique_ptr<Picture>, const Places&, const Look&);
    ~Console() override;

    // Nothing to paint where the face is: it covers its whole stage, and where its window is cut out,
    // what shows through is the product's. Only in full screen is there window left round the stage,
    // and that is painted black.
    void paint (juce::Graphics&) override;
    void resized() override;

    /** Cmd+Z and Cmd+Shift+Z step the history; A B C D play a register; what the number keys and the
        others do to the channels is the product's (channelKey). */
    bool keyPressed (const juce::KeyPress&) override;

    /** A right click on the panel itself — anywhere that is not a control — opens the face's settings:
        the things a player sets once for the machine and the room, which have no place of their own on
        the console. */
    void mouseDown (const juce::MouseEvent&) override;

    /** A double click on GATE's lamp is LEARN — the first line of GATE's menu. */
    void mouseDoubleClick (const juce::MouseEvent&) override;

    /** IRs DROPPED ANYWHERE ON THE FACE become cabinets of the player's own — files, folders of them,
        zips. While they hang over the window a tag over CAB says what letting go will do. */
    bool isInterestedInFileDrag (const juce::StringArray& files) override;
    void fileDragEnter (const juce::StringArray& files, int x, int y) override;
    void fileDragExit (const juce::StringArray& files) override;
    void filesDropped (const juce::StringArray& files, int x, int y) override;

protected:
    AmpProcessor& amp;
    Engine&   engine;       // the product's half of the processor: the channels live there, window or no window
    Channels& channels;     // ...and these are its
    Presets   presets;
    const Places places;
    std::vector<std::pair<juce::String, juce::Image>> renders;     // the Look's, by the names exportForWeb writes them under
    struct LookForWeb { ArtKnob::Pointer drive {}, tone {}; juce::Colour handLight; Ink ink; } lookForWeb;   // ...and the rest of it
    std::vector<std::pair<juce::String, juce::Rectangle<float>>> spritesWritten;     // writeSprite's, for spriteBounds
    std::map<juce::String, bool> postersWritten;     // writePoster's stems, each with whether a live frame went under its glass
    juce::var webPlaces;                             // places.json, written once every poster is
    void poseNext (const juce::File& dir, int pose);
    void shootPoster (const juce::File& dir, int place, const juce::String& stem, std::function<void()> then);
    void finishWeb (const juce::File& dir);

    juce::Component stage;
    std::unique_ptr<Picture> picture;
    NameTag nameTag;             // over the controls: the last thing on the stage

    /** A control of the product's own onto the stage, under the name tag. */
    void addToStage (juce::Component&);

    void showGateMenu();            // GATE's plate: the gate the settings menu holds too
    void showOutputMenu();          // the OUTPUT column: the limiter, and where its ceiling is — and LIMITER's plate

    // While a lever is held, a tag over it says where it stands, in the lever's own decibels — which
    // for INPUT are the trim's own, so the middle of the travel reads 0.
    void sayLever (ColumnFader&, const juce::String& name, std::function<float()> reading);
    // ...or in words of its own: a share, a frequency.
    void sayLeverAs (ColumnFader&, const juce::String& name, std::function<juce::String()> words);

    // THE PRODUCT'S OWN. Each is asked from the console's own code once the face is built.

    /** Where the state's channel is now: the product's selector goes there (without saying so). */
    virtual void showSelector (int /*channel*/) {}

    /** A key with no modifier that the console does not use itself — the number keys, say. True when it
        was the product's. */
    virtual bool channelKey (const juce::KeyPress&) { return false; }

    /** A Program Change from a MIDI input, counted from 0. */
    virtual void programChange (int program) { if (program >= 0 && program < channels.count()) go (program); }

    /** TURBO's controller, thrown on or off. */
    virtual void turboChange (bool /*thrown*/) {}

    /** The WINDOW section the settings menu opens with: what the product's window shows, and full
        screen; then whatever else is the product's to set there. */
    virtual void addWindowSections (juce::PopupMenu&);

    /** A left click on the bare picture that the console does not use: true when the product took it. */
    virtual bool pictureClicked (juce::Point<int> /*onStage*/) { return false; }

    /** A right click on the bare picture, before the console's own: true when the product took it. */
    virtual bool pictureRightClicked (juce::Point<int> /*onStage*/) { return false; }

    /** The stage has been placed in the window again. */
    virtual void stagePlaced() {}

    /** FOR THE SITE: what the web's demo of this face is built from, written into `dir` as the kit the site
        reads, every picture a WebP (WebImages.h) — the picture that never changes at twice the stage's
        size, its window transparent, at the three sizes (cabin.webp, cabin@1x.webp, cabin@half.webp); the
        renders its controls are drawn with, in sprites/; where everything stands (places.json, in the
        stage's own 1672 x 941); and what the product adds (webExtras). Done once, when the window first
        comes up with the environment variable ORBITAMP_WEB_EXPORT naming the folder; a player never sees
        it. */
    void exportForWeb (const juce::File& dir);

    /** The product's part of it: its own renders (writeSprite) and files; in `places` the two keys every
        world has — "window", the box its live view goes in, and "stills", the files of its stills in the
        lever's order; in `world` whatever is its own alone — and its poster (writePoster). */
    virtual void webExtras (const juce::File& /*dir*/, juce::DynamicObject& /*places*/, juce::DynamicObject& /*world*/) {}

    /** A render of a control written for the site — sprites/<stem>.webp (web::writeSprite), which it
        returns for places.json to name it by, or null where there is no render to write — its opaque box
        (opaqueBounds) kept for places.json's spriteBounds under `stem`. */
    juce::var writeSprite (const juce::File& dir, const juce::String& stem, const juce::Image& img);

    /** ...and the name of one written already, for places.json: null where none was. */
    juce::var spriteRef (const juce::String& stem) const;

    /** THE POSTER: the whole face as it stands — every control where it stands, the lamps out — at twice
        the stage's size and the two smaller ones, in three kinds: with `live`, the live view's first frame,
        in `window` under the glass (<stem>.webp, <stem>@1x.webp, <stem>@half.webp), so that a page that
        starts the view there does not jump; with `still` there instead (<stem>-still.webp and its two); and
        with the window empty (<stem>-hole.webp and its two). With no live frame, the still's are the
        poster's and nothing is written twice. What shows through the window live is `hidden` while it is
        taken. */
    void writePoster (const juce::File& dir, juce::Rectangle<float> window, const juce::Image& still,
                      const juce::Image& live, const std::vector<juce::Component*>& hidden, const juce::String& stem);

    /** ...and how places.json names a poster's files: the three sizes of it, and the same three of its
        kinds, "still" and "hole" — the poster's own being the still's where no live frame went in. */
    static juce::var posterFiles (const juce::String& stem, bool live);

    /** THE POSTERS: the one the page opens on — the face as it opened, at the place it opened at — and one
        for each place of the lever, for a page that opens on another channel than the app does: how many
        places there are, which one the face opens at, how the face is stood in one (no animation), the
        still there, the live view's first frame there, and the window and its live layers. Set by
        webExtras; exportForWeb then writes the face's poster (poster.webp), stands the face in each place
        in turn and writes poster-<n>.webp once it has settled, then places.json, and done.txt last. */
    struct WebPoses
    {
        int count = 0;
        int opening = 0;
        std::function<void (int)> standAt;
        std::function<juce::Image (int)> still;

        /** THE LIVE VIEW'S FIRST FRAME at a place: what the view shows the moment it starts there, before
            anything has moved — as a page that starts its own copy of the view there shows it first —
            handed to `done` on the message thread, the window's size at twice the stage, or invalid where
            the GPU could not give one (the still goes under the glass then). Asked for once the face stands
            at the place. Unset, every poster has the still. */
        std::function<void (int, std::function<void (juce::Image)>)> firstFrame;
        juce::String live;      // ...what that frame is, for places.json's posterWindow: "live: <live>"

        juce::Rectangle<float> window;
        std::vector<juce::Component*> hidden;
    };
    WebPoses webPoses;

    /** THE PATCHES OF THE POSTER: where the face draws, on its hull, a control the site will not work — the
        history and the registers in the roof, the tuner, GATE's and LIMITER's doors, the version, PRESET,
        CPU and MEM; a product adds its own (webPatch). Each the box round the component as it stands. */
    std::vector<std::pair<juce::String, juce::Rectangle<float>>> webPatches;
    void webPatch (const juce::String& name, std::initializer_list<const juce::Component*> parts);

    /** To that channel, by a hand: one step of the history. False, and the face back on the channel
        that is playing, when its pack is not installed. */
    bool go (int channel);

    // THE STAGE IN THE WINDOW. The window has the face's shape and the stage fills it — except in full
    // screen, where the screen rarely has that shape: there the stage is the largest that fits, centred.
    float stageScale() const;
    juce::Point<float> stageOrigin() const;

    // FULL SCREEN, where the product stands alone: the window takes the whole screen — no title bar, no
    // menu bar, no Dock — and the face keeps its shape in the middle of it. From the settings menu,
    // Cmd+Ctrl+F or F11; Esc leaves.
    bool fullScreen = false;
    void setFullScreen (bool);

    // WHAT IS SET ON A CONTROL IS FOUND ON THAT CONTROL: a right click on it opens the few choices that
    // are about it, and nothing else. The settings menu keeps the machine's among them as well.
    void addChoice (juce::PopupMenu&, const juce::String& text, bool ticked,
                    std::function<void (Console&)> picked, bool enabled = true);

    // THE BOOST'S LEVEL (params::boostLevel) on TURBO's own menu: how much louder the amp leaves while
    // TURBO is on. The sound's — a session and a preset keep it, undo steps over it. How TURBO itself
    // drives the capture is the pack's and the engine's, and no menu's.
    void addBoostLevels (juce::PopupMenu&);
    void showBoostMenu();

    // Tapping — see tapTempo. Anything that moves the state ends a count left open.
    void endTapping();

    void  setParam (const char* paramId, float value);
    float getParam (const char* paramId) const;
    juce::ParameterAttachment* follow (const char* paramId, std::function<void (float)> moved);

    /** Puts the face where the state is. Reads only — it is called from inside the history's own
        callbacks. */
    void showChannel();

private:
    bool adoptionPending = false;
    void adoptState();
    void followEngine();

    // A LOOP IN PLACE OF THE GUITAR — OrbitAmp's audition player (core/DemoPlayer.h), here in the
    // settings menu. Only on a machine that has the loops (params::demoLoopsPresent); anywhere else the
    // menu does not offer it. A loop picked plays from its top; -1 starts the one last picked, or stops it.
    void playDemo (int loop);

    juce::Point<int> windowedAt;             // where the window stood before it took the screen
    int windowedTitleBarH = 0;               // ...and its title bar's height, gone while it has the screen
    void showSettingsMenu();

    const juce::String midiCommands;
    const Ink ink;

    ArtKnob drive;
    std::array<std::unique_ptr<ArtKnob>, Channels::maxTones> tones;

    /** Where each tone's sign is painted (the picture takes no hand): the hand over it names the tone,
        as over its knob. */
    struct HoverSpot final : juce::Component
    {
        HoverSpot() { setRepaintsOnMouseActivity (false); }
        std::function<void (bool)> onHover;
        void mouseEnter (const juce::MouseEvent&) override { if (onHover) onHover (true); }
        void mouseExit (const juce::MouseEvent&) override  { if (onHover) onHover (false); }
    };
    std::array<std::unique_ptr<HoverSpot>, Channels::maxTones> toneSpots;
    std::array<std::unique_ptr<PushButton>, numKeys> buttons;   // the keys under the tone knobs
    std::array<std::unique_ptr<PushButton>, 6> overhead;     // the keys in the roof's holes

protected:
    // A face's own sprites go onto these keys, where it has them (PushButton::setArt).
    PushButton& key (int index)     { return *buttons[(size_t) index]; }
    PushButton& roofKey (int index) { return *overhead[(size_t) index]; }
    ArtKnob& driveKnob()            { return drive; }
    ArtKnob& toneKnob (int index)   { return *tones[(size_t) index]; }
    const juce::String& keyName (int index) const { return keyNames[(size_t) index]; }

private:
    std::array<std::unique_ptr<PlateSlider>, 3> sliders;
    Legend reverbName;                       // REVERB and its character; a click picks another
    Legend cabName;                          // CAB and the cabinet that is playing
    juce::ParameterAttachment* reverbType = nullptr;
    // The delay's plate reads three things, and each answers the hand its own way:
    Legend delayWord;                        // DELAY — tapped, it takes the tempo from the taps
    Legend delayNote;                        // the note value — a click opens the list of them
    Legend delayTempo;                       // the tempo — dragged up or down like a knob
    juce::ParameterAttachment* delayDiv = nullptr;
    juce::ParameterAttachment* delayBpm = nullptr;
    float tempoTravel = 0.0f;                // the hand's travel not yet spent on a whole BPM
    bool  tempoIsOwn  = true;                // false while a host is conducting

    // Tapping. However many taps it takes to find the beat, the history sees one step: the count is
    // held open as a gesture from the first tap until the taps have stopped for a moment.
    struct After final : juce::Timer
    {
        std::function<void()> then;
        void timerCallback() override { stopTimer(); if (then) then(); }
    };
    After tapPause;

    // MIDI. A Program Change the engine heard (AmpProcessor::takeProgramChange) picks a channel the
    // product's way (programChange). A controller's value (takeControlChange) is a foot on TURBO, HPF
    // or LPF, or a pedal under DRIVE or a tone knob (midi::Controller). They are asked for a hundred
    // times a second — a foot must not feel the wait, and the face's own timer ticks four times.
    struct Pulse final : juce::Timer
    {
        std::function<void()> beat;
        void timerCallback() override { if (beat) beat(); }
    };
    Pulse midiPulse;
    void playMidi();
    std::vector<double> tapGaps;             // the last few gaps between taps, ms
    double lastTap = 0.0;
    bool   tapping = false;
    void tapTempo();
    ColumnFader inFader, outFader;

    // INPUT'S LEVER IS THE TRIM ITSELF, as OUTPUT's is: unity in the middle of its travel, ±24 dB about it.
    // How hard the capture is fed is the pack's to say, and it says it (`chain[].input_db`), so a lever
    // left in the middle feeds every pack where its captures were taken. Up to 0.8.0 the lever's middle
    // stood at a zero of the machine's instead, which a state of then carries folded into its trim
    // (AmpProcessor::takeFormerTrims).
    //
    // HOW DRIVE GOES BETWEEN THE PACK'S CAPTURES is the machine's too. Smoothly, unless told otherwise:
    // between two captures the player mixes them by the knob's angle, and the sound goes with the hand.
    // In steps, it lands on the nearer capture and holds it until the knob is nearer the next — one
    // capture playing at a time, each exactly as it was shot. The knob goes the same way: it clicks from
    // one capture's place to the next under the hand, and stands on one whatever DRIVE was left at.
    bool driveSteps = false;
    bool settingsDiffer() const;
    void settleOnSettings();
    void chooseDriveSteps (bool steps);

    void showInputMenu();           // the INPUT column: the hum
    void addHumLines (juce::PopupMenu&);    // the hum's switch and its modes, as every menu has them

    // THE HUM'S QUICK A/B: H flips it between OFF and the mode OFF bypasses (prefs::humFlip), and the
    // name tag over INPUT says for a moment which it is now. G does the same for the gate's On — the
    // sound's switch, so an undo step — and the tag over GATE says it.
    void flipHum();
    void flipGate();
    void sayForAMoment (juce::Point<float> at, const juce::String& words);
    int  humTagShown = 0;           // which flip the tag still speaks for
    void showTunerMenu();           // the tuner: whether it listens, and whether the amp is silent meanwhile
    void showTunerState();          // ...both written on its glass

    // A right click on DRIVE picks between the two ways, and offers a capture as a `.nam`: in steps the
    // one it stands on, turning smoothly the nearer of the two it stands between.
    std::unique_ptr<juce::FileChooser> captureChooser;
    void showDriveMenu();
    void saveCapture();

    // A right click on CAB opens the cabinets' window (Cabs.h): the lists, and what its keys do — the
    // cabinet that is playing handed out as the IR file it is, files taken in, and one of the player's
    // own renamed or removed.
    std::unique_ptr<juce::FileChooser> cabChooser;
    void saveCab();
    void chooseCabsToAdd();
    void renameCab();
    void removeCab();

    // The player's own cabinets: files taken into the IRs folder, CAB given a position for each, and
    // the first of the new ones played.
    void addCabinets (const juce::StringArray& paths);
    void cabinetsChanged();

    SegmentMeter inMeter, outMeter;

    // The lamps over the columns: each lights when its side has gone over full scale — the input as it
    // arrives, the output as it leaves — and stays lit long enough for the peak to be seen.
    static constexpr double clipHoldMs = 1000.0, clipFadeMs = 500.0;
    Lamp inClip, outClip;

    // GATE burns as hard as the gate is pressing the signal, LIMITER as hard as the limiter is squeezing
    // it. A click on either name opens what it is set by.
    Lamp gateLight, limiterLight;
    Legend gateDoor, limiterDoor;

protected:
    TunerFace tuner;

private:
    // LEARN, from GATE's menu: the gate's own measurement, the one OrbitAmp's GATE runs (ui/GateLearner.h)...
    GateLearner learner { amp.apvts, amp.gateKeyDb };

    // ...the hum's, from HUM's menus — its own, apart from the gate's (ui/HumLearner.h); only one of the
    // two runs at a time: starting either cancels the other.
    HumLearner humLearner { amp.product(), amp.humLearn, amp.gateKeyDb, amp.humTuned.quietHz };

protected:
    // ...and its picture, which the product lays over a glass of its own and places there (LearnGlass.h).
    // A face with a key of its own for it starts it as the menu does.
    LearnGlass learnGlass { learner, humLearner };
    void startGateLearn();
    void startHumLearn();

    /** THE CABINETS' WINDOW (Cabs.h), as a right click on CAB opens it — for a face whose cabinet is chosen its own way. */
    void showCabs();

    /** DRAWN CABINETS (Lineup::drawnCabinets, the toys' TOP 12): no window — CAB's right click lists the twelve by name,
        the one that plays ticked, and CABINET OFF, the cabinet out of the sound and back (the owner, 08.11). */
    void showDrawnCabs();

    /** A KEY OF THE SIX THE FACE TAKES FOR ITSELF, under a name of its own: the console neither lights it
        nor answers it from then on — what it does and whether it is lit are the face's. */
    void claimKey (int key, const juce::String& name);

private:
    Emblem emblem;

    // The version on its plate, the family's orange dot beside it when a newer release has been seen.
    // A click opens the same window OrbitAmp's footer does — appkit's badge, kept invisible and only
    // for that window.
    Legend version;
    felitronics::appkit::VersionBadge about;

    // CPU: the share of each audio block's time the engine spends — the number OrbitAmp's footer calls
    // DSP. It warms as it climbs, and a click opens the same stage-by-stage window (ui/LoadBreakdown.h)
    // — here inside the face, in the family's colours.
    Legend load;
    std::unique_ptr<Sheet> sheet;            // the window that click opens, while it is open
    void showLoad();
    void showMidi();                         // the MIDI inputs, from the settings menu
    void showSheet (std::unique_ptr<juce::Component> content);

    // MEM: what the process is holding, as the system's own monitor counts it (core/ProcessMemory.h).
    // Only while the product stands alone — inside a host the process is the host, and the figure
    // would be the host's.
    Legend memory;
    int memoryTick = 0;          // the timer runs four times a second; this is asked once a second

    // PRESET: the one word, the family's orange dot beside it while the sound has moved away from the
    // preset it came from, and everything else — which preset, the list, saving, renaming — behind a
    // click.
    Legend presetDoor;
    void showPresetMenu();
    void timerCallback() override;

    std::vector<std::unique_ptr<juce::ParameterAttachment>> attachments;

    template <typename Control>
    void bind (Control&, const juce::String& paramId);
    template <typename Control>
    std::unique_ptr<juce::ParameterAttachment> attach (Control&, const juce::String& paramId);

    std::array<std::unique_ptr<juce::ParameterAttachment>, Channels::maxTones> toneBindings;
    std::array<juce::String, Channels::maxTones> toneBound;
    void bindTones();
    void bindButton (PushButton&, const char* paramId);

    /** THE RIGHT GROUP'S KEYS on a channel: the switches of its pack a hand may throw (Channels::
        switchesOf, all but the one the channel holds), in the pack's order and under its names — a key to
        each position of a switch, the one it stands at lit (the Ch2's TIGHT · FAT; a switch whose every
        position is bare, the IR-X Ch1's Bright, its name once over its keys and each position alone by its
        key: BRIGHT over OFF · 1 · 2), and a switch whose two positions are off and on one key under the switch's
        own name — and after them the keys the face has taken for itself (claimKey), under the names it
        gave them. As many as there are, at most the keys the console has for them. */
    struct RightKey
    {
        int button = -1;        // which of `buttons`
        int slot = -1;          // the selector it throws; -1 = the face's own key
        int position = -1;      // lit while the switch stands here, and where a press puts it
        int off = -1;           // an off/on key: where it puts the switch when let up; -1 for a position's key
        juce::String control;   // the switch's name in the pack
        juce::String name;      // what is written by it
        juce::String title;     // the switch's name written once over its keys (BRIGHT); empty for most
    };
    std::vector<RightKey> rightKeysOf (int channel) const;
    std::vector<RightKey> rightKeys;            // the playing channel's, as showKeys last laid them
    std::array<juce::String, numKeys> keyNames; // each key's name for the tag over it, as showKeys last said
    std::array<bool, numKeys> claimed {};       // ...and the keys the face has taken for itself
    void keyThrown (int key, bool on);
    void showKeys();                            // the keys as the playing channel has them; reads only

protected:
    /** THE PLAYING CHANNEL'S ROWS (Strip.h), laid by one rule from the face's places, the channel's pack's
        tones and its right keys: what the controls stand on, what the picture paints and what the site
        is told (exportForWeb), each read off this. `stripsFor` lays any channel's without touching the
        face; `strips` is the playing one's, as layStrips last put the controls on it. */
    Strips stripsFor (int channel) const;
    Strips strips;
    void layStrips();

    /** A TONE'S SIGN, from the pack (rig.json `chain[].tone[i]`): its frequency response from 30 Hz to
        16 kHz — the sum of its bands (`sections`: low and high shelves, bells, tilts, by the cookbook's
        shapes), a knob at the top of its travel, a switch at its last position; or the position's own
        measured curve where it ships one — its lowest point 0 and its highest 1. Flat (all 0.5) where
        it states no shape. Dumb: the tone in, the points out. */
    static std::vector<float> toneCurve (const namz::rig::Tone&);

    /** The rows have been laid again — another channel, another count: what the face draws round its
        knobs and keys follows them (the rovers' rings). */
    virtual void stripsLaid (const Strips&) {}

private:

    void showReverbMenu();
    void showDelayMenu();
    void showDelayTime();
    void refreshHistory();
    void showRegisterMenu (int index);
    void chooseCab (int step);
    void showCab();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Console)
};

} // namespace orbitamp::face
