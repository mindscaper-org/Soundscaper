// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#include "Parameters.h"

#include "device/DeviceLibrary.h"
#include "device/PackOpening.h"

namespace orbitamp::params
{

namespace
{
    /** The factory defaults of a captured block, read from the PACK it opens on — the device by
        name in its slot's list, its tone knobs where the pack starts them, its selectors likewise.
        A parameter's default is what a fresh instance IS, and "the middle of every slot" is not a
        sound anyone chose. With the pack absent, everything falls back to the old neutral. A product
        that plays a pack of its own first (`capture`, its `rig_id`) has that pack's place as the
        device, and the named pack's knobs and switches still. */
    struct BlockDefaults
    {
        int   device = 0;
        std::array<float, (size_t) preampNumMeasured> meas;
        std::array<int,   (size_t) numSelectors>     sel {};

        BlockDefaults() { meas.fill (0.5f); }
    };

    BlockDefaults blockDefaults (const juce::String& product, device::DeviceLibrary::Slot slot,
                                 const juce::String& wantedName, const char* capture, bool packTones)
    {
        BlockDefaults d;
        const auto packs = device::DeviceLibrary::scan (product, slot);
        int named = -1, own = -1;

        for (int i = 0; i < packs.size(); ++i)
        {
            const auto& pack = packs.getReference (i);
            if (capture != nullptr && own < 0 && pack.rigId == capture)
                own = i;
            if (named >= 0 || pack.displayName() != wantedName)
                continue;

            const auto opening = device::PackOpening::of (pack);
            named    = i;
            d.device = i;
            d.meas   = opening.meas;
            d.sel    = opening.sel;
        }

        if (own >= 0)
            d.device = own;
        if (packTones && d.device < packs.size())      // ...or the tones where the pack that plays starts them (Opening::packTones)
            d.meas = device::PackOpening::of (packs.getReference (d.device)).meas;
        return d;
    }

    /** COMP's parameters, the bass's and the guitar's alike but for the character it opens on: on in the strip, its
        BLEND at half — or where the product's Opening says — its threshold at -24 dB and its ratio at 4:1 (the owner,
        31.10). */
    void addCompParameters (juce::AudioProcessorValueTreeState::ParameterLayout& layout, int character, float blend = 0.5f)
    {
        using Bool   = juce::AudioParameterBool;
        using Choice = juce::AudioParameterChoice;
        using Float  = juce::AudioParameterFloat;
        layout.add (std::make_unique<Bool>   (juce::ParameterID { compOn, 1 },        "Comp", true),
                    std::make_unique<Float>  (juce::ParameterID { compAmount, 1 },    "Comp Mix",
                                              juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f), blend),
                    std::make_unique<Choice> (juce::ParameterID { compAttack, 1 },    "Comp Attack",    compAttacks, 1),
                    std::make_unique<Choice> (juce::ParameterID { compRelease, 1 },   "Comp Release",   compReleases, 0),
                    std::make_unique<Choice> (juce::ParameterID { compCharacter, 1 }, "Comp Character", compCharacters, character),
                    std::make_unique<Float>  (juce::ParameterID { compThreshold, 1 }, "Comp Threshold",
                                              juce::NormalisableRange<float> (compThresholdMin, compThresholdMax, 0.1f), compThresholdDefault),
                    std::make_unique<Float>  (juce::ParameterID { compRatio, 1 },     "Comp Ratio",
                                              juce::NormalisableRange<float> (compRatioMin, compRatioMax, 0.01f, 0.5f), 4.0f));
    }
}

void addGuitarCompParameters (juce::AudioProcessorValueTreeState::ParameterLayout& layout)
{
    // Out of the strip until the player adds it; on OPTO (the owner, 02.11).
    addCompParameters (layout, compCharacters.indexOf ("Opto"));
    layout.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { compPresent, 1 }, "Comp In Strip", false));
}

void addBassParameters (juce::AudioProcessorValueTreeState::ParameterLayout& layout)
{
    addBassParameters (layout, Opening {});
}

void addBassParameters (juce::AudioProcessorValueTreeState::ParameterLayout& layout, const Opening& opening)
{
    using Bool   = juce::AudioParameterBool;
    using Choice = juce::AudioParameterChoice;
    using Float  = juce::AudioParameterFloat;
    const auto hz = [] (float lo, float hi, float centre)
    {
        return juce::NormalisableRange<float> (lo, hi, 0.1f, std::log (0.5f) / std::log ((centre - lo) / (hi - lo)));
    };

    addCompParameters (layout, compCharacters.indexOf ("Opto"), opening.compAmount);   // on OPTO (the owner, 02.11)

    // The three effects: in the strip, their sliders at 0 — present, and doing nothing until one is moved. The menus'
    // defaults are the modules' own.
    const juce::NormalisableRange<float> unit { 0.0f, 1.0f, 0.001f };
    layout.add (std::make_unique<Bool>   (juce::ParameterID { octaveOn, 1 },       "Octave", true),
                std::make_unique<Float>  (juce::ParameterID { octaveAmount, 1 },   "Octave Amount", unit, 0.0f),
                std::make_unique<Float>  (juce::ParameterID { octaveToneHz, 1 },   "Octave Tone Hz", hz (30.0f, 2000.0f, 120.0f), 120.0f));
    layout.add (std::make_unique<Bool>   (juce::ParameterID { filterOn, 1 },        "Envelope", true),
                std::make_unique<Float>  (juce::ParameterID { filterAmount, 1 },    "Envelope Amount", unit, 0.0f),
                std::make_unique<Choice> (juce::ParameterID { filterMode, 1 },      "Envelope Mode", filterModes, 0),
                std::make_unique<Choice> (juce::ParameterID { filterDirection, 1 }, "Envelope Direction", filterDirections, 0),
                std::make_unique<Float>  (juce::ParameterID { filterResonance, 1 }, "Envelope Resonance",
                                          juce::NormalisableRange<float> (0.5f, 12.0f, 0.01f, 0.5f), 4.0f),
                std::make_unique<Choice> (juce::ParameterID { filterRange, 1 },     "Envelope Range", filterRanges, 1),
                std::make_unique<Bool>   (juce::ParameterID { filterKeepLows, 1 },  "Envelope Keep Lows", true),
                std::make_unique<Float>  (juce::ParameterID { filterKeepHz, 1 },    "Envelope Keep Lows Hz",
                                          juce::NormalisableRange<float> (80.0f, 300.0f, 1.0f), 150.0f),
                std::make_unique<Float>  (juce::ParameterID { filterReleaseMs, 1 }, "Envelope Release ms",
                                          juce::NormalisableRange<float> (5.0f, 2000.0f, 1.0f, 0.4f), 120.0f));
    layout.add (std::make_unique<Bool>   (juce::ParameterID { chorusOn, 1 },          "Chorus", true),
                std::make_unique<Float>  (juce::ParameterID { chorusAmount, 1 },      "Chorus Amount", unit, 0.0f),
                std::make_unique<Float>  (juce::ParameterID { chorusRateHz, 1 },      "Chorus Rate Hz",
                                          juce::NormalisableRange<float> (0.05f, 10.0f, 0.01f, 0.4f), 0.7f),
                std::make_unique<Float>  (juce::ParameterID { chorusCrossoverHz, 1 }, "Chorus Crossover Hz",
                                          hz (200.0f, 500.0f, 300.0f), 200.0f));

    // IN THE STRIP OR NOT (Parameters.h): the three effects in, the echo and the room out — a player adds them through
    // the strip's checklist.
    layout.add (std::make_unique<Bool> (juce::ParameterID { octavePresent, 1 }, "Octave In Strip", true),
                std::make_unique<Bool> (juce::ParameterID { filterPresent, 1 }, "Envelope In Strip", true),
                std::make_unique<Bool> (juce::ParameterID { chorusPresent, 1 }, "Chorus In Strip", true),
                std::make_unique<Bool> (juce::ParameterID { delayPresent, 1 },  "Delay In Strip", false),
                std::make_unique<Bool> (juce::ParameterID { reverbPresent, 1 }, "Reverb In Strip", false));

    layout.add (std::make_unique<Float> (juce::ParameterID { ampBlend, 1 },       "Amp Blend",
                                         juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f), 1.0f),
                std::make_unique<Float> (juce::ParameterID { ampBlendHz, 1 },     "Amp Blend Hz",
                                         hz (ampBlendMinHz, ampBlendMaxHz, ampBlendDefaultHz), ampBlendDefaultHz),
                std::make_unique<Bool>  (juce::ParameterID { ampBlendInvert, 1 }, "Amp Blend Invert", false));

    layout.add (std::make_unique<Float> (juce::ParameterID { cabMix, 1 }, "Cab Mix",
                                         juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), cabMixDefault));

    layout.add (std::make_unique<Bool>   (juce::ParameterID { bassHpfOn, 1 },        "Bass HPF On", true),
                std::make_unique<Choice> (juce::ParameterID { bassHpf, 1 },          "Bass HPF", bassHpfPositions, (int) BassHpf::five),
                std::make_unique<Float>  (juce::ParameterID { bassHpfHz4, 1 },       "Bass HPF 4 Hz",
                                          juce::NormalisableRange<float> (20.0f, 60.0f, 0.1f), bassHpfDefaultHz4),
                std::make_unique<Float>  (juce::ParameterID { bassHpfHz5, 1 },       "Bass HPF 5 Hz",
                                          juce::NormalisableRange<float> (15.0f, 45.0f, 0.1f), bassHpfDefaultHz5),
                std::make_unique<Bool>   (juce::ParameterID { bassLpfOn, 1 },        "Bass LPF On", opening.bassLpfOn),
                std::make_unique<Choice> (juce::ParameterID { bassLpf, 1 },          "Bass LPF", bassLpfPositions, (int) BassLpf::fingers),
                std::make_unique<Float>  (juce::ParameterID { bassLpfHzFingers, 1 }, "Bass LPF Fingers Hz",
                                          hz (2000.0f, 8000.0f, 4500.0f), bassLpfDefaultHzFingers),
                std::make_unique<Float>  (juce::ParameterID { bassLpfHzSlap, 1 },    "Bass LPF Slap Hz",
                                          hz (5000.0f, 16000.0f, 9500.0f), bassLpfDefaultHzSlap));
}

float engineDefault (const juce::RangedAudioParameter& p, int enginePlace)
{
    const Opening engine;
    const auto& id = p.paramID;

    if (id == preampDevice) return p.convertTo0to1 ((float) enginePlace);
    if (id == stereoMode)   return p.convertTo0to1 ((float) (int) engine.stereoMode);
    if (id == reverbType)   return p.convertTo0to1 ((float) juce::jmax (0, reverbCharacters.indexOf (engine.reverb)));
    if (id == reverbMix)    return p.convertTo0to1 (engine.reverbMix);
    if (id == delayMix)     return p.convertTo0to1 (engine.delayMix);
    return p.getDefaultValue();
}

juce::AudioProcessorValueTreeState::ParameterLayout createLayout (const juce::String& product, const Opening& opening)
{
    // A FRESH INSTANCE IS WHAT ITS DEFAULTS SAY — the first launch, a new instance in a host, and INIT
    // alike: the Soldano X88-IR Crunch through RED GIANT, the input and output columns in the chain, the delay
    // on with nothing in its mix, and everything else where the cockpit leaves it, at its parameter's
    // own default — except where `opening` says otherwise: a product's first channel's pack, room and
    // delay, and the channel mode the environment chose. The cockpit and the rovers set their chain over
    // these defaults (channels/Engine.cpp, setUpChain) and find them already so.
    //
    // The device a fresh instance opens on, and everything the engine's pack says about starting it.
    const auto preampDef = blockDefaults (product, device::DeviceLibrary::ampSlot, enginePack, opening.capture, opening.packTones);

    using Bool   = juce::AudioParameterBool;
    using Choice = juce::AudioParameterChoice;
    using Float  = juce::AudioParameterFloat;
    using Int    = juce::AudioParameterInt;

    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    // The tuner's own STANDBY/ON — the rovers' and the cockpit's menus (Product::tunerSwitch). On out of
    // the box.
    layout.add (std::make_unique<Bool> (juce::ParameterID { tunerOn, 1 }, "Tuner",  true));

    // The tuner's mute ships OFF: a plugin that opens silent is a plugin reported as broken.
    layout.add (std::make_unique<Bool> (juce::ParameterID { tunerMute, 1 }, "Tuner Mute", false));

    // Block power. Both are the sound, so both start on — the reverb where the product's chain holds one
    // (Opening::reverbOn).
    layout.add (std::make_unique<Bool> (juce::ParameterID { preampOn, 1 }, preampName, true),
                std::make_unique<Bool> (juce::ParameterID { reverbOn, 1 }, "Reverb", opening.reverbOn));

    // The input trim, ahead of everything. Unity by default: it exists to fix a rig, not to be
    // part of a sound.
    layout.add (std::make_unique<Float> (juce::ParameterID { inTrim, 1 }, "Input Trim",
                                         juce::NormalisableRange<float> (-inTrimRangeDb, inTrimRangeDb, 0.1f),
                                         0.0f));

    layout.add (std::make_unique<Float> (juce::ParameterID { outTrim, 1 }, "Output Trim",
                                         juce::NormalisableRange<float> (-inTrimRangeDb, inTrimRangeDb, 0.1f),
                                         0.0f));

    // SAFETY out of the box: the ceiling at -0.3 — the guard rail, not a sound.
    layout.add (std::make_unique<Bool> (juce::ParameterID { limiterOn, 1 }, "Limiter", true),
                std::make_unique<Float> (juce::ParameterID { limiterCeiling, 1 }, "Limiter Ceiling",
                                         juce::NormalisableRange<float> (limiterCeilingMin,
                                                                         limiterCeilingMax, 0.1f),
                                         -0.3f));

    // The boost's level, heard only while the amp's boost is on — see Parameters.h.
    layout.add (std::make_unique<Float> (juce::ParameterID { boostLevel, 1 }, "Boost Level",
                                         juce::NormalisableRange<float> (boostLevelMin, boostLevelMax, 1.0f),
                                         opening.boostLevel));

    // The noise gate. Off out of the box — a gate is a decision about YOUR noise floor, not part
    // of the voicing. The ceiling is -10, NOT OrbitCab's -20: that range was voiced for a
    // post-trim guitar, and a raw input's bleed can sit at -20 dBFS all day — a threshold that
    // cannot climb over the signal is a gate that can never close, which read as "GR never
    // fires". Found live, against a speaker feeding the mic exactly that.
    layout.add (std::make_unique<Bool>  (juce::ParameterID { gateOn, 1 }, "Gate", false),
                std::make_unique<Float> (juce::ParameterID { gateThreshold, 1 }, "Gate Threshold",
                                         juce::NormalisableRange<float> (gateThresholdMin, gateThresholdMax, 1.0f), -50.0f),
                std::make_unique<Choice> (juce::ParameterID { gatePos, 1 }, "Gate Mute At",
                                          gatePositions, 1),
                std::make_unique<Choice> (juce::ParameterID { gateDecay, 1 }, "Gate Decay",
                                          gateDecayModes, 0));

    // The raw switch and the selector slots, one set per captured block. No trim of its own: how
    // hard the capture is fed is the pack's stated level and the IN column's hand.
    for (const char* blk : { preampId })
    {
        const juce::String label = blk == preampId ? preampName : blk;   // the block's name, as a host shows it

        // The DEVICE's own tone by default: a captured pedal arrives wearing its own knobs, and
        // the console is the scalpel you reach for past them.
        layout.add (std::make_unique<Choice> (juce::ParameterID { blockEqMode (blk), 1 },
                                              label + " EQ", eqModes, 0));

        // The dial's motion between captures. STEP by default — the captured positions are the
        // device as it was shot — and SMOOTH for whoever wants every angle between them.
        layout.add (std::make_unique<Bool> (juce::ParameterID { blockSmooth (blk), 1 },
                                            label + " Smooth", false));

        const auto& def = blk == preampId ? preampDef : BlockDefaults();
        for (int i = 0; i < numSelectors; ++i)
            layout.add (std::make_unique<Int> (juce::ParameterID { selectorId (blk, i), 1 },
                                               label + " Select " + juce::String (i + 1),
                                               0, 15, def.sel[(size_t) i]));
    }

    layout.add (std::make_unique<Int> (juce::ParameterID { preampDevice, 1 }, juce::String (preampName) + " Device",
                                       0, maxDevices - 1, preampDef.device));

    // Normalised 0..1: a measured control's real span is degrees on some device's dial, and the pack
    // is what knows it. The parameter stays the same shape whatever loads.
    for (int i = 0; i < preampNumMeasured; ++i)
        layout.add (std::make_unique<Float> (juce::ParameterID { preampMeasured (i), 1 },
                                             juce::String (preampName) + " " + juce::String (i + 1),
                                             juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f),
                                             preampDef.meas[(size_t) i]));

    // The hero. 0-10 is the amp-panel scale, not a dB value — it maps onto the captured detents, so
    // the number on the face is the number the capture was taken at. The knob is CONTINUOUS: between
    // two captured positions the player mixes the two neighbours by angle, and in STEP mode it lands
    // on the nearer one itself — the parameter never has to know where the captures are.
    layout.add (std::make_unique<Float> (juce::ParameterID { preampGain, 1 }, "Gain",
                                         juce::NormalisableRange<float> (0.0f, 10.0f, 0.01f), 5.0f));

    // The boost of a pack that has no Boost switch of its own — see Parameters.h. Off out of the box.
    layout.add (std::make_unique<Bool> (juce::ParameterID { preampBoost, 1 }, juce::String (preampName) + " Boost", false));

    // Frequencies are skewed so the useful end of each sweep gets the middle of the travel.
    auto hz = [] (float lo, float hi, float centre)
    {
        return juce::NormalisableRange<float> (lo, hi, 0.1f, std::log (0.5f) / std::log ((centre - lo) / (hi - lo)));
    };

    // The EQ link, in the console grammar. It ships FLAT, which is also what it used to ship switched
    // off as — a link with every band at zero is bit-transparent, so the enable it used to carry said
    // nothing the values did not.
    for (int l = 0; l < numEqLinks; ++l)
    {
        const juce::String name = juce::String (preampName) + " EQ ";
        const juce::NormalisableRange<float> tone { -toneRangeDb, toneRangeDb, 0.1f };
        const juce::NormalisableRange<float> q    { 0.3f, 6.0f, 0.01f, 0.5f };
        const juce::NormalisableRange<float> qN   { 1.0f, 18.0f, 0.01f, 0.5f };   // the surgical bell runs narrow

        // The cut filters, each with its slope. Off by default: they are for tightening a
        // specific rig, not part of the voicing.
        layout.add (std::make_unique<Bool>   (juce::ParameterID { eqHpfOn (l),    1 }, name + "HPF", false),
                    std::make_unique<Float>  (juce::ParameterID { eqHpfHz (l),    1 }, name + "HPF Freq",
                                              hz (0.0f, 1000.0f, 80.0f), 80.0f),
                    std::make_unique<Choice> (juce::ParameterID { eqHpfSlope (l), 1 }, name + "HPF Slope",
                                              eqSlopes, eqSlopeDefault),
                    std::make_unique<Bool>   (juce::ParameterID { eqLpfOn (l),    1 }, name + "LPF", false),
                    std::make_unique<Float>  (juce::ParameterID { eqLpfHz (l),    1 }, name + "LPF Freq",
                                              hz (1200.0f, 20000.0f, 8000.0f), 10000.0f),
                    std::make_unique<Choice> (juce::ParameterID { eqLpfSlope (l), 1 }, name + "LPF Slope",
                                              eqSlopes, eqSlopeDefault));

        // The shelves: gain and corner, no Q — a shelf with a Q is a bell wearing a coat.
        layout.add (std::make_unique<Float> (juce::ParameterID { eqLoDb (l), 1 }, name + "Lo",      tone, 0.0f),
                    std::make_unique<Float> (juce::ParameterID { eqLoHz (l), 1 }, name + "Lo Freq",
                                             hz (30.0f, 500.0f, 100.0f), 100.0f),
                    std::make_unique<Float> (juce::ParameterID { eqHiDb (l), 1 }, name + "Hi",      tone, 0.0f),
                    std::make_unique<Float> (juce::ParameterID { eqHiHz (l), 1 }, name + "Hi Freq",
                                             hz (1500.0f, 16000.0f, 6000.0f), 8000.0f));

        // The bells: two for the tone, and the narrow third that switches in — the surgical slot
        // search→treat lands in.
        layout.add (std::make_unique<Float> (juce::ParameterID { eqBellDb (l, 0), 1 }, name + "B1",      tone, 0.0f),
                    std::make_unique<Float> (juce::ParameterID { eqBellHz (l, 0), 1 }, name + "B1 Freq",
                                             hz (60.0f, 3000.0f, 400.0f), opening.midHz),
                    std::make_unique<Float> (juce::ParameterID { eqBellQ (l, 0),  1 }, name + "B1 Q", q, 1.0f),
                    std::make_unique<Float> (juce::ParameterID { eqBellDb (l, 1), 1 }, name + "B2",      tone, 0.0f),
                    std::make_unique<Float> (juce::ParameterID { eqBellHz (l, 1), 1 }, name + "B2 Freq",
                                             hz (300.0f, 12000.0f, 2500.0f), 2500.0f),
                    std::make_unique<Float> (juce::ParameterID { eqBellQ (l, 1),  1 }, name + "B2 Q", q, 1.0f),
                    std::make_unique<Bool>  (juce::ParameterID { eqB3On (l),      1 }, name + "B3", false),
                    std::make_unique<Float> (juce::ParameterID { eqBellDb (l, 2), 1 }, name + "B3",      tone, 0.0f),
                    std::make_unique<Float> (juce::ParameterID { eqBellHz (l, 2), 1 }, name + "B3 Freq",
                                             hz (100.0f, 12000.0f, 3000.0f), 3000.0f),
                    std::make_unique<Float> (juce::ParameterID { eqBellQ (l, 2),  1 }, name + "B3 Q", qN, 8.0f));
    }

    // The cabinet. Position and distance are the two halves of one gesture on the grid; distance is
    // in centimetres, matching the grid's own ladder.
    layout.add (std::make_unique<Bool> (juce::ParameterID { cabOn, 1 }, "Cabinet", true));

    // The IR's own post: two cuts, a trim and a flip, each behind a switch — off, the IR plays as
    // it was shot. The frequencies are ranged as OrbitCab ranges them.
    layout.add (std::make_unique<Bool>  (juce::ParameterID { cabHpfOn,  1 }, "Cab HPF", false),
                std::make_unique<Float> (juce::ParameterID { cabHpfHz,  1 }, "Cab HPF Hz",
                                         juce::NormalisableRange<float> (cabHpfMinHz, cabHpfMaxHz, 1.0f, 0.5f), cabHpfDefaultHz),
                std::make_unique<Choice> (juce::ParameterID { cabHpfSlope, 1 }, "Cab HPF Slope", eqSlopes, 1),
                std::make_unique<Bool>  (juce::ParameterID { cabLpfOn,  1 }, "Cab LPF", false),
                std::make_unique<Float> (juce::ParameterID { cabLpfHz,  1 }, "Cab LPF Hz",
                                         juce::NormalisableRange<float> (cabLpfMinHz, cabLpfMaxHz, 10.0f, 0.5f), cabLpfDefaultHz),
                std::make_unique<Choice> (juce::ParameterID { cabLpfSlope, 1 }, "Cab LPF Slope", eqSlopes, 1),
                std::make_unique<Bool>  (juce::ParameterID { cabTrimOn, 1 }, "Cab Trim", false),
                std::make_unique<Float> (juce::ParameterID { cabTrim,   1 }, "Cab Trim Length",
                                         juce::NormalisableRange<float> (cabTrimMin, 1.0f, 0.001f), 1.0f),
                std::make_unique<Bool>  (juce::ParameterID { cabPhase,  1 }, "Cab Phase", false));


    // MONO is the truth of a guitar chain and half the neural cost; STEREO is the double-track
    // option — two takes on one bus, each through its own amp; STEREO SPACE keeps the amp mono
    // and lets the reverb and everything after it go wide. Which one a fresh instance stands on is
    // the environment's (AmpProcessor::modeOfEnvironment), and so is its default.
    layout.add (std::make_unique<Choice> (juce::ParameterID { stereoMode, 1 }, "Stereo Mode",
                                          stereoModes, (int) opening.stereoMode));

    // ON ships as the pack's stated law for its ALIASES; a library captured at one honest level
    // switches it off and feeds every model exactly what the chain hands over. It bypasses
    // `files[].input_db` and nothing else — the pack's own two levels are applied whatever this says.
    layout.add (std::make_unique<Bool> (juce::ParameterID { packLevelComp, 1 }, "Pack Level Comp",
                                        true));

    layout.add (std::make_unique<Choice> (juce::ParameterID { cabIr, 1 }, "Cabinet IR",
                                          cabIrNames, cabIrDefault));

    // The delay, ON with nothing in its mix, as the cockpit's Crunch opens (a product whose first channel
    // opens on some declares that): the echo is there to be turned up, and still not a starting point.
    // Sync ships ON at a quarter note: the free milliseconds are the specialist's mode, the division is
    // the player's. The BPM field is the standalone's conductor; in a host the session's tempo conducts,
    // unless the player asks the delay to keep its own.
    layout.add (std::make_unique<Bool>   (juce::ParameterID { delayOn, 1 }, "Delay", opening.delayOn),
                std::make_unique<Bool>   (juce::ParameterID { delaySync, 1 }, "Delay Sync", true),
                std::make_unique<Bool>   (juce::ParameterID { delayHostTempo, 1 }, "Delay Follows Host", true),
                std::make_unique<Choice> (juce::ParameterID { delayDiv, 1 }, "Delay Division",
                                          delayDivisions, delayDivDefault),
                std::make_unique<Float>  (juce::ParameterID { delayBpm, 1 }, "Delay BPM",
                                          juce::NormalisableRange<float> (delayBpmMin, delayBpmMax, 0.1f),
                                          delayBpmDefault),
                std::make_unique<Float>  (juce::ParameterID { delayTimeMs, 1 }, "Delay Time",
                                          juce::NormalisableRange<float> (delayTimeMinMs, delayTimeMaxMs,
                                                                          1.0f, 0.5f),
                                          350.0f),
                std::make_unique<Float>  (juce::ParameterID { delayRepeats, 1 }, "Delay Repeats",
                                          juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 35.0f),
                std::make_unique<Float>  (juce::ParameterID { delayDark, 1 }, "Delay Dark",
                                          juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f),
                                          delayDarkDefaultPct),
                std::make_unique<Float>  (juce::ParameterID { delayOffset, 1 }, "Delay Offset",
                                          juce::NormalisableRange<float> (-delayOffsetMaxMs,
                                                                          delayOffsetMaxMs, 0.1f),
                                          0.0f),
                std::make_unique<Float>  (juce::ParameterID { delayMix, 1 }, "Delay Mix",
                                          juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), opening.delayMix));

    // PLATE at thirty: the shipping room, or the room and share a product's first channel opens on.
    // DECAY breathes around unity, PREDELAY ships at zero, and the tail's HPF waits switched off at a
    // bass-cleaning corner.
    layout.add (std::make_unique<Choice> (juce::ParameterID { reverbType, 1 }, "Reverb", reverbCharacters,
                                          juce::jmax (0, reverbCharacters.indexOf (opening.reverb))),
                std::make_unique<Float>  (juce::ParameterID { reverbMix, 1 }, "Mix",
                                          juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), opening.reverbMix),
                std::make_unique<Float>  (juce::ParameterID { reverbDecay, 1 }, "Reverb Decay",
                                          juce::NormalisableRange<float> (0.5f, 2.0f, 0.01f,
                                                                          std::log (0.5f) / std::log ((1.0f - 0.5f) / (2.0f - 0.5f))),
                                          1.0f),
                std::make_unique<Float>  (juce::ParameterID { reverbPredelay, 1 }, "Reverb Predelay",
                                          juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 0.0f),
                std::make_unique<Float>  (juce::ParameterID { reverbHpfHz, 1 }, "Reverb HPF Hz",
                                          hz (40.0f, 500.0f, 120.0f), 120.0f));

    return layout;
}

} // namespace orbitamp::params
