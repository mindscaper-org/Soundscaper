// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#pragma once

#include <juce_audio_basics/juce_audio_basics.h>

namespace orbitamp::core
{

/** THE ONE FADE, for every link that REPLACES the signal rather than adding to it.

    An additive link — the delay, the room — needs none of this: stop feeding it and its own tail
    is the fade. A link that replaces has no tail to ride out; drop it out of the path and the
    waveform takes a step, and a step is a click. So it is crossfaded against the signal it was
    handed: dry at one end, what the block made at the other.

    The whole point is that it costs NOTHING while nothing is happening. A fade that is finished
    reports `moving() == false`, and the call site then either runs the block plainly or skips it
    plainly — no copy of the signal, no per-sample multiply. Only the fifteen milliseconds after a
    switch is touched pay for anything, which is why the length can be generous enough to be
    inaudible without anybody having to think about the cost.

    Message thread sets nothing here: the audio thread reads its switches itself and this only
    follows what it read. */
class BypassFade
{
public:
    /** Milliseconds. Long enough that no step survives it, short enough that a switch still feels
        like a switch — a bypass that takes longer than this stops reading as a bypass and starts
        reading as a slow knob. */
    static constexpr float lengthMs = 15.0f;

    void prepare (double sampleRate) noexcept
    {
        perSample = sampleRate > 0.0
                      ? (float) (1000.0 / (sampleRate * (double) lengthMs))
                      : 1.0f;
    }

    /** No fade on the first block after a prepare: a chain that arrives switched off should be
        silent from its first sample, not fade in from wherever the last session left this. */
    void snapTo (bool on) noexcept { g = on ? 1.0f : 0.0f; }

    /** Where the blend stands at the start of this block and where it will stand at its end.
        `moving` false means the whole block sits at one end: nothing to blend, nothing to copy. */
    struct Span
    {
        float from = 1.0f, to = 1.0f;
        bool  moving = false;

        /** How many samples OF THIS BLOCK the fade actually occupies. Interpolating across the
            whole block instead stretched the last stretch of every fade to the block's length:
            at four thousand samples a fifteen-millisecond fade became eighty-five. */
        int   ramp = 0;
    };

    Span advance (int numSamples, bool target) noexcept
    {
        const float want = target ? 1.0f : 0.0f;

        if (juce::approximatelyEqual (g, want))
            return { g, g, false };

        // A block with no samples moves nothing — but a fade that is under way is still under way:
        // reporting it stopped would tell the chain an outgoing link is gone, and the link would be
        // cleared with its tail still sounding. (It used to reach the ramp below and ask for a
        // number between 1 and 0.)
        if (numSamples <= 0)
            return { g, g, true, 0 };

        const float from   = g;
        const float needed = std::abs (want - g) / juce::jmax (1.0e-9f, perSample);
        const int   ramp   = juce::jlimit (1, numSamples, (int) std::ceil (needed));
        const float step   = perSample * (float) ramp;

        g = target ? juce::jmin (want, g + step) : juce::jmax (want, g - step);
        return { from, g, true, ramp };
    }

    /** Is the block's output wanted at all this block — because it is in, or because it is still
        on its way out and the tail of the crossfade needs something to fade FROM. */
    static bool runs (const Span& s, bool target) noexcept { return target || s.moving; }

    /** dry + (wet - dry) * g, with g walking from `from` to `to` across the block. `wet` is the
        buffer the block just wrote in place; `dry` is what it was handed. */
    static void blend (float* const* wet, const float* const* dry, int numChannels, int numSamples,
                       const Span& s) noexcept
    {
        if (numSamples <= 0)
            return;

        const int   ramp = juce::jlimit (1, numSamples, s.ramp);
        const float step = (s.to - s.from) / (float) ramp;

        for (int ch = 0; ch < numChannels; ++ch)
        {
            float*       w = wet[ch];
            const float* d = dry[ch];

            // Walk for as long as the fade actually lasts, then HOLD. A fade that finishes a
            // fifth of the way into a big block must not go on sliding for the other four.
            for (int i = 0; i < numSamples; ++i)
            {
                const float g = i < ramp ? s.from + step * (float) i : s.to;
                w[i] = d[i] + (w[i] - d[i]) * g;
            }
        }
    }

private:
    float g         = 1.0f;
    float perSample = 1.0f;
};

} // namespace orbitamp::core
