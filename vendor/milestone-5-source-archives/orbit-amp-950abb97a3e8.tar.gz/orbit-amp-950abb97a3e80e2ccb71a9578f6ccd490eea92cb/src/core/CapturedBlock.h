// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

#pragma once

#include "../Parameters.h"
#include "../device/DeviceLibrary.h"
#include "ScopeTap.h"
#include "WaveRibbon.h"

#include <felitronics/lineareq/MagnitudeCurve.h>
#include <felitronics/rigplayer/RigPlayer.h>

#include <juce_events/juce_events.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <memory>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace orbitamp::core
{

/** Everything one captured block needs to play and to be looked at.

    A block is a device list, the player sounding whatever is chosen from it, and the two taps its
    pictures read. The PLAYER is felitronics::rigplayer — the one the capture app auditions through —
    so which captures sound for a panel, how two of them are mixed along the gain dial, how a tone
    knob becomes a filter and how two models are lined up in time are decided once, there, and
    checked there without a sound card. What is here is the translation: a host's parameters into
    the player's knobs, a pack on disk into the bytes the player asks for, and the player's
    read-outs into what a face draws.

    Nothing here knows which block it is. What differs between them is the SLOT they scan for and the
    parameters they are wired to — both handed in from outside. */
class CapturedBlock
{
public:
    using RigPlayer = felitronics::rigplayer::RigPlayer;

    /** Tone slots a host can see. Parameters exist for this many, and the loaded pack decides what
        each one turns — five, because the biggest preamp pack ships five. */
    static constexpr int numMeasured = params::preampNumMeasured;

    /** The picture's frequency axis: the player draws its tone on a 20 Hz – 20 kHz grid. */
    static constexpr double toneLoHz = 20.0;
    static constexpr double toneHiHz = 20000.0;

    explicit CapturedBlock (device::DeviceLibrary::Slot deviceSlot) : slot (deviceSlot) {}

    /** A load still out on the pool comes back to nobody: the token it checks is gone. */
    ~CapturedBlock() { alive.reset(); }

    void prepare (double sampleRate, int maxBlock, int numChannels)
    {
        player.prepare (sampleRate, maxBlock, numChannels);
        ribbon.prepare (sampleRate);
        curDrive = drive.load();
        pushGain.reset (sampleRate, pushRampSeconds);
        pushGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (push.load (std::memory_order_relaxed)));
        lastGain = -1.0f;
        lastTone.fill (-1.0f);
    }

    /** Re-reads the folder and STAYS ON THE DEVICE THAT IS PLAYING. Message thread.

        It used to re-select by the index it was handed, which is the one thing an index cannot
        survive: the list is in the AMP menu's order, so importing a pack
        that sorts earlier moves everything after it down one — and a rescan happens exactly when
        a pack has just been imported. The block would come back playing its neighbour.

        Returns where the loaded device now stands, so the caller can put the parameter there; -1
        when nothing is loaded or the device that was playing has gone from the folder, in which
        case the index it was handed stands as before. `product` is the name of the product playing it. */
    int rescan (const juce::String& product, int index)
    {
        const auto playing = loadedName;
        packs = device::DeviceLibrary::scan (product, slot);


        const int moved = playing.isNotEmpty() ? indexOfName (playing) : -1;

        select (moved >= 0 ? moved : index);
        return moved;
    }

    /** Loads the device at `index` — the HOST's handle on the choice, and only that.

        The index is not an identity and cannot be one: the list is whatever is on disk today,
        in the AMP menu's order, so dropping one new pack into the folder
        renumbers everything after it. What the state carries is the NAME (see `selectedName` and
        `AmpProcessor::applySwitchAims`); this takes the number the name resolved to.

        When the number points nowhere the first device stands in rather than nothing loading, since
        silence is a worse answer than the wrong device and the name on the block says which it is. */
    void select (int index)
    {
        lastSelected = index;

        const auto* pack = packAt (index);

        if (pack == nullptr)
        {
            loadedName.clear();
            player.unload();
            refreshWearableTone();
            return;
        }

        loadedName = pack->displayName();

        // The bytes come by `files[].id`, from whatever thread the host runs the load job on — not
        // the one that opened the pack. So the source owns what it needs to find them, and the
        // library opens the archive afresh per call and shares nothing with anyone.
        auto where = std::make_shared<const device::DeviceLibrary::Pack> (*pack);

        player.load (pack->rig, [where] (const std::string& id) -> std::vector<std::byte>
        {
            const auto block = device::DeviceLibrary::readBinaryEntry (*where, juce::String (id));
            const auto* p = static_cast<const std::byte*> (block.getData());
            return std::vector<std::byte> (p, p + block.getSize());
        });

        player.setBlendShape (shapeFor (lastSmooth));

        if (raw)
            parkTone();

        // The pump lands every knob where its parameter stands: the values are the host's, and
        // a device change does not move them.
        lastGain = -1.0f;
        lastTone.fill (-1.0f);
        lastSelector.fill (-1);

        refreshWearableTone();
    }

    /** WHICH DEVICE IS ACTUALLY LOADED, BY NAME — the pack file's own name for it, which is what
        the list shows and what travels with the file when it is copied to another machine.

        This is the identity the state saves. The parameter beside it is an index into a list that
        is in the AMP menu's order, so ONE new pack dropped into the
        folder renumbers every device after it and every session that named one by number now names
        a different one — silently, and with the loaded device's name still printed on the block to
        say so. Empty when nothing is loaded. */
    juce::String selectedName() const { return loadedName; }

    /** WHICH INDEX THE LOADED PACK CAME FROM — so a caller can tell whether the name above is an
        answer about the number it is holding, or about the one before it. The device parameter can
        move from the audio thread between two message-thread passes; naming the block then would
        write the leaving device's name beside the arriving device's number. */
    int selectedIndex() const noexcept { return lastSelected; }

    /** Where a NAMED device stands in the list as it is right now, or -1 when this machine has
        nothing by that name. Message thread — the list is rescanned there. */
    int indexOfName (const juce::String& name) const
    {
        for (int i = 0; i < packs.size(); ++i)
            if (packs.getReference (i).displayName() == name)
                return i;

        return -1;
    }

    /** Loads what the device parameter now points at, when it moved. This is how a restored session
        or a host automating the parameter actually lands: replaceState changes the number and calls
        nothing, so the pump watches it — the same arrangement every other loading knob has. */
    void selectIfMoved (int index)
    {
        if (index != lastSelected)
            select (index);
    }

    /** The device's OTHER selecting controls — everything that picks a file and is not the gain dial.
        Fur Coat's octave, IR-X's Bright: in the order the pack lists them, because that order is the
        one the device's own panel had. */
    struct Selector
    {
        juce::String      name;
        juce::StringArray values;
        int               defaultIndex = 0;   // where the pack says a player starts
    };

    juce::Array<Selector> selectors() const
    {
        juce::Array<Selector> out;

        if (const auto* s = nam())
            for (const auto& c : s->device.controls)
                if (c.role != namz::rig::Role::Gain && c.values.size() > 1)
                {
                    Selector sel { juce::String (c.name), {}, 0 };
                    for (const auto& v : c.values)
                        sel.values.add (juce::String (v));

                    sel.defaultIndex = juce::jmax (0, sel.values.indexOf (
                        juce::String (namz::rig::defaultValue (c))));

                    out.add (std::move (sel));
                }

        return out;
    }

    /** Turn a selecting control. The player resolves the closest captured combination — the dial
        keeps its angle and follows along the new knots. Message thread. */
    void applySelectors (const std::array<int, (size_t) params::numSelectors>& indices)
    {
        const auto list = selectors();

        for (int i = 0; i < params::numSelectors && i < list.size(); ++i)
        {
            const auto& sel = list.getReference (i);
            const int index = juce::jlimit (0, sel.values.size() - 1, indices[(size_t) i]);

            if (index == lastSelector[(size_t) i])
                continue;

            lastSelector[(size_t) i] = index;
            player.setSwitch (sel.name.toStdString(), sel.values[index].toStdString());
        }
    }

    /** The gain dial, 0..10 on the panel, onto the captured dial's degrees. SMOOTH lets it stand
        anywhere and the player mixes the two neighbouring captures by angle; STEP lands it on the
        nearest captured position, so one capture plays at a time and the knob reads like a
        selector. A device with no captured axis has nothing to select, so there the knob DRIVES:
        5 is unity, the middle of the dial is the capture as it was taken.

        `turbo` is THE BOOST OF A PACK THAT HAS NONE OF ITS OWN (params::preampBoost): the capture
        turboSteps captured positions up the dial from where the knob stands — 7:00 plays 9:00, 9:00
        plays 11:00 — the knob itself staying where the hand left it. A step the dial does not have
        above its top capture is fed into the top capture instead, turboDbPerStep a step: 16:00 plays
        17:00 3 dB hotter, 17:00 plays it 6 dB hotter. SMOOTH goes the same way between the captures,
        so 16:30 plays 17:00 4.5 dB hotter; STEP, from the position it has landed on. The step is the
        player's own move along the dial, crossfaded as a hand's would be; the push ramps in `process`.
        A device with no captured axis has no step at all, and is fed both. Message thread. */
    void setGain (float gain, bool smooth, bool turbo = false)
    {
        if (smooth != lastSmooth)
        {
            lastSmooth = smooth;
            player.setBlendShape (shapeFor (smooth));
            lastGain = -1.0f;   // the same number lands differently now
        }

        if (! player.loaded())
        {
            push.store (0.0f, std::memory_order_relaxed);
            return;
        }

        const auto& dial = player.dialName();

        if (dial.empty())
        {
            drive.store (juce::Decibels::decibelsToGain ((gain - 5.0f) * driveDbPerStep));
            push.store (turbo ? (float) turboSteps * turboDbPerStep : 0.0f, std::memory_order_relaxed);
            return;
        }

        drive.store (1.0f);

        if (juce::approximatelyEqual (gain, lastGain) && turbo == lastTurbo)
            return;

        lastGain  = gain;
        lastTurbo = turbo;

        double deg = juce::jlimit (0.0, 1.0, (double) gain / 10.0) * (double) player.dialSweep();
        if (! smooth)
            deg = nearestKnot (deg);

        const auto up = turbo ? stepsUp (deg, (double) turboSteps) : Shift { deg, 0.0 };
        push.store ((float) (up.missing * (double) turboDbPerStep), std::memory_order_relaxed);
        dialAt.store (up.deg, std::memory_order_relaxed);
        player.setDial (dial, up.deg);
    }

    /** TURBO's two numbers, as the engine plays them (setGain). */
    static constexpr int   turboSteps     = 2;
    static constexpr float turboDbPerStep = 3.0f;

    /** Where the dial was last set, in its degrees — under TURBO, the position it plays, not the
        knob's — and how many decibels TURBO feeds the capture on top of it. Any thread. */
    double dialDegrees() const noexcept { return dialAt.load (std::memory_order_relaxed); }
    float  turboPushDb() const noexcept { return push.load (std::memory_order_relaxed); }

    /** ...and the push as far as the ramp has carried it by the end of the last block, as a gain. */
    float  turboPushApplied() const noexcept { return pushNow.load (std::memory_order_relaxed); }

    /** WHERE THE GAIN DIAL LANDS IN STEP, as a fraction of its travel: the captured position nearest to
        `travel` — what `setGain` plays there with SMOOTH off, so a face can stand its knob on it. The
        travel itself when no pack is loaded or the device has no captured axis. Message thread. */
    double stepAt (double travel) const
    {
        travel = juce::jlimit (0.0, 1.0, travel);

        if (! player.loaded() || player.dialName().empty())
            return travel;

        const double sweep = (double) player.dialSweep();
        return sweep > 0.0 ? nearestKnot (travel * sweep) / sweep : travel;
    }

    /** The pack's per-file input trims (`input_db`), see RigPlayer::setInputTrims: off, every
        capture eats exactly what the chain feeds it — for a library shot at one honest level
        the stated attenuations are somebody else's story. Atomic underneath; any thread. */
    void setInputTrims (bool on) { player.setInputTrims (on); }

    /** THE CROSSOVER BLEND (RigPlayer's — a bass amp's clean low end): below `hz` the clean input, above
        it the capture, phase-aligned; `amount` 0 is the player without it, bit for bit. Message thread;
        only what moved reaches the player. */
    void setCrossover (float amount, float hz, bool invert)
    {
        const auto moved = [] (float a, float b) { return a < b || a > b; };
        if (moved (amount, crossoverSet[0])) { crossoverSet[0] = amount; (void) player.setCrossoverAmount ((double) amount); }
        if (moved (hz, crossoverSet[1]))     { crossoverSet[1] = hz;     (void) player.setCrossoverHz ((double) hz); }
        if (invert != crossoverInvertSet) { crossoverInvertSet = invert; player.setCrossoverInvert (invert); }
    }

    /** What the player was last told of its crossover: the amount, the frequency and the polarity. */
    float crossoverAmountTold() const noexcept { return crossoverSet[0]; }
    float crossoverHzTold() const noexcept     { return crossoverSet[1]; }
    bool  crossoverInvertTold() const noexcept { return crossoverInvertSet; }

    /** THE PACK'S OWN TWO LEVELS, as it states them — `chain[].input_db` and `chain[].output_db`.
        The player applies both itself, always, with no switch anywhere (setInputTrims above gates
        the per-FILE alias trims and nothing else). They are readable here because both land where
        no meter can stand — the input before the network, the output after the mix — so a face that
        could not say them would be showing a level nobody can account for. Message thread. */
    double packInputDb()  const { return player.stageInputDb(); }
    double packOutputDb() const { return player.stageOutputDb(); }

    /** WHAT THE MODEL IS ACTUALLY EATING, in dB from the block's own input.

        The IN meter taps right after the block's trim and before `process` below, and the green zone
        beside it describes the NETWORK's door — so between the two stands a stack of gains the meter
        has to be told about, of which `packInputDb` above is only the first. In order from the tap:
        the DRIVE of a device with no captured axis and TURBO's push (both applied in `process` below), the pack's
        `chain[].input_db`, the pre-model tone, the chain's `extendDb` past the ends of the captured
        range, and — under Pack Level Comp — the sounding capture's own `files[].input_db`, which on a
        linked bottom rung is commonly 6 dB.

        Every one of those is a plain gain except THE TONE, which is a filter: it has no decibel to
        give, so it is not in this number, and the face says the number is a LEVEL rather than
        pretending the spectrum is in it.

        TWO MODELS CAN BE SOUNDING. When the pack feeds them at different trims there is no single
        number true of both — `single` is false then and `otherDb` carries the second, so a face can
        draw one mark each instead of an average, which would describe neither. The weight is the one
        read back from the audio thread, so a slot the crossfade has left at zero does not count:
        what is answered is what is being HEARD.

        Message thread, like every read-out here. */
    struct Feed
    {
        double db      = 0.0;    // the block's input → the model's input
        double otherDb = 0.0;    // …and the second model's, when there are two; == db otherwise
        bool   single  = true;   // false: two models, two levels, and no average between them
    };

    Feed modelFeed() const
    {
        if (! player.loaded())
            return {};

        const double base = (double) juce::Decibels::gainToDecibels (drive.load(), -120.0f)
                          + (double) push.load (std::memory_order_relaxed)
                          + player.stageInputDb()
                          + player.selection().extendDb;

        const auto&  p     = player.plan();
        const bool   trims = player.inputTrims();
        const double a     = base + (trims ? p.inputDb[0] : 0.0);
        const double b     = base + (trims ? p.inputDb[1] : 0.0);

        // ONE NUMBER WHENEVER ONE IS TRUE, and it usually is. Both slots holding a capture is NOT a
        // crossfade: at either end of the dial the plan puts the same file in both, and a pack whose
        // two captures state the same trim feeds them alike. What actually splits the answer is two
        // DIFFERENT levels with both models audible. A thousandth of a decibel is not two levels:
        // the player's own gain rounds anything under half of that away to unity.
        if (std::abs (a - b) < 1.0e-3)
            return { a, a, true };

        // THE APPLIED WEIGHT, not the asked-for one: a switch or a selector moves the target in one
        // jump while the law ramps across it, and a slot that is still loading is held at zero with
        // the target already past it. Both rails are exact — the player itself steers by `<= 0`.
        const double w = (double) player.liveMix();
        if (w <= 0.0) return { a, a, true };
        if (w >= 1.0) return { b, b, true };

        return { a, b, false };
    }

    /** The loudness tag of the model sounding now, and whether it has one. Normalizing by it is a
        contract — nothing here turns it off — so the case worth saying aloud is a model WITHOUT the
        tag: it plays raw, some 8-10 dB away from every neighbour, and nothing else would report it.
        Message thread. */
    RigPlayer::SoundingLoudness loudness() const { return player.soundingLoudness(); }

    /** Whether the pack's own tone controls are out of the signal — see `params::blockEqMode`. Raw
        is what OURS means: our parametric is standing where the device's tone stack used to, and a
        device wearing both at once is a decibel nobody can trace. Parked, not bypassed: every tone
        knob goes to its `reference`, the position every model was captured at, which is flat by
        construction — exactly what the weights already contain. */
    void setRaw (bool shouldBeRaw)
    {
        if (raw == shouldBeRaw)
            return;

        raw = shouldBeRaw;

        if (raw)
            parkTone();
        else
            lastTone.fill (-1.0f);   // the pump lands every knob again
    }

    bool isRaw() const noexcept { return raw; }

    /** THE POSITION A SWITCH SLOT STANDS ON, BY NAME — message thread.

        A session must save the name, never the fraction. The fraction is an index into the pack's
        position list, so a device repacked one position shorter reopens an old session on a
        different position, silently and with no way to notice. The name is the pack's own address
        for that position (namz addresses a switch by `value`, and since schema 4 there is no `norm`
        on a switch at all — the array order IS the panel order).

        Empty when the slot is not a switch, or when no pack is loaded yet. */
    juce::String switchValueAt (int slot, float parameterValue) const
    {
        const auto tones = player.tones();

        if (slot < 0 || slot >= (int) tones.size())
            return {};

        const auto& t = tones[(size_t) slot];

        if (t.sweep > 0 || t.positions.empty())
            return {};

        const int n     = (int) t.positions.size();
        const int index = juce::jlimit (0, n - 1, juce::roundToInt (parameterValue * (float) (n - 1)));
        return juce::String (t.positions[(size_t) index].value);
    }

    /** The parameter value that lands on a NAMED position, or -1 when this pack has no position by
        that name — including "no pack at all", which the caller tells apart with `isReady()`. That
        second case is narrow: `RigPlayer::load` reads the manifest synchronously, so the positions
        are knowable from the instant a device is selected and long before its models arrive. */
    float switchParameterFor (int slot, const juce::String& value) const
    {
        const auto tones = player.tones();

        if (slot < 0 || slot >= (int) tones.size())
            return -1.0f;

        const auto& t = tones[(size_t) slot];

        if (t.sweep > 0 || t.positions.empty())
            return -1.0f;

        const int n = (int) t.positions.size();

        for (int i = 0; i < n; ++i)
            if (value == juce::String (t.positions[(size_t) i].value))
                return n > 1 ? (float) i / (float) (n - 1) : 0.0f;

        return -1.0f;
    }

    /** The tone slots, 0..1 each, onto the pack's knobs in the order it lists them: a swept knob
        takes the value as a fraction of its rotation, a switch takes the position nearest to it. */
    void updateToneIfMoved (const std::array<float, (size_t) numMeasured>& values)
    {
        if (raw || ! player.loaded())
            return;

        const auto tones = player.tones();

        for (int i = 0; i < numMeasured && i < (int) tones.size(); ++i)
        {
            const float v = values[(size_t) i];

            if (juce::approximatelyEqual (v, lastTone[(size_t) i]))
                continue;

            lastTone[(size_t) i] = v;
            const auto& t = tones[(size_t) i];

            if (t.sweep > 0)
            {
                player.setDial (t.name, (double) juce::jlimit (0.0f, 1.0f, v) * (double) t.sweep);
            }
            else if (! t.positions.empty())
            {
                const int n = (int) t.positions.size();
                const int index = juce::jlimit (0, n - 1, juce::roundToInt (v * (float) (n - 1)));
                player.setSwitch (t.name, t.positions[(size_t) index].value);
            }
        }
    }

    /** What the device's tone controls are doing as a whole, in dB at a frequency — the block's
        answer for any picture that wants to draw its tone. Read off the player's own design: the
        curve its FIRs were built from and the bands its biquads are running, both sides of the
        models summed, because they sit in series. Message thread, like every read-out. */
    double toneDb (double freqHz) const
    {
        double sum = 0.0;
        const auto& grid = player.commonGrid();

        for (int side = 0; side < 2; ++side)
        {
            if (const auto& c = player.curveDb (side); ! c.empty() && c.size() == grid.size())
                sum += felitronics::lineareq::curveDbAt (c, grid, freqHz);

            for (const auto& b : player.bands (side))
                sum += felitronics::rigplayer::sectionMagnitudeDb (b, freqHz, player.sampleRate());
        }

        return sum;
    }

    /** The message-thread heartbeat: the player's housekeeping, and its LOAD JOBS. A model the law
        asks for is built on `pool` — bytes from the pack, a network parsed and warmed, some twenty
        milliseconds — and brought back to the player on the message thread, where it installs. With
        no pool the job runs right here, which is what a test wants and what a host without a message
        loop can have. Call it from a timer, a few times a second at least. */
    void pump (juce::ThreadPool* pool)
    {
        player.service();

        if (pool == nullptr)
        {
            while (auto job = player.takeLoadJob())
                player.deliver (RigPlayer::run (std::move (*job)));
                if (onLanded) onLanded();
            return;
        }

        if (auto job = player.takeLoadJob())
        {
            // The job carries everything the work needs and nothing of the player, so the pool
            // thread touches nothing here. The result rides back on the message queue; if the block
            // is gone by then, the token says so and the model is simply dropped.
            std::weak_ptr<int> token = alive;
            auto* self = this;
            auto boxed = std::make_shared<RigPlayer::LoadJob> (std::move (*job));

            pool->addJob ([self, token, boxed]
            {
                auto loaded = std::make_shared<RigPlayer::Loaded> (RigPlayer::run (std::move (*boxed)));

                juce::MessageManager::callAsync ([self, token, loaded]
                {
                    if (token.lock() != nullptr)
                    {
                        self->player.deliver (std::move (*loaded));

                        // 🔴 IN THIS CALLBACK, NOT AT THE NEXT TICK. `deliver` is the instant the
                        // block's latency becomes real, and anything that has to be as long as that
                        // latency — the bypass wire — has to be told here. Left to the 30 Hz pump
                        // it is told up to 33 ms later, which at 96 kHz is about fifty blocks of a
                        // bypass path short by the difference, or a whole 15 ms crossfade combing
                        // inside that window.
                        if (self->onLanded) self->onLanded();
                    }
                });
            });
        }
    }

    /** Called on the MESSAGE THREAD the moment a model has landed and `latencySamples()` has
        changed — before the next pump, because up to a pump's worth of blocks is what the
        difference costs. Set by the owner; empty by default. */
    std::function<void()> onLanded;

    /** Host-rate latency of the models — their rate-matching, when a capture's rate is not the
        host's. Zero for a pack captured at the session's rate. */
    int latencySamples() const { return player.latencySamples(); }

    /** Plays the block and feeds its pictures. `dry` is scratch the caller owns, big enough for the
        buffer — kept so a picture can show what went in, not only what came out. Audio thread. */
    void process (juce::AudioBuffer<float>& buffer, juce::AudioBuffer<float>& dry) noexcept
    {
        const int numSamples = buffer.getNumSamples();

        dry.setSize (1, numSamples, false, false, true);
        dry.copyFrom (0, 0, buffer, 0, 0, numSamples);

        // The drive of a device with no captured axis — into the model, like every trim here.
        if (const float target = drive.load (std::memory_order_relaxed);
            ! juce::approximatelyEqual (target, 1.0f) || ! juce::approximatelyEqual (curDrive, 1.0f))
        {
            buffer.applyGainRamp (0, numSamples, curDrive, target);
            curDrive = target;
        }

        // TURBO's push past the top capture (setGain) — into the model too, and ramped over a fixed
        // time rather than a block, so a host's short block does not make a step of it. At nothing it
        // touches nothing.
        pushGain.setTargetValue (juce::Decibels::decibelsToGain (push.load (std::memory_order_relaxed)));
        if (pushGain.isSmoothing())
        {
            auto* const* d = buffer.getArrayOfWritePointers();
            for (int i = 0; i < numSamples; ++i)
            {
                const float g = pushGain.getNextValue();
                for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
                    d[ch][i] *= g;
            }
        }
        else if (const float g = pushGain.getCurrentValue(); ! juce::exactlyEqual (g, 1.0f))
        {
            buffer.applyGain (0, numSamples, g);
        }
        pushNow.store (pushGain.getCurrentValue(), std::memory_order_relaxed);

        player.process (buffer.getArrayOfWritePointers(), buffer.getNumChannels(), numSamples);

        scope.write (dry.getReadPointer (0), buffer.getReadPointer (0), numSamples);
        ribbon.write (dry.getReadPointer (0), buffer.getReadPointer (0), numSamples);
    }

    // ---- what a block's face asks about the device it is playing ----

    /** The tone knobs as they play: the pack's description of each, in the pack's order. */
    std::vector<namz::rig::Tone> tones() const { return player.tones(); }

    /** The captured positions of the gain dial, in dial order — the knob's detents. */
    juce::StringArray gainPositions() const
    {
        juce::StringArray out;

        if (const auto* s = nam())
            for (const auto& c : s->device.controls)
                if (c.role == namz::rig::Role::Gain)
                {
                    for (const auto& v : c.values)
                        out.add (juce::String (v));
                    break;
                }

        return out;
    }

    /** HOW MANY CAPTURES THE GAIN DIAL PLAYS — files, not detents. A dial can state eleven positions and
        be recorded at nine, its bottom notches pointing at the capture above them (namz FileEntry: the
        X88-IR's 0 and 30 play its 60). Counted for one setting of the pack's other switches, the most any
        setting has: BOOST's two positions are two dials of nine, not one of eighteen. */
    int gainCaptures() const
    {
        const auto* s = nam();
        if (s == nullptr)
            return 0;

        std::string gain;
        for (const auto& c : s->device.controls)
            if (c.role == namz::rig::Role::Gain)
            {
                gain = c.name;
                break;
            }
        if (gain.empty())
            return 0;

        std::map<std::string, std::set<std::string>> bySetting;   // the other switches' setting -> its files
        for (const auto& f : s->device.files)
        {
            std::string others;
            for (const auto& [name, value] : f.settings)
                if (name != gain)
                    others += name + "=" + value + ";";
            bySetting[others].insert (f.id);
        }

        size_t most = 0;
        for (const auto& [setting, files] : bySetting)
            most = std::max (most, files.size());
        return (int) most;
    }

    juce::String dialName() const { return juce::String (player.dialName()); }

    /** THE CAPTURE THE DIAL STANDS ON, AS A FILE: its name in the pack and its bytes as a plain `.nam`,
        whatever the pack keeps it as. In STEP that is the one capture playing; in SMOOTH, the nearer
        of the two the player is mixing. Nothing when no pack is loaded, the dial picks no file, or
        the file will not be read. Message thread — it opens the pack. */
    struct CaptureFile
    {
        juce::String      name;         // the file's name in the pack, without its extension
        juce::MemoryBlock nam;          // the model, as NAM JSON
        double            hour = 0.0;   // where the gear's gain knob stood for it, as on a clock face:
                                        // 1 to 12, 9.5 = half past nine; 0 = the pack does not say
    };

    CaptureFile captureOnDial() const
    {
        const auto* pack = packAt (lastSelected);
        if (pack == nullptr || ! player.loaded())
            return {};

        const auto& plan  = player.plan();
        const auto& files = player.stage().device.files;
        const int   file  = plan.file[plan.targetB > 0.5 ? 1 : 0];
        if (! juce::isPositiveAndBelow (file, (int) files.size()))
            return {};

        const juce::String id (files[(size_t) file].id);
        auto bytes = device::DeviceLibrary::readBinaryEntry (*pack, id);

        if (namz::isNamz (bytes.getData(), bytes.getSize()))
        {
            const auto json = namz::unpack (bytes.getData(), bytes.getSize(), maxNamBytes);
            bytes.replaceAll (json.data(), json.size());    // nothing, when it would not unpack
        }

        if (bytes.isEmpty())
            return {};

        return { juce::File::createLegalFileName (id).upToLastOccurrenceOf (".", false, false), bytes,
                 hourShotAt (files[(size_t) file].id) };
    }

    /** WHERE THE GEAR'S GAIN KNOB STOOD FOR A CAPTURE, as an hour on a clock face. The pack states a
        position in degrees up from the knob's lower stop, and how far the knob turns in all; that
        travel is centred on twelve, so 150 of 300 degrees is 12 and 180 is 1. A capture the pack also
        plays lower on the dial, fed softer, answers with the position it was SHOT at — the entry
        that feeds it untouched. 0 when the pack names no dial, or says this position some other way. */
    double hourShotAt (const std::string& id) const
    {
        const double sweep = (double) player.dialSweep();
        if (sweep <= 0.0 || ! player.loaded())
            return 0.0;

        for (const auto& f : player.stage().device.files)
        {
            if (f.id != id || std::abs (f.inputDb) > 0.0005)
                continue;

            const auto at = f.settings.find (player.dialName());
            if (at == f.settings.end())
                continue;

            const juce::String degrees (at->second);
            if (degrees.isEmpty() || ! degrees.containsOnly ("0123456789."))
                continue;

            const double hour = std::fmod (12.0 + (degrees.getDoubleValue() - sweep * 0.5) / 30.0, 12.0);
            return hour > 0.0 ? hour : hour + 12.0;
        }

        return 0.0;
    }

    juce::String circuit() const
    {
        const auto* s = nam();
        return s != nullptr ? juce::String (s->circuit) : juce::String();
    }

    /** The gear's make and model, as the pack states them. */
    juce::String deviceName() const
    {
        const auto* s = nam();
        if (s == nullptr)
            return {};

        const auto make = juce::String (s->make), model = juce::String (s->model);
        return make.isNotEmpty() ? make + " " + model : model;
    }

    bool isReady() const noexcept { return player.loaded(); }

    /** Whether a measured control's positions are NAMED rather than numbered — the difference
        between a switch and a knob that happened to be swept at two points. */
    static bool namedPositions (const namz::rig::Tone& t)
    {
        // ROTATION OR NOT — that is the whole question, and since schema 4 it is the only signal
        // there is: a switch has an order and no angle, so it states no `sweep` and its positions
        // carry no `norm`. Sniffing the labels for letters was a guess, and it rules the wrong way
        // on a selector whose legends read "1 / 2 / 3".
        return t.sweep <= 0 && ! t.positions.empty();
    }

    /** Whether this device brought a tone stack a console can WEAR: at least one swept dial that is
        not a switch and not a control the pack tested and found flat.

        ONE function, asked from both sides. The face uses it to decide whether the choice between
        the two tone stacks exists at all — a device that measured nothing collapses to ours rather
        than showing an empty row — and the DSP has to reach the same verdict, or a block whose
        parameter says NATIVE while its face wears OURS would have its own bands parked in favour
        of a tone stack that does not exist, and end up with no tone at all. */
    bool hasWearableTone() const noexcept { return wearable.load (std::memory_order_relaxed); }

    /** Works it out again, on the message thread, and stores the answer for the audio thread.

        THE ANSWER IS CACHED BECAUSE THE QUESTION IS NOT CHEAP AND THE ASKER IS THE AUDIO THREAD.
        `processBlock` needs this verdict for every block, and `RigPlayer::tones()` builds and
        returns a whole vector — a heap allocation and a copy of every tone's name and positions,
        thousands of times a second on the one thread that must never allocate. Worse, it walks
        the player's tone list while the message thread may be replacing it, which is a race with
        a dangling read at the end of it. Neither cost buys anything: the answer only changes when
        a pack is loaded, and this is called from where that happens. */
    void refreshWearableTone()
    {
        wearable.store (computeWearableTone(), std::memory_order_relaxed);
    }

private:
    bool computeWearableTone() const
    {
        for (const auto& t : tones())
        {
            if (t.sweep > 0 && ! trustFailed (t))
                return true;

            // ...and since schema 4, a knob that CLICKS can be a tone control too: its positions
            // state the filter each one IS. A device whose only tone is a two-position Bright now
            // genuinely HAS a tone stack, and the face must be allowed to offer it — a switch that
            // shapes the sound and is judged "not tone" leaves the block wearing ours over a stack
            // that exists.
            if (t.sweep <= 0 && switchCarriesBands (t))
                return true;
        }

        return false;
    }

public:
    /** A switch whose positions declare filters rather than merely selecting captures. */
    static bool switchCarriesBands (const namz::rig::Tone& t)
    {
        for (const auto& p : t.positions)
            if (! p.sections.empty())
                return true;

        return false;
    }

    /** A control the pack tested and found NOT to be a filter anywhere: a collapsed trusted band.
        The player plays it as silence; a face should not build a knob for it. Bands are played
        whole — for them `trusted` is provenance, never a verdict. */
    static bool trustFailed (const namz::rig::Tone& t)
    {
        if (! t.sections.empty())
            return false;

        const auto& tr = t.trusted;
        const bool tested = tr.levels >= 2;
        const bool stated = tr.loHz > 0.0 || tr.hiHz > 0.0 || tr.loIndex != 0 || tr.hiIndex != 0;
        return tested && stated && (tr.loIndex > tr.hiIndex || (tr.hiHz > 0.0 && tr.hiHz <= tr.loHz));
    }

    /** Where a fresh device parks a tone slot, 0..1: the pack's `default`, else its `reference`.
        A player must not invent one — two readers starting the same pack at different positions
        make it two products. */
    static double defaultNorm (const namz::rig::Tone& t)
    {
        const auto start = felitronics::rigplayer::toneStart (t);

        if (t.sweep > 0)
        {
            double norm = 0.5;
            return felitronics::rigplayer::toneNorm (t, start, norm) ? norm : 0.5;
        }

        const int n = (int) t.positions.size();
        for (int i = 0; i < n; ++i)
            if (t.positions[(size_t) i].value == start)
                return n > 1 ? (double) i / (double) (n - 1) : 0.0;

        return 0.5;
    }

    RigPlayer player;
    float crossoverSet[2] { 0.0f, 150.0f };   // the amount and the frequency the player was last told: its own defaults
    bool  crossoverInvertSet = false;
    ScopeTap scope;
    WaveRibbon ribbon;
    juce::Array<device::DeviceLibrary::Pack> packs;

private:
    // Four decibels a step: the full dial spans forty, which is enough to take a capture from barely
    // breaking up to thoroughly into it without leaving the range a model behaves in.
    static constexpr float driveDbPerStep = 4.0f;

    // What a capture may unpack to — the player's own guard (NamStage) against a file that lies about its size.
    static constexpr size_t maxNamBytes = 64u * 1024u * 1024u;

    const namz::rig::Stage* nam() const { return player.loaded() ? &player.stage() : nullptr; }

    /** The pack an index stands for: when it points nowhere the first one, as `select` plays it. */
    const device::DeviceLibrary::Pack* packAt (int index) const
    {
        return juce::isPositiveAndBelow (index, packs.size()) ? &packs.getReference (index)
                                                              : (packs.isEmpty() ? nullptr : &packs.getReference (0));
    }

    /** SMOOTH is the player's own law — the midpoint handover, the full span. STEP is that law with
        no width at all: a hard switch halfway between two captures, which the dial never visits
        anyway because the block has already landed it on one of them. */
    static felitronics::rigplayer::BlendShape shapeFor (bool smooth)
    {
        return smooth ? felitronics::rigplayer::BlendShape {}
                      : felitronics::rigplayer::BlendShape { 0.5, 0.0 };
    }

    /** The captured position nearest to `deg`, among the files along the dial at the panel's other
        settings. With nothing along it, the angle itself. */
    /** TURBO'S MOVE ALONG THE DIAL: from `deg`, `steps` captured positions up — counted between the
        captures, so a hand between two goes as far between the two it lands among. As far as the top
        capture and no further; what is left over is `missing`, in steps. Below the first capture the
        first gap is the step, so a hand the player feeds softer there comes up by the same measure. */
    struct Shift
    {
        double deg     = 0.0;
        double missing = 0.0;
    };

    Shift stepsUp (double deg, double steps) const
    {
        const auto& knots = player.selection().knots;
        const int last = (int) knots.size() - 1;
        if (last < 1)
            return { last == 0 ? knots.front().deg : deg, steps };     // one capture, or none: no step to take

        const auto at = [&] (int i) { return knots[(size_t) i].deg; };

        // Where the hand stands, as a place among the captures: 3.5 halfway between the fourth and fifth.
        double place = (double) last;
        if (deg < at (1))
            place = (deg - at (0)) / (at (1) - at (0));
        else
            for (int i = 1; i < last; ++i)
                if (deg < at (i + 1))
                {
                    place = (double) i + (deg - at (i)) / (at (i + 1) - at (i));
                    break;
                }

        const double to = place + steps;
        if (to >= (double) last)
            return { at (last), to - (double) last };
        if (to < 0.0)
            return { at (0) + to * (at (1) - at (0)), 0.0 };

        const int i = (int) std::floor (to);
        return { at (i) + (to - (double) i) * (at (i + 1) - at (i)), 0.0 };
    }

    double nearestKnot (double deg) const
    {
        const auto& knots = player.selection().knots;
        if (knots.empty())
            return deg;

        double best = knots.front().deg;
        for (const auto& k : knots)
            if (std::abs (k.deg - deg) < std::abs (best - deg))
                best = k.deg;

        return best;
    }

    /** Every tone knob to its `reference`: the position the models were captured at, flat by
        construction. */
    void parkTone()
    {
        for (const auto& t : player.tones())
            player.setSwitch (t.name, t.reference);
    }

    device::DeviceLibrary::Slot slot;
    std::array<float, (size_t) numMeasured> lastTone { };
    std::array<int, (size_t) params::numSelectors> lastSelector { -1, -1 };
    float lastGain    = -1.0f;
    bool  lastSmooth  = true;
    int   lastSelected = -1;
    juce::String loadedName;   // the name of the pack actually playing — the state's identity

    /** Whether the loaded pack has a tone stack worth wearing — see `refreshWearableTone`. */
    std::atomic<bool> wearable { false };
    bool  raw = false;

    std::atomic<float> drive { 1.0f };
    float curDrive = 1.0f;

    std::atomic<float>  push { 0.0f };          // TURBO's push, dB — setGain's, for `process`
    std::atomic<double> dialAt { 0.0 };         // the degrees last handed to the player's dial
    std::atomic<float>  pushNow { 1.0f };       // the push the last block ended on, a gain — `process`'s, for a reader
    juce::LinearSmoothedValue<float> pushGain { 1.0f };
    static constexpr double pushRampSeconds = 0.02;
    bool lastTurbo = false;

    // LAST, so it dies first: a load coming back finds the token gone before anything else here is.
    std::shared_ptr<int> alive = std::make_shared<int> (0);
};

} // namespace orbitamp::core
