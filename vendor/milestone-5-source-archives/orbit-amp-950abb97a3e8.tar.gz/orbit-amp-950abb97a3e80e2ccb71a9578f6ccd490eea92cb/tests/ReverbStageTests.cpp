// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of OrbitAmp — see LICENSE.

// Headless acceptance gate for the room this plugin plays, felitronics::reverb::AmpReverb — that Mix
// adds rather than replaces, that a tail exists and decays, and that disabling the block cannot spill
// the previous tail back in. Returns non-zero on any failure.

#include "GateMain.h"
#include <felitronics/reverb/AmpReverb.h>

#include <cmath>
#include <limits>
#include <cstdio>
#include <string>
#include <vector>

using felitronics::reverb::AmpReverb;
using felitronics::reverb::Character;

namespace
{
    int failures = 0;

    void report (const char* what, bool ok, const char* detail = "")
    {
        if (! ok)
            ++failures;

        std::printf ("%-52s %s  %s\n", what, ok ? "ok" : "FAIL", detail);
    }

    constexpr double sampleRate = 48000.0;

    /** Feeds one impulse, then silence, and returns the peak level over a window (in ms). */
    double tailPeak (AmpReverb& r, int fromMs, int toMs)
    {
        const int n = (int) (sampleRate * toMs / 1000.0);
        std::vector<float> left ((size_t) n, 0.0f), right ((size_t) n, 0.0f);
        left[0] = right[0] = 1.0f;

        float* channels[2] = { left.data(), right.data() };
        (void) r.process (channels, 2, n);

        const int from = (int) (sampleRate * fromMs / 1000.0);
        double peak = 0.0;
        for (int i = from; i < n; ++i)
            peak = std::max (peak, (double) std::fabs (left[(size_t) i]));

        return peak;
    }
}

int ORBITAMP_GATE_MAIN()
{
    AmpReverb r;
    (void) r.prepare (sampleRate, (int) sampleRate * 3, 2);   // the tests hand whole seconds in one call

    // An amp's reverb ADDS to the dry signal, it does not crossfade away from it. So the dry path
    // must sit at unity at EVERY mix setting — including the maximum. This is the behaviour the
    // whole control hangs on, so it is checked at both ends.
    auto dryLevelAt = [&r] (float mix)
    {
        r.setMix (mix);
        r.reset();

        // The room glides a changed setting in over ~10 ms so a move never zips. Run silence through
        // first so the measurement is of the settled level, whatever a restart does with the glide.
        {
            std::vector<float> l (4800, 0.0f), rr (4800, 0.0f);
            float* warm[2] = { l.data(), rr.data() };
            (void) r.process (warm, 2, 4800);
        }

        std::vector<float> left (256, 0.0f), right (256, 0.0f);
        left[0] = right[0] = 1.0f;
        float* channels[2] = { left.data(), right.data() };
        (void) r.process (channels, 2, 256);

        return (double) left[0];
    };

    report ("mix 0: dry at unity",   std::fabs (dryLevelAt (0.0f) - 1.0) < 0.02, "");
    report ("mix 1: dry STILL unity (adds, never replaces)", std::fabs (dryLevelAt (1.0f) - 1.0) < 0.02, "");

    // Mix at zero must be silent after the dry impulse — inaudible, not "nearly" inaudible.
    r.setMix (0.0f);
    r.reset();
    {
        std::vector<float> left (256, 0.0f), right (256, 0.0f);
        left[0] = right[0] = 1.0f;
        float* channels[2] = { left.data(), right.data() };
        (void) r.process (channels, 2, 256);

        double spill = 0.0;
        for (size_t i = 1; i < left.size(); ++i)
            spill = std::max (spill, (double) std::fabs (left[i]));

        report ("mix 0: impulse passes, nothing follows it", spill < 1.0e-4,
                ("spill " + std::to_string (spill)).c_str());
    }

    // Fully wet: there must still be a tail 200 ms after the impulse, and it must be decaying.
    r.setMix (1.0f);
    r.setCharacter (Character::hall);
    r.reset();
    const double early = tailPeak (r, 50, 150);
    r.reset();
    const double late  = tailPeak (r, 400, 500);

    report ("mix 1: tail present at 50-150 ms", early > 1.0e-3,
            ("peak " + std::to_string (early)).c_str());
    report ("mix 1: tail is decaying, not sustaining", late < early,
            ("late " + std::to_string (late) + " < early " + std::to_string (early)).c_str());

    // reset() must actually empty the network — otherwise re-enabling the block spills the tail of
    // whatever was playing before it was switched off.
    r.reset();
    {
        std::vector<float> left (4096, 0.0f), right (4096, 0.0f);
        float* channels[2] = { left.data(), right.data() };
        (void) r.process (channels, 2, 4096);

        double residue = 0.0;
        for (float v : left)
            residue = std::max (residue, (double) std::fabs (v));

        report ("reset: silence in, silence out", residue < 1.0e-6,
                ("residue " + std::to_string (residue)).c_str());
    }

    // Character must be audible: a spring is small and damped, a hall is not.
    r.setMix (1.0f);
    r.setCharacter (Character::spring);
    r.reset();
    const double spring = tailPeak (r, 300, 500);
    r.setCharacter (Character::hall);
    r.reset();
    const double hall = tailPeak (r, 300, 500);

    report ("character: hall rings longer than spring", hall > spring,
            ("hall " + std::to_string (hall) + " > spring " + std::to_string (spring)).c_str());

    // ONE BAD SAMPLE MUST NOT KILL THE ROOM FOR EVER. Every element in here is recursive, and a NaN
    // or an infinity that got in used to make every sample after it not a number — at any mix, and
    // standing by — until the reverb was taken out of the rig. Blocks of a host's size: a quiet
    // 220 Hz, one poisoned sample on both channels, then the tone again. What comes out must be
    // finite from the very block after, the dry must pass through the poisoned block's neighbours
    // untouched — the poisoned sample itself is the dry's, and stays — and the room must be ringing
    // again a moment later.
    {
        constexpr int block = 512;

        const auto poisonRun = [&] (float poison, float mix)
        {
            AmpReverb room;
            (void) room.prepare (sampleRate, block, 2);
            room.setCharacter (Character::hall);
            room.setMix (mix);

            std::vector<float> l ((size_t) block), rr ((size_t) block);
            float* ch[2] = { l.data(), rr.data() };
            long long phase = 0;
            int badAfter = 0;
            double tailLate = 0.0;

            for (int b = 0; b < 200; ++b)
            {
                for (int i = 0; i < block; ++i, ++phase)
                    l[(size_t) i] = rr[(size_t) i] = 0.1f * (float) std::sin (2.0 * 3.141592653589793 * 220.0 * (double) phase / sampleRate);

                if (b == 20)
                    l[100] = rr[100] = poison;

                (void) room.process (ch, 2, block);

                if (b > 20)
                    for (int i = 0; i < block; ++i)
                        if (! std::isfinite (l[(size_t) i]) || ! std::isfinite (rr[(size_t) i]))
                            ++badAfter;

                if (b >= 190)
                    for (int i = 0; i < block; ++i)
                        tailLate = std::max (tailLate, (double) std::fabs (room.addedWet (0)[i]));
            }

            return std::make_pair (badAfter, tailLate);
        };

        const auto nanRun  = poisonRun (std::numeric_limits<float>::quiet_NaN(), 0.5f);
        const auto infRun  = poisonRun (std::numeric_limits<float>::infinity(),  0.5f);
        const auto zeroMix = poisonRun (std::numeric_limits<float>::quiet_NaN(), 0.0f);

        report ("a NaN in: everything after it is a number", nanRun.first == 0,
                ("non-finite after " + std::to_string (nanRun.first)).c_str());
        report ("...and the room rings again",               nanRun.second > 1.0e-4,
                ("late tail " + std::to_string (nanRun.second)).c_str());
        report ("an infinity in: the same",                  infRun.first == 0 && infRun.second > 1.0e-4,
                ("non-finite after " + std::to_string (infRun.first)).c_str());
        report ("mix 0 is not a hiding place",               zeroMix.first == 0,
                ("non-finite after " + std::to_string (zeroMix.first)).c_str());
    }

    // ...and poison the room makes of ITS OWN — its state, not its door — is dropped and the room
    // restarts: a tail that is not a number never reaches the dry.
    {
        constexpr int block = 256;
        AmpReverb room;
        (void) room.prepare (sampleRate, block, 2);
        room.setMix (1.0f);

        std::vector<float> l ((size_t) block, 0.0f), rr ((size_t) block, 0.0f);
        float* ch[2] = { l.data(), rr.data() };

        // Enormous but finite: past what Freeverb's feedback sums can hold. Whether it overflows
        // inside depends on the float path, so the check is on the OUTCOME either way.
        for (int b = 0; b < 40; ++b)
        {
            for (int i = 0; i < block; ++i)
                l[(size_t) i] = rr[(size_t) i] = (b < 4 && i % 2 == 0) ? 3.0e38f : (b < 4 ? -3.0e38f : 0.25f);

            (void) room.process (ch, 2, block);
        }

        bool finite = true;
        for (int i = 0; i < block; ++i)
            finite = finite && std::isfinite (l[(size_t) i]) && std::isfinite (rr[(size_t) i]);

        report ("an overflow inside the room heals too",  finite, "");
        report ("the room says how much it wrote",        room.addedLength() == block, "");
    }

    std::printf ("\n%s\n", failures != 0 ? "FAILURES" : "all checks passed");
    return failures;
}
