<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->
<!-- Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. -->

# Law 8 — the whole audit, closed

[`DSP-ARCHITECTURE.md`](DSP-ARCHITECTURE.md) law 8: *every feedback kernel flushes denormal state in
SOFTWARE; hardware FTZ is a desktop optimisation, never a correctness crutch.* Three passes have now
touched this. The first fixed `analysis::KWeightingFilter` and `multiband::MultibandProcessor`
([`LAW8-KWEIGHTING.md`](LAW8-KWEIGHTING.md)) and left a short "still open, deliberately" list. This
document is the pass that finishes it: **every recursive kernel in the repo has a verdict here, including
the ones that turned out clean and why.** Nobody should have to derive any of it a fourth time.

The short version: **six kernels were stalling, four are clean, and one of the four "leftovers" the first
pass recorded as harmless was in fact the most expensive of the lot.**

---

## The mechanism, stated generally (it is not really about denormals)

A one-pole approaching a target never *arrives*: `x ← t + r·(x−t)`. Under round-to-nearest the residual
has a **band of fixed points** — write the residual as `k` ulps and it maps to itself whenever

```
k·(1 − r) ≤ ½          i.e.   k ≤ ½ / (1 − r)
```

so the decay stops dead as soon as it enters that band. Two consequences, and the audit needed both:

- **Target 0.** The band is in the *subnormal* range, where the ulp is absolute (2⁻¹⁰⁷⁴ double, 2⁻¹⁴⁹
  float). The state parks there **permanently** and every later operation touching it pays the subnormal
  penalty — 10–100× on x86 without FTZ, nothing at all on Apple Silicon, which is why this class of bug
  survives on the dev machine. This is law 8 proper.
- **Any other target.** The band is at `k·ulp(target)`, which is a *normal* number, so there is no CPU
  penalty — but the kernel still never reports itself settled, and anything gated on exact settling
  (`core::Smoother`'s cost-zero early-out) never fires. Same defect, invisible cost.

A flush written only against the first case fixes half the problem. Both fixed kernels that glide toward a
*parameter* — `core::Smoother` among them — therefore
carry **two** conditions: a magnitude threshold, and "the update did not move the value", which is exact,
target-independent, and cannot fire early (in the normal range the mantissa makes `k(1−r) ≫ ½`).

---

## Verdicts

| kernel | recursive state decaying to 0? | sticks? | cost of not fixing | verdict |
|---|---|---|---|---|
| `core::Smoother` | yes, asymptotic to target | **yes** — 720 ulp (3.56e-321) after 22 s of `next()`; 5 ulp after 28 s of `advance(128)` | one subnormal multiply **per sample**; plus a `std::pow` every block, forever, on a settled parameter | **FIXED** |
| `core::LinearSmoother` | no — fixed-increment ramp | — | — | clean by construction |
| `measurement::LevelProbe` | no persistent state | — | — | clean |
| `measurement::Sweep` | no recursion at all | — | — | clean |
| `dither::Dither` | loop exists, state does not decay | no | — | clean |
| `saturation::Saturator` DC blocker | yes | **yes** — 2.14e-42 from 1.5 s, permanent | **23.9× measured**, and it leaks out of the stage | **FIXED** |
| `analysis::CorrelationMeter` | yes | **yes** — 7200 ulp after ~220 s | three subnormal double FMAs **per sample** | **FIXED** |
| `dynamics::AutoLeveler` | yes | **yes** — 28 ulp after ~106 s | two FMAs **per block**, behind a silence gate | **FIXED** (see "not independently tested") |

### The six that were stalling — four here, two in felitronics-guitar-core

**`core::Smoother`** — the one the previous pass named. `current = target + coeff·(current−target)`; with
`target == 0` (a mute, a band parked at 0 dB) it is a pure geometric decay. At 30 ms / 48 kHz,
`coeff = 0.9993058`, so every `k ≤ 720` is a fixed point: measured stuck at **720 ulp after 22.17 s**,
first subnormal at 21.25 s. `advance(n)` sticks whenever `k(1−coeffⁿ) ≤ ½` — 5 ulp at n = 128, and it does
reach zero at n = 1024 only because `coeff¹⁰²⁴ = 0.49 < ½`. In-repo caller: `eq::EqBand`, 15 instances,
`advance()` only.

The second half of this one is not a denormal at all. The header claimed "an idle parameter costs one
compare per block, not a transcendental (the eq lanes' cost-zero contract rides on this)", guarded by
`fabs(current − target) > 0.0`. A residual that merely decays never becomes `0.0`, so the guard never
fired and the `pow` ran forever. A 1e-15 absolute snap alone does **not** fix that for a real target:
measured with threshold-only, target 1000 at n = 64 still made **18750 `pow` calls over 25 s** with a
residual of 1.25e-12. The fixed-point condition is what makes the claim true, for every target.

**`saturation::Saturator`'s DC blocker — the one the first pass got wrong, including this author.** It
flushed non-finite state only, with a written rationale: *"no denormal threshold here: zapping a tiny
finite tail would break the bit-identical NULL for quiet legitimate signals."* Three things turned out to
be true at once:

- The stall is **permanent**, not transient. It was assumed the state would traverse the subnormals in
  ~0.25 s and underflow to zero. It does not: `R = 0.99967283` (10 Hz at 4× 48 kHz) gives a fixed-point
  band up to `k ≤ 1528`, and `y1` freezes at **2.14e-42 after 1.49 s** and stays there. On silence the
  Asym curve emits exactly zero (`tanh(k·bias) − biasTanh_` is the same float expression), so nothing
  re-excites it.
- **It escapes the stage.** The frozen value feeds the 128-tap downsampling FIR with every operand
  subnormal, and the Saturator's own output becomes **−3.40249e-41 on every sample** — bit-identical on
  arm64 and x86 — i.e. contagion into whatever comes next.
- **Measured cost**, x86-64 (i9-13900H, gcc 14.2 `-O2`, 2 s mono, best of 5): music **18.97 ms**, stalled
  silence **452.72 ms — 23.9×**, 22.6 %RT per channel. Forcing FTZ/DAZ on the *same binary*: 18.33 ms, no
  penalty at all, which is what proves it is purely the denormal path. With the flush: 18.25 ms.

The rationale is retracted rather than edited, because the NULL it appealed to never tested the claim
either way: scenario 4's 1e-20 block is absorbed to exact zero by the Asym bias (`−0.3f + 1e-20f == −0.3f`;
`ulp(0.3) = 3e-8`), so the fixture never puts a tiny *finite* value into that state. Verified rather
than assumed: three threshold variants were built against it — per-sample 1e-30f, per-sample 1e-15f,
per-call 1e-15f — and all **197** checks of the three saturation suites pass in every one, so the
fixture does not discriminate the threshold at all. (194 before this document's own law-8 test added
three; if you reproduce this, count what your tree has rather than trusting the figure.) The threshold
chosen is **1e-30f**,
on the margin argument alone: 8 decades above the float subnormal floor, ~600 dB below anything audible.
The flush is applied **per sample, not per call** — a threshold at the end of a call would put a numerical
event wherever the *caller* cut the stream, which is exactly the chunk-invariance argument from
[`LAW8-KWEIGHTING.md`](LAW8-KWEIGHTING.md), and this module asserts bit-identical chunking explicitly.

**`analysis::CorrelationMeter`** — found in this pass, and it is the first pass's own lesson repeating:
`flushDenormals()` existed and **nothing in the repo called it**. It is a leaf primitive with no in-repo
owner (only a comment in `stereo::StereoWidth` mentions the class), so the adapter driving it was the only
thing that could have, and never did. Three double one-poles decay on silence and stick (`k ≤ 7200` at the
default 300 ms window). The stall is slow — ~220 s of silence to reach the subnormal band — but that is a
long tail on a mix bus, not an exemption. `process()` now flushes itself, so there is no call to forget;
the cost is three `fabs`+compares against a three-FMA dependency chain the loop is latency-bound on anyway.

**`dynamics::AutoLeveler`** — two per-block mean-square followers, stick at `k ≤ 28` after ~106 s. Two
FMAs per block behind a silence gate, so the cost is genuinely immeasurable; fixed because the remedy is
two compares and law 8 is not a cost-benefit rule.

### The four that are clean, and why

- **`core::LinearSmoother`** — a fixed-increment ramp *arrives*. `countdown` hits 0 and the final step
  assigns `currentValue = target` exactly. No asymptote, no residual, nothing to flush. This is the
  structural difference from the exponential `Smoother` beside it.
- **`measurement::LevelProbe`** — the one-pole is a *function-local* `lp`, re-zeroed on every `fill()`
  call and driven by full-scale LCG noise the whole time; there is no persistent state and no silence.
  Off-thread/offline besides.
- **`measurement::Sweep`** — clean twice over: closed-form `sin(φ)·env` with no recursion of any kind, and
  explicitly offline / message-thread (double, allocates).
- **`dither::Dither`** — the error-feedback loop is real, but the state cannot decay. `e[]` is in LSB
  units and is re-excited every sample by a ±1 LSB TPDF draw: with `in == 0`,
  `e = code + fb` where `code` is a small integer and `|fb| ≤ Σ|h_k|·8` (16 for the Weighted curve, 171
  for the 9-tap), so `e` is O(1). Two independent reasons beyond that: for the Weighted curve the
  coefficients 1.5 / −0.5 are **dyadic**, so every `e` is a dyadic rational with a bounded denominator and
  *cannot* be subnormal; and auto-blanking clears the shaper to exact zero after 4096 samples of digital
  black. The `autoBlank == false` path was checked separately and is clean for the same reason.

### Swept and clean, no action (recorded so the sweep is not repeated)

`TruePeakLimiter` (its `grDb` is flushed) · `dynamics::RelativeLevel` (dB domain, fixed point is nonzero)
· `NoiseGate` (per-sample flush plus an env flush) · `eq::EqBand` (per-block `flushState()`, and a reset
when no lane runs) · `eq::Svf` / `eq::MatchedBiquad` (1e-15f) · the convolver IR
crossfade (a countdown, not a decay) · `stereo::MonoBass` (flushes its crossover, resets on bypass) ·
`stereo::StereoWidth` (`LinearSmoother` only) · `MultiResSpectrumPane` (has its own power-aware guard) ·
`dynamics::EnvelopeFollower` in **Rms** mode (1e-30f — the state there is a
POWER, so the house 1e-15 amplitude threshold would have zapped a level of 3.2e-8, i.e. −150 dBFS. That
is not merely audible-adjacent, it made the OUTPUT depend on the caller's block partition, because the
flush fires once per `process()` call: measured on a −160 dBFS input, −7.5 dB of gain reduction in one
10000-sample call against 0.00 dB in 10000 one-sample calls, the same stream. Same reasoning, and the
same constant, as the power-aware guard in `MultiResSpectrumPane`) · every `EnvelopeFollower` owner (Compressor, NoiseGate, DeEsser, DynamicEqBand,
LaneDynamics, TransientShaper) · `DelayLine` / `DryAligner` / `StreamResampler` (no recursion) ·
`Fft` / `Pffft*` / `MatrixConvolver*` / `IrResampler` / `PolyphaseOversampler` / `CascadeOversampler` / `BlendKernels` (FIR and
transforms — no decaying recursion) · `TruePeakMeter` and `SpectrumPane` (settled in the F1 pass) ·
`measurement` / `blend` / `lineareq` / `io` (offline or FIR).

**Not verified here:** neural inference state — the backends live outside core.

### ⚠ THE SWEEP ABOVE ASSUMED A SMALL BLOCK, and one call shape falls outside it

Every "clean, per-block flush" verdict here rests on `core/FlushToZero.h`'s own reasoning: *"a block is
too short to re-traverse the gap, so state never reaches subnormal across blocks."* **That is false for a
big block**, and a big block is not exotic — `Compressor`, `EqEngine` and `Dither` all accept any length,
and `TruePeakLimiter`'s header explicitly tells an offline caller that sizing `maxBlock` to a whole file
is a normal thing to do. A flush that fires once per CALL cannot fire inside one.

Measured (P6, `eq::EqEngine`, one +6 dB bell, 1000 samples of tone then 39000 of digital silence, tail
`[2000, 40000)`):

| call shape | exact zeros | SUBNORMAL | last non-zero |
|---|---|---|---|
| whole file, one call | 1 | **37678** | 7.006e-45 at i = 39999 |
| block 4096 | 35905 | 1774 | 7.006e-45 at i = 4095 |
| block 64 | 38000 | 0 | — |
| block 1 | 38000 | 0 | — |

So the entire tail sits in the subnormal range — the 10–100× stall this law exists to prevent, and the
one already measured at 23.9× on `Saturator`'s DC blocker. `eq::EqBand` and `stereo::MonoBass` are listed
as clean above; that verdict holds for a host-sized block and NOT for a whole-file call. `Saturator` is
genuinely clean either way, because its flush is per SAMPLE.

**What to do about it is a choice, and P6 took the third option:** (a) move the flushes into the sample
loop — correct, but a versioned behaviour change in a module TabbyEQ ships; (b) cap the block a stage
will accept — reintroduces the silent-truncation defect P2 F2 closed; (c) **stop the caller's block from
reaching the stage at all**, which is what `felitronics::mastering` (felitronics-mastering-core) does with a
fixed internal quantum, and why it has one. A future re-audit should measure the whole-file shape for every row above rather than
assume the sweep covered it.

### ✅ CLOSED for `eq` and `stereo` — option (a), on a GRID rather than per sample

The window that made (a) expensive closed (TabbyEQ has no audience), and the cheap form of it is a
sample-phase counter rather than a per-sample branch: `core::StateGrid`, period 64 samples, described as
law 8a in [`DSP-ARCHITECTURE.md`](DSP-ARCHITECTURE.md). `eq::EqBand` (and therefore `EqEngine`) and
`stereo::MonoBass` now flush there. Measured, same fixture as the table above:

| | `eq::EqEngine` | `stereo::MonoBass` |
|---|---:|---:|
| tail samples differing between a whole-file call and one-sample calls, BEFORE | 38 522 of 40 000 | 37 180 of 40 000 |
| … AFTER | **0** | **0** |
| subnormal tail samples on a whole-file call, BEFORE | 37 678 | 32 842 |
| … AFTER | **0** | **0** |
| non-finite outputs after ONE +Inf, whole-file call, BEFORE | 479 900 of 480 000 | — |
| … AFTER | **28** (≤ one grid period) | — |

The flush cadence and the **control** cadence moved together, because block-invariance is false without
both: `core::Smoother::advance(n)` is a closed form in `pow(coeff, n)`, and `pow(c,a)·pow(c,b)` is not
`pow(c,a+b)` in binary64, so a band with a ramp in flight was slicing-dependent at **1.31 full scale** —
eight orders of magnitude louder than the denormal effect and invisible to a fixture that only renders
settled parameters. `EqBand` now advances its smoothers by exactly one period per grid tick and redesigns
there; a MATERIAL change (type, slope, swept, on/bypass, an active lane's design) still applies at the
call boundary, because the run flags and the stopped-cell ledger already read the new parameters and
would otherwise run the new topology on the old coefficients for up to 63 samples.

**Still per call, measured and left for their own pass** — same mechanism, different owners:
`deesser::DeEsser` (1 735 samples of 336 000 slicing-dependent, worst 1.97e-17), `dynamiceq::DynamicEqBand`
(5 844, worst 2.46e-16), `dynamiceq::LaneDynamics` (its 16-sample control grid restarts at every call —
felitronics-mastering-core's `mastering::MasteringChain`, which drives one per EQ band, always calls it with exactly the internal
quantum, so that restart lands on the same absolute sample whatever the caller's block size),
`dynamics::Compressor` / `NoiseGate` / `TransientShaper` (their followers), `multiband::MultibandProcessor`,
`limiter::TruePeakLimiter` (its internal chunk loop is
anchored at the call, not at audio time), and the offline `EnvelopeAnalyzer` / `ThresholdSolver`, which
flush once per WHOLE KEY and so carry the whole-file hole into the solver.

---

### Added with the module: `dehum::HumRemover` — gridded from the start

**Recursive state:** the canceller's weights (double; one complex weight per harmonic per channel), its
references (re-anchored from an exact uint32 phase every grid period, so nothing decays), the 20 ms one-pole
of the broadband and residual powers, the floor (a minimum over sixteen hop minima — not recursive) and
the FLL's estimate (a bounded sum of slewed steps). **Verdict: clean, by three mechanisms.** (1) The weights
can only decay by adapting to a non-black quiet input — an exact-zero sample adapts nothing, so digital
black holds them — and on `core::StateGrid` every weight is flushed (`|w| < 1e-15 → 0`), healed
(non-finite → 0) and bounded (beyond +60 dBFS → 0); the non-finite half also runs at the end of every
call. Measured: 60 s of ±1e-20 noise after a hum leaves every weight at 0 or ≥ 1e-15 after every
64-aligned call, and removing the flush puts them in the band below. (2) Each increment is a float-rounded
product added to a double, so with float inputs it cannot be subnormal in double. (3) The smoothed powers
hold through an all-zero period (black or a pause), so they never decay toward zero on silence; the floors
(input and residual) are minima over hop minima — not recursive — and the black fade is an integer counter.
A smoothed power is seeded from a settled level, never from one 64-sample period. Subnormal INPUT samples
cost the input's own arithmetic (measured +52 % per block on `deb` with FTZ off, by the review's probe) and
leave no subnormal state: a second of ±1e-40 input leaves every weight at 0 or ≥ 1e-15. The residual's PEAK
follower (the trigger's reference) decays geometrically on every grid boundary, silence included, so it is
flushed there too (`< 1e-15 → 0`); unflushed it reached the subnormal band after ≈ 20 s of black (review 3) —
the minute-of-silence test now asks `anySubnormalState()`, which covers it with the weights, powers and floors. Tested in
`modules/dehum/tests/HumRemoverContractTests.cpp` (the minute of black and of quiet, the poison and burst
cases) with FTZ off on the `deb` row.

### Added with the modules: `delay::TapeDelay` and `reverb::Freeverb` / `reverb::AmpReverb` — flushed per sample

**Recursive state.** `TapeDelay`: the loop's one-pole low pass (`x ← x + c·(v − x)`), the line it writes (every
write is a `tanh` of that state), the motor glide (`d ← d + c·(T − d)`, T ≥ 1 ms of samples) and the per-channel
offset glides (target 0 whenever the offset is 0, so they decay geometrically toward zero). `Freeverb`: each
comb's damping one-pole, and every value written into a comb (feedback up to 1) or an allpass (0.5).
`AmpReverb` adds the wet HPF (`eq::Svf`); its predelay and chorus lines are pure delays and its parameter glides
are linear (they end exactly on target).
**Verdict: flushed, per sample, at the house 1e-15 (`core::flushDenormal`).** Ported unflushed from the app —
whose Freeverb did not quantise on arm64, measured — every one of these decayed into the subnormal band on
silence; the offset glide to zero is item 6 below. With the line written only through the loop filter, a flush
there keeps every stored line value zero or ≥ 1e-15; in Freeverb the buffers ARE the state, so a flush at each
write is the only place one can stand. Per sample makes the claim slicing-free. Against an unflushed reference
the flush moves a HALL impulse by 1.2e-10 at most (-198 dBFS). That number is not flushed residues piling up
over the decay: it is about one ulp of a ~1e-3 sample, where a sum's rounding flips because a flushed residue
would have met a loud operand. Inaudible, and since these stages compute in `core::det` the goal is the same
bits on every row, not the app's bits. The HPF keeps the eq module's own 1e-15 flush on `core::StateGrid`
(audio time) and heals poison at the end of every call.
**Cost, measured** (review): the per-sample flush adds 13 % to a kernel that costs 0.07 % of real time — about
+0.008 % RT.
**Item 6, the glides that do not head for zero.** The delay's heads glide in DOUBLE and land: once an update no
longer moves a head, it is put on its target. In float — as the app had them — the update stops moving the
value once `(T − d)·c` falls under half an ulp of `d`, which is `1/(2c)` ulps short: 112 samples (2.3 ms) short
of a 6 s target at 48 kHz, parked there for good. In double that distance is ~1e-6 of a sample, so the landing
step is inaudible. The room's glides are linear and land by construction.
Tested in `modules/delay/tests/TapeDelayTests.cpp` (a minute of silence after a bloom with the offset gliding to
zero: no subnormal in any state at any block, and the silence holds; the heads stand exactly on their targets)
and `modules/reverb/tests/AmpReverbTests.cpp` (three minutes after a HALL at DECAY ×2: no subnormal in the room,
the predelay or the chorus line, and once exact zero is reached it holds).

### Added with the module: `envfilter::EnvelopeFilter` — gridded from the start

**Recursive state.** The swept TPT state-variable filter's two integrators per lane — four lanes, the low-pass
path and the band-pass path per channel (`envfilter::detail::SweptSvf`, `eq::Svf`'s update) — the two clean-lows
splits (`eq::DeterministicSvf`, a high pass, and `eq::DeterministicCrossover2`, LR4), the doors' allpass
(`eq::DeterministicSvf`, the LR4 pair's own), the envelope follower
(`dynamics::EnvelopeFollower`, peak) and nine glides, one-pole in double: mix, sensitivity, keepLows, resonance,
the direction blend, the range's two ends, the corner (log2 Hz) and the playing's cutoff smoother (log2 Hz). The
low-pass door and the band pass's three-stage ladder are counted linear ramps (clean, they land by construction).
**Verdict: flushed at the house 1e-15 on `core::StateGrid` (audio time), poison healed at the end of every call.**
The follower, the filters' integrators and both splits decay geometrically toward zero on silence and would
otherwise park in the subnormal band. The glides LAND (item 6): on their target once the update no longer moves
them or once within 1e-9 × max(1, |target|) of it, so none of them can creep through the subnormals; the stage
goes idle on the last counted door's landing, which is exact. A gap (law 11c) runs the same per-sample
control step as silence and, when keyless, stops once the shared state stands still with the follower at exact
zero.
Tested in `modules/envfilter/tests/EnvelopeFilterTests.cpp` (a Q 12 band-pass ring, then 60 s of silence in
512-sample calls and as ONE 61 s call: no subnormal in any state, exact zero from 1.5 s after the ring; and the
fastest settings' 20 Hz Q 12 ring dies to exact zero). Removing the flush turns all of them red.

### Added with the module: `chorus::BassChorus` — the eq flush on the grid, the line flushed per write

**Recursive state.** The voice's high pass — two `eq::Svf` sections carried as lanes of one Svf — and the parameter
glides: depth and centre delay as two one-poles in cascade, rate and crossover as one (depth may glide to zero).
The mix is a counted linear ramp, and the line is NOT recursive: it holds the high pass's output and is only read
back, never fed back.
**Verdict: flushed.** The Svf keeps the eq module's 1e-15 flush on `core::StateGrid` (audio time, 64 samples) and
heals poison at the end of every call; what is written into the line goes through `core::flushDenormal`, so a
stored value is zero or ≥ 1e-15. The glides land (item 6): each stage is put on its target once its residual is
under a landing far below audibility (the heads 1e-9 of a sample, rate 1e-12 Hz, crossover 1e-3 Hz) or an update
no longer moves it; the mix ramp is counted and lands on an exact zero, which is what lets the stage idle.
Tested in `modules/chorus/tests/BassChorusTests.cpp` (a minute of silence after a full chorus at 44.1, 48 and
96 kHz: no subnormal in the lines or the glides at any block, and the last second is exact zeros). The Svf's
integrators are not visible to that test; they stand on the eq module's own flush contract.

## How these are tested

State tests, in the style of `modules/dynamics/tests/DynamicsTests.cpp:61` — after a long silence the
state is **exactly** zero. Not timing: PR #107 removed CPU-grading from the suite and none of it comes
back here. The 23.9× above is a one-off measurement for this write-up, run by hand on x86, not a ctest.

Every one of these was verified by **reverting its own fix and watching the assertion fail** — the flush
is never called from the test, so a test that passes with the flush removed is not testing it.

| kernel | observable | negative control (fix reverted) |
|---|---|---|
| `core::Smoother` | `value()` after 5 s aimed at 0, via `next()` and `advance(128)`; plus a **non-zero** target reached exactly and `settled(0)` firing | 4.15e-73 — a normal double, so FTZ cannot mask it |
| `analysis::CorrelationMeter` | after 5 s of silence, 1000 samples on L only ⇒ `sRR == 0` ⇒ `d == 0` ⇒ `correlation()` is exactly 1.0 | residual 1.9e-19 gives `d = 1.6e-10`, **161× the meter's own 1e-12 gate**, and `correlation()` reads ~1e-9 |
| `saturation::Saturator` | the **output** — a state that reached zero emits exact zero | −3.4e-41 on every sample |

Saturator's asserts **twice** (as rigplayer's does, in felitronics-guitar-core), at an early instant and at 5 s, and the reason is worth keeping: at 5 s the
un-flushed value is *subnormal*, so a machine running hardware FTZ would read it as zero and a regression
could hide. The early assertion is placed where the un-flushed value is still a **normal** float
(Saturator: the flush fires at 1.10 s, the value goes subnormal at 1.39 s, so 1.25 s discriminates on any
machine).

**Not independently tested, deliberately:** `dynamics::AutoLeveler`. It is invisible through its public
surface — its silence gate returns before the state can influence anything. There is no assertion that
would fail without the fix, so writing one would be theatre.

---

## Checking a new kernel

1. Does it hold state updated as `x ← f(x)` where `f` contracts toward a fixed point? If not (FIR,
   transform, closed-form generator, countdown, linear ramp), stop — it is clean, and say so in the header
   so the question is not re-asked.
2. Can the target be **exactly zero** on a real path? Trace it: a default, a reset, a clamp floor, a dB
   conversion that underflows (`≤ −120 dB` in this repo returns literal `0.0`).
3. Compute the fixed-point band, `k ≤ ½/(1−r)`. If `k ≥ 1` the decay stops; it does not "eventually
   underflow".
4. Ask **where the stuck value is read**, not just where it is written. The three expensive findings here
   were all cheap at the write site and costly at the read site — a per-sample loop, an oversampled
   kernel, a 128-tap FIR.
5. Flush inside the kernel, not in a method the owner must remember to call. That mistake has now been
   made twice in this repo (`MultibandSplitter`, `CorrelationMeter`) and caught twice by an audit rather
   than by a test.
6. Where the state glides to a *parameter* rather than to zero, use both conditions (threshold **and**
   "the update did not move the value"). A threshold alone leaves every non-zero target parked a few ulp
   short forever. "A few ulp" is optimistic: an exponential glide with coefficient `c` parks `1/(2c)` ulps short —
   thousands for a slow motor (`delay::TapeDelay`: 112 samples at 6 s). Landing from there is a jump; glide
   in double, where the parked distance is negligible, and then land.
