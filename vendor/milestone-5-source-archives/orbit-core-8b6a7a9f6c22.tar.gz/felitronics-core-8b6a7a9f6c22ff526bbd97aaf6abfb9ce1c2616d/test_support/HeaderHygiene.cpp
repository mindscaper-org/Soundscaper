// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

// HEADER HYGIENE — one TU that #includes EVERY public header (felitronics + the teq compat shims) and
// is compiled under a strict, downstream-grade warning set (-Wconversion, -Wfloat-equal, … + -Werror;
// see the target in the top-level CMakeLists). Consumers (TabbyEQ links its test targets against
// juce::juce_recommended_warning_flags) compile these headers under exactly this class of flags — this
// target makes header warning-cleanliness a CORE gate instead of a downstream surprise.
//
// Class templates are explicitly instantiated below (with their shipped default arguments) so warnings
// inside template member bodies fire HERE, not only when a consumer instantiates them.

#include <felitronics/analysis/CorrelationMeter.h>
#include <felitronics/analysis/KWeightingFilter.h>
#include <felitronics/analysis/LoudnessMeter.h>
#include <felitronics/analysis/MultiResSpectrumPaneFast.h>
#include <felitronics/analysis/ReferenceTruePeakMeter.h>
#include <felitronics/analysis/SpectrumTap.h>
#include <felitronics/analysis/offline/SpectrumCurve.h>
#include <felitronics/analysis/TruePeakMeter.h>
#include <felitronics/blend/Blend.h>
#include <felitronics/blend/BlendKernels.h>
#include <felitronics/blend/BlendParams.h>
#include <felitronics/blend/IrBlend.h>
#include <felitronics/blend/Overlay.h>
#include <felitronics/chorus/BassChorus.h>
#include <felitronics/chorus/ChorusLaw.h>
#include <felitronics/codecgrid/BackResampler.h>
#include <felitronics/codecgrid/CodecGridDetector.h>
#include <felitronics/codecgrid/GridCurve.h>
#include <felitronics/codecgrid/GridScan.h>
#include <felitronics/codecgrid/Mdct.h>
#include <felitronics/codecgrid/Mp3Hybrid.h>
#include <felitronics/codecgrid/Mp3Window.h>
#include <felitronics/codecgrid/Windows.h>
#include <felitronics/convolution/CabConvolver.h>
#include <felitronics/convolution/ConvolutionEngine.h>
#include <felitronics/convolution/IrResampler.h>
#include <felitronics/convolution/MatrixConvolver.h>
#include <felitronics/convolution/MatrixConvolverNupc.h>
#include <felitronics/convolution/NonUniformConvolver.h>
#include <felitronics/convolution/PartitionedConvolver.h>
#include <felitronics/core/Config.h>
#include <felitronics/core/DelayLine.h>
#include <felitronics/core/DeliveryResampler.h>
#include <felitronics/core/DryAligner.h>
#include <felitronics/core/Fft.h>
#include <felitronics/core/FlushToZero.h>
#include <felitronics/core/Math.h>
#include <felitronics/core/OfflineFft.h>
#include <felitronics/core/PolyphaseFir.h>
#include <felitronics/core/RtStreams.h>
#include <felitronics/core/Smoother.h>
#include <felitronics/core/StateGrid.h>
#include <felitronics/core/StreamResampler.h>
#include <felitronics/deesser/DeEsser.h>
#include <felitronics/dehum/HumRemover.h>
#include <felitronics/delay/DelayLaw.h>
#include <felitronics/delay/TapeDelay.h>
#include <felitronics/dither/Dither.h>
#include <felitronics/dynamiceq/DynamicEqBand.h>
#include <felitronics/dynamiceq/LaneDynamics.h>
#include <felitronics/dynamics/AutoLeveler.h>
#include <felitronics/dynamics/BandBallistics.h>
#include <felitronics/dynamics/ChannelLinker.h>
#include <felitronics/dynamics/Compressor.h>
#include <felitronics/dynamics/EnvelopeFollower.h>
#include <felitronics/dynamics/GainComputer.h>
#include <felitronics/dynamics/GainReductionFollower.h>
#include <felitronics/dynamics/GainReductionPath.h>
#include <felitronics/dynamics/LinkedDetector.h>
#include <felitronics/dynamics/NoiseGate.h>
#include <felitronics/dynamics/offline/DetectorAnalysis.h>
#include <felitronics/dynamics/offline/Quantile.h>
#include <felitronics/dynamics/offline/ThresholdSolver.h>
#include <felitronics/dynamics/RelativeLevel.h>
#include <felitronics/dynamics/TransientShaper.h>
#include <felitronics/envfilter/EnvelopeFilter.h>
#include <felitronics/envfilter/EnvelopeFilterLaw.h>
#include <felitronics/eq/Crossover2.h>
#include <felitronics/eq/EqBand.h>
#include <felitronics/eq/EqEngine.h>
#include <felitronics/eq/EqTypes.h>
#include <felitronics/eq/MatchedBiquad.h>
#include <felitronics/eq/MultibandSplitter.h>
#include <felitronics/eq/Svf.h>
#include <felitronics/io/Wav.h>
#include <felitronics/limiter/TruePeakLimiter.h>
#include <felitronics/lineareq/LinearPhaseEq.h>
#include <felitronics/lineareq/MagnitudeCurve.h>
#include <felitronics/lineareq/MixedPhaseFir.h>
#include <felitronics/lineareq/NaturalPhaseEq.h>
#include <felitronics/measurement/CaptureGate.h>
#include <felitronics/measurement/Convolve.h>
#include <felitronics/measurement/Deconvolve.h>
#include <felitronics/measurement/IrPost.h>
#include <felitronics/measurement/LevelProbe.h>
#include <felitronics/measurement/MicSetAlign.h>
#include <felitronics/measurement/ModelGuess.h>
#include <felitronics/measurement/PeakClip.h>
#include <felitronics/measurement/ReferenceUnity.h>
#include <felitronics/measurement/Sweep.h>
#include <felitronics/measurement/XcorrAlign.h>
#include <felitronics/multiband/MultibandCompressor.h>
#include <felitronics/multiband/MultibandProcessor.h>
#include <felitronics/multiband/MultibandWidth.h>
#include <felitronics/neural/Inference.h>
#include <felitronics/neural/NeuralStage.h>
#include <felitronics/octave/OctaveLaw.h>
#include <felitronics/octave/Octaver.h>
#include <felitronics/oversampling/CascadeOversampler.h>
#include <felitronics/oversampling/Oversampler.h>
#include <felitronics/oversampling/PolyphaseOversampler.h>
#include <felitronics/reverb/AmpReverb.h>
#include <felitronics/reverb/Freeverb.h>
#include <felitronics/saturation/Saturator.h>
#include <felitronics/saturation/WaveShaper.h>
#include <felitronics/stereo/MidSide.h>
#include <felitronics/stereo/MonoBass.h>
#include <felitronics/stereo/StereoWidth.h>
#include <felitronics/text/Translit.h>

#include <felitronics/analysis/PlotMap.h>
#include <felitronics/analysis/SpectrumPane.h>
#include <felitronics/analysis/MultiResSpectrumPane.h>
#include <felitronics/analysis/RollingSpectrumTap.h>

#if defined(FELITRONICS_WITH_PFFFT)   // optional compiled SIMD backend — headers only reach the gate when the option is ON
#include <felitronics/fftpffft/PffftRealFft.h>
#include <felitronics/fftpffft/PffftOrderedRealFft.h>
#include <felitronics/fftpffft/PffftComplexFft.h>
#endif

// The teq compat shims are public too — they are what TabbyEQ/OrbitCab actually include.
#include <teq/EqBand.h>
#include <teq/EqEngine.h>
#include <teq/EqTypes.h>
#include <teq/MatchedBiquad.h>
#include <teq/Math.h>
#include <teq/Smoother.h>
#include <teq/SpectrumTap.h>
#include <teq/Svf.h>

namespace
{
    // Minimal Inference backend so NeuralStage's members instantiate.
    struct NullInference
    {
        void prepare (double, int, int) noexcept {}
        bool process (float* const*, int, int) noexcept { return true; }
        void reset() noexcept {}
        int  latencySamples() const noexcept { return 0; }
    };
    static_assert (felitronics::neural::Inference<NullInference>);
}

// Explicit instantiations (shipped defaults) — force every template member body through the compiler.
template class  felitronics::convolution::PartitionedConvolver<felitronics::core::fft::DefaultRealFft>;
template class  felitronics::dehum::HumRemover<>;
template class  felitronics::convolution::ConvolutionEngine<felitronics::core::fft::DefaultRealFft, 2>;
template class  felitronics::convolution::MatrixConvolver<felitronics::core::fft::DefaultRealFft>;
template class  felitronics::lineareq::MixedPhaseFir<felitronics::core::fft::DefaultRealFft>;
template class  felitronics::lineareq::BasicLinearPhaseEq<felitronics::core::fft::DefaultRealFft>;
template class  felitronics::lineareq::BasicNaturalPhaseEq<felitronics::core::fft::DefaultRealFft>;
template struct felitronics::analysis::SpectrumPaneT<felitronics::core::fft::DefaultRealFft>;
template struct felitronics::analysis::MultiResSpectrumPaneT<14, 4, felitronics::core::fft::DefaultRealFft>;
#if defined(FELITRONICS_WITH_PFFFT)   // the SIMD backends through the strict gate: PR2's C1 static_asserts + the row-stride precondition,
template class  felitronics::convolution::MatrixConvolver<felitronics::fftpffft::PffftRealFft>;            // and the ordered one under both panes
template struct felitronics::analysis::SpectrumPaneT<felitronics::fftpffft::PffftOrderedRealFft>;
template struct felitronics::analysis::MultiResSpectrumPaneT<14, 4, felitronics::fftpffft::PffftOrderedRealFft>;
template class  felitronics::codecgrid::Mdct<felitronics::fftpffft::PffftComplexFft>;                   // the complex backend under the MDCT, the scan
template class  felitronics::codecgrid::GridScan<felitronics::fftpffft::PffftComplexFft>;               // and the detector
template class  felitronics::codecgrid::CodecGridDetector<felitronics::fftpffft::PffftComplexFft>;
#endif
template class  felitronics::eq::MultibandSplitter<4>;
template class  felitronics::multiband::MultibandProcessor<felitronics::dynamics::Compressor, 4>;
template class  felitronics::multiband::MultibandCompressor<4>;
template class  felitronics::multiband::MultibandWidth<4>;
template class  felitronics::neural::NeuralStage<NullInference>;
template struct felitronics::analysis::SpectrumTapT<felitronics::analysis::kSpectrumFftOrder>;
// Public class templates nothing else here instantiated, so no gate — strict warnings OR -fno-exceptions —
// ever entered their member bodies. Both compilers skip an uninstantiated template member entirely, so a
// `throw` added inside one of these would have been invisible on every CI row.
template class  felitronics::convolution::NonUniformConvolver<felitronics::core::fft::DefaultRealFft>;
template class  felitronics::convolution::MatrixConvolverNupc<felitronics::core::fft::DefaultRealFft>;
template struct felitronics::analysis::RollingSpectrumTapT<14>;
template class  felitronics::codecgrid::Mdct<felitronics::codecgrid::MixedRadixFft>;
template class  felitronics::codecgrid::GridScan<felitronics::codecgrid::MixedRadixFft>;
template class  felitronics::codecgrid::CodecGridDetector<felitronics::codecgrid::MixedRadixFft>;

int main() { return 0; }
