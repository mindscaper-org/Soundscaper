// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <felitronics/core/Config.h>
#include <felitronics/core/DetMath.h>
#include <felitronics/core/FlushToZero.h>
#include <felitronics/core/Math.h>

#include <cmath>

namespace felitronics::analysis
{

//==============================================================================
// felitronics::analysis::KWeightingFilter — the ITU-R BS.1770 K-weighting pre-filter: stage 1 (a high
// shelf, ~+4 dB) then stage 2 (the RLB high-pass, ~38 Hz). Coefficients are RECOMPUTED for the actual
// sample rate (analog prototype + bilinear) — correct at 44.1/48/88.2/96 kHz, not a hardcoded 48 k table
// (the usual porting bug). Per-channel double biquad state for loudness accuracy.
template <class Math = core::SystemMath>
class BasicKWeightingFilter
{
public:
    struct Coeffs { double b0, b1, b2, a1, a2; };

    // The shelf's design frequency (BS.1770's published constant). Named because the core's rate floor is
    // derived from it: below 2 x kShelfHz the bilinear tan() is past its pole — the shelf is aliased, and wherever
    // tan() comes out negative ((f0, 2 f0), (f0/2, 2 f0/3), …) unstable. This
    // filter itself still accepts any rate — its prepare() cannot refuse, and its one owner, LoudnessMeter, refuses a
    // rate below core::kMinSampleRate before it prepares one (P103) — and the assertion keeps that floor above the edge.
    static constexpr double kShelfHz = 1681.974450955533;

    void prepare (double sampleRate, int numChannels) noexcept
    {
        fs = sampleRate;
        ch = numChannels < 1 ? 1 : (numChannels > kMaxChannels ? kMaxChannels : numChannels);
        computeCoeffs (fs);
        reset();
    }

    void reset() noexcept
    {
        for (int c = 0; c < kMaxChannels; ++c) { z1a[c] = z2a[c] = 0.0; z1b[c] = z2b[c] = 0.0; }
    }

    // Clear ONE channel's state, leaving every other bit-exact — for an owner whose channel stopped
    // being fed and will be fed again (law 11a's falling edge). Unprepared or out of range is a no-op.
    void resetChannel (int c) noexcept
    {
        if (c < 0 || c >= kMaxChannels) return;
        z1a[c] = z2a[c] = 0.0; z1b[c] = z2b[c] = 0.0;
    }

    // K-weighted sample (double) for channel c. Two TDF-II biquads in series.
    inline double process (int c, double x) noexcept
    {
        const double y1 = sa.b0 * x  + z1a[c]; z1a[c] = sa.b1 * x  - sa.a1 * y1 + z2a[c]; z2a[c] = sa.b2 * x  - sa.a2 * y1;
        const double y2 = sb.b0 * y1 + z1b[c]; z1b[c] = sb.b1 * y1 - sb.a1 * y2 + z2b[c]; z2b[c] = sb.b2 * y1 - sb.a2 * y2;
        return y2;
    }

    // LAW 8 (docs/DSP-ARCHITECTURE.md §2). Zero the state once it is numerically dead, so it never reaches
    // the subnormal range: with zero input these two TDF-II biquads decay and then STICK — the RLB pair
    // (z1,z2) = (-251u, +249u), u = 2^-1074, maps to itself EXACTLY at 48 kHz — and on a CPU with no
    // hardware FTZ, which is what a browser gives, silence then costs ~54x more than music.
    // THE BINDING NUMBER IS THE SHELF, NOT THE RLB, and it is much smaller than it first looks. From the
    // 1e-15 threshold the RLB (pole 0.995) needs ~2.85 s to reach the subnormal floor, but the shelf
    // (pole 0.856) needs only **90 ms** — 4 324 samples at 48 kHz, 3 983 at 44.1 kHz, and 90 ms at every
    // rate, since both scale together. So the owner's flush cadence has to beat 90 ms, not 2.85 s.
    // The OWNER therefore calls this on a deterministic AUDIO boundary: not per sample (that would tax a
    // 4.6 ns/sample path), and not per host block — 8192 samples is 170 ms at 48 kHz, already past the
    // shelf limit, and it would also make the result depend on the caller's chunking, which this repo
    // tests as bit-invariant. LoudnessMeter uses its 10 ms sub-hop: 480 samples at 48 kHz, a 9x margin.
    // flushPoison, not flushDenormal — the strict superset, which also zeroes NON-FINITE state. That is the
    // second half of the same problem: this is an IIR, so one NaN sample makes its state NaN FOREVER, every
    // later block energy NaN, and `NaN > absT` false — the absolute gate then silently drops them all while
    // the meter keeps reporting a healthy number computed over the fraction of the programme that predates
    // the NaN. Healing here bounds the damage to the 10 ms sub-hop the bad sample fell in. It is NOT a
    // licence to ignore the event: LoudnessMeter counts it in nonFiniteSubHops(), because a meter must
    // REPORT damage, not quietly repair it. Cost is one isfinite per state word per sub-hop — negligible,
    // but not literally free. Numbers, fixed point and benchmark: docs/LAW8-KWEIGHTING.md.
    void flushDenormals() noexcept
    {
        for (int c = 0; c < ch; ++c)   // `ch`, not kMaxChannels: the rest are zeroed by reset() and never
        {                              // processed, so flushing them is pure cost for a guaranteed no-op
            core::flushPoison (z1a[c]); core::flushPoison (z2a[c]);
            core::flushPoison (z1b[c]); core::flushPoison (z2b[c]);
        }
    }

    const Coeffs& shelfCoeffs() const noexcept { return sa; }   // for tests (vs the canonical 48 k values)
    const Coeffs& highpassCoeffs() const noexcept { return sb; }

private:
    void computeCoeffs (double sampleRate) noexcept
    {
        // Stage 1 — high shelf (the published BS.1770 design constants).
        {
            const double f0 = kShelfHz, G = 3.999843853973347, Q = 0.7071752369554196;
            const double K = Math::tan (core::kPi * f0 / sampleRate);
            const double Vh = Math::pow10 (G / 20.0);
            const double Vb = Math::pow (Vh, 0.4996667741545416);
            const double D = 1.0 + K / Q + K * K;
            sa = { (Vh + Vb * K / Q + K * K) / D, 2.0 * (K * K - Vh) / D, (Vh - Vb * K / Q + K * K) / D,
                   2.0 * (K * K - 1.0) / D, (1.0 - K / Q + K * K) / D };
        }
        // Stage 2 — RLB high-pass.
        {
            const double f0 = 38.13547087602444, Q = 0.5003270373238773;
            const double K = Math::tan (core::kPi * f0 / sampleRate);
            const double D = 1.0 + K / Q + K * K;
            sb = { 1.0, -2.0, 1.0, 2.0 * (K * K - 1.0) / D, (1.0 - K / Q + K * K) / D };
        }
    }

    static constexpr int kMaxChannels = core::kMaxChannels;
    double fs = 48000.0; int ch = 2;
    Coeffs sa {}, sb {};
    double z1a[kMaxChannels] {}, z2a[kMaxChannels] {}, z1b[kMaxChannels] {}, z2b[kMaxChannels] {};
};


// P51: the core's rate floor has to stay clear of the edge where the shelf goes unstable. The margin is the
// floor's own business (see core::kMinSampleRate); what is asserted is only that it is not INSIDE the band.
static_assert (core::kMinSampleRate > 2.0 * BasicKWeightingFilter<core::SystemMath>::kShelfHz,
               "core::kMinSampleRate admits rates at which the K-weighting shelf is past Nyquist");

using KWeightingFilter = BasicKWeightingFilter<core::SystemMath>;
using DeterministicKWeightingFilter = BasicKWeightingFilter<core::DetMath>;

} // namespace felitronics::analysis
