// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

// EBU Tech 3341 conformance for felitronics::analysis::LoudnessMeter — the meter against the THEORY of
// ITU-R BS.1770-4, never against the implementation. Tech 3341 (2023) Table 1 defines its test signals
// mathematically — 1 kHz sines at set per-channel peak levels and durations, expected readings ±0.1 LU — so
// every fixture here is synthesized from the spec, at both base rates the family runs at:
//   * cases 1–2: calibration and linearity, for I, M and S alike;
//   * cases 3–5: the −10 LU relative gate, the −70 LUFS absolute gate, power-averaging across levels;
//   * case 6: the 5.0 channel weights (Ls/Rs at 1.41);
//   * cases 9 and 12: short-term and momentary settle to a constant over a periodic program;
//   * cases 10 and 13: short-term and momentary read a slid tone in full at every offset.
// Then what Table 1 alone would let a wrong meter get away with, each pinned by a signal built so that only
// the property under test can change the reading: the absolute gate isolated from the relative one and at its
// boundary; the relative gate at −10 LU; every channel counted, in phase or not; the K in K-weighting at both
// rates against the spec's published coefficients; a burst that tells 75 % block overlap from none; the −120
// answer for what cannot be measured; chunk invariance; and process() allocating nothing.
//
// Grown from the Looper Cat conformance suite that gated the product's move onto this meter.

#include <felitronics_test.h>
#include <alloc_counter.h>   // installs the allocation counter: EVERY form of `new`, over-aligned included
#include <felitronics/core/Math.h>
#include <felitronics/analysis/LoudnessMeter.h>

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <string>
#include <utility>
#include <vector>

// One vector's allocation, as the counter sees it. The storage is written through `volatile`: an allocation nothing
// observes may be removed by the optimizer, operator new call and all, and a counter that then reads 0 proves nothing.
static long long vectorRequest (std::size_t n)
{
    const long long before = alloc::bytes.load();
    {
        std::vector<char> v;
        v.assign (n, 0);
        volatile char* sink = v.data();
        sink[0] = 1;
    }
    return alloc::bytes.load() - before;
}

using namespace felitronics;

namespace
{
    // Tech 3341 Table 1 specifies 1 kHz. (BS.1770's own calibration is stated at 997 Hz, where the
    // K-filter's gain is +0.691 dB exactly; at 1 kHz it is +0.698 dB, a residual well inside ±0.1 LU.)
    constexpr double kToneHz = 1000.0;
    constexpr double kNone   = -120.0;     // the meter's "nothing survived the gates" answer

    using Steps = std::vector<std::pair<double, double>>;   // (dBFS per-channel peak, seconds)

    // Appends `seconds` of a dual-mono sine at `dbfs` peak amplitude, phase-continuous across calls through
    // the caller's running sample counter (the level steps of cases 3–5 must add no click energy), fed in
    // `chunk`-frame slices so the meter sees the block boundaries a real stream produces. `after` hears the
    // seconds fed so far after every slice — the hook the ballistics cases read M and S through.
    template <typename After>
    void feedSine (analysis::LoudnessMeter& lm, double sr, double hz, double dbfs, double seconds,
                   long long& sampleIndex, int chunk, After&& after)
    {
        const double amp = std::pow (10.0, dbfs / 20.0);
        const double w   = 2.0 * core::kPi * hz / sr;
        long long frames = std::llround (seconds * sr);
        std::vector<float> buf ((std::size_t) chunk);
        while (frames > 0)
        {
            const int n = (int) std::min<long long> (frames, chunk);
            for (int i = 0; i < n; ++i) buf[(std::size_t) i] = (float) (amp * std::sin (w * (double) sampleIndex++));
            const float* ch[2] { buf.data(), buf.data() };
            felitronics::test::run (lm.process (ch, 2, n));
            frames -= n;
            after ((double) sampleIndex / sr);
        }
    }

    void feedSine (analysis::LoudnessMeter& lm, double sr, double hz, double dbfs, double seconds,
                   long long& sampleIndex, int chunk = 8192)
    {
        feedSine (lm, sr, hz, dbfs, seconds, sampleIndex, chunk, [] (double) {});
    }

    // One fresh stereo meter over a whole Tech 3341-style program of (dbfs, seconds) steps; `after` as above.
    template <typename After>
    analysis::LoudnessMeter run (double sr, const Steps& steps, int chunk, After&& after)
    {
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 200.0));
        long long idx = 0;
        for (const auto& [dbfs, seconds] : steps) feedSine (lm, sr, kToneHz, dbfs, seconds, idx, chunk, after);
        return lm;
    }

    double measure (double sr, const Steps& steps)
    {
        return run (sr, steps, 8192, [] (double) {}).integratedLufs();
    }

    std::string at (double sr, const char* what) { return std::string (what) + (sr == 48000.0 ? " @48k" : " @44.1k"); }

    // How a tone is laid across the channels — the fixtures that tell a per-channel power sum from every
    // cheaper thing a meter could do instead (drop a channel, sum the samples, count one channel twice).
    enum class Layout { leftOnly, rightOnly, antiPhase, mono };

    double measureLayout (double sr, double dbfs, double seconds, Layout layout)
    {
        const int channels = layout == Layout::mono ? 1 : 2;
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, channels, 60.0));
        const double amp = std::pow (10.0, dbfs / 20.0);
        const double w   = 2.0 * core::kPi * kToneHz / sr;
        const long long frames = std::llround (seconds * sr);
        std::vector<float> a (8192), b (8192, 0.0f);
        for (long long o = 0; o < frames; o += 8192)
        {
            const int n = (int) std::min<long long> (8192, frames - o);
            for (int i = 0; i < n; ++i)
            {
                const float v = (float) (amp * std::sin (w * (double) (o + i)));
                switch (layout)
                {
                    case Layout::leftOnly:  a[(std::size_t) i] = v;  b[(std::size_t) i] = 0.0f; break;
                    case Layout::rightOnly: a[(std::size_t) i] = 0.0f; b[(std::size_t) i] = v;  break;
                    case Layout::antiPhase: a[(std::size_t) i] = v;  b[(std::size_t) i] = -v;   break;
                    case Layout::mono:      a[(std::size_t) i] = v;  break;
                }
            }
            const float* ch[2] { a.data(), b.data() };
            felitronics::test::run (lm.process (ch, channels, n));
        }
        return lm.integratedLufs();
    }
}

//==================================================================================================
// EBU TECH 3342 TABLE 1 — the minimum-requirements compliance test for Loudness Range, which this suite did
// not have. Tech 3341's Table 1 covers I, M and S and is unaffected by the LRA cadence, so nothing here was
// watching the one measure that cadence decides.
//
// Cases 1-4 are synthetic and reproduced exactly from the standard's text: a 1 kHz stereo sine, applied in
// phase to both channels, in 20 s segments at the stated PER-CHANNEL PEAK levels, each case's expected LRA
// carrying the standard's own +-1 LU tolerance. Cases 5 and 6 are authentic programme material distributed by
// the EBU and are not reproducible here; their absence is stated rather than papered over.
//
// WORTH KNOWING: both the 1 Hz cadence this meter used to run and the 10 Hz one Tech 3342 3.1 requires pass
// all four EXACTLY — measured on both, not argued. The reason is the SHAPE, not the length: each case is a
// few long steady segments, so every window that is not straddling a step reads the same value and where the
// grid samples them does not matter. (Length alone would prove nothing, and the sentence here used to say it
// did: a 120 s programme whose states last the window's 3 s splits 20.0 LU against 9.5.) So this test does
// not prove the cadence right; it pins
// compliance, which is a different claim and one nothing was making.
void tech3342MinimumRequirements()
{
    felitronics::test::group ("EBU Tech 3342 Table 1: the Loudness Range minimum requirements");
    constexpr double kFs = 48000.0;
    struct Case { const char* what; std::vector<double> peaksDb; double wantLu; };
    const Case cases[] = {
        { "case 1: -20 then -30 dBFS",                     { -20.0, -30.0 },                 10.0 },
        { "case 2: -20 then -15 dBFS",                     { -20.0, -15.0 },                  5.0 },
        { "case 3: -40 then -20 dBFS",                     { -40.0, -20.0 },                 20.0 },
        { "case 4: -50, -35, -20, -35, -50 dBFS",          { -50.0, -35.0, -20.0, -35.0, -50.0 }, 15.0 },
    };
    for (const Case& c : cases)
    {
        std::vector<std::vector<float>> ch (2);
        for (const double peakDb : c.peaksDb)
        {
            const double a = std::pow (10.0, peakDb / 20.0);
            const auto n = (std::size_t) (20.0 * kFs);
            const std::size_t at = ch[0].size();
            for (auto& v : ch) v.resize (at + n, 0.0f);
            for (std::size_t i = 0; i < n; ++i)
            {
                // CONTINUOUS PHASE ACROSS THE SEGMENTS, so the level step is the only discontinuity: a phase
                // jump would be a click, and a click is a transient the meter would rightly see.
                const double t = (double) (at + i) / kFs;
                const float v = (float) (a * std::sin (2.0 * 3.14159265358979323846 * 1000.0 * t));
                ch[0][at + i] = v; ch[1][at + i] = v;
            }
        }
        const int n = (int) ch[0].size();
        felitronics::analysis::LoudnessMeter m;
        if (! felitronics::test::run (m.prepareForSamples (kFs, 2, n))) continue;
        const float* q[2] { ch[0].data(), ch[1].data() };
        if (! felitronics::test::run (m.process (q, 2, n))) continue;
        const double got = m.loudnessRangeLu();
        felitronics::test::ok (std::fabs (got - c.wantLu) <= 1.0,
            std::string (c.what) + ": LRA " + std::to_string (got) + " LU against the standard's "
            + std::to_string (c.wantLu) + " +-1");
    }
    felitronics::test::ok (true, "cases 5 and 6 are authentic EBU programme segments and are NOT covered here — said out loud "
              "rather than left to be inferred from four rows where the standard lists six");
}

//==================================================================================================
// THE CADENCE ITSELF. Tech 3342 3.1 requires a short-term sample at least every 100 ms; this meter sampled
// every second until K12. The count is the claim: one per hop, not one per ten.
void theShortTermCadenceIsTenHertz()
{
    felitronics::test::group ("Tech 3342 3.1: a short-term sample every hop, not every tenth");
    constexpr double kFs = 48000.0;
    const auto n = (std::size_t) (kFs * 12.0);
    std::vector<std::vector<float>> ch (2, std::vector<float> (n, 0.0f));
    for (int c = 0; c < 2; ++c)
        for (std::size_t i = 0; i < n; ++i)
            ch[(std::size_t) c][i] = (float) (0.1 * std::sin (2.0 * 3.14159265358979323846 * 1000.0 * (double) i / kFs));
    felitronics::analysis::LoudnessMeter m;
    if (! felitronics::test::run (m.prepareForSamples (kFs, 2, (int) n))) return;
    const float* q[2] { ch[0].data(), ch[1].data() };
    if (! felitronics::test::run (m.process (q, 2, (int) n))) return;
    // 12 s of programme is 120 hops; the first short-term sample lands once 3 s are in, so 120 - 30 + 1 = 91.
    // At the old 1 Hz cadence it would have been 10.
    felitronics::test::ok (m.shortTermCount() == 91,
        "12 s gives " + std::to_string (m.shortTermCount())
        + " short-term samples — one per 100 ms hop from 3 s on (91); at 1 Hz it was 10");

    // A TOTAL IS NOT A CADENCE. 91 over 12 s pins the average; it does not pin WHERE the first sample lands or
    // that the spacing is uniform, and a build that started late and then ran fast would match it. So: the count
    // at each hop boundary around the first sample, and at the next few, fed in IRREGULAR call sizes so the
    // answer cannot come from the call boundaries. (The companion range check is weaker than it looks — a 20 Hz
    // cadence lands inside its tolerance, and 20 Hz satisfies §3.1 anyway, which asks a MINIMUM. What is pinned
    // here is this meter's exact grid, which is the thing a caller reading shortTermCount() is told.)
    {
        const long long hop = 10LL * std::llround (0.01 * kFs);
        struct Step { long long hops; int want; };
        const Step steps[] = { { 29, 0 }, { 30, 1 }, { 31, 2 }, { 32, 3 }, { 60, 31 }, { 120, 91 } };
        const int splits[] = { 1, 4096, 37, 8192, 300, 1 };                 // nothing lines up with 4800
        for (const Step& s : steps)
        {
            const auto total = (std::size_t) (s.hops * hop);
            std::vector<std::vector<float>> v (2, std::vector<float> (total, 0.0f));
            for (std::size_t i = 0; i < total; ++i)
                v[0][i] = v[1][i] = (float) (0.1 * std::sin (2.0 * 3.14159265358979323846 * 1000.0 * (double) i / kFs));
            felitronics::analysis::LoudnessMeter mm;
            if (! felitronics::test::run (mm.prepareForSamples (kFs, 2, (double) total))) continue;
            std::size_t at = 0, k = 0;
            while (at < total)
            {
                const int len = (int) std::min<std::size_t> ((std::size_t) splits[k++ % 6], total - at);
                const float* q2[2] { v[0].data() + at, v[1].data() + at };
                if (! felitronics::test::run (mm.process (q2, 2, len))) break;
                at += (std::size_t) len;
            }
            felitronics::test::ok (mm.shortTermCount() == s.want,
                std::to_string (s.hops) + " hops in irregular calls: " + std::to_string (mm.shortTermCount())
                + " short-term samples (the first at hop 30, then one each)");
        }
    }
}

//==================================================================================================
// WHAT THE CADENCE IS WORTH, on the programme that shows it. A square envelope whose states last exactly the
// window's 3 s is the worst case for a coarse grid: the window can sit wholly inside a state, and how often it
// does is decided by the sampling phase rather than by the audio. The header states 20.0 LU at the old 1 Hz
// against 9.5 LU here, unchanged from 12 s out to 120 s — this measures the half of that pair the shipped code
// can produce, so the header is not citing a number nothing runs. The 1 Hz figures are named there as read off
// the pre-change meter, and stay named that way; no gate can hold them once the code cannot produce them.
//
// The swing is a flat 20 dB, so 20.0 LU is what a phase-lucky grid reports and also the ceiling: a result of
// 9.5 is the mixed windows being counted, not precision lost. Both rates, because a cadence expressed in hops
// must not depend on how many samples a hop holds.
//
// THE VALUE HERE DOES NOT IDENTIFY THE CADENCE, and it would be easy to read this group as if it did. The
// range is a function of the PHASE SET the grid visits, {k·stride mod 60}, whose size is 60/gcd(stride,60) —
// so strides that share a gcd give the same distribution. Measured on a stride-parametrised meter at 48 kHz:
// stride 3 (3.33 Hz) and stride 9 (1.11 Hz) both read 9.6 LU, inside the tolerance below, while stride 2 reads
// 8.2 and stride 4 reads 11.2. Faster cadences land inside too (20 Hz reads 9.4, and the continuous limit is
// 10·log10(95.05/10.9) = 9.41) — which is correct behaviour, since §3.1 sets a MINIMUM and 20 Hz meets it.
// What pins this meter's grid is the COUNT, in the group above: the first sample's hop and the spacing. This
// group pins the number that grid produces, and is the half that would catch a change in the percentile rule
// or the window rather than in the cadence.
void theCadenceIsMeasuredOnAWindowLengthEnvelope()
{
    felitronics::test::group ("Tech 3342 3.1: the range of a 3 s-state envelope, at the cadence the standard asks for");
    for (const double fs : { 44100.0, 48000.0 })
        for (const double secs : { 12.0, 30.0, 120.0 })
        {
            const auto n   = (std::size_t) (fs * secs);
            const auto blk = (std::size_t) (fs * 3.0);          // a state exactly as long as the window
            std::vector<std::vector<float>> ch (2, std::vector<float> (n, 0.0f));
            for (std::size_t i = 0; i < n; ++i)
            {
                const double s = std::sin (2.0 * 3.14159265358979323846 * 1000.0 * (double) i / fs);
                const double g = ((i / blk) % 2 == 0) ? 0.25 : 0.025;   // 20 dB apart, so 20 LU is the ceiling
                ch[0][i] = ch[1][i] = (float) (g * s);
            }
            felitronics::analysis::LoudnessMeter m;
            if (! felitronics::test::run (m.prepareForSamples (fs, 2, (double) n))) return;
            const float* q[2] { ch[0].data(), ch[1].data() };
            if (! felitronics::test::run (m.process (q, 2, (int) n))) return;
            const std::string where = std::to_string ((int) fs) + " Hz, " + std::to_string ((int) secs) + " s";
            felitronics::test::approx (m.loudnessRangeLu(), 9.5, 0.25,
                where + ": the range is " + std::to_string (m.loudnessRangeLu())
                      + " LU — the mixed windows counted, not the full 20 LU swing a 1 Hz grid lands on");
            // AND THE LENGTH DOES NOT BUY IT BACK: the count grows tenfold from 12 s to 120 s and the range does
            // not move, which is the point the old claim ("nothing changes past 30 s") got backwards.
            felitronics::test::ok (m.shortTermCount() == (int) std::llround ((secs - 3.0) * 10.0) + 1,
                where + ": " + std::to_string (m.shortTermCount()) + " short-term samples, one per hop from 3 s on");
        }
}

int main()
{
    std::printf ("felitronics::analysis LoudnessMeter — EBU Tech 3341 conformance\n");

    for (const double sr : { 48000.0, 44100.0 })
    {
        // --- Table 1: the integrated-loudness minimum requirements, ±0.1 LU ---
        test::group (at (sr, "Tech 3341 Table 1"));

        // Case 1: 1 kHz at −23 dBFS per channel, in phase on both channels, 20 s → M, S, I = −23.0 LUFS.
        // The arithmetic behind the round number: a sine's mean square is −3.01 dB under its peak, the
        // in-phase stereo sum adds +3.01 dB back, and the K-filter's +0.69 dB at the tone is what the −0.691
        // calibration term was chosen to cancel.
        {
            const auto lm = run (sr, { { -23.0, 20.0 } }, 8192, [] (double) {});
            test::approx (lm.integratedLufs(), -23.0, 0.1, at (sr, "case 1: I = −23.0 LUFS"));
            test::approx (lm.momentaryLufs(),  -23.0, 0.1, at (sr, "case 1: M = −23.0 LUFS"));
            test::approx (lm.shortTermLufs(),  -23.0, 0.1, at (sr, "case 1: S = −23.0 LUFS"));
        }

        // Case 2: the same tone at −33 dBFS → −33.0 (linearity), again for all three.
        {
            const auto lm = run (sr, { { -33.0, 20.0 } }, 8192, [] (double) {});
            test::approx (lm.integratedLufs(), -33.0, 0.1, at (sr, "case 2: I = −33.0 LUFS"));
            test::approx (lm.momentaryLufs(),  -33.0, 0.1, at (sr, "case 2: M = −33.0 LUFS"));
            test::approx (lm.shortTermLufs(),  -33.0, 0.1, at (sr, "case 2: S = −33.0 LUFS"));
        }

        // Case 3: quiet −36 dBFS shoulders around a −23 dBFS body. The relative gate (−10 LU under the
        // absolutely-gated mean) drops the shoulders; ungated averaging would read ≈ −24.2.
        test::approx (measure (sr, { { -36.0, 10.0 }, { -23.0, 60.0 }, { -36.0, 10.0 } }), -23.0, 0.1,
                      at (sr, "case 3: the relative gate drops the −36 dBFS shoulders"));

        // Case 4: case 3 wrapped in −72 dBFS. The spec's own robustness case: −72 sits under the absolute
        // gate AND far under the relative one, so this reads −23.0 whichever gate does the dropping — the
        // absolute gate is isolated further down, where only it can make the difference.
        test::approx (measure (sr, { { -72.0, 10.0 }, { -36.0, 10.0 }, { -23.0, 60.0 }, { -36.0, 10.0 }, { -72.0, 10.0 } }),
                      -23.0, 0.1, at (sr, "case 4: the −72 dBFS tails are dropped"));

        // Case 5: −26 / −20 / −26 dBFS at 20 / 20.1 / 20 s (the spec's 20.1 is deliberate) — everything gated
        // IN (all blocks within 10 LU of the mean), power-averaging to −23.0. A meter averaging amplitude or
        // dB instead of power reads −23.5 or worse.
        test::approx (measure (sr, { { -26.0, 20.0 }, { -20.0, 20.1 }, { -26.0, 20.0 } }), -23.0, 0.1,
                      at (sr, "case 5: three levels power-average to −23.0"));
    }

    const double sr = 48000.0;

    // --- Table 1 case 6: 5.0 channels at −28 (L, R), −24 (C), −30 (Ls, Rs) dBFS with the BS.1770 weights
    //     (1.0 front, 1.41 surround — a power weight, +1.5 dB) sum to −23.0. The one case that exercises
    //     setChannelWeight; the role→channel mapping is the host's. ---
    test::group ("Tech 3341 Table 1 case 6: 5.0 channel weights");
    {
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 5, 30.0));
        lm.setChannelWeight (3, 1.41); lm.setChannelWeight (4, 1.41);
        const auto tone = [sr] (double dbfs) {
            std::vector<float> v ((std::size_t) std::llround (20.0 * sr));
            const double amp = std::pow (10.0, dbfs / 20.0);
            for (std::size_t i = 0; i < v.size(); ++i) v[i] = (float) (amp * std::sin (2.0 * core::kPi * kToneHz * (double) i / sr));
            return v;
        };
        const auto front = tone (-28.0), centre = tone (-24.0), surround = tone (-30.0);
        for (std::size_t o = 0; o < front.size(); o += 8192)
        {
            const int n = (int) std::min<std::size_t> (8192, front.size() - o);
            const float* ch[5] { front.data() + o, front.data() + o, centre.data() + o, surround.data() + o, surround.data() + o };
            felitronics::test::run (lm.process (ch, 5, n));
        }
        test::approx (lm.integratedLufs(), -23.0, 0.1, "case 6: L/R −28, C −24, Ls/Rs −30 with weights → −23.0");
    }

    // --- Table 1 cases 9 and 12: over a program periodic in exactly one window, the windowed measure is a
    //     constant once the window is full — S over (1.34 s at −20, 1.66 s at −30) × 5 after 3 s, M over
    //     (0.18 s at −20, 0.22 s at −30) × 25 after 1 s — and that constant is the power mean, −23.0. ---
    test::group ("Tech 3341 Table 1 cases 9 and 12: S and M settle on a periodic program");
    {
        Steps nine, twelve;
        for (int r = 0; r < 5; ++r)  { nine.push_back ({ -20.0, 1.34 });  nine.push_back ({ -30.0, 1.66 }); }
        for (int r = 0; r < 25; ++r) { twelve.push_back ({ -20.0, 0.18 }); twelve.push_back ({ -30.0, 0.22 }); }
        const int hop = (int) std::lround (0.1 * sr);   // read the meter once per hop, as a display would
        double lo = 0.0, hi = -200.0;
        {
            analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 60.0));
            long long idx = 0;
            for (const auto& [dbfs, seconds] : nine)
                feedSine (lm, sr, kToneHz, dbfs, seconds, idx, hop, [&] (double t) { if (t >= 3.0) { lo = std::min (lo, lm.shortTermLufs()); hi = std::max (hi, lm.shortTermLufs()); } });
            test::approx (lo, -23.0, 0.1, "case 9: S after 3 s never reads under −23.0 ± 0.1");
            test::approx (hi, -23.0, 0.1, "case 9: S after 3 s never reads over −23.0 ± 0.1");
        }
        {
            analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 60.0)); lo = 0.0; hi = -200.0;
            long long idx = 0;
            for (const auto& [dbfs, seconds] : twelve)
                feedSine (lm, sr, kToneHz, dbfs, seconds, idx, hop, [&] (double t) { if (t >= 1.0) { lo = std::min (lo, lm.momentaryLufs()); hi = std::max (hi, lm.momentaryLufs()); } });
            test::approx (lo, -23.0, 0.1, "case 12: M after 1 s never reads under −23.0 ± 0.1");
            test::approx (hi, -23.0, 0.1, "case 12: M after 1 s never reads over −23.0 ± 0.1");
        }
    }

    // --- Table 1 cases 10 and 13, the file-based S and M tests: a tone slid across the window grid in steps
    //     finer than the gating hop (150 ms for the 3 s short-term case, 20 ms for the 400 ms momentary one)
    //     must read its full level at EVERY offset, ±0.1 LU. A window that only moves in 100 ms steps misses
    //     up to 40 ms of a 400 ms burst and reads it 0.45 LU low; the meter's 10 ms sub-hop lands within
    //     one sub-hop of any offset. The meter is polled every 10 ms, as a display would at its finest. ---
    test::group ("Tech 3341 Table 1 cases 10 and 13: S and M at every offset");
    {
        const int poll = (int) std::lround (0.01 * sr);
        // (i × lead of silence, `tone` seconds at −23 dBFS, 1 s of silence): the maximum of `read` over the file.
        const auto maxOver = [&] (double lead, double tone, double (analysis::LoudnessMeter::*read)() const) {
            analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 10.0));
            std::vector<float> sig ((std::size_t) std::llround (lead * sr), 0.0f);
            const double amp = std::pow (10.0, -23.0 / 20.0);
            const auto frames = (std::size_t) std::llround (tone * sr);
            for (std::size_t i = 0; i < frames; ++i) sig.push_back ((float) (amp * std::sin (2.0 * core::kPi * kToneHz * (double) i / sr)));
            sig.insert (sig.end(), (std::size_t) sr, 0.0f);
            double best = -200.0;
            for (std::size_t o = 0; o < sig.size(); o += (std::size_t) poll)
            {
                const int n = (int) std::min<std::size_t> ((std::size_t) poll, sig.size() - o);
                const float* ch[2] { sig.data() + o, sig.data() + o };
                felitronics::test::run (lm.process (ch, 2, n));
                best = std::max (best, (lm.*read)());
            }
            return best;
        };
        double worst13 = 0.0, worst10 = 0.0;
        for (int i = 0; i < 20; ++i)
        {
            worst13 = std::max (worst13, std::fabs (maxOver (i * 0.020, 0.4, &analysis::LoudnessMeter::momentaryLufs) + 23.0));
            worst10 = std::max (worst10, std::fabs (maxOver (i * 0.150, 3.0, &analysis::LoudnessMeter::shortTermLufs) + 23.0));
        }
        test::ok (worst13 <= 0.1, "case 13: max M of a 400 ms tone at −23 dBFS reads −23.0 ± 0.1 at all twenty 20 ms offsets");
        test::ok (worst10 <= 0.1, "case 10: max S of a 3 s tone at −23 dBFS reads −23.0 ± 0.1 at all twenty 150 ms offsets");
    }

    // --- the relative gate must be computed from ALL absolutely-gated blocks, not on the fly. Loud body FIRST
    //     is the control: a running threshold set by the loud head would drop the quiet tail too. Loud body LAST
    //     is the discriminating case: a running threshold would have admitted the whole quiet head (20 s at
    //     −36 dBFS), and the ungated power mean of that program is −24.2 LUFS — outside ±0.1. ---
    test::group ("relative gate is a two-pass over the whole program");
    {
        test::approx (measure (sr, { { -23.0, 60.0 }, { -36.0, 20.0 } }), -23.0, 0.1, "loud body first → −23.0 (the quiet tail is gated out)");
        test::approx (measure (sr, { { -36.0, 20.0 }, { -23.0, 60.0 } }), -23.0, 0.1, "loud body last → −23.0 (a running threshold would read −24.2)");
    }

    // --- what cannot be measured answers −120, never a made-up number ---
    test::group ("unmeasurable input answers the −120 sentinel");
    {
        // Digital silence: blocks exist, every one of them is under the absolute gate.
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 10.0));
        std::vector<float> zeros ((std::size_t) sr, 0.0f);
        const float* ch[2] { zeros.data(), zeros.data() };
        felitronics::test::run (lm.process (ch, 2, (int) sr));
        test::ok (lm.integratedLufs() == kNone, "one second of digital silence → −120");

        // A tone wholly under the absolute gate: −80 dBFS reads −80 LUFS, below −70 — gated to nothing.
        test::ok (measure (sr, { { -80.0, 2.0 } }) == kNone, "a −80 dBFS tone (under the −70 LUFS gate) → −120");

        // 399 ms is one hop short of the first 400 ms gating block; exactly 400 ms is exactly one block — and
        // that block reads the tone, not merely something above the sentinel.
        test::ok (measure (sr, { { -23.0, 0.399 } }) == kNone, "399 ms → no block yet → −120");
        test::approx (measure (sr, { { -23.0, 0.400 } }), -23.0, 0.2, "400 ms → one block → −23.0");

        // Any real gated mean averages blocks that each passed the −70 LUFS gate, so it lies above the gate by
        // construction: the gate is the line a consumer can draw between a reading and the sentinel.
        test::approx (measure (sr, { { -69.0, 5.0 } }), -69.0, 0.1, "a −69 dBFS tone (just over the gate) reads −69.0");
    }

    // --- the absolute gate, isolated: Table 1's case 4 drops its −72 dBFS tails by the relative gate as much as
    //     by the absolute one, so a meter with no absolute gate at all passes it. Here the sub-gate part sits
    //     INSIDE the relative gate — only the absolute gate can drop it. ---
    test::group ("absolute gate at −70 LUFS, isolated from the relative gate");
    {
        // −65 dBFS body, −72 dBFS tail, equal lengths: the abs-gated mean is −65.0 and the relative gate
        // −75.0, so −72 would be kept by the relative gate — and a meter keeping it reads their mean, −67.2.
        test::approx (measure (sr, { { -65.0, 10.0 }, { -72.0, 10.0 } }), -65.0, 0.1, "−65 body + −72 tail → −65.0 (the tail is dropped by the absolute gate alone)");
        // The boundary itself: half a dB over the gate is a reading, half a dB under is the sentinel.
        test::approx (measure (sr, { { -69.5, 5.0 } }), -69.5, 0.1, "−69.5 dBFS (just over the gate) reads −69.5");
        test::ok (measure (sr, { { -70.5, 5.0 } }) == kNone, "−70.5 dBFS (just under the gate) → −120");
    }

    // --- the relative gate at −10 LU, not −8 (ATSC A/85's first edition) and not −12 ---
    test::group ("relative gate at −10 LU");
    {
        // 60 s at −23 then 10 s at −32: the abs-gated mean is −23.6 and the relative gate −33.6, so the −32
        // segment sits inside it and COUNTS — the reading is the mean of both, −23.58. At −34 the segment
        // falls outside and the reading is the body alone, −23.0. A −8 LU gate would drop both (reading −23.0
        // twice); a −12 LU gate would keep both (−23.58, then −23.61).
        test::approx (measure (sr, { { -23.0, 60.0 }, { -32.0, 10.0 } }), -23.58, 0.1, "a segment 9 LU under the body is counted → −23.58");
        test::approx (measure (sr, { { -23.0, 60.0 }, { -34.0, 10.0 } }), -23.00, 0.1, "a segment 11 LU under the body is dropped → −23.0");
    }

    // --- every channel counts, as power, in phase or not. Table 1 is dual-mono throughout, which a meter that
    //     reads one channel and adds 3 dB, or sums the samples before squaring, passes just the same. ---
    test::group ("channel handling: per-channel power, summed");
    {
        // One channel alone is the mono figure, −3.01 under the dual-mono one: −26.01. Either channel.
        test::approx (measureLayout (sr, -23.0, 10.0, Layout::leftOnly),  -26.01, 0.1, "left only → −26.01");
        test::approx (measureLayout (sr, -23.0, 10.0, Layout::rightOnly), -26.01, 0.1, "right only → −26.01");
        // Anti-phase stereo carries the same power as in-phase: a meter summing samples before squaring
        // would read silence.
        test::approx (measureLayout (sr, -23.0, 10.0, Layout::antiPhase), -23.0, 0.1, "L = −R → −23.0 (power, not a sample sum)");
        // A mono meter is the single-channel figure.
        test::approx (measureLayout (sr, -23.0, 10.0, Layout::mono), -26.01, 0.1, "mono → −26.01");
    }

    // --- the K in K-weighting, at both rates. Table 1 sits at the one frequency where the K-filter's gain and
    //     the −0.691 calibration cancel, so a flat meter passes all of it; away from 1 kHz the shape shows.
    //     Expected readings come from BS.1770-4's PUBLISHED 48 kHz coefficient table, evaluated analytically
    //     at the tone: |K| = −2.899 dB at 60 Hz (the RLB high-pass), +4.039 dB at 8 kHz (the shelf); a
    //     −23 dBFS dual-mono tone therefore reads −23 + |K| − 0.691. The 44.1 kHz design differs from the
    //     48 kHz table by under 0.005 dB at these tones. ---
    for (const double rate : { 48000.0, 44100.0 })
    {
        test::group (at (rate, "K-weighting shapes the reading"));
        analysis::LoudnessMeter hi; felitronics::test::run (hi.prepare (rate, 2, 20.0));
        long long n1 = 0; feedSine (hi, rate, 8000.0, -23.0, 10.0, n1);
        test::approx (hi.integratedLufs(), -19.65, 0.15, at (rate, "8 kHz at −23 dBFS reads −19.65 (the shelf's +4.04 dB)"));

        analysis::LoudnessMeter lo; felitronics::test::run (lo.prepare (rate, 2, 20.0));
        long long n2 = 0; feedSine (lo, rate, 60.0, -23.0, 10.0, n2);
        test::approx (lo.integratedLufs(), -26.59, 0.15, at (rate, "60 Hz at −23 dBFS reads −26.59 (the high-pass's −2.90 dB)"));
    }

    // --- 400 ms blocks at a 100 ms hop: steady tones cannot tell 75 % overlap from none, a burst can ---
    test::group ("block overlap: a burst tells 75 % from none");
    {
        // 200 ms of −20 dBFS tone from 300 ms to 500 ms in one second of silence, hop-aligned. Five
        // overlapping 400 ms blocks touch it, holding 1/4, 1/2, 1/2, 1/2 and 1/4 of a full block's power; the
        // silent blocks fall under the absolute gate and the relative gate (−10 LU under the mean) keeps all
        // five, so the reading is the tone −10·log10(0.4) = −3.98 LU: −23.98. Non-overlapping blocks would
        // hold 1/4 and 1/4 and read −6.02 LU under: −26.02.
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 10.0));
        std::vector<float> sig ((std::size_t) sr, 0.0f);
        const double amp = std::pow (10.0, -20.0 / 20.0);
        for (std::size_t i = (std::size_t) (0.3 * sr); i < (std::size_t) (0.5 * sr); ++i)
            sig[i] = (float) (amp * std::sin (2.0 * core::kPi * kToneHz * (double) (i - (std::size_t) (0.3 * sr)) / sr));
        for (std::size_t o = 0; o < sig.size(); o += 4097)
        {
            const int n = (int) std::min<std::size_t> (4097, sig.size() - o);
            const float* ch[2] { sig.data() + o, sig.data() + o };
            felitronics::test::run (lm.process (ch, 2, n));
        }
        test::approx (lm.integratedLufs(), -20.0 - 3.98, 0.3, "a 200 ms burst reads the tone −3.98 LU (five overlapping blocks)");
    }

    // --- chunking must not matter: one call vs odd-sized pieces straddling every hop ---
    test::group ("chunk invariance");
    {
        analysis::LoudnessMeter one;  felitronics::test::run (one.prepare (sr, 2, 20.0));
        analysis::LoudnessMeter many; felitronics::test::run (many.prepare (sr, 2, 20.0));
        long long a = 0, b = 0;
        feedSine (one,  sr, kToneHz, -23.0, 5.0, a, 240000);   // one call
        feedSine (many, sr, kToneHz, -23.0, 5.0, b, 4097);     // odd chunks, straddling hops
        test::approx (many.integratedLufs(), one.integratedLufs(), 1e-9, "the same stream in 4097-frame pieces reads identically");
        test::approx (many.momentaryLufs(),  one.momentaryLufs(),  1e-9, "momentary too");
    }

    // --- ...and BIT-exact, not merely close: a comparison of this meter across toolchains or call patterns
    //     leans on it. The measurement probe's suite (felitronics-mastering-core's ProbeTests) pins the same
    //     property through the probe, from call sizes 1 to 100 003; the meter's own suite pins it here, on
    //     every pre-gate block energy and the integrated and momentary readings as bit patterns. ---
    test::group ("chunk invariance is BIT-exact: every pre-gate block energy, at every call size");
    {
        struct Reading { std::vector<std::uint64_t> blocks; std::uint64_t integrated = 0, momentary = 0; };
        auto measure = [&] (int chunk)
        {
            analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 20.0));
            long long idx = 0;
            feedSine (lm, sr, kToneHz, -20.0, 2.0, idx, chunk);
            feedSine (lm, sr, kToneHz, -35.0, 1.5, idx, chunk);   // a level step, so the gates have work to do
            Reading r;
            for (const double e : lm.gatingBlockEnergies()) r.blocks.push_back (std::bit_cast<std::uint64_t> (e));
            r.integrated = std::bit_cast<std::uint64_t> (lm.integratedLufs());
            r.momentary  = std::bit_cast<std::uint64_t> (lm.momentaryLufs());
            return r;
        };
        const Reading whole = measure (1 << 20);
        test::ok (whole.blocks.size() > 30, "PRECONDITION: the programme produced a meaningful number of gating blocks ("
                                            + std::to_string (whole.blocks.size()) + ")");
        for (const int chunk : { 1, 7, 999, 4096, 8192, 8193, 100003 })
        {
            const Reading r = measure (chunk);
            test::ok (r.blocks == whole.blocks && r.integrated == whole.integrated && r.momentary == whole.momentary,
                      "chunk " + std::to_string (chunk) + " gives the same block energies and readings, bit for bit");
        }
    }

    // --- the pre-gate block energies are exposed so a cross-toolchain check can compare a quantity that is
    //     CONTINUOUS in the input (the gated reading jumps when a block crosses a threshold). They are only
    //     worth exposing if they are genuinely what the reading is computed from — so re-derive BS.1770's
    //     two-pass gating from the vector alone and null it against the meter's own answer ---
    test::group ("gating block energies: the exposed vector re-derives the gated reading");
    {
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 60.0));
        long long idx = 0;
        feedSine (lm, sr, kToneHz, -20.0, 3.0, idx);
        feedSine (lm, sr, kToneHz, -35.0, 3.0, idx);           // quiet enough for the relative gate to drop it

        const auto e = lm.gatingBlockEnergies();
        const int    n = (int) e.size();
        test::ok (n == 57, "6 s → one 400 ms block per 100 ms hop, the first at 400 ms (60 hops less 3)");
        test::ok (e.size() == (std::size_t) n && ! e.empty(), "the span carries exactly the recorded blocks");

        const double absT = std::pow (10.0, (-70.0 + 0.691) / 10.0);        // energy for −70 LUFS
        double s1 = 0.0; int c1 = 0;
        for (int j = 0; j < n; ++j) if (e[(std::size_t) j] > absT) { s1 += e[(std::size_t) j]; ++c1; }
        test::ok (c1 > 0, "the absolute gate kept something to average");
        const double relT = 0.1 * (s1 / (double) c1);                        // −10 LU relative to the abs-gated mean
        double s2 = 0.0; int c2 = 0;
        for (int j = 0; j < n; ++j)
        {
            const double z = e[(std::size_t) j];
            if (z > absT && z > relT) { s2 += z; ++c2; }
        }
        test::ok (c2 > 0 && c2 < c1, "the relative gate dropped the quiet stretch — so this is not a vacuous null");
        test::approx (-0.691 + 10.0 * std::log10 (s2 / (double) c2), lm.integratedLufs(), 1e-12,
                      "gating re-derived from the vector alone nulls the meter's own integrated reading");
    }

    // --- lifecycle: the vector is empty before prepare() and again after reset(), so a harness cannot read
    //     a stale block from a previous run ---
    test::group ("gating block energies: empty before prepare, cleared by reset");
    {
        analysis::LoudnessMeter fresh;
        test::ok (fresh.gatingBlockCount() == 0, "no blocks before prepare()");
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 20.0));
        test::ok (lm.gatingBlockCount() == 0, "none straight after prepare() either");
        long long idx = 0;
        feedSine (lm, sr, kToneHz, -23.0, 2.0, idx);
        test::ok (lm.gatingBlockCount() == 17, "2 s of program → 17 blocks");
        lm.reset();
        test::ok (lm.gatingBlockCount() == 0, "reset() clears the count");
    }

    // --- the headline RT claim: process() allocates nothing, through hops, blocks and short-term samples ---
    test::group ("process() does not allocate");
    {
        analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 10.0));
        std::vector<float> l (4800, 0.3f), r (4800, -0.2f);
        const float* io[2] { l.data(), r.data() };
        felitronics::test::run (lm.process (io, 2, 4800));                                   // warm: the first hop
        const long long before = alloc::count.load();
        for (int i = 0; i < 40; ++i) felitronics::test::run (lm.process (io, 2, 4800));     // 4 s: hops, blocks and short-term samples all fire
        const bool noAlloc = (alloc::count.load() == before);
        test::okNoAlloc (noAlloc, "40 hops of process() did not allocate");
        test::ok (std::isfinite (lm.integratedLufs()), "and the meter still reads");
    }

    // --- the stated capacity holds a program of exactly that length at any rate, and a longer one is counted,
    //     not silently truncated ---
    test::group ("maxDurationSec: sized by the hop cadence, overflow reported");
    {
        // Exactly the stated length keeps every block and reads as an uncapped meter — at 22.05 kHz too,
        // where 0.01·fs rounds and the hop is 2210 samples rather than a true 100 ms, so a store sized in
        // seconds would not match the blocks that arrive.
        for (const double rate : { 48000.0, 44100.0, 22050.0 })
        {
            analysis::LoudnessMeter tight; felitronics::test::run (tight.prepare (rate, 2, 3.0));
            analysis::LoudnessMeter roomy; felitronics::test::run (roomy.prepare (rate, 2, 60.0));
            long long a = 0, b = 0;
            feedSine (tight, rate, kToneHz, -20.0, 3.0, a);
            feedSine (roomy, rate, kToneHz, -20.0, 3.0, b);
            test::ok (tight.droppedBlocks() == 0, "3 s of capacity keeps every block of 3 s of program");
            test::approx (tight.integratedLufs(), roomy.integratedLufs(), 1e-9, "and reads as the uncapped meter");
        }
        // Past it the surplus is counted: 5 s into 3 s of capacity at 48 kHz — the store holds 30 + 4 = 34
        // blocks, 5 s produce 47 (50 hops less the 3 before the first block), 13 are dropped — and the
        // reading still stands, over the blocks that were kept.
        {
            analysis::LoudnessMeter lm; felitronics::test::run (lm.prepare (sr, 2, 3.0));
            long long n = 0; feedSine (lm, sr, kToneHz, -20.0, 5.0, n);
            test::ok (lm.droppedBlocks() == 13, "5 s into 3 s of capacity → 13 blocks reported dropped");
            test::approx (lm.integratedLufs(), -20.0, 0.1, "the kept blocks still read the tone");
            lm.reset();
            test::ok (lm.droppedBlocks() == 0, "reset clears the count");
        }
        // K12 — THE RANGE HAS ITS OWN STORE AND ITS OWN OVERFLOW, and until this group nothing said so. The
        // counter above was documented as covering loudnessRangeLu() as well; it does not, and the two do not
        // even overflow together. Block store: capacity floor(hops) + 4 against a production of floor(hops) - 3,
        // so slack 7. Short-term store: capacity ceil(hops) + 8 against floor(hops) - 29, so slack 37. Blocks
        // always go first, by thirty hops, and between the two thresholds one counter climbs while the other
        // answer is still whole.
        //
        // MEASURED IN HOPS, NOT SECONDS, and that is not pedantry — the first draft of this group asked for
        // "3.8 s past" and got 1 622 399 samples at 48 kHz where it meant 1 622 400, which is one hop short and
        // put the threshold on the wrong side. A hop is 10·lround(0.01·fs) samples; every length below is an
        // exact multiple of one, so the thresholds are integers and the same integers at both rates.
        {
            // `spare` is the extra SAMPLE that makes the declared length a fractional number of hops. It moves
            // the short-term threshold by one and the block threshold not at all — capacity is ceil(hops) + 8
            // against floor(hops) + 4 — so a grid of whole hops alone would never exercise the ceiling.
            for (const double rate : { 48000.0, 44100.0 })
                for (const long long declHops : { 300LL, 73LL })
                    for (const long long spare : { 0LL, 1LL })
                {
                    const long long hop = 10LL * std::llround (0.01 * rate);
                    const long long stGoes = 38 + spare;          // 38 at whole hops, 39 with the extra sample
                    struct Row { long long over; bool wantBlk; bool wantSt; };
                    // 7 hops over: the block store is exactly full. 8: it goes. One short of stGoes the
                    // short-term store is exactly full, blocks long gone. At stGoes it goes too.
                    const Row rows[] = { { 0, false, false }, { 7, false, false }, { 8, true, false },
                                         { stGoes - 1, true, false }, { stGoes, true, true } };
                    for (const Row& r : rows)
                    {
                        analysis::LoudnessMeter m;
                        if (! felitronics::test::run (m.prepareForSamples (rate, 2, (double) (declHops * hop + spare)))) continue;
                        long long fed = 0;
                        feedSine (m, rate, kToneHz, -20.0, (double) ((declHops + r.over) * hop) / rate, fed);
                        const std::string where = std::to_string ((int) rate) + " Hz, " + std::to_string (declHops)
                                                + " hops + " + std::to_string (spare) + " declared, "
                                                + std::to_string (r.over) + " over";
                        const bool blk = m.droppedBlocks() > 0, st = m.droppedShortTermSamples() > 0;
                        test::ok (blk == r.wantBlk && st == r.wantSt,
                                  where + ": blocks dropped " + std::to_string (m.droppedBlocks())
                                        + ", short-term dropped " + std::to_string (m.droppedShortTermSamples()));
                        // AND THE ORDERING ITSELF, which is the property rather than the two numbers: the
                        // range's store never overflows first. This is what fails if one capacity formula is
                        // changed without the other, at any rate and any declared length.
                        test::ok (! (st && ! blk),
                                  where + ": the range's store did not overflow before the block store");
                    }
                }
            // reset() clears it, like every other exposure — a counter that survives a reset reports the
            // previous programme's damage against this one's numbers.
            analysis::LoudnessMeter m;
            if (felitronics::test::run (m.prepare (sr, 2, 5.0)))
            {
                long long fed = 0;
                feedSine (m, sr, kToneHz, -20.0, 20.0, fed);
                test::ok (m.droppedShortTermSamples() > 0, "far past the capacity the range's store is counted too ("
                          + std::to_string (m.droppedShortTermSamples()) + " dropped)");
                m.reset();
                test::ok (m.droppedShortTermSamples() == 0, "and reset clears it");
            }
        }
    }

    // --- P41: the store is sized by ONE function, in samples, and that function is TOTAL ---
    test::group ("storageFor: one sizing function, in samples, refusing what it cannot represent");
    {
        using M = analysis::LoudnessMeter;
        const double inf = std::numeric_limits<double>::infinity();
        const double nan = std::numeric_limits<double>::quiet_NaN();
        M::Storage s;
        // Every one of these used to reach a float-to-size_t conversion out of range, or an out-of-range lround.
        test::ok (! M::storageFor (48000.0, inf, s),     "+inf samples: refused");
        test::ok (! M::storageFor (48000.0, nan, s),     "NaN samples: refused");
        test::ok (! M::storageFor (48000.0, -1.0, s),    "negative samples: refused");
        test::ok (! M::storageFor (48000.0, 1.0e300, s), "a finite count past the int block index: refused");
        test::ok (! M::storageFor (inf, 1000.0, s),      "an infinite rate: refused");
        test::ok (! M::storageFor (3.0e10, 1000.0, s),   "a rate whose hop does not fit an int: refused");
        test::ok (s.blocks == 0 && s.shortTerm == 0,     "and a refusal leaves `out` untouched");
        // A rate <= 0 or NaN is read as 48 kHz, as prepare() reads it — the budget of a call is storageFor() with the
        // SAME arguments. (The diverse-testing round: it used to refuse what prepare() sizes at 48 kHz.)
        M::Storage z, zn, ref;
        test::ok (M::storageFor (0.0, 1000.0, z) && M::storageFor (std::numeric_limits<double>::quiet_NaN(), 1000.0, zn)
                  && M::storageFor (48000.0, 1000.0, ref) && z.bytes() == ref.bytes() && zn.bytes() == ref.bytes()
                  && z.subSamples == 480, "a zero or NaN rate is sized at 48 kHz, as prepare() sizes it");
        // The rate bound IS the property, taken on the computed 0.01·fs: a round number short of it refused rates the
        // old code handled without UB (the code-review round: 21 GHz), and a bound on fs itself admits a rate whose
        // 0.01·fs rounds UP to .5 at the edge.
        M::Storage s2;
        test::ok (M::storageFor (21474836449.0, 1000.0, s2) && s2.subSamples == 214748364,
                  "21474836449 Hz: its hop still fits an int — accepted, sub-hop 214748364");
        test::ok (! M::storageFor (21474836450.0, 1000.0, s2), "21474836450 Hz: 0.01·fs is .5 over — refused");
        M lmRate;
        test::ok (lmRate.prepare (2.1e10, 1, 1.0e-6), "prepare(21 GHz, 1 µs) is accepted, as it always was");

        // K12 — THE LENGTH BOUND BELONGS TO THE TIGHTER STORE, and it used to be written for the looser one.
        // `blocks` is floor(hops) + 4 and `shortTerm` is ceil(hops) + 8, so a bound of INT_MAX - 4 kept the
        // block index in an int and handed the short-term store a capacity of INT_MAX + 4. Then
        // `stCount < (int) stE.size()` compares against a NARROWED value — negative — and every short-term
        // sample is refused from the first one onward, while droppedBlocks() still reads 0: a range of 0.0 LU
        // presented as a measurement. Nothing allocates here; storageFor() is arithmetic, and arithmetic is
        // where a bound is wrong or right. 4800 samples is a hop at 48 kHz, so the length is exact in a double.
        {
            constexpr double kHop = 4800.0;                       // 10 · lround (0.01 · 48000)
            const double atBound  = 2147483639.0 * kHop;          // hops = INT_MAX - 8
            const double overIt   = 2147483640.0 * kHop;          // one hop more
            M::Storage edge, past;
            const bool tookIt = M::storageFor (48000.0, atBound, edge);
            test::ok (tookIt && edge.shortTerm == (std::size_t) std::numeric_limits<int>::max()
                             && edge.blocks    == (std::size_t) std::numeric_limits<int>::max() - 4,
                      "the longest accepted programme sizes the short-term store at exactly INT_MAX ("
                      + std::to_string (edge.shortTerm) + ") and the block store below it");
            test::ok (edge.shortTerm <= (std::size_t) std::numeric_limits<int>::max(),
                      "…so (int) stE.size() is the capacity and not a negative");
            test::ok (! M::storageFor (48000.0, overIt, past), "and one hop past it is refused");
        }

        // P41 F1, RE-HOMED TWICE (P51, P103). The solver sizes the meter behind a solve in SAMPLES, because `frames / fs`
        // seconds was +inf at an absurd finite rate and the store used to be `(std::size_t) inf` — 3 kept blocks on arm64
        // and wasm32, 4 on x86-64 gcc, for one call. It was pinned by a solve at 1e-305 Hz (refused by the search since
        // P51), then by this meter at that rate — which the meter itself refuses since P103 (the group below). At the
        // floor the seconds form is finite and a trip through it costs nothing: ceil((n / 8000) · 8000) is never below
        // n (checked over four million n), so there is no rounding witness left to pin. What is left is the capacity the
        // solver asks for, at the floor — it holds the programme — and +inf seconds, refused rather than converted.
        {
            const double fs = M::kMinSampleRate;
            const int frames = 160000;                      // 200 hops of 800 samples
            M byTime;
            test::ok (! byTime.prepare (fs, 1, inf), "at the floor, in seconds (+inf): refused, not converted");
            M bySamples;
            test::ok (bySamples.prepareForSamples (fs, 1, (double) frames + std::ceil (fs)),
                      "at the floor, in samples, frames + ceil(fs) — the solver's own capacity: accepted");
            std::vector<float> x ((std::size_t) frames);
            for (int i = 0; i < frames; ++i) x[(std::size_t) i] = (i & 1) ? 0.25f : -0.25f;
            const float* xp[1] { x.data() };
            test::run (bySamples.process (xp, 1, frames));
            // 80-sample sub-hops: 160000 samples are 200 hops, and the first block is born on the 4th — 197 blocks
            test::ok (bySamples.droppedBlocks() == 0 && bySamples.gatingBlockCount() == 197,
                      "and it holds all 197 blocks the programme produces (dropped "
                      + std::to_string (bySamples.droppedBlocks()) + ")");
        }

        M lm;
        test::ok (! lm.prepare (48000.0, 2, inf),        "prepare(+inf s): REFUSED — it used to convert inf to size_t");
        test::ok (! lm.prepare (48000.0, 2, 1.0e300),    "prepare(1e300 s): REFUSED");
        test::ok (! lm.prepareForSamples (48000.0, 2, inf), "prepareForSamples(+inf): REFUSED");
        // What did NOT change: a NaN or negative duration still reads as 0 s and is accepted.
        felitronics::test::run (lm.prepare (48000.0, 2, nan));
        felitronics::test::run (lm.prepare (48000.0, 2, -5.0));

        // THE ORACLE IS A TABLE, on purpose (the one place a restatement is mandatory): prepare() and a caller's
        // budget both READ storageFor(), so a check of one against the other cannot move when storageFor's own
        // arithmetic does. Each row is derived by hand from `s = max(1, lround(0.01·fs))`, `hops = ⌈n⌉/(10·s)`,
        // blocks = ⌊hops⌋ + 4, shortTerm = ⌈hops⌉ + 8, bytes = 8·(300 + blocks + shortTerm). `shortTerm` was
        // ⌊hops/10⌋ + 8 until K12: the short-term cadence is one sample per HOP now, ten times as many, which
        // is what EBU Tech 3342 §3.1 requires. Every row below is re-derived by hand from the new formula
        // rather than copied from a run — that is the whole point of a table nobody can satisfy by editing
        // one number:
        struct Row { double fs, n; int s; std::size_t blocks, shortTerm; std::uint64_t bytes; };
        // (Since P103 the rows sit at 8000 Hz and up, with the same block counts they had at 150, 149 and 100 Hz. The
        // plateau `max(1, ·)` is out of reach now: the smallest sub-hop an accepted rate has is 80 samples, and a rate
        // <= 0 reads as 48 kHz.)
        const Row rows[] = {
            { 48000.0,    480000.0, 480,    104,    108,     4096 },   // hops 100
            { 44100.0,    441000.0, 441,    104,    108,     4096 },   // hops 100
            { 22050.0,    220500.0, 221,    103,    108,     4088 },   // lround(220.5) = 221, hops 99.77 → ⌈⌉ 100
            {  8050.0,     60750.0,  81,     79,     83,     3696 },   // lround(80.5) = 81, hops 75
            {  8049.0,        80.0,  80,      4,      9,     2504 },   // lround(80.49) = 80, hops 0.1 → ⌈⌉ 1
            {  8000.0, 288000000.0,  80, 360004, 360008,  5762496 },   // the floor: hops 360000
        };
        for (const Row& r : rows)
        {
            M::Storage t;
            const bool okay = M::storageFor (r.fs, r.n, t);
            test::ok (okay && t.subSamples == r.s && t.blocks == r.blocks && t.shortTerm == r.shortTerm && t.bytes() == r.bytes,
                      "storageFor(" + std::to_string ((long long) r.fs) + " Hz, " + std::to_string ((long long) r.n)
                      + ") is the hand-derived row");
        }

        // THE COUNTER'S OWN RULE, checked where it is relied on: vectors just under the STL's big-block threshold, at
        // it, and far above it count as exactly the bytes they asked for. On MSVC's STL that is its pad being taken
        // off — the pad differs between Release and _DEBUG and between x86 and x64 — and everywhere else it is
        // operator new being asked for exactly that. Literal sizes, not the counter's own constants.
        for (const std::size_t n : { std::size_t { 4095 }, std::size_t { 4096 }, std::size_t { 4097 }, std::size_t { 1 } << 20 })
        {
            const long long got = vectorRequest (n);
            test::ok (got == (long long) n, "the byte counter counts a " + std::to_string (n) + "-byte vector as "
                                            + std::to_string (n) + " bytes (read " + std::to_string (got) + ")");
        }

        // THE ALLOCATION IS THE FORMULA: a fresh meter allocates exactly storageFor(...).bytes(), counted by this
        // file's own operator new — and the seconds form is the same store as the samples form.
        // The delta is read into a local BEFORE the check: a call's arguments are evaluated in an unspecified
        // order, and the message is a std::string that allocates. gcc builds it first — measured on the Debian
        // row, where reading the counter inside the call counted the message's own bytes and failed all 12.
        for (const Row& r : rows)
        {
            M a;
            const long long before = alloc::bytes.load();
            felitronics::test::run (a.prepareForSamples (r.fs, 2, r.n));
            const long long got = alloc::bytes.load() - before;
            test::ok (got == (long long) r.bytes,
                      "prepareForSamples(" + std::to_string ((long long) r.fs) + " Hz) allocates exactly the formula");
            M b;
            const long long before2 = alloc::bytes.load();
            felitronics::test::run (b.prepare (r.fs, 2, r.n / r.fs));
            const long long got2 = alloc::bytes.load() - before2;
            test::ok (got2 == (long long) r.bytes, "and the seconds form allocates the same store");
        }

        // THE BOUNDARY FIXTURE: a store sized for EXACTLY n samples, fed exactly n, at the lengths that straddle
        // a hop — k·hop − 1, k·hop, k·hop + 1. The precondition is the claim itself (nothing dropped), and the
        // fixture is live (blocks were produced). Only an OVERFEED can see the +4 margin (the group above); here
        // the margin is invisible by construction, which is what the stand measured.
        for (const double rate : { 48000.0, 44100.0, 22050.0 })
        {
            const long long hop = 10LL * std::lround (0.01 * rate);
            const int want[3] = { 36, 37, 37 };
            for (int d = -1; d <= 1; ++d)
            {
                const long long n = 40 * hop + d;
                M m;
                felitronics::test::run (m.prepareForSamples (rate, 2, (double) n));
                std::vector<float> buf (4096);
                const float* ch[2] { buf.data(), buf.data() };
                long long done = 0, idx = 0;
                while (done < n)
                {
                    const int k = (int) std::min<long long> (4096, n - done);
                    for (int i = 0; i < k; ++i) buf[(std::size_t) i] = (float) (0.1 * std::sin (2.0 * core::kPi * kToneHz * (double) idx++ / rate));
                    felitronics::test::run (m.process (ch, 2, k));
                    done += k;
                }
                test::ok (m.droppedBlocks() == 0 && m.gatingBlockCount() == want[d + 1],
                          "a store of exactly 40·hop" + std::string (d < 0 ? "-1" : d > 0 ? "+1" : "")
                          + " samples keeps every block it is fed (" + std::to_string (want[d + 1]) + ")");
            }
        }
    }

    // --- P103: the meter's own rate floor, and a refusal that leaves nothing of the previous programme ---
    test::group ("P103: a rate in (0, 8000) Hz is refused, a rate <= 0 is still 48 kHz, and a refusal disarms");
    {
        using M = analysis::LoudnessMeter;
        const double inf = std::numeric_limits<double>::infinity();
        const double nan = std::numeric_limits<double>::quiet_NaN();
        test::ok (M::kMinSampleRate == 8000.0, "the floor is 8000 Hz — a literal pin");

        // What a never-prepared meter answers, bit for bit — the reference every refusal is held to.
        auto bits = [] (double v) { std::uint64_t u = 0; std::memcpy (&u, &v, sizeof u); return u; };
        auto sameAsFresh = [&] (const M& m) {
            const M fresh;
            return bits (m.momentaryLufs())  == bits (fresh.momentaryLufs())
                && bits (m.shortTermLufs())  == bits (fresh.shortTermLufs())
                && bits (m.integratedLufs()) == bits (fresh.integratedLufs())
                && bits (m.loudnessRangeLu()) == bits (fresh.loudnessRangeLu())
                && m.droppedBlocks() == fresh.droppedBlocks() && m.nonFiniteSubHops() == fresh.nonFiniteSubHops()
                && m.gatingBlockCount() == fresh.gatingBlockCount()
                // K12's two readings belong in this list. A list that omits an exposure certifies the ones it
                // names and says nothing about the rest, which is the shape of every stale-state defect.
                && m.shortTermCount() == fresh.shortTermCount()
                && m.droppedShortTermSamples() == fresh.droppedShortTermSamples()
                && m.gatingBlockEnergies().size() == fresh.gatingBlockEnergies().size();
        };
        // A previous programme that leaves EVERY reading non-trivial: 14 s of tone into 10 s of capacity, one
        // NaN sample in it (a poisoned sub-hop), the last 400 ms loud (momentary).
        //
        // FOURTEEN, WHERE TWELVE STOOD. Twelve dropped gating blocks but NOT short-term samples — the block
        // store's slack is 7 hops and the short-term store's 38, so 12 s into 10 s (20 hops over) is past one
        // threshold and short of the other. `droppedShortTermSamples()` would have been compared at 0 against a
        // fresh meter's 0: in the list, and dead. 40 hops over puts it at 3.
        auto played = [&] () {
            M m;
            felitronics::test::run (m.prepare (48000.0, 2, 10.0));
            long long idx = 0;
            feedSine (m, 48000.0, kToneHz, -30.0, 7.0, idx);
            std::vector<float> bad (480, 0.1f);
            bad[7] = std::numeric_limits<float>::quiet_NaN();
            const float* bp[2] { bad.data(), bad.data() };
            felitronics::test::run (m.process (bp, 2, 480));
            feedSine (m, 48000.0, kToneHz, -20.0, 7.0, idx);
            return m;
        };
        {
            const M m = played();
            test::ok (! sameAsFresh (m) && m.droppedBlocks() > 0 && m.nonFiniteSubHops() > 0 && m.gatingBlockCount() > 0
                      && m.shortTermCount() > 0 && m.droppedShortTermSamples() > 0
                      && std::isfinite (m.integratedLufs()) && m.loudnessRangeLu() > 0.0,
                      "PRECONDITION: the previous programme is readable through every reading (dropped "
                      + std::to_string (m.droppedBlocks()) + ", non-finite " + std::to_string (m.nonFiniteSubHops()) + ")");
        }

        struct Bad { double fs; int nch; double samples; const char* what; };
        const Bad bad[] {
            { 7999.0,                       2, 48000.0, "7999 Hz" },
            { std::nextafter (8000.0, 0.0), 2, 48000.0, "one ulp under 8000 Hz" },
            { 3300.0,                       2, 48000.0, "3300 Hz, where the shelf is unstable" },
            { 44.1,                         2, 48000.0, "44.1 — kilohertz passed as hertz" },
            { 1.0e-300,                     2, 48000.0, "1e-300 Hz" },
            { 5.0e-324,                     2, 48000.0, "the smallest subnormal" },
            { inf,                          2, 48000.0, "+inf" },
            { 48000.0,                      0, 48000.0, "zero channels (an old refusal)" },
            { 48000.0, core::kMaxChannels + 1, 48000.0, "one channel too many (an old refusal)" },
            { 48000.0,                      2, inf,     "+inf samples (an old refusal)" },
        };
        for (const Bad& b : bad)
        {
            M m = played();
            test::ok (! m.prepareForSamples (b.fs, b.nch, b.samples), std::string ("refused: ") + b.what);
            test::ok (sameAsFresh (m), std::string ("and every reading is a fresh meter's: ") + b.what);
            std::vector<float> z (480, 0.25f);
            const float* zp[2] { z.data(), z.data() };
            test::ok (! m.process (zp, 2, 480), std::string ("and process() is refused: ") + b.what);
            M byTime = played();
            test::ok (! byTime.prepare (b.fs, b.nch, b.samples / 48000.0) && sameAsFresh (byTime),
                      std::string ("the seconds form says the same, and disarms too: ") + b.what);
            if (b.nch == 2 && std::isfinite (b.samples))
            {
                M::Storage st;
                test::ok (! M::storageFor (b.fs, b.samples, st), std::string ("storageFor agrees: ") + b.what);
            }
        }

        // ACCEPTED: the floor and above as themselves; a rate that is NOT GIVEN — <= 0, NaN — as 48 kHz, which is the
        // published default and is left alone. "Read as 48 kHz" is checked on the readings, not only on the store: the
        // same programme measures bit-identically on a meter prepared at 48000.
        long long ref0 = 0;
        M ref;
        felitronics::test::run (ref.prepare (48000.0, 2, 10.0));
        feedSine (ref, 48000.0, 997.0, -18.0, 4.0, ref0);
        struct Good { double fs; bool as48k; const char* what; };
        const Good good[] {
            { 8000.0,                        false, "8000 Hz, the floor itself" },
            { std::nextafter (8000.0, 1e9),  false, "one ulp over the floor" },
            { 0.0,                           true,  "0 — not given" },
            { -0.0,                          true,  "-0 — not given" },
            { -48000.0,                      true,  "a negative rate — not given" },
            { -inf,                          true,  "-inf — not given" },
            { nan,                           true,  "NaN — not given" },
        };
        for (const Good& g : good)
        {
            M m = played();
            M::Storage st;
            test::ok (m.prepareForSamples (g.fs, 2, 480000.0) && M::storageFor (g.fs, 480000.0, st),
                      std::string ("accepted, and storageFor agrees: ") + g.what);
            if (! g.as48k) continue;
            long long i0 = 0;
            feedSine (m, 48000.0, 997.0, -18.0, 4.0, i0);
            test::ok (st.subSamples == 480 && bits (m.integratedLufs()) == bits (ref.integratedLufs())
                          && bits (m.momentaryLufs()) == bits (ref.momentaryLufs()),
                      std::string ("and it measures as 48 kHz, bit for bit: ") + g.what);
        }
    }

    tech3342MinimumRequirements();
    theShortTermCadenceIsTenHertz();
    theCadenceIsMeasuredOnAWindowLengthEnvelope();
    return test::report();
}
