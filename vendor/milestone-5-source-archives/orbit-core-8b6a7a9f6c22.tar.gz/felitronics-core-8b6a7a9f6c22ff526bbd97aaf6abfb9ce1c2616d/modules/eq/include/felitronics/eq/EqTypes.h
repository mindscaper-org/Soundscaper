// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <bit>
#include <cstddef>
#include <cstdint>

// felitronics::eq base types (FilterType, Lane, LaneParams, BandParams) + the module's internal ALIAS
// HUB: it pulls the cross-module names the eq engine uses — kMaxChannels + kPi + Smoother
// (felitronics::core) and SpectrumTap (felitronics::analysis) — into felitronics::eq, so the
// MatchedBiquad/Svf/EqBand/EqEngine bodies migrated from TabbyEQ's teq:: sources stay byte-identical
// (they reference these unqualified). The SSOT kMaxChannels lives in felitronics::core (see Config.h).
#include <felitronics/core/Config.h>
#include <felitronics/core/Math.h>
#include <felitronics/core/Smoother.h>
#include <felitronics/analysis/SpectrumTap.h>

namespace felitronics::eq
{

// --- internal alias hub (see the header note) ---
using felitronics::core::kMaxChannels;
using felitronics::core::kPi;
using felitronics::core::Smoother;
using felitronics::analysis::SpectrumTap;

enum class FilterType
{
    Bell,        // peaking, gainDb + Q
    LowShelf,    // gainDb (Butterworth slope, Q ignored)
    HighShelf,   // gainDb (Butterworth slope, Q ignored)
    HighPass,    // Q at 12 dB/oct; 24 dB/oct is Butterworth (Q ignored)
    LowPass,     // Q at 12 dB/oct; 24 dB/oct is Butterworth (Q ignored)
    BandPass,    // unity gain at centre; Q = overall −3 dB bandwidth (order-INVARIANT), skirt
                 // steepness by slope (order = slope/6; slope 6/12 = the frozen single matched
                 // band-pass, bit-for-bit). Near Nyquist CENTRE UNITY WINS: the true peak may read
                 // up to ~+0.29 dB just off f0 — matched::bandpassCascade's documented trade
    Notch,       // band-stop: deep null at f0, unity at DC; width by Q, steepness by slope. Toward
                 // Nyquist it tracks the analog Butterworth band-stop residual (a wide/high notch
                 // legitimately reads below 0 dB at fs/2; slope 6/12 = the frozen single notch,
                 // which under-shoots that residual — see matched::notch)
    AllPass,     // flat magnitude, 360° phase rotation through f0 (Q = sharpness)
    Tilt         // spectral tilt about f0: lows -gainDb, highs +gainDb; slope 6 = first-order shelves
};

// Placement lanes (Pro-Q-style, but multi-select — a point may live in several at once). The fixed
// enum order IS the processing order (ST first), which the engine, the analytic 2×2 matrix and the FIR
// builder all compose in — see EqBand::process / matrixResponse. `kNumLanes` is the SSOT count.
enum class Lane : std::uint8_t { Stereo, Left, Right, Mid, Side };
inline constexpr int kNumLanes = 5;

// One placement lane's full parameter set. The point's `type`/`swept` are SHARED across its lanes
// (decision #2); everything that can differ per domain lives here.
struct LaneParams
{
    bool   on     = false;    // lane enabled (the menu checkbox)
    double freq   = 1000.0;   // Hz (engine clamps to [10, 0.49*fs])
    double Q      = 1.0;
    double gainDb = 0.0;      // bells & shelves
    int    slope  = 12;       // HP/LP: 6..96 dB/oct Butterworth. Notch/BandPass: skirt steepness
                              // (order = slope/6; Q stays the −3 dB bandwidth, order-invariant).
                              // Tilt: 6 = first-order shelves (gentle), anything else the 2-pole ones
    bool   bypass = false;    // lane kept but muted (ghost node) — distinct from on=false

    // Doubles compared by bit pattern (not `==`) so the engine's recompute-skip stays exact without
    // tripping -Wfloat-equal in strict-warning builds.
    bool operator== (const LaneParams& o) const noexcept
    {
        auto bits = [] (double d) noexcept { return std::bit_cast<std::uint64_t> (d); };
        return on == o.on && slope == o.slope && bypass == o.bypass
            && bits (freq) == bits (o.freq) && bits (Q) == bits (o.Q) && bits (gainDb) == bits (o.gainDb);
    }
};

// Optional dynamics for a point. POINT-LEVEL, not per lane: every running lane gets its own detector
// and its own delta (each probes its own freq/Q on its own signal), but they SHARE these settings.
// That is only sound because the threshold is auto-relative — an absolute dBFS threshold shared
// between a Mid and a Side lane, which can sit 20+ dB apart, would be meaningless. Wanting genuinely
// different dynamics per domain is what fission is for: split the point.
//
// `range` is the one number a user is expected to set; its SIGN is the direction (negative = pull
// down as the region gets loud, the common move). Attack/release are deviations from values derived
// from the band's own fc/Q by dynamics::BandBallistics, 0.5 meaning "auto".
//
// TWO THRESHOLD MODES, and the default is the interesting one.
//
// `thrAuto` (default) is RELATIVE: each lane measures against its own programme level, which is what
// lets one shared setting mean the same thing in Mid and in Side. It reacts to departures from a
// signal's recent norm — sibilance, a resonance ringing on one note — and by construction it cannot
// keep treating a level that has BECOME the norm.
//
// That last property is a real gap, not a philosophical one, and it is why the absolute mode exists.
// Measured: a dark source whose 7 kHz sits under the activity floor BETWEEN sibilants gives the
// estimator nothing but the sibilants themselves to learn from, so the relative excess collapses to
// ~0 and the de-esser does nothing (0.117 dB of reduction where the same programme 40 dB louder got
// the full 12). A relative threshold also cannot express "keep this band under X dBFS", nor treat a
// chorus that is harsher for thirty seconds — the estimator absorbs it within a few.
//
// `thrAuto == false` uses `thrDb` as a plain dBFS threshold. It is POINT-level like everything here,
// so every lane of a split point shares it: predictable (a louder domain crosses it more often) but
// asymmetric, and a user who wants genuinely different thresholds per domain uses fission, exactly
// as with every other shared setting. Auto remains the default precisely because the absolute mode
// is the one that needs a level-aware user.
struct DynParams
{
    bool   on      = false;
    double rangeDb = 0.0;      // signed cap on the delta; 0 == no dynamics
    double thrDb   = -24.0;    // ABSOLUTE threshold, dBFS — used only when thrAuto is false
    bool   thrAuto = true;     // default: relative to the lane's own programme level
    double atk     = 0.5;      // 0..1 deviation, 0.5 == the automatic value
    double rel     = 0.5;

    bool operator== (const DynParams& o) const noexcept
    {
        auto bits = [] (double d) noexcept { return std::bit_cast<std::uint64_t> (d); };
        return on == o.on && thrAuto == o.thrAuto
            && bits (rangeDb) == bits (o.rangeDb) && bits (thrDb) == bits (o.thrDb)
            && bits (atk) == bits (o.atk) && bits (rel) == bits (o.rel);
    }
};

// One band ("point"): a filter of one shared `type`, split across a set of placement lanes. The plugin
// adapter maps APVTS params into this; the engine owns no parameter system of its own (framework-
// agnostic). A fresh band reproduces the pre-lanes default exactly: point off, one Stereo lane enabled
// at 1 kHz / Q 1 / 0 dB / slope 12, all other lanes off, dynamics off.
struct BandParams
{
    bool       on     = false;               // the point exists
    FilterType type   = FilterType::Bell;    // SHARED by all lanes (decision #2)
    bool       swept  = false;               // search band; honored only in the single-ST configuration
    bool       bypass = false;               // whole-point bypass (strip power button)
    DynParams  dyn;                          // SHARED by all lanes (see DynParams)
    LaneParams lanes[kNumLanes] { { true }, {}, {}, {}, {} };   // lanes[Stereo].on = true, the rest off

    // Index a lane by its enum (the array is public, but this reads without the static_cast noise).
    LaneParams&       lane (Lane l)       noexcept { return lanes[static_cast<std::size_t> (l)]; }
    const LaneParams& lane (Lane l) const noexcept { return lanes[static_cast<std::size_t> (l)]; }

    // Exact change-detection across the shared fields + every lane (each LaneParams compares its own
    // doubles by bit pattern), so the engine's recompute-skip stays exact.
    bool operator== (const BandParams& o) const noexcept
    {
        if (! (on == o.on && type == o.type && swept == o.swept && bypass == o.bypass)) return false;
        if (! (dyn == o.dyn)) return false;
        for (int i = 0; i < kNumLanes; ++i) if (! (lanes[i] == o.lanes[i])) return false;
        return true;
    }
};

} // namespace felitronics::eq
