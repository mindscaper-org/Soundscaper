# felitronics::convolution — zero-latency partitioned FFT convolution on the core/Fft seam. Header-only
# for the spike (scalar reference FFT); becomes a compiled target when SIMD/real FFT backends + the
# offline IR resampler land. Depends on core (the FFT seam).
add_library(felitronics_convolution INTERFACE)
add_library(felitronics::convolution ALIAS felitronics_convolution)
target_include_directories(felitronics_convolution INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(felitronics_convolution INTERFACE felitronics::core)
target_compile_features(felitronics_convolution INTERFACE cxx_std_20)
if(FELITRONICS_WITH_PFFFT)
    # CabConvolver's public backend selection must be uniform across every consumer translation unit.
    target_compile_definitions(felitronics_convolution INTERFACE FELITRONICS_WITH_PFFFT)
    target_link_libraries(felitronics_convolution INTERFACE felitronics::fftpffft)
endif()

if(FELITRONICS_BUILD_TESTS)
    add_executable(felitronics_convolution_tests tests/ConvolutionTests.cpp)
    target_link_libraries(felitronics_convolution_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_convolution_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_convolution_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_convolution_tests COMMAND felitronics_convolution_tests)

    add_executable(felitronics_convolution_resampler_tests tests/ResamplerTests.cpp)
    target_link_libraries(felitronics_convolution_resampler_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_convolution_resampler_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_convolution_resampler_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_convolution_resampler_tests COMMAND felitronics_convolution_resampler_tests)

    add_executable(felitronics_convolution_engine_tests tests/ConvolutionEngineTests.cpp)
    target_link_libraries(felitronics_convolution_engine_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_convolution_engine_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_convolution_engine_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_convolution_engine_tests COMMAND felitronics_convolution_engine_tests)

    add_executable(felitronics_matrixconvolver_tests tests/MatrixConvolverTests.cpp)
    target_link_libraries(felitronics_matrixconvolver_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_matrixconvolver_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_matrixconvolver_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_matrixconvolver_tests COMMAND felitronics_matrixconvolver_tests)

    add_executable(felitronics_nonuniformconvolver_tests tests/NonUniformConvolverTests.cpp)
    target_link_libraries(felitronics_nonuniformconvolver_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_nonuniformconvolver_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_nonuniformconvolver_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_nonuniformconvolver_tests COMMAND felitronics_nonuniformconvolver_tests)

    add_executable(felitronics_matrixconvolvernupc_tests tests/MatrixConvolverNupcTests.cpp)
    target_link_libraries(felitronics_matrixconvolvernupc_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_matrixconvolvernupc_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_matrixconvolvernupc_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_matrixconvolvernupc_tests COMMAND felitronics_matrixconvolvernupc_tests)

    add_executable(felitronics_matrixconvolvernupc_stress_tests tests/MatrixConvolverNupcStressTests.cpp)
    target_link_libraries(felitronics_matrixconvolvernupc_stress_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_matrixconvolvernupc_stress_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_matrixconvolvernupc_stress_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_matrixconvolvernupc_stress_tests COMMAND felitronics_matrixconvolvernupc_stress_tests)

    add_executable(felitronics_convolution_cabconvolver_tests tests/CabConvolverTests.cpp)
    target_link_libraries(felitronics_convolution_cabconvolver_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_convolution_cabconvolver_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_convolution_cabconvolver_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_convolution_cabconvolver_tests COMMAND felitronics_convolution_cabconvolver_tests)
endif()

if(FELITRONICS_BUILD_TESTS)
    # A convolver channel that stops being asked for and is asked for again — a whole frame, an FDL and a
    # pending tail, none of which decays while it is away.
    add_executable(felitronics_convolution_gatestate_tests tests/ConvolutionGateStateTests.cpp)
    target_link_libraries(felitronics_convolution_gatestate_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_convolution_gatestate_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_convolution_gatestate_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_convolution_gatestate_tests COMMAND felitronics_convolution_gatestate_tests)

    # A restart with an operator published and not yet adopted (P88, law 11e): random interleavings of
    # publish / process / reset / clearAudioState on all three swap-safe convolvers, against a settled shadow.
    add_executable(felitronics_convolution_restart_fuzz_tests tests/ConvolutionRestartFuzzTests.cpp)
    target_link_libraries(felitronics_convolution_restart_fuzz_tests PRIVATE felitronics::convolution)
    target_include_directories(felitronics_convolution_restart_fuzz_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_convolution_restart_fuzz_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_convolution_restart_fuzz_tests COMMAND felitronics_convolution_restart_fuzz_tests)

    # …and the one hazard of that restart only REAL threads reach: reset() spinning beside a publishing
    # loader. Outside the wasm-audio tier by construction, like core's RtStreams suite — that tier is
    # single-threaded by contract, and this tree wraps pthread_create there, so a std::thread fails the link.
    if(NOT EMSCRIPTEN)
        add_executable(felitronics_convolution_restart_race_tests tests/ConvolutionRestartRaceTests.cpp)
        target_link_libraries(felitronics_convolution_restart_race_tests PRIVATE felitronics::convolution)
        target_include_directories(felitronics_convolution_restart_race_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
        target_compile_features(felitronics_convolution_restart_race_tests PRIVATE cxx_std_20)
        find_package(Threads REQUIRED)
        target_link_libraries(felitronics_convolution_restart_race_tests PRIVATE Threads::Threads)
        add_test(NAME felitronics_convolution_restart_race_tests COMMAND felitronics_convolution_restart_race_tests)
    endif()
endif()
