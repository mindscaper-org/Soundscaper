# felitronics::stereo — stereo-field tools: the Mid/Side matrix + MonoBass (elliptical-EQ / bass mono-maker
# for vinyl + mastering). Header-only, JUCE-free. Depends on core + eq (the Cytomic SVF supplies the LR4
# low-pass + all-pass sections).
add_library(felitronics_stereo INTERFACE)
add_library(felitronics::stereo ALIAS felitronics_stereo)
target_include_directories(felitronics_stereo INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(felitronics_stereo INTERFACE felitronics::core felitronics::eq)
target_compile_features(felitronics_stereo INTERFACE cxx_std_20)

if(FELITRONICS_BUILD_TESTS)
    add_executable(felitronics_stereo_air_tests tests/StereoAirTests.cpp)
    target_link_libraries(felitronics_stereo_air_tests PRIVATE felitronics::stereo felitronics::eq)
    target_include_directories(felitronics_stereo_air_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_stereo_air_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_stereo_air_tests COMMAND felitronics_stereo_air_tests)

    # MonoBass's live moves: the corners glide on the grid, `enabled` fades, the first write snaps (law 8a pinned).
    add_executable(felitronics_monobass_glide_tests tests/MonoBassGlideTests.cpp)
    target_link_libraries(felitronics_monobass_glide_tests PRIVATE felitronics::stereo)
    target_include_directories(felitronics_monobass_glide_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_monobass_glide_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_monobass_glide_tests COMMAND felitronics_monobass_glide_tests)

    add_executable(felitronics_stereo_tests tests/StereoTests.cpp)
    target_link_libraries(felitronics_stereo_tests PRIVATE felitronics::stereo)
    target_include_directories(felitronics_stereo_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_stereo_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_stereo_tests COMMAND felitronics_stereo_tests)
endif()
