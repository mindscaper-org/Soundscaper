# felitronics::dynamics — EnvelopeFollower + GainComputer (the first NEW module). Header-only;
# depends on core (FlushToZero). Composition (dynamic EQ / de-esser) is product glue, not here.
add_library(felitronics_dynamics INTERFACE)
add_library(felitronics::dynamics ALIAS felitronics_dynamics)
target_include_directories(felitronics_dynamics INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(felitronics_dynamics INTERFACE felitronics::core)
target_compile_features(felitronics_dynamics INTERFACE cxx_std_20)

if(FELITRONICS_BUILD_TESTS)
    add_executable(felitronics_dynamics_tests tests/DynamicsTests.cpp)
    target_link_libraries(felitronics_dynamics_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_tests COMMAND felitronics_dynamics_tests)

    # The makeup glide: the first write snaps, a mid-stream move glides per sample and lands (replayed bit for bit),
    # clocked by samples through a clock-only pause.
    add_executable(felitronics_dynamics_makeup_glide_tests tests/CompressorMakeupGlideTests.cpp)
    target_link_libraries(felitronics_dynamics_makeup_glide_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_makeup_glide_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_makeup_glide_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_makeup_glide_tests COMMAND felitronics_dynamics_makeup_glide_tests)

    add_executable(felitronics_dynamics_compressor_tests tests/CompressorTests.cpp)
    target_link_libraries(felitronics_dynamics_compressor_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_compressor_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_compressor_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_compressor_tests COMMAND felitronics_dynamics_compressor_tests)

    # Links eq as well: the acceptance signal needs a REAL sidechain high-pass, and building it from
    # eq::MatchedBiquad in the TEST is the point — the filter lives in the caller, never in the
    # compressor (ADR §4). The dynamics MODULE itself stays independent of eq.
    add_executable(felitronics_dynamics_sidechain_tests tests/CompressorSidechainTests.cpp)
    target_link_libraries(felitronics_dynamics_sidechain_tests PRIVATE felitronics::dynamics felitronics::eq)
    target_include_directories(felitronics_dynamics_sidechain_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_sidechain_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_sidechain_tests COMMAND felitronics_dynamics_sidechain_tests)

    # P3: the offline detector-domain analysis and the threshold solver. Links only dynamics — the
    # acceptance runs the REAL Compressor and sorts its gain-reduction tap, so the second instrument
    # verifying the search is in the same module rather than a dependency.
    add_executable(felitronics_dynamics_detector_analysis_tests tests/DetectorAnalysisTests.cpp)
    target_link_libraries(felitronics_dynamics_detector_analysis_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_detector_analysis_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_detector_analysis_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_detector_analysis_tests COMMAND felitronics_dynamics_detector_analysis_tests)

    # P14 part one: what the SHARED recursive primitives do with a poisoned state. Links eq as well —
    # the primitives being hardened live on both sides of that line (eq::Svf, eq::Biquad,
    # dynamics::EnvelopeFollower, dynamics::GainReductionFollower) and the contract is one contract.
    add_executable(felitronics_dynamics_poison_recovery_tests tests/PoisonRecoveryTests.cpp)
    target_link_libraries(felitronics_dynamics_poison_recovery_tests PRIVATE felitronics::dynamics felitronics::eq felitronics::deesser felitronics::dynamiceq)
    target_include_directories(felitronics_dynamics_poison_recovery_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_poison_recovery_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_poison_recovery_tests COMMAND felitronics_dynamics_poison_recovery_tests)

    # P14 part two: PREVENTION — the four consumers gate their detector input before the filter. Links
    # deesser and dynamiceq for the same reason the recovery suite does: the contract spans them.
    add_executable(felitronics_dynamics_detector_gate_tests tests/DetectorGateTests.cpp)
    target_link_libraries(felitronics_dynamics_detector_gate_tests PRIVATE felitronics::dynamics felitronics::eq felitronics::deesser felitronics::dynamiceq)
    target_include_directories(felitronics_dynamics_detector_gate_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_detector_gate_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_detector_gate_tests COMMAND felitronics_dynamics_detector_gate_tests)

    add_executable(felitronics_dynamics_transient_tests tests/TransientShaperTests.cpp)
    target_link_libraries(felitronics_dynamics_transient_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_transient_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_transient_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_transient_tests COMMAND felitronics_dynamics_transient_tests)

    add_executable(felitronics_dynamics_noisegate_tests tests/NoiseGateTests.cpp)
    target_link_libraries(felitronics_dynamics_noisegate_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_noisegate_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_noisegate_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_noisegate_tests COMMAND felitronics_dynamics_noisegate_tests)

    add_executable(felitronics_dynamics_autoleveler_tests tests/AutoLevelerTests.cpp)
    target_link_libraries(felitronics_dynamics_autoleveler_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_autoleveler_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_autoleveler_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_autoleveler_tests COMMAND felitronics_dynamics_autoleveler_tests)

    add_executable(felitronics_dynamics_autoleveler_theory_tests tests/AutoLevelerTheoryTests.cpp)
    target_link_libraries(felitronics_dynamics_autoleveler_theory_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_autoleveler_theory_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_autoleveler_theory_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_autoleveler_theory_tests COMMAND felitronics_dynamics_autoleveler_theory_tests)

    add_executable(felitronics_dynamics_autoleveler_falsify_tests tests/AutoLevelerFalsifyTests.cpp)
    target_link_libraries(felitronics_dynamics_autoleveler_falsify_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_autoleveler_falsify_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_autoleveler_falsify_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_autoleveler_falsify_tests COMMAND felitronics_dynamics_autoleveler_falsify_tests)

    add_executable(felitronics_dynamics_relativelevel_tests tests/RelativeLevelTests.cpp)
    target_link_libraries(felitronics_dynamics_relativelevel_tests PRIVATE felitronics::dynamics)
    target_include_directories(felitronics_dynamics_relativelevel_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_relativelevel_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_relativelevel_tests COMMAND felitronics_dynamics_relativelevel_tests)

    # Links eq as well: the ballistics law is NULLed against a directly measured eq::Svf probe rise,
    # which is what falsifies it. The dynamics MODULE itself stays independent of eq.
    add_executable(felitronics_dynamics_ballistics_tests tests/BandBallisticsTests.cpp)
    target_link_libraries(felitronics_dynamics_ballistics_tests PRIVATE felitronics::dynamics felitronics::eq)
    target_include_directories(felitronics_dynamics_ballistics_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_dynamics_ballistics_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_dynamics_ballistics_tests COMMAND felitronics_dynamics_ballistics_tests)
endif()
