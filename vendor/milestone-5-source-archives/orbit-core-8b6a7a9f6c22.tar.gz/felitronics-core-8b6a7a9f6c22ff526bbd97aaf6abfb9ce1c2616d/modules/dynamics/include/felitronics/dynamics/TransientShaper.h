// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <felitronics/dynamics/EnvelopeFollower.h>
#include <felitronics/dynamics/ChannelLinker.h>
#include <felitronics/core/Math.h>
#include <felitronics/core/Config.h>
#include <felitronics/core/FlushToZero.h>

#include <algorithm>
#include <cmath>

namespace felitronics::dynamics
{

//==============================================================================
// felitronics::dynamics::TransientShaper — attack/sustain shaping (SPL-Transient-Designer style). A FAST
// and a SLOW envelope on the linked sidechain, BOTH Peak (same detector type — different crest factors,
// e.g. Peak vs Rms, would read a steady sine as norm≈0.17 and falsely shape it). Their contrast tells the
// ATTACK phase (fast above slow, the onset) from the SUSTAIN phase (slow above fast, the decay):
//     norm = (fast − slow) / (fast + slow + ε)   ∈ [−1, 1]
//     shaped = deadzone(norm, threshold)         (a steady tone's micro-crest stays inside the deadzone)
//     gainDb = attackDb·max(shaped,0) + sustainDb·max(−shaped,0)     (two independent ± controls)
// A boost/cut on the attack sharpens/softens hits; on the sustain it lengthens/tightens tails. The gain is
// one-pole smoothed (no zipper). ZERO latency: the gain is computed from, and applied to, the SAME sample —
// the detector reacts within its 0.3 ms attack. (A proper anticipatory lookahead — gain pre-ramped over a
// delay window — is a future option; the naive "detect-now, apply-to-delayed" leads the audio and mis-times
// the boost, so it's intentionally not shipped.)
//
// This is GAIN MODULATION, not waveshaping → no oversampling. ONE linked gain drives all channels
// (image-preserving). Broadband; a per-band version is multiband::MultibandProcessor<TransientShaper>.
// RT-safe: prepare() allocates nothing on the hot path; process() is alloc/lock/throw-free, in place.
struct TransientShaperParams
{
    LinkMode link = LinkMode::Max;
    double attackDb     = 0.0;     // −24..24 — attack-phase boost(+) / cut(−)
    double sustainDb    = 0.0;     // −24..24 — sustain-phase boost(+) / cut(−)
    double fastAttackMs = 0.3,  fastReleaseMs = 20.0;
    double slowAttackMs = 15.0, slowReleaseMs = 150.0;
    double threshold    = 0.2;     // 0..0.9 — deadzone on |norm| so a steady tone's micro-crest isn't shaped
    double gainSmoothMs = 1.0;     // gain de-zipper time
    double mix          = 1.0;     // 0 dry … 1 fully shaped
};

class TransientShaper
{
public:
    // Law 11(b): `maxChannels` is BINDING. It used to be ignored, so the shaper's declared width was a
    // fiction and process() bounded itself by core::kMaxChannels instead — "prepared for 2" then meant
    // something different here than in the stage next door.
    [[nodiscard]] bool prepare (double sampleRate, int /*maxBlock*/ = 0, int maxChannels = 2) noexcept
    {
        prepared_ = false;                                        // any early return below leaves it unprepared
        if (maxChannels < 1 || maxChannels > core::kMaxChannels) return false;
        channels_ = maxChannels;
        fs_ = sampleRate > 0.0 ? sampleRate : 48000.0;
        fast_.prepare (fs_); fast_.setDetector (Detector::Peak);
        slow_.prepare (fs_); slow_.setDetector (Detector::Peak);   // SAME type as fast → steady tone = norm 0
        apply (params_);
        reset();
        prepared_ = true;
        return true;
    }

    bool isPrepared() const noexcept { return prepared_; }

    void reset() noexcept { fast_.reset(); slow_.reset(); gainSm_ = 1.0f; }

    void setParams (const TransientShaperParams& p) noexcept { params_ = p; apply (p); }
    static constexpr int latencySamples() noexcept { return 0; }

    // Law 11 (DSP-ARCHITECTURE.md §2).
    [[nodiscard]] bool process (float* const* channels, int numChannels, int n) noexcept
    {
        if (numChannels < 0 || n < 0) return false;
        if (! prepared_) return false;
        if (numChannels > channels_) return false;                // width is a LIMIT — law 11(b)
        if (n == 0) return true;                                  // no samples: the ONE true no-op
        // LAW 11c — a pause IS silence. There is no per-channel memory here, so the whole state is the
        // two envelopes and the de-zipper, and all three have to spend the audio time law 11(d) says
        // went by. Freezing them left the return 1.76-2.60 dB away from what the same stretch of
        // digital silence produces, in either direction depending on how far the two envelopes had
        // separated when the gap arrived.
        if (numChannels == 0) { advanceSilence (n); return true; }
        const int nc = numChannels;
        for (int i = 0; i < n; ++i)
        {
            // GATED, and per sample before the link — the same shape and the same reason as the
            // compressor's. `MeanPower` squares INSIDE the link, so a gate on the linked result would
            // read an overflowed frame as silence; and both followers below are recursive, so one bad
            // sample reaching them is permanent. Measured on the unguarded code: one NaN in ONE
            // channel left 102300 of 102400 output samples non-finite in EVERY channel, for good.
            const float m = sharedStep (linkAmplitudeGated (params_.link, channels, nc, i));
            for (int c = 0; c < nc; ++c) channels[c][i] += channels[c][i] * m;  // = x*(1 + mix*(gain-1))
        }
        fast_.flushDenormals(); slow_.flushDenormals();
        // ...AND the de-zipper, which is a recursive one-pole of its own and was not flushed at all.
        // Hardening the two envelope followers is not enough: `norm` reaches `gainSm_` through
        // `std::clamp(NaN)` = NaN and `dbToGain(NaN)`, and from there `m = mix*(gainSm_-1)` multiplies
        // EVERY channel — so one poisoned sample in ONE channel took the whole buffer down for good.
        // Measured before this line existed: 100764 of 102400 output samples non-finite in the
        // *innocent* channel, the last block 512 of 512, with the follower flushes already in place.
        // NEUTRAL HERE IS ONE, NOT ZERO. `core::flushPoison` would set unity gain to 0, and
        // `m = mix*(0-1)` is silence at full mix — the same value `reset()` writes is the only answer
        // that means "do nothing", which is what a cleared de-zipper has to mean.
        if (! std::isfinite (gainSm_)) gainSm_ = 1.0f;
        return true;
    }

private:
    // LAW 11c — `n` samples of DIGITAL SILENCE. `linkAmplitudeGated` on an all-zero frame is exactly
    // +0.0f at every width, so the pinned level below is what a silent block of ANY width feeds these
    // two followers, and the rest is the audio loop's own body, line for line.
    //
    // NOTHING COLLAPSES HERE, and saying so is the point. This stage has no dB floor to hide behind:
    // `fast_` and `slow_` decay at DIFFERENT rates, so `norm = (fe-se)/(fe+se+1e-9)` keeps moving for as
    // long as either envelope is alive — it slides toward -1 while the slow one dominates and back to 0
    // as it dies — and the deadzone, the two gain trims and `dbToGain` all stay live behind it. One
    // observed zero of `shaped` is NOT a plateau; the only sufficient condition is both envelopes
    // resting, and at that point `norm` is 0/1e-9 = 0, `gdb` is 0, `dbToGain(0)` is exactly 1.0f and the
    // de-zipper converges on the unity its own `reset()` writes. So the honest loop runs, and the
    // fixed-point exit is what bounds it.
    void advanceSilence (int n) noexcept
    {
        for (int i = 0; i < n; ++i)
        {
            const float f0 = fast_.stateWord(), s0 = slow_.stateWord(), g0 = gainSm_;
            (void) sharedStep (0.0f);       // linkAmplitudeGated of an all-zero frame, at every width
            if (core::sameBits (f0, fast_.stateWord()) && core::sameBits (s0, slow_.stateWord())
                && core::sameBits (g0, gainSm_)) break;
            if (! std::isfinite (gainSm_) && ! std::isfinite (g0)) break;
        }
        fast_.flushDenormals(); slow_.flushDenormals();
        if (! std::isfinite (gainSm_)) gainSm_ = 1.0f;            // the same neutral-is-ONE guard as above
    }

    // ONE sample of the SHARED body: linked level in, the mix-weighted gain offset `m` out. Written once
    // and called from both loops, so the pause runs the audio path's arithmetic rather than a copy of it.
    float sharedStep (float linked) noexcept
    {
        const float fe = fast_.process (linked);
        const float se = slow_.process (linked);
        const float norm = (fe - se) / (fe + se + 1.0e-9f);                 // ∈ [−1, 1]
        // deadzone: a steady tone has a small fast/slow ripple — only a real transient clears `threshold`.
        const float a = std::fabs (norm);
        const float t = a <= threshold_ ? 0.0f : (a - threshold_) / (1.0f - threshold_);   // rescale [thr,1]→[0,1]
        const float shaped = norm < 0.0f ? -t : t;
        float gdb = attackDb_ * std::max (shaped, 0.0f) + sustainDb_ * std::max (-shaped, 0.0f);
        gdb = std::clamp (gdb, -24.0f, 24.0f);
        const float g = (float) core::dbToGain ((double) gdb);
        gainSm_ = g + smoothCoeff_ * (gainSm_ - g);                         // one-pole de-zipper
        return mix_ * (gainSm_ - 1.0f);                                     // 0 dry … applied at mix 1
    }

    static double finite (double v, double fallback) noexcept { return std::isfinite (v) ? v : fallback; }

    void apply (const TransientShaperParams& p) noexcept
    {
        fast_.setTimes (finite (p.fastAttackMs, 0.3), finite (p.fastReleaseMs, 20.0));
        slow_.setTimes (finite (p.slowAttackMs, 15.0), finite (p.slowReleaseMs, 150.0));
        attackDb_  = (float) std::clamp (finite (p.attackDb,  0.0), -36.0, 36.0);
        sustainDb_ = (float) std::clamp (finite (p.sustainDb, 0.0), -36.0, 36.0);
        threshold_ = (float) std::clamp (finite (p.threshold, 0.2), 0.0, 0.9);
        mix_       = (float) std::clamp (finite (p.mix, 1.0), 0.0, 1.0);
        const double tms = finite (p.gainSmoothMs, 1.0) * 0.001;
        smoothCoeff_ = (tms <= 0.0 || fs_ <= 0.0) ? 0.0f : (float) std::exp (-1.0 / (tms * fs_));
    }

    double fs_ = 48000.0;
    int  channels_ = 2;                   // declared width — law 11(b), a LIMIT
    bool prepared_ = false;               // true only after a prepare() that succeeded
    TransientShaperParams params_;
    EnvelopeFollower fast_, slow_;
    float attackDb_ = 0.0f, sustainDb_ = 0.0f, threshold_ = 0.2f, mix_ = 1.0f, smoothCoeff_ = 0.0f, gainSm_ = 1.0f;
};

} // namespace felitronics::dynamics
