// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <felitronics/core/FlushToZero.h>

#include <algorithm>
#include <cmath>

//==============================================================================
// felitronics::dynamics::AutoLeveler — the wet->dry loudness match. Two slow one-pole RMS
// followers + a silence gate produce a makeup gain of sqrt(dryMS / mixMS), clamped
// and rate-limited so the blend stays balanced without pumping or zippering.
// (Extracted from OrbitCab, where it levels the convolved cab against the dry guitar.)
//
// Gain dynamics (two stages, both block-size- and sample-rate-invariant):
//   • the block-rate TARGET is dB-slew-limited against the PREVIOUS TARGET at
//     kMakeupSlewDbPerSec — the hard cap on how fast the loudness match may move.
//     Normal playing never hits it (the 150 ms followers already move slowly); it makes
//     an audible loudness PUMP structurally impossible from any fast target jump.
//   • the APPLIED gain glides toward the target at that same rate PER SAMPLE (a
//     dB-linear ramp implemented as a geometric progression — one multiply per sample,
//     no per-sample pow). No juce::SmoothedValue: re-arming a fixed-length ramp against
//     a slew-clamped target every block compounds into a block-size-dependent crawl
//     (measured 0.4 dB/s @ 64-sample blocks vs the intended 9 dB/s — the frozen-leveler
//     bug this design replaces).
//
// DETERMINISTIC retargets — a route snap (the engine knows the correct makeup
// for the route it is switching to), the enable/disable toggle, seed() at IR load — are
// not follower chases: they may jump the TARGET directly (bypassing the target slew) and
// open a bounded FAST window (kSnapSlewDbPerSec) so the applied gain lands in ~a fade
// length instead of dragging at 9 dB/s. The fast rate is still a hard rate limit — a
// deliberate glide synced with a mode change, not a pump.
//
// Pure-numeric: it takes per-block mean-square energies and returns a per-sample
// gain — no buffers, no framework types — so it's trivially unit-testable and portable.
//
// 🔴 RT-safe: every method is allocation-, lock-, IO- and exception-free — plain arithmetic
// on value members. prepare()/reset()/seed() are for stream (re)starts; the rest may run on
// the audio thread.
//==============================================================================
namespace felitronics::dynamics
{

class AutoLeveler
{
public:
    void prepare (double sampleRate) noexcept
    {
        currentSampleRate = sampleRate > 1000.0 ? sampleRate : 48000.0;
        const double perSample = kMakeupSlewDbPerSec / currentSampleRate;
        const double perSampleFast = kSnapSlewDbPerSec / currentSampleRate;
        ratioUpNormal = (float) std::pow (10.0, perSample / 20.0);
        ratioUpFast   = (float) std::pow (10.0, perSampleFast / 20.0);
        ratioDnNormal = 1.0f / ratioUpNormal;
        ratioDnFast   = 1.0f / ratioUpFast;
        reset();
    }

    void reset() noexcept
    {
        dryMeanSq = 0.0;
        mixMeanSq = 0.0;
        targetDb  = 0.0f;
        targetGain = 1.0f;
        appliedGain = 1.0f;
        fastSamplesLeft = 0;
        prevEnabled = true;
    }

    // Seed the makeup + followers to a known gain (estimated from the loaded IR's energy)
    // so the first audio after prepare starts at ~the converged value — no startup boost
    // while the followers crawl up from zero (OrbitCab #48). The followers are set to a
    // consistent (dry, mix) pair so the slow follower doesn't yank the makeup during
    // convolver warm-up.
    void seed (float makeupGain) noexcept
    {
        const float g = std::clamp (makeupGain, kMatchMinGain, kMatchMaxGain);
        targetDb  = gainToDecibels (g, kSilentDb);
        targetGain = g;
        appliedGain = g;
        fastSamplesLeft = 0;
        // Seed the followers at a REALISTIC program energy (−18 dBFS mean-square), not 1.0
        // (= 0 dBFS): the seed state decays at the follower τ, and a 0 dBFS seed out-masses a
        // real signal (~−15..−20 dBFS) for ~5τ ≈ 0.75 s, pinning the ratio to the seed long
        // after audio arrives. At −18 dBFS the followers hand over to the live signal promptly.
        dryMeanSq = kSeedMeanSq;
        mixMeanSq = kSeedMeanSq / ((double) g * g);     // sqrt(dryMeanSq / mixMeanSq) == g
    }

    // DETERMINISTIC route retarget (a router switching between signal paths): jump the
    // target to the KNOWN converged makeup of the route being switched to and glide there at
    // the fast (still hard-limited) rate, in sync with the router's crossfade. The mix follower
    // is re-seeded at the CURRENT dry level so the followers agree with the snapped ratio
    // instead of pulling back toward the old route's spectrum (no absolute-level transient:
    // the dry follower keeps tracking the real signal).
    void snapRatioTo (float makeupGain) noexcept
    {
        const float g = std::clamp (makeupGain, kMatchMinGain, kMatchMaxGain);
        targetDb = gainToDecibels (g, kSilentDb);
        targetGain = g;
        // The retarget lands INSTANTLY — mode switches are deliberately HARD (the honest PDC
        // re-report already makes the host re-sync around the switch, so any glide of ours is
        // masked noise; the user chose "no transitions between the modes, period").
        appliedGain = g;
        // Re-seed the mix follower so the followers AGREE with the snapped ratio — otherwise the
        // very next block's raw target would pull straight back toward the OLD route's spectrum.
        // In silence the dry state is floored so the pair stays consistent (tiny but ratio-true);
        // when signal returns both followers climb together and the ratio holds.
        mixMeanSq = std::max (dryMeanSq, kMatchFloorMeanSq) / ((double) g * g);
        fastSamplesLeft = 0;
    }

    // Advance the followers with this block's dry / mixed mean-square energy and set the
    // rate-limited makeup target. `enabled` false => aim for unity (the followers keep
    // running, so re-enabling snaps back). Below the silence floor the target is held
    // (won't chase the noise floor).
    void processBlock (double dryBlockMeanSq, double mixBlockMeanSq, bool enabled, int numSamples) noexcept
    {
        const double a = 1.0 - std::exp (-(double) numSamples / (kMatchTimeConstant * currentSampleRate));
        dryMeanSq += a * (dryBlockMeanSq - dryMeanSq);
        mixMeanSq += a * (mixBlockMeanSq - mixMeanSq);
        // Law 8. Both followers decay geometrically on silence and STICK in the subnormals (at 128
        // samples / 48 kHz, a ≈ 0.0176, so every k·u with k ≤ ½/a ≈ 28 is a fixed point). The cost of
        // leaving them there is small — two double FMAs per BLOCK, not per sample, and the silence gate
        // below skips the sqrt — but it is not zero, it never ends, and the fix is two compares.
        // POISON, not only denormals — and here the failure is silent, which is why it is worth the
        // two extra compares. A single non-finite block energy makes both followers NaN for ever
        // (`state += a*(x - state)` never returns), and then `dryMeanSq > kMatchFloorMeanSq` is FALSE,
        // so the silence gate below HOLDS THE LAST TARGET and returns. The audio stays perfectly
        // finite and the makeup simply stops moving: measured, frozen at +6.02 dB across 8000 healthy
        // unity blocks — 21 seconds — with nothing anywhere reading as broken.
        // `flushPoison` is safe on these states rather than merely convenient: its 1e-15 threshold is
        // 90 dB below `kMatchFloorMeanSq` (1e-6), so the silence gate reaches them long before it does.
        core::flushPoison (dryMeanSq);
        core::flushPoison (mixMeanSq);

        float rawTarget;
        if (! enabled)
            rawTarget = 1.0f;
        else if (dryMeanSq > kMatchFloorMeanSq)
            rawTarget = std::clamp ((float) std::sqrt (dryMeanSq / (mixMeanSq + 1.0e-12)),
                                    kMatchMinGain, kMatchMaxGain);
        else
            return;   // silence gate: hold the last target — and leave prevEnabled untouched, so a
                      // re-enable that lands inside silence is still treated as a flip (fast glide)
                      // on the first non-silent block instead of being silently consumed here.

        const bool enabledFlipped = (enabled != prevEnabled);
        prevEnabled = enabled;

        const float rawDb = gainToDecibels (rawTarget, kSilentDb);
        if (enabledFlipped)
        {
            // The on/off toggle is a deterministic retarget, not a follower chase: jump the
            // target (unity when disabling, the live ratio when re-enabling) and glide fast.
            targetDb = rawDb;
            targetGain = rawTarget;
            fastSamplesLeft = (int) std::lround (kSnapWindowSeconds * currentSampleRate);
            return;
        }

        // dB-domain slew limit against the PREVIOUS TARGET (not the applied gain — clamping
        // around the applied value compounds with the applied glide into a block-size-dependent
        // crawl). Exactly kMakeupSlewDbPerSec regardless of block size — except inside a
        // TRANSITION window (a route change just happened): there the followers are legitimately
        // re-measuring a stepped ratio, so the cap opens to kTransitionSlewDbPerSec and the
        // convergence is follower-limited (τ = 150 ms) instead of slew-starved. The followers'
        // own dynamics stay untouched — this is NOT the old 10 ms fast-track (which pumped by
        // making the ESTIMATE jumpy); the estimate stays slow and smooth, only its rate ceiling
        // briefly matches its natural speed.
        const double slew = fastSamplesLeft > 0 ? kTransitionSlewDbPerSec : kMakeupSlewDbPerSec;
        const float stepDb = (float) (slew * (double) numSamples / currentSampleRate);
        targetDb = std::clamp (rawDb, targetDb - stepDb, targetDb + stepDb);
        targetGain = decibelsToGain (targetDb, kSilentDb);   // one pow per block
    }

    // Per-sample: glide the applied gain toward the target at the (normal or fast) hard rate.
    // dB-linear ramp as a geometric progression — one multiply per sample. The LINEAR gain is
    // the single source of truth (a separate dB accumulator would drift against the multiplied
    // gain and pop on landing); min/max clamp the last step exactly onto the target.
    float getNextGain() noexcept
    {
        const bool fast = fastSamplesLeft > 0;
        if (fast) --fastSamplesLeft;
        if (appliedGain < targetGain)
            appliedGain = std::min (appliedGain * (fast ? ratioUpFast : ratioUpNormal), targetGain);
        else if (appliedGain > targetGain)
            appliedGain = std::max (appliedGain * (fast ? ratioDnFast : ratioDnNormal), targetGain);
        return appliedGain;
    }

    float currentGain()   const noexcept { return appliedGain; }
    float currentGainDb() const noexcept { return gainToDecibels (appliedGain, kSilentDb); }

    // A deterministic-retarget glide (route snap / on-off flip / transition window) is in
    // progress. The engine blocks route-makeup cache WRITES during it so a mid-glide value can
    // never be remembered as "converged". (An earlier, stricter settled()-gate also blocked
    // writes whenever the applied gain merely trailed the wandering live target — on real,
    // non-stationary material that is ~always, so caches never formed and every mode switch
    // re-faded from scratch. The narrow window below is the actual poison case.)
    bool snapGliding() const noexcept { return fastSamplesLeft > 0; }

    // Open the transition window WITHOUT retargeting: a route change happened but no remembered
    // makeup (and no learned pair delta) exists — let the followers re-measure at their natural
    // speed with the transition slew ceiling instead of crawling at 9 dB/s.
    void openTransitionWindow() noexcept
    {
        fastSamplesLeft = (int) std::lround (kSnapWindowSeconds * currentSampleRate);
    }

private:
    // juce::Decibels::{gainToDecibels, decibelsToGain} replicated EXACTLY (incl. the explicit
    // minusInfinityDb floor semantics and float-precision log10/pow), so the extraction is
    // numerically identical to the JUCE-based original:
    //   gainToDecibels: gain > 0 ? max (floor, log10 (gain) * 20) : floor
    //   decibelsToGain: db > floor ? 10^(db * 0.05) : 0
    static float gainToDecibels (float gain, float minusInfinityDb) noexcept
    {
        return gain > 0.0f ? std::max (minusInfinityDb, std::log10 (gain) * 20.0f)
                           : minusInfinityDb;
    }

    static float decibelsToGain (float decibels, float minusInfinityDb) noexcept
    {
        return decibels > minusInfinityDb ? std::pow (10.0f, decibels * 0.05f)
                                          : 0.0f;
    }

    static constexpr double kMatchTimeConstant  = 0.15;   // s — slow enough not to pump
    static constexpr double kSeedMeanSq         = 0.0158; // −18 dBFS² — realistic program energy for seeds
    static constexpr double kMakeupSlewDbPerSec = 9.0;    // dB/s — hard cap on makeup movement (no pump, ever)
    static constexpr double kSnapSlewDbPerSec   = 40.0;   // dB/s — deterministic-retarget glide (route snap / on-off)
    static constexpr double kTransitionSlewDbPerSec = 20.0; // dB/s — target ceiling inside a transition window
                                                            // (≈ the 150 ms followers'' own initial slope for a
                                                            // ~3 dB step — the cap stops starving them there)
    static constexpr double kSnapWindowSeconds  = 0.35;   // fast-rate budget per snap (covers ±12 dB and lands)
    static constexpr double kMatchFloorMeanSq  = 1.0e-6;  // ~ -60 dBFS RMS: below this, hold
    static constexpr float  kMatchMinGain      = 0.0631f; // -24 dB
    static constexpr float  kMatchMaxGain      = 63.10f;  // +36 dB (headroom for lossy IRs)
    static constexpr float  kSilentDb          = -120.0f;

    double currentSampleRate = 44100.0;
    double dryMeanSq = 0.0;
    double mixMeanSq = 0.0;
    float  targetDb  = 0.0f;               // block-rate target, slew-limited against itself
    float  targetGain = 1.0f;              // linear mirror of targetDb (updated when targetDb moves)
    float  appliedGain = 1.0f;             // per-sample rate-limited glide toward targetGain — THE truth
    float  ratioUpNormal = 1.0f, ratioDnNormal = 1.0f, ratioUpFast = 1.0f, ratioDnFast = 1.0f;
    int    fastSamplesLeft = 0;
    bool   prevEnabled = true;
};

} // namespace felitronics::dynamics
