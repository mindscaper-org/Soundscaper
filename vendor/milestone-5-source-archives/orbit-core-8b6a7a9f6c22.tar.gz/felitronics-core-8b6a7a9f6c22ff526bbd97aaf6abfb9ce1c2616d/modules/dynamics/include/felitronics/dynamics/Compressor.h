// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <felitronics/core/Config.h>
#include <felitronics/core/Math.h>
#include <felitronics/core/DelayLine.h>
#include <felitronics/core/FlushToZero.h>
#include <felitronics/dynamics/ChannelLinker.h>
#include <felitronics/dynamics/EnvelopeFollower.h>     // Detector enum (Peak / Rms)
#include <felitronics/dynamics/GainComputer.h>
#include <felitronics/dynamics/GainReductionPath.h>    // detector → curve → ballistics, as one object

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace felitronics::dynamics
{

// Derives from GainReductionParams — which derives from DetectorParams in turn — rather than
// repeating those fields, so that handing a CompressorParams to a GainReductionPath (and through it to
// a LinkedDetector) is a base-class binding and not a mapping somebody has to keep in step. Field
// access is unchanged: `p.detector`, `p.thresholdDb`, `p.attackMs` all still name the same things, and
// what is left HERE is exactly what lives outside the gain-reduction path — makeup is a decision about
// output level, lookahead one about alignment, and neither changes how much to compress.
// It stays an aggregate (a public, non-virtual base is allowed in one since C++17), so
// `CompressorParams p;` then assigning members works exactly as before, and it stays trivially
// copyable. THE SOURCE-COMPATIBILITY BREAK P2 DOCUMENTED IS UNCHANGED IN KIND, one level deeper:
// POSITIONAL brace initialisation needs the bases nested, a designated initialiser naming a base
// member does not compile, and `std::is_standard_layout_v` is false (`is_aggregate_v` and
// `is_trivially_copyable_v` stay true — compile-checked). Nothing in this repository does any of
// those; a consumer outside it might. The LOGICAL field order is unchanged from P2's layout. One more
// shape moved and is worth naming because it is silent: a POINTER TO MEMBER now has the base's type —
// `decltype (&CompressorParams::thresholdDb)` is `double GainReductionParams::*`, not
// `double CompressorParams::*` — which matters to exact-type reflection, serialisation tables and
// overload sets built on member pointers. Ordinary access `p.thresholdDb` is untouched.
struct CompressorParams : GainReductionParams
{
    double makeupDb    = 0.0;
    bool   autoMakeup  = false;                   // adds a STATIC auto-makeup (see autoMakeupDb)
    double lookaheadMs = 0.0;
};

// WHERE THE PER-SAMPLE GAIN REDUCTION COMES OUT. `gainReductionDb()` reports the value after the LAST
// sample of the block, which is a sample of the gain reduction, not a summary of it: polling it at
// block ends is a subsampling whose rate is the host's block size, so no percentile, mean or maximum
// can be built on it. This is that missing output, and it is deliberately a BUFFER rather than a
// statistic: a mean here would fix a window, a histogram would fix a bin width and a percentile rule,
// and both would then be a SECOND definition of a quantity the offline analysis already defines. The
// compressor emits the samples; whoever wants a statistic owns its definition, once.
//
// `data == nullptr` (the default) is off, and costs one perfectly predicted branch per sample — the
// source says per sample and means it; whether a compiler hoists it out of the loop is the compiler's
// business, not a promise this header can make. Otherwise `capacity` must be at least `numSamples` or
// THE WHOLE CALL IS REFUSED — audio, state and the tap buffer untouched — for the same reason a channel
// count above the prepared maximum is refused: a partially written diagnostic is worse than none,
// because it looks like data. `capacity` is not deducible from the pointer, which is the whole reason
// it travels with it in one type instead of being a bare argument; the same lesson as
// `numKeyChannels`, whose absence is why there is no four-argument key form.
//
// IT MUST NOT OVERLAP `io` OR `key`, AT ANY SHIFT, and this one is not diagnosable from in here. The
// gain reduction for sample `i` is written before that sample's audio is read, so a tap aliased onto
// a programme plane destroys the input it is about to measure: measured, with `ratio = 1` (a
// transparent compressor), no lookahead, and `gr.data == io[0]`, a block of 0.5 came out as digital
// silence. A shifted overlap corrupts samples this call has not reached yet. Same rule and same
// reason as the key's: aliasing here is not "usually fine", it is the caller's to avoid.
struct GainReductionTap
{
    float* data     = nullptr;
    int    capacity = 0;
};

// A STATIC auto-makeup (dB): half-compensate the gain reduction a 0 dBFS signal would receive. Static
// (a function of the curve only) — NOT signal-following (which would be a second compressor and pump).
// It reads the CURVE, so it assumes the key and the programme share a scale; an external key at a
// different level makes it over- or under-correct, and the product owns that decision.
inline double autoMakeupDb (const GainComputer& gc) noexcept { return -0.5 * gc.deltaDb (0.0); }

//==============================================================================
// felitronics::dynamics::Compressor — a broadband, channel-LINKED compressor that composes the dynamics
// primitives in the clean topology:
//     GainReductionPath (detector → curve → ballistics, ONE object) → makeup → apply to the
//     LOOKAHEAD-delayed signal.
// Smoothing the gain reduction (not the detector level) keeps the attack/release independent of the
// knee/ratio. Product-neutral: no sidechain EQ, params system, GUI, metering policy, dry/wet — those
// stay in the product (it's the "core gives primitives + a broadband composite; products compose" line).
// RT-safe: prepare() allocates; process() does no alloc/lock/throw. Reported latency = lookahead.
//
// ====================================================================================
// THE EXTERNAL KEY (sidechain), and the contract the caller owes it
// ====================================================================================
// `process()` has a five-argument form that feeds the DETECTOR from a separate buffer while the gain is
// still applied to `io`. That is how a mastering bus stops its kick and bass from ducking the whole mix:
// the product high-passes a copy of the bus and passes it as the key. THE FILTER IS NOT IN HERE and
// will not be — ADR §4, "the core gives primitives; products compose them" — so the key arrives already
// filtered, built from `eq::MatchedBiquad` or anything else the product likes.
//
//   * TIME BASE. `key[c][i]` must be the SAME INSTANT as `io[c][i]` at the input. The compressor
//     supplies the lookahead itself, by delaying `io` and not the key, so key sample `i` sets the gain
//     applied to programme sample `i - latencySamples()`. Do NOT pre-advance or pre-delay the key by
//     this module's latency: a host compensates a plug-in's reported latency downstream of it, so both
//     buses arrive on the same timeline. (Hosts have not always got the key bus right — Pro Tools
//     before 2021.6 and Logic before 10.8 did not compensate it — but that is a wrapper's problem to
//     detect, not something a DSP primitive can guess.)
//   * KEY-FILTER GROUP DELAY eats lookahead. A minimum-phase HPF is not a constant delay, and it is
//     not free either: a 2nd-order Butterworth high-pass at fc has a group delay of sqrt(2)/(2*pi*fc)
//     AT the corner — 0.75 ms, or 36 samples at 48 kHz, for a 300 Hz corner — falling as 1/f^2 above
//     it, which is why it is normally left uncompensated for the transients a key exists to pass. How
//     much is a property of the filter the product chose, not something this module knows. A
//     LINEAR-PHASE key filter is a different
//     matter: an N-tap symmetric FIR delays the key by exactly (N-1)/2 samples, which subtracts that
//     much from the effective lookahead and can make it negative. Use a minimum-phase key filter, or
//     delay `io` to match and declare the extra latency.
//   * CHANNEL COUNT is the key's own. `numKeyChannels` has nothing to do with `numChannels`: one mono
//     kick bus keying a stereo master is `numKeyChannels == 1`, and it is read for every sample of the
//     block. Only `key[0 .. numKeyChannels-1]` are touched, and the count must be the true length of
//     that array — an array length is not observable from in here. NB `LinkMode::MeanPower` divides by
//     the key's channel count, so a mono key and the same key duplicated into two channels agree, while
//     a mono key and a stereo key whose second channel is silent differ by 3 dB. That is arithmetic, not
//     a bug, and it is the reason the count travels with the pointer.
//   * `key == nullptr`, OR A COUNT OF ZERO OR LESS, is the SELF-KEYED path, identical to the
//     three-argument form. Passing `io` itself as the key is also exactly identical, bit for bit: at
//     each sample every detector read happens before any write. NB FOR A PLUG-IN WRAPPER: a host that
//     reports zero sidechain channels because the bus is not connected therefore gets SELF-KEYING, not
//     silence — which is the safe default, but it is not "external sidechain engaged and receiving
//     nothing". A product that wants the second must say so itself.
//   * THERE IS NO FOUR-ARGUMENT FORM, deliberately. A bare pointer with no count is the shape that
//     reads one element past a mono key array on a stereo bus, silently; here it does not compile.
//   * ALIASING IS EXACT OR NOT AT ALL. `key[c] == io[c]` is the self-keyed identity above. A key that
//     OVERLAPS the programme at a shift (`io[0] - 1`, say) reads samples this call has already
//     overwritten, and two `io` planes pointing at the same buffer get the gain and the delay applied
//     twice. Neither is diagnosable from in here; both are the caller's to avoid.
//   * A POISONED KEY FILTER IS UPSTREAM OF THE GATE. The gate bounds what reaches the detector, not
//     what reaches the product's own filter: one Inf into a recursive HPF makes every sample it emits
//     afterwards a NaN, which this module then reads — correctly — as silence, for good. A product that
//     filters the key owns guarding that filter's input and state.
//
// ====================================================================================
// THE DETECTOR GATE — what it protects, and what it deliberately does not touch
// ====================================================================================
// Every key sample passes `detectorGate()` (non-finite → 0, magnitude clamped to 1e6) BEFORE the link.
// This is not decoration: the detector is recursive, and `state += c*(x - state)` never decays a NaN
// out, so ONE bad key sample used to be permanent. Measured on the unguarded code, from a single +Inf
// (or a NaN, or a finite 1e20 — which squares to +Inf in float): DownCompress became a permanent
// bypass, DownExpand a permanent -rangeDb of silence, and UpCompress a permanent +60 dB. The gate is
// per SAMPLE and not on the linked result because `MeanPower` squares inside the link, so a gate on the
// result would see the overflowed frame as silence — a loud key read as nothing.
// BIT-TRANSPARENT for any finite key sample within ±1e6 (+120 dBFS): it takes neither branch, so every
// real audio sample passes through untouched with 120 dB to spare. ABOVE that bound the two detectors
// part company, and it is worth being exact about it. `Peak` is still output-transparent once the curve
// has saturated, because the level is instantaneous and both the clamped and unclamped spikes land on
// -rangeDb. `Rms` is NOT: the window stores x^2/tau and carries it forward, so what the clamp bounds is
// the MEMORY of the spike, not just its instant. Measured with one key sample of 1e8, a 5 ms window and
// the defaults: gated and ungated gain reduction differ in 46010 of 48000 samples, by up to 16.65 dB at
// 4:1 and 17.45 dB at 20:1, where `Peak` differs in none. `MeanPower` behaves like `Rms`.
// THE AUDIO PATH IS NOT GATED. A compressor is not a sanitiser: `io` carries no recursive state (the
// delay line is a ring, not a feedback path), so a non-finite programme sample passes through and out,
// which is the honest answer and leaves bounding the signal to the limiter that owns that promise.
//
// ====================================================================================
// WHAT CHANGES OF SHAPE DO, all of them deliberate
// ====================================================================================
//   * MORE CHANNELS THAN PREPARED are REFUSED — the buffer is returned untouched. This module's one
//     structural promise is that every channel gets the SAME gain; processing a prefix breaks exactly
//     that, and silently: measured with a stereo buffer on a mono-prepared instance, the second channel
//     came out neither gained nor delayed, i.e. a level mismatch plus a lookahead-sized time skew — a
//     comb-filtered fold-down that can ship unnoticed. Delivering no compression cannot. Prepare for the
//     most channels you will ever pass, and check what prepare() returned.
//   * A CHANGE OF CHANNEL COUNT resets the delay lines of the channels that were idle, and nothing
//     else. Only `delays[]` is per-channel; the detector and the gain reduction are shared and keep
//     advancing, so they are not stale and clearing them would be a gain jump the change never asked
//     for. Without this, stereo → mono → stereo re-emitted the returning channel's pre-mono audio:
//     measured at 0.75 out of digital silence, 417 ms after the fact.
//   * A CHANGE OF MAKEUP GLIDES — `makeupDb`, and `autoMakeup` with every curve change that moves it — over
//     kMakeupGlideMs, linearly in dB and per sample, on the samples this stage processes. It used to be added
//     as is: measured through the mastering chain on a -12 dBFS sine at 4:1, makeupDb 0 -> +3 put max|Δ²y|
//     at -30.5 dBFS (the steady tone reads -76.8), autoMakeup switched on -21.4, and a threshold move with
//     autoMakeup on -19.5 — the curve's own change goes through the GR ballistics, its makeup did not. Every
//     write before the first sample after prepare()/reset() lands at once, so a compressor configured before
//     its first sample renders exactly what it rendered before the glide existed.
//   * A CHANGE OF THE RESULTING SAMPLE DELAY — the rounded, clamped one, not every touch of
//     `lookaheadMs` — clears the delay lines and moves `latencySamples()`, which makes it a
//     resynchronisation event rather than automation. Moving the read pointer of a live ring re-emits
//     audio already delivered (measured: 48 samples of 0.9 into silence) or skips over some; a cleared
//     line emits the gap as zeros instead, which is the bounded failure. Set it once if you can.
class Compressor
{
public:
    // The bounds prepare() enforces, public so a wrapper that computes sizes from the SAME arguments
    // can reject an out-of-range value before its own arithmetic rather than after ours.
    static constexpr double kMaxSampleRate  = 3.0e6;    // far above any audio rate; keeps every derived
                                                        // size inside int with the lookahead capacity
    static constexpr double kMaxLookaheadMs = 250.0;    // five times any musical setting; bounds what one
                                                        // prepare() can be asked to allocate per channel
    // The makeup glide (see "A CHANGE OF MAKEUP GLIDES" above): 30 ms, the length the mastering chain's own gain
    // ramps and the EQ's smoothers use, linear in dB. Measured on the chain's -12 dBFS sine: makeup 0 -> +3 at
    // -30.5 dBFS as a step, -76.4 as this glide.
    static constexpr double kMakeupGlideMs  = 30.0;

    // Returns false and leaves the compressor UNPREPARED on a configuration it cannot honour; process()
    // then does nothing at all rather than half-processing. A false return is the only way to learn
    // this, so check it. What it prevents is not `std::ceil(NaN)` — that just returns NaN — but the
    // out-of-range floating-to-INTEGER conversions downstream of it, which are undefined.
    // WHAT prepare() ASKS THE HEAP FOR (law 11d) — the one function it sizes itself with, so a caller
    // budgeting memory reads the numbers the bank is actually built from and the two cannot drift. FALSE,
    // with `out` untouched, exactly where prepare() refuses the same arguments (it IS prepare()'s gate),
    // and a refused prepare() allocates nothing. Asked of a FRESH compressor: one already prepared for at
    // least this much keeps its bank and asks for nothing. `GainReductionPath::prepare` allocates nothing
    // — measured, not assumed — so the bank is the whole of it.
    struct Storage
    {
        std::size_t lines          = 0;    // one core::DelayLine per channel, held in one vector
        int         maxLookSamples = 0;    // the ring capacity every line is prepared for
        std::uint64_t bytes() const noexcept { return core::delayBankBytes (lines, maxLookSamples); }
    };

    [[nodiscard]] static bool storageFor (double sampleRate, int maxBlock, int maxChannels,
                                          double maxLookaheadMs, Storage& out) noexcept
    {
        // Spelled positively so NaN fails: `sampleRate <= 0.0` is FALSE for a NaN, which is how one
        // reaches the undefined conversions the class comment names.
        if (! (sampleRate > 0.0) || ! std::isfinite (sampleRate) || sampleRate > kMaxSampleRate) return false;
        if (maxBlock < 1) return false;                        // no scratch is sized by it, but a caller
                                                               // that passes 0 has a bug worth reporting
        // Refused rather than clamped: a silently reduced channel count would leave the surplus channels
        // refused at every process() call, i.e. a compressor that does nothing, discovered much later.
        if (maxChannels < 1 || maxChannels > core::kMaxChannels) return false;
        if (! std::isfinite (maxLookaheadMs) || maxLookaheadMs < 0.0 || maxLookaheadMs > kMaxLookaheadMs) return false;
        out.lines          = (std::size_t) maxChannels;
        out.maxLookSamples = (int) std::ceil (maxLookaheadMs * 0.001 * sampleRate);
        return true;
    }

    // THE LOOKAHEAD A PARAMETER SET ACTUALLY TAKES at this rate against a ring of `maxLookSamples` — the
    // clamp chain apply() runs, in ONE place, which is what makes `latencyFor()` below the same number the
    // prepared object reports rather than a second derivation of it.
    static int lookaheadSamplesFor (double sampleRate, double lookaheadMs, int maxLookSamples) noexcept
    {
        // A non-finite lookahead would feed lround() undefined behaviour; clamp in the DOUBLE domain
        // first, because std::lround(1e300) is out of range for a long before any int clamp can help.
        const double lookMs = std::isfinite (lookaheadMs)
                            ? (lookaheadMs < 0.0 ? 0.0 : (lookaheadMs > kMaxLookaheadMs ? kMaxLookaheadMs : lookaheadMs))
                            : 0.0;
        int n = (int) std::lround (lookMs * 0.001 * sampleRate);
        if (n < 0) n = 0;
        if (n > maxLookSamples) n = maxLookSamples;
        return n;
    }

    // THE LATENCY a prepared compressor will report for this geometry, WITHOUT preparing one. A composite
    // that has to size a dry aligner before its stages exist needs this number, and deriving it a second
    // time is exactly what `MasteringChain::prepare` (felitronics-mastering-core) refuses to do — so here it is once, and the prepared
    // object reports what this returns (pinned in the suites). 0 where prepare() refuses the same
    // arguments, which is how `latencySamples()` reads on an unprepared compressor.
    static int latencyFor (double sampleRate, int maxBlock, int maxChannels,
                           double maxLookaheadMs, double lookaheadMs) noexcept
    {
        Storage st;
        if (! storageFor (sampleRate, maxBlock, maxChannels, maxLookaheadMs, st)) return 0;
        return lookaheadSamplesFor (sampleRate, lookaheadMs, st.maxLookSamples);
    }

    [[nodiscard]] bool prepare (double sampleRate, int maxBlock, int maxChannels, double maxLookaheadMs = 50.0)
    {
        prepared_ = false;                                     // any early return below leaves it unprepared
        Storage st;
        if (! storageFor (sampleRate, maxBlock, maxChannels, maxLookaheadMs, st)) return false;

        fs    = sampleRate;
        maxCh = maxChannels;
        maxLookSamples = st.maxLookSamples;
        core::prepareDelayBank (delays, st.lines, maxLookSamples);
        path.prepare (fs);
        makeupRampLen_ = std::max (1, (int) std::lround (kMakeupGlideMs * 0.001 * fs));
        lookSamples = -1;                                      // force apply() to size the fresh lines
        fresh_ = true;                                         // a preparation is a stream restart
        apply (params);
        reset();
        prepared_ = true;
        return true;
    }

    void reset() noexcept
    {
        for (auto& d : delays) d.reset();
        path.reset();
        lastNc_ = 0;
        // A stream restart lands the makeup glide on its target, and the next write snaps.
        makeupNowDb_ = makeupAppliedDb; makeupLeft_ = 0;
        fresh_ = true;
    }

    void   setParams (const CompressorParams& p) noexcept { params = p; apply (p); }
    int    latencySamples()  const noexcept { return prepared_ ? lookSamples : 0; }
    // The gain reduction AFTER THE LAST SAMPLE of the most recent block — a sample, not a summary.
    // For anything that needs the shape (a percentile, a mean, a maximum), pass a GainReductionTap:
    // polling this at block ends subsamples at the host's block rate, which is not a property of the
    // signal at all.
    double gainReductionDb() const noexcept { return path.valueDb(); }         // for metering
    float  detectorLevel()   const noexcept { return path.detectorLevel(); }   // linked level, linear
    bool   isPrepared()      const noexcept { return prepared_; }

    // Audio thread, in place, self-keyed (the detector reads the programme). RT-safe.
    [[nodiscard]] bool process (float* const* channels, int numChannels, int numSamples) noexcept
    {
        return process (channels, numChannels, numSamples, nullptr, 0, GainReductionTap {});
    }

    // Self-keyed, with the per-sample gain reduction tapped out. NB this IS a four-argument form, and
    // the one the key deliberately does not have — because `GainReductionTap` is a named type carrying
    // its own capacity, so the shape that made a bare `const float*` key dangerous (a pointer whose
    // extent only the caller knows) does not arise. RT-safe.
    [[nodiscard]] bool process (float* const* channels, int numChannels, int numSamples, GainReductionTap gr) noexcept
    {
        return process (channels, numChannels, numSamples, nullptr, 0, gr);
    }

    // Audio thread, in place, with an EXTERNAL KEY — read the header note above for the time-base and
    // channel-count contract. `key == nullptr` or `numKeyChannels <= 0` means self-keyed. RT-safe.
    [[nodiscard]] bool process (float* const* channels, int numChannels, int numSamples,
                                const float* const* key, int numKeyChannels) noexcept
    {
        return process (channels, numChannels, numSamples, key, numKeyChannels, GainReductionTap {});
    }

    // The full form: external key AND the per-sample gain reduction. `gr.data == nullptr` is off; a
    // non-null tap with `gr.capacity < numSamples` REFUSES the whole call, leaving audio, state and
    // the tap buffer untouched. RT-safe.
    [[nodiscard]] bool process (float* const* channels, int numChannels, int numSamples,
                                const float* const* key, int numKeyChannels, GainReductionTap gr) noexcept
    {
        if (numChannels < 0 || numSamples < 0) return false;   // malformed
        if (! prepared_) return false;
        if (numChannels > maxCh) return false;                 // refuse — see "MORE CHANNELS THAN PREPARED"
        // Checked BEFORE anything moves, so a refused call is indistinguishable from one never made.
        if (gr.data != nullptr && gr.capacity < numSamples) return false;
        if (numSamples == 0) return true;                      // no samples: no time, no edge, nothing
        fresh_ = false;                                        // the stream has started: makeup writes glide
        const int nc = numChannels;

        // A channel that sat out blocks holds `lookSamples` of audio from before it left. Zero only
        // those lines; the shared detector and gain reduction are still tracking a real signal.
        //
        // LAW 11a: a channel that STOPPED is one at index >= nc on a call that carried samples — the
        // width alone does not say it, the sample count does. Only the widening half used to be handled
        // here, so a stretch of narrower (or zero-width) calls left the departed lanes' lookahead lines
        // FROZEN and they replayed on return: measured, 5 ms of lookahead, a tone, 4800 samples of
        // zero-width calls, then stereo DIGITAL SILENCE -> 0.280315 out of the silence (-11.05 dBFS),
        // last non-zero at sample 239, i.e. the whole 240-sample line, note for note.
        for (int c = nc; c < lastNc_; ++c) delays[(std::size_t) c].reset();
        if (lastNc_ > 0 && nc > lastNc_)
            for (int c = lastNc_; c < nc; ++c) delays[(std::size_t) c].reset();
        lastNc_ = nc;
        if (nc == 0)
        {
            // LAW 11c: A PAUSE IS SILENCE. Audio time passed (law 11(d) says so), and the shared
            // ballistics spend it the way `n` samples of digital silence would — the per-channel lines
            // above have just been dropped, and what is left is one detector and one gain-reduction
            // follower, whose silent input is exactly +0.0f at any width. Freezing them instead held
            // -25.311 dB of gain reduction through a full second of gap where silence releases to
            // -2.076, and dipped the return by -22.11 dB on material below the threshold (-24.09 dB
            // through a ten-second gap).
            //
            // AN EXTERNAL KEY IS STILL CONSUMED, and that follows from the law rather than adding to it.
            // The invariant is "this call equals the same call at a live width carrying digital
            // silence", and `process(zeros, nch, n, key, nk)` runs the detector on the KEY. The
            // PROGRAMME is what stopped, not the key: a sidechain that keeps arriving keeps being
            // detected, and pretending it vanished would make the pause differ from the silence it is
            // defined to equal.
            //
            // A REQUESTED TAP TAKES THE HONEST LOOP, because the tap is a per-SAMPLE observable and a
            // silent block of any width fills it sample by sample. Nothing is lost: the collapse buys
            // its speed by not producing the intermediate values, so a caller that asked for exactly
            // those values has asked for the linear work. All three spellings end in the same
            // `GainReductionPath` entry points the audio loop uses, so they agree bit for bit.
            if (key != nullptr && numKeyChannels > 0)
            {
                for (int i = 0; i < numSamples; ++i)
                {
                    const float grDb = path.process (key, numKeyChannels, i);
                    if (gr.data != nullptr) gr.data[i] = grDb;
                }
            }
            else if (gr.data != nullptr) for (int i = 0; i < numSamples; ++i) gr.data[i] = path.processSample (0.0f);
            else                         path.advanceSilence (numSamples);
            path.flushDenormals();                             // the same once-per-call cadence as below
            // The makeup glide spends the pause too — sample by sample, the same steps the audio loop takes,
            // so a gap cut any way lands it at the same place. Bounded by the glide, not by the pause.
            for (int i = 0; i < numSamples && makeupLeft_ > 0; ++i) stepMakeup();
            return true;
        }

        const float* const* detCh = key;
        int                 detNc = numKeyChannels;
        if (key == nullptr || numKeyChannels <= 0) { detCh = channels; detNc = nc; }

        for (int i = 0; i < numSamples; ++i)
        {
            // --- detector → curve → GR ballistics, in the ONE object an offline pass drives too ---
            const float  grDb       = path.process (detCh, detNc, i);
            if (gr.data != nullptr) gr.data[i] = grDb;         // signed, BEFORE makeup and the delay
            if (makeupLeft_ > 0) stepMakeup();                 // the makeup glide, one step per sample
            // THE SUM is what reaches dbToGain, and it is bounded here and nowhere else. An UpCompress
            // curve sitting at +rangeDb plus a large makeup is +800 dB, i.e. 1e40 — +Inf once cast to
            // float — and `0.0f * Inf` is NaN, so a silent passage came out poisoned from entirely
            // finite parameters (measured: 64 of 64 output samples). Two comparisons, and
            // bit-transparent for any total inside ±400 dB, a gain of 1e±20 no real setting approaches.
            const double totalDb    = (double) grDb + makeupNowDb_;
            const float  gain       = (float) core::dbToGain (totalDb < -kMaxGainDb ? -kMaxGainDb : (totalDb > kMaxGainDb ? kMaxGainDb : totalDb));

            // --- apply to the lookahead-delayed signal (read input before overwriting in place) ---
            for (int c = 0; c < nc; ++c)
            {
                const float x = channels[c][i];
                const float y = delays[(std::size_t) c].process (x);
                channels[c][i] = y * gain;
            }
        }

        path.flushDenormals();
        return true;
    }

private:
    // With kMaxSampleRate and kMaxLookaheadMs the delay ring is at most 750001 slots, and DelayLine
    // casts its own size to int internally — so the pair above is what keeps that conversion in range.
    static constexpr double kMaxGainDb      = 400.0;    // gain reduction PLUS makeup, the only thing that
                                                        // reaches dbToGain; 400 dB is a gain of 1e20
    static constexpr double kRampBoundDb    = 1.0e6;    // the makeup glide's arithmetic only — see apply()

    void apply (const CompressorParams& p) noexcept
    {
        // SLICING, on purpose: the compressor's own parameter object IS the path's, and through it the
        // detector's. Nothing maps fields across, so nothing can fall out of step when a field is added
        // at either level. Non-finite times and windows are handled inside the followers' coefficient
        // guards.
        path.setParams (p);

        // THROUGH the static, not beside it: `latencyFor()` publishes this number to a caller that has no
        // compressor yet, and two spellings of one clamp chain is exactly the drift law 11d's budgets exist
        // to make impossible.
        const int newLook = lookaheadSamplesFor (fs, p.lookaheadMs, maxLookSamples);

        // Changing the delay of a LIVE ring moves only the read pointer: raising it re-emits audio
        // already delivered, lowering it skips over some. Clear instead — a hole of zeros is the
        // bounded failure, and the reported latency has moved anyway, which is a resync either way.
        const bool lookChanged = (newLook != lookSamples);
        lookSamples = newLook;
        for (auto& d : delays) d.setDelay (lookSamples);
        if (lookChanged) for (auto& d : delays) d.reset();

        // Not bounded HERE, deliberately: what has to stay inside float is the SUM of this and the
        // gain reduction, and process() bounds that in one place. Two clamps would mask each other —
        // and did, until a mutation of either survived the suite because the other was still standing.
        makeupAppliedDb = (std::isfinite (p.makeupDb) ? p.makeupDb : 0.0) + (p.autoMakeup ? autoMakeupDb (path.curve()) : 0.0);
        // THE GLIDE: a moved target restarts a linear ramp from where the makeup stands NOW (double, landing on
        // the target itself); before the stream's first sample it lands at once. An unchanged target — every
        // re-sent parameter set — restarts nothing.
        // The STEP is computed between endpoints bounded to ±kRampBoundDb, and only the arithmetic sees that bound:
        // a finite makeup of ±1e308 is a legal write (process() clamps the SUM to ±kMaxGainDb, the one clamp this
        // class has), but the difference of two of them overflows to inf and the next retarget turns the ramp into
        // NaN, which that clamp passes (the code-review round: -1e308 -> +1e308 -> 0 emitted NaN). The bound is far
        // outside ±kMaxGainDb, so it never decides a gain; the last step still lands on the exact target.
        if (fresh_ || makeupRampLen_ <= 0) { makeupNowDb_ = makeupAppliedDb; makeupLeft_ = 0; }
        else if (! core::exactlyEqual (makeupAppliedDb, makeupTargetDb_))
        {
            const auto bounded = [] (double v) noexcept { return std::clamp (v, -kRampBoundDb, kRampBoundDb); };
            makeupNowDb_  = bounded (makeupNowDb_);
            makeupLeft_   = makeupRampLen_;
            makeupStepDb_ = (bounded (makeupAppliedDb) - makeupNowDb_) / (double) makeupRampLen_;
        }
        makeupTargetDb_ = makeupAppliedDb;
    }

    void stepMakeup() noexcept
    {
        --makeupLeft_;
        makeupNowDb_ = makeupLeft_ > 0 ? makeupNowDb_ + makeupStepDb_ : makeupTargetDb_;
    }

    double fs = 48000.0;
    CompressorParams params;

    GainReductionPath            path;
    std::vector<core::DelayLine> delays;

    int    lookSamples = 0, maxLookSamples = 0, maxCh = 0, lastNc_ = 0;
    double makeupAppliedDb = 0.0;                      // the TARGET the parameters resolve to
    double makeupNowDb_ = 0.0, makeupStepDb_ = 0.0, makeupTargetDb_ = 0.0;   // the glide toward it
    int    makeupLeft_ = 0, makeupRampLen_ = 0;
    bool   prepared_ = false, fresh_ = true;
};

} // namespace felitronics::dynamics
