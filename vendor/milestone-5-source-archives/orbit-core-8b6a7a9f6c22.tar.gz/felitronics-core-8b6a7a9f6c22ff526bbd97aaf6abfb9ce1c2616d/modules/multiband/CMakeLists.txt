# felitronics::multiband — the generic MultibandProcessor (split into LR4 bands → per-band processor →
# recombine) + the MultibandCompressor / MultibandWidth products. Header-only, JUCE-free. Deps: core
# (DelayLine) + eq (MultibandSplitter) + dynamics (Compressor) + stereo (StereoWidth, per-band width).
add_library(felitronics_multiband INTERFACE)
add_library(felitronics::multiband ALIAS felitronics_multiband)
target_include_directories(felitronics_multiband INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(felitronics_multiband INTERFACE felitronics::core felitronics::eq felitronics::dynamics felitronics::stereo)
target_compile_features(felitronics_multiband INTERFACE cxx_std_20)

if(FELITRONICS_BUILD_TESTS)
    add_executable(felitronics_multiband_tests tests/MultibandTests.cpp)
    target_link_libraries(felitronics_multiband_tests PRIVATE felitronics::multiband)
    target_include_directories(felitronics_multiband_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_multiband_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_multiband_tests COMMAND felitronics_multiband_tests)

    add_executable(felitronics_multibandwidth_tests tests/MultibandWidthTests.cpp)
    target_link_libraries(felitronics_multibandwidth_tests PRIVATE felitronics::multiband)
    target_include_directories(felitronics_multibandwidth_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_multibandwidth_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_multibandwidth_tests COMMAND felitronics_multibandwidth_tests)
endif()

if(FELITRONICS_BUILD_TESTS)
    # A channel that stops being split and is split again — the whole crossover tree for that column,
    # plus its per-band alignment delay lines, none of which decays while it is away.
    add_executable(felitronics_multiband_gatestate_tests tests/MultibandGateStateTests.cpp)
    target_link_libraries(felitronics_multiband_gatestate_tests PRIVATE felitronics::multiband)
    target_include_directories(felitronics_multiband_gatestate_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_multiband_gatestate_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_multiband_gatestate_tests COMMAND felitronics_multiband_gatestate_tests)
endif()
