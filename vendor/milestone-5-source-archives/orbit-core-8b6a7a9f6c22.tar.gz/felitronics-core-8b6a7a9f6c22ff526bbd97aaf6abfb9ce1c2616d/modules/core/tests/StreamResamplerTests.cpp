// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

// Streaming rate-matcher (it rate-locks a model to 48 kHz on any host rate). The first four groups are
// the resampler cases of the product it was promoted from, ported with the SAME expected values — they are the golden this extraction must not move:
// identity ratio = a clean 2-sample delay, up/down conversion keeps level and output count, DC
// shows no drift over many blocks. On top: block-size invariance (same count, samples within one
// float ulp — the phase accumulator runs at different magnitudes per chunking, measured 5.96e-8
// worst-case; bit-exact at ratio 1), startup underflow padding, and the no-alloc-in-process proof.

#include <felitronics/core/StreamResampler.h>

#include "felitronics_test.h"
#include <alloc_counter.h>   // installs the allocation counter: EVERY form of `new`, over-aligned included

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <utility>
#include <vector>

using felitronics::core::StreamResampler;
using felitronics::test::approx;
using felitronics::test::group;
using felitronics::test::ok;

namespace
{
    constexpr double kPi = 3.14159265358979323846;

    // Run a signal through a resampler in `block`-sized chunks; return the concatenated output.
    std::vector<float> runResampler (double inRate, double outRate, const std::vector<float>& in, int block)
    {
        StreamResampler r;
        r.reset (inRate, outRate, block * 2 + 16);
        std::vector<float> out, tmp ((std::size_t) (block * 4 + 16));
        out.reserve ((std::size_t) ((double) in.size() * outRate / inRate) + 32);
        for (std::size_t i = 0; i < in.size(); i += (std::size_t) block)
        {
            const int n = (int) std::min ((std::size_t) block, in.size() - i);
            r.feed (in.data() + i, n);
            const int got = r.produceAvailable (tmp.data(), (int) tmp.size());
            out.insert (out.end(), tmp.begin(), tmp.begin() + got);
        }
        return out;
    }

    bool anyBad (const std::vector<float>& v)
    { for (float x : v) if (std::isnan (x) || std::isinf (x)) return true; return false; }

    float peak (const std::vector<float>& v)
    { float p = 0; for (float x : v) p = std::max (p, std::fabs (x)); return p; }

    std::vector<float> sine (int n, double rate, double f, float amp = 0.5f)
    {
        std::vector<float> v ((std::size_t) n);
        for (int i = 0; i < n; ++i) v[(std::size_t) i] = amp * (float) std::sin (2.0 * kPi * f * i / rate);
        return v;
    }
}

int main()
{
    std::printf ("felitronics::core stream-resampler tests\n");

    group ("identity at ratio 1 — a BIT-EXACT delay of kHalf, not a filter");
    {
        // 🔴 A DELIBERATE SHORT-CIRCUIT, not a property of the kernel. The cutoff is 0.99 of the lower
        // Nyquist and sinc(0.99·n) is NOT zero at integer n, so running ratio 1 through the general
        // path would apply a real (if gentle) low-pass to a caller who asked for no rate change at all.
        // The class detects an exactly equal in/out rate and copies. The DELAY stays kHalf, so latency
        // is one formula for every ratio and only the filtering is skipped. It was 2 samples while the
        // kernel was a cubic; that number was the cubic's geometry, not a promise about identity.
        const std::size_t D = (std::size_t) felitronics::core::StreamResampler::kHalf;
        auto in  = sine (4000, 48000.0, 600.0);
        auto out = runResampler (48000.0, 48000.0, in, 512);
        ok (! anyBad (out), "no NaN/Inf at identity ratio");
        int matched = 0, checked = 0;
        for (std::size_t k = D; k + 2 < out.size() && k < in.size() && k < 2000; ++k, ++checked)
            if (std::fabs (out[k] - in[k - D]) <= 0.0f) ++matched;      // BIT-exact, not a tolerance
        ok (checked > 1000 && matched == checked,
            "out[k] IS in[k-kHalf], bit for bit — the identity path copies, it does not resample");

        // 🔴 …AND A RATIO THAT IS MERELY CLOSE MUST NOT TAKE THAT PATH. A mutation relaxing the
        // identity test from exact equality to a 1 Hz tolerance survived the entire suite, because
        // the two paths have the SAME DELAY (kHalf either way) and every existing check compares
        // delays or bit-equality at exact unity. What separates them is FILTERING: the copy passes
        // everything, the kernel band-limits at 0.99 of the lower Nyquist. So probe just off unity
        // with a tone the band edge actually attenuates.
        {
            // The discriminator is NOT a magic frequency — the first attempt picked 23.5 kHz and
            // failed, because at a ratio this close to unity the cutoff sits at 0.99·24 kHz = 23.76 kHz
            // and 23.5 is still inside the passband. The sharp, frequency-free question is simply
            // whether the two paths produce the same samples: an identity test with a tolerance would
            // make them identical, and they must not be.
            const double in = 48000.0, out = 47999.5;          // 0.5 Hz apart: inside a 1 Hz tolerance
            felitronics::core::StreamResampler near, exact;
            near .reset (in, out, 8192);
            exact.reset (in, in,  8192);
            ok (! near.identity && exact.identity,
                "a ratio 0.5 Hz off unity is NOT the identity path, and exact unity is");

            auto render = [] (felitronics::core::StreamResampler& r)
            {
                std::vector<float> x (2048), o (4096);
                for (int i = 0; i < 2048; ++i)
                    x[(std::size_t) i] = 0.5f * (float) std::sin (2.0 * kPi * 9000.0 * i / 48000.0);
                r.feed (x.data(), 2048);
                const int k = r.produceAvailable (o.data(), (int) o.size());
                o.resize ((std::size_t) k);
                return o;
            };
            const auto a2 = render (near), b3 = render (exact);
            double worst = 0.0;
            for (std::size_t i = 100; i < std::min (a2.size(), b3.size()) - 100; ++i)
                worst = std::max (worst, std::fabs ((double) a2[i] - (double) b3[i]));
            ok (worst > 1.0e-4,
                "…and it does NOT produce what the copy path produces (worst difference "
                + std::to_string (worst) + " on a 9 kHz tone). An identity test with a tolerance would "
                "send this ratio down the bit-copy path and the two would agree exactly");
        }
    }

    group ("upsample 44100 -> 48000 (no NaN, level kept, count ~ ratio)");
    {
        auto in  = sine (44100, 44100.0, 100.0);
        auto out = runResampler (44100.0, 48000.0, in, 512);
        ok (! anyBad (out), "no NaN/Inf on upsample");
        approx (peak (out), 0.5, 0.04, "sine level survives the upsample");
        approx ((double) out.size() / (double) in.size(), 48000.0 / 44100.0, 0.01, "output count tracks the ratio");
    }

    group ("downsample 96000 -> 48000 (no NaN, level kept, count ~ half)");
    {
        auto in  = sine (96000, 96000.0, 100.0);
        auto out = runResampler (96000.0, 48000.0, in, 512);
        ok (! anyBad (out), "no NaN/Inf on downsample");
        approx (peak (out), 0.5, 0.04, "sine level survives the downsample");
        approx ((double) out.size() / (double) in.size(), 0.5, 0.01, "output count is ~ half");
    }

    group ("no drift on DC over many blocks");
    {
        std::vector<float> in (48000, 1.0f);
        auto out = runResampler (44100.0, 48000.0, in, 512);
        ok (! anyBad (out), "no NaN/Inf on DC");
        double tail = 0; int c = 0;
        for (std::size_t k = (out.size() > 256 ? out.size() - 256 : 0); k < out.size(); ++k) { tail += out[k]; ++c; }
        approx (c ? tail / c : 0.0, 1.0, 0.02, "DC tail still sits at 1 after a second of resampling");
    }

    group ("block-size invariance — chunking never changes the stream");
    {
        auto in = sine (9000, 44100.0, 440.0);
        const auto a = runResampler (44100.0, 48000.0, in, 512);
        const auto b = runResampler (44100.0, 48000.0, in, 64);
        const auto c = runResampler (44100.0, 48000.0, in, 48);   // not a divisor of the input length
        ok (a.size() == b.size() && a.size() == c.size(), "output count is independent of the feed block size");
        float worst = 0.0f;
        const std::size_t n = std::min ({ a.size(), b.size(), c.size() });
        for (std::size_t k = 0; k < n; ++k)
            worst = std::max ({ worst, std::fabs (a[k] - b[k]), std::fabs (a[k] - c[k]) });
        ok (worst <= 1.5e-7f, "samples match within ~1 float ulp across chunkings");   // measured 5.96e-8 worst-case

        const auto i1 = runResampler (48000.0, 48000.0, in, 512);
        const auto i2 = runResampler (48000.0, 48000.0, in, 48);
        ok (i1 == i2, "identity ratio is BIT-exact across chunkings (integer phase)");
    }

    group ("produceExact pads startup underflow with silence");
    {
        StreamResampler r;
        r.reset (48000.0, 48000.0, 64);
        float out[8] = { 9, 9, 9, 9, 9, 9, 9, 9 };
        r.produceExact (out, 8);                                 // nothing fed yet — only the 3 history zeros
        bool allZero = true;
        for (float x : out) allZero = allZero && x == 0.0f;
        ok (allZero, "unfed resampler emits exact silence, never junk");
    }

    group ("RT safety — feed/produce never allocate");
    {
        StreamResampler r;
        r.reset (44100.0, 48000.0, 512 * 2 + 16);                // ALLOC lives here, message thread
        auto in = sine (512 * 8, 44100.0, 220.0);
        std::vector<float> tmp ((std::size_t) (512 * 4 + 16));
        const long long before = alloc::count.load();
        for (int blk = 0; blk < 8; ++blk)
        {
            r.feed (in.data() + (std::size_t) (blk * 512), 512);
            (void) r.produceAvailable (tmp.data(), (int) tmp.size());
        }
        r.produceExact (tmp.data(), 32);
        felitronics::test::okNoAlloc (alloc::count.load() == before, "feed/produceAvailable/produceExact allocated nothing");
    }

    group ("\U0001f534 clearAudioState() — the stream restart WITHOUT re-deriving the kernel (P47)");
    {
        // WHY IT EXISTS: `reset (rates, capacity)` is this class's prepare(). It reassigns both vectors,
        // `shrink_to_fit()`s on the identity path and re-derives 513 x 64 windowed-sinc coefficients with
        // a Bessel evaluation per tap — 1.756 ms for the two legs of one lane, measured, and deliberately
        // not noexcept. A caller restarting a LIVE stream (a model stage's reset()) cannot pay
        // that on the audio thread, and re-deriving a kernel is not what a restart means anyway.
        //
        // WHAT IT MUST BE: the state `reset()` leaves, exactly — so a restarted leg and a freshly reset
        // one answer the same programme with the same BITS. Asserted on both paths, because the identity
        // short-circuit and the filtering kernel keep their history differently.
        for (const bool identity : { true, false })
        {
            const double inRate  = 48000.0;
            const double outRate = identity ? 48000.0 : 44100.0;
            const auto programme = sine (4000, inRate, 600.0);

            StreamResampler restarted, freshly;
            restarted.reset (inRate, outRate, 512);
            freshly  .reset (inRate, outRate, 512);

            // …the one that will be RESTARTED hears a different stream first.
            {
                const auto other = sine (3000, inRate, 311.0, 0.4f);
                std::vector<float> tmp (2048);
                for (int off = 0; off + 512 <= (int) other.size(); off += 512)
                {
                    restarted.feed (other.data() + off, 512);
                    (void) restarted.produceAvailable (tmp.data(), (int) tmp.size());
                }
            }
            const long long before = alloc::count.load();
            restarted.clearAudioState();
            felitronics::test::okNoAlloc (alloc::count.load() == before,
                                          std::string ("clearAudioState() allocates nothing on the ")
                                          + (identity ? "identity" : "filtering") + " path");

            std::vector<float> a (4096, 0.0f), b (4096, 0.0f);
            int na = 0, nb = 0;
            for (int off = 0; off + 512 <= (int) programme.size(); off += 512)
            {
                restarted.feed (programme.data() + off, 512);
                na += restarted.produceAvailable (a.data() + na, (int) a.size() - na);
                freshly  .feed (programme.data() + off, 512);
                nb += freshly  .produceAvailable (b.data() + nb, (int) b.size() - nb);
            }
            int diff = 0;
            for (int i = 0; i < std::min (na, nb); ++i) if (a[(std::size_t) i] != b[(std::size_t) i]) ++diff;
            ok (na == nb && na > 1000 && diff == 0,
                std::string ("a restarted leg is bit-identical to a freshly reset one on the ")
                + (identity ? "identity" : "filtering") + " path (" + std::to_string (na) + " against "
                + std::to_string (nb) + " samples, " + std::to_string (diff) + " differing)");
        }

        // 🔴 AND IT DOES NOT RESURRECT AN INSTANCE reset() NEVER CONFIGURED. `reset()` sets `len = 0`
        // FIRST so that a throwing allocation leaves an object that produces NOTHING rather than one
        // that reads an absent coefficient table; a restart that derived its length from `buf.size()`
        // alone would undo exactly that. A default-constructed instance is the reachable half of the
        // same state, and it must stay inert.
        {
            StreamResampler untouched;
            untouched.clearAudioState();
            std::vector<float> in (512, 0.5f), out (512, -1.0f);
            untouched.feed (in.data(), 512);
            const int got = untouched.produceAvailable (out.data(), (int) out.size());
            ok (got == 0, "a resampler reset() never configured produces nothing after clearAudioState(): "
                          + std::to_string (got) + " samples");
        }

        // …AND A MOVED-FROM INSTANCE, which is the same state reached by the one transition the validity
        // bit does not see: the implicit move COPIES `configured_` and steals the vectors, so the corpse
        // reads "configured" with an empty buffer. This was the first method of this class a moved-from
        // instance could not survive — a fill through a null `data()`, which UBSan calls a store to a
        // null pointer and ASan a SEGV. Every older method is benign there, and so is this one now.
        {
            StreamResampler alive;
            alive.reset (48000.0, 44100.0, 512);
            StreamResampler taken = std::move (alive);
            alive.clearAudioState();
            std::vector<float> in (512, 0.5f), out (512, -1.0f);
            alive.feed (in.data(), 512);
            ok (alive.produceAvailable (out.data(), (int) out.size()) == 0,
                "a moved-FROM resampler survives clearAudioState() and still produces nothing");
            taken.clearAudioState();
            taken.feed (in.data(), 512);
            ok (taken.produceAvailable (out.data(), (int) out.size()) > 0,
                "…and the leg that took its storage still works");
        }
    }

    return felitronics::test::report();
}
