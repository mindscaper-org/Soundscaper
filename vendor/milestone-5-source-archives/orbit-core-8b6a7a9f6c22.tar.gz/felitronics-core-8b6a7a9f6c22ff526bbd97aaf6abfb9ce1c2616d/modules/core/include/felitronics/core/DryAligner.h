// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace felitronics::core
{

//==============================================================================
// felitronics::core::DryAligner — emits the input delayed by a per-block-VARIABLE number of samples,
// through a fixed-capacity per-channel circular ring fed EVERY block (so it stays warm and the delay
// tap can change block-to-block — a stage toggling between modes, or a model load moving a rate-match
// latency — with no reallocation and no glitch). Its job: hold a bypassed / powered-off stage at the
// ACTIVE stage's PDC, so toggling that stage's power never changes the plugin's reported latency (no
// host re-sync GAP) and an off↔active crossfade blends time-aligned signals (no comb / level JUMP).
//
// Same integer-ring algorithm as core::DelayLine, deliberately a SEPARATE type — the shape differs:
// DelayLine is one channel, one sample per call, with a delay you set and hold; DryAligner is
// N channels, one block per call, tap passed per block, and it STAGES the delayed copy into internal
// scratch so the caller can snapshot the raw input BEFORE an in-place stage overwrites the buffer and
// still read the aligned dry afterwards. Folding either into the other would cost the per-sample API
// or the stage-then-read semantics.
//
// Bit-exact: the delayed sample is a pure copy of the input from exactly D samples earlier — no
// arithmetic, no interpolation. D == 0 → an exact identity copy.
//
// Contract: advance() with numChannels ≤ the prepared channel count and numSamples ≤ the prepared
// maxBlock; call it BEFORE any in-place stage overwrites `io`; delayed(ch) stays valid until the
// next advance()/prepare(). advance() clamps both counts to the prepared sizes — a kept contract
// makes the clamps a no-op, a violated one processes the prefix that fits (defined, no overrun)
// instead of writing out of bounds. prepare() is still REQUIRED for real use: the default-
// constructed state is safe but degenerate (1 channel, capacity 2, maxBlock 1 — everything clamps
// down to that).
//
// 🔴 RT: advance() never allocates, locks or throws — both buffers are sized once in prepare().
//==============================================================================
class DryAligner
{
public:
    // WHAT prepare() ASKS THE HEAP FOR (law 11d) — the one function it sizes itself with, so a caller
    // budgeting memory reads the numbers the two buffers are actually built from. Every clamp prepare()
    // makes is made here as well, because the budget of a call is storageFor() with the SAME arguments:
    // a caller that passes 0 channels is sized for 1, exactly as it is prepared for 1.
    // NB a default-constructed aligner is NOT empty — its constructor already took the seed below — so
    // preparing one for counts inside that seed asks the heap for nothing and `bytes()` is then an upper
    // bound rather than the request. `freshBytes()` is the request itself.
    struct Storage
    {
        std::size_t ring = 2, scratch = 1;       // floats, both already multiplied by the channel count
        std::uint64_t bytes() const noexcept
        {
            return (std::uint64_t) sizeof (float) * ((std::uint64_t) ring + (std::uint64_t) scratch);
        }

        // WHAT preparing a DEFAULT-CONSTRUCTED aligner asks the heap for: each buffer that outgrows the seed
        // is asked for its size, and one that still fits inside the seed is asked for nothing, since `assign`
        // re-uses capacity it already holds. Not an edge nobody reaches — a ONE-channel aligner for a stage
        // with no latency is a 2-slot ring, i.e. exactly the seed, and the mastering chain (felitronics-mastering-core) builds one for a
        // mono compressor whose lookahead rounds to 0 samples. `bytes()` over-stated that preparation by 8 B.
        std::uint64_t freshBytes() const noexcept
        {
            const std::uint64_t r = ring    > 2 ? (std::uint64_t) ring    : 0u;
            const std::uint64_t s = scratch > 1 ? (std::uint64_t) scratch : 0u;
            return (std::uint64_t) sizeof (float) * (r + s);
        }
    };

    static Storage storageFor (int numChannels, int maxBlock, int capacity) noexcept
    {
        const std::size_t ch = (std::size_t) std::max (1, numChannels);
        Storage s;
        s.ring    = ch * (std::size_t) std::max (2, capacity);
        s.scratch = ch * (std::size_t) std::max (1, maxBlock);
        return s;
    }

    // What the DEFAULT-CONSTRUCTED degenerate state below asks for (a 2-slot ring and a 1-sample scratch).
    // An owner that holds an aligner BY VALUE pays this at its own construction and then, for each of the
    // two buffers it prepares LARGER than the seed, hands that buffer's share back — so a budget that sums
    // an owner's requests exceeds what the owner HOLDS by up to this much per aligner: all 12 bytes when
    // both buffers grow, 4 when a one-channel ring stays at its 2-slot seed (see `freshBytes()`). Stated
    // rather than hidden: it is the one place in the mastering chain where the sum and the peak differ.
    static constexpr std::uint64_t constructBytes() noexcept { return (std::uint64_t) sizeof (float) * 3u; }

    // `capacity` must exceed any latency the tap will ever request (the delay is clamped to
    // [0, capacity-1]). Size it to the largest stage latency plus margin.
    void prepare (int numChannels, int maxBlock, int capacity)
    {
        channels_ = std::max (1, numChannels);
        cap_      = std::max (2, capacity);
        maxBlock_ = std::max (1, maxBlock);
        const Storage st = storageFor (numChannels, maxBlock, capacity);
        ring_.assign    (st.ring,    0.0f);
        scratch_.assign (st.scratch, 0.0f);
        pos_ = 0;
    }

    void reset() noexcept
    {
        std::fill (ring_.begin(),    ring_.end(),    0.0f);
        std::fill (scratch_.begin(), scratch_.end(), 0.0f);
        pos_ = 0;
    }

    int capacity()    const noexcept { return cap_; }
    int numChannels() const noexcept { return channels_; }

    // Stage the internal scratch = `io` delayed by `delaySamples` (0 → an exact copy) and advance the
    // ring by numSamples. Read the result via delayed(ch). `io` may be the caller's live buffer — call
    // this BEFORE any in-place stage overwrites it.
    void advance (const float* const* io, int numChannels, int numSamples, int delaySamples) noexcept
    {
        const int C  = cap_;
        const int D  = std::clamp (delaySamples, 0, C - 1);
        const int nc = std::clamp (numChannels, 0, channels_);   // kept contract → both clamps are
        const int ns = std::clamp (numSamples,  0, maxBlock_);   //   no-ops; violated → no overrun
        for (int ch = 0; ch < nc; ++ch)
        {
            float* r = ring_.data()    + (std::size_t) ch * (std::size_t) C;
            float* s = scratch_.data() + (std::size_t) ch * (std::size_t) maxBlock_;
            const float* x = io[ch];
            int wp = pos_;
            for (int i = 0; i < ns; ++i)
            {
                r[wp] = x[i];                       // write freshest input
                int rp = wp - D; if (rp < 0) rp += C;
                s[i] = r[rp];                       // read the sample D samples ago (D == 0 → == input)
                if (++wp >= C) wp = 0;
            }
        }
        pos_ = (pos_ + ns) % C;                     // every channel advanced identically → one commit
    }

    const float* delayed (int channel) const noexcept
    {
        return scratch_.data() + (std::size_t) channel * (std::size_t) maxBlock_;
    }

private:
    std::vector<float> ring_    { 0.0f, 0.0f };   // circular delay history (capacity ≥ any stage latency);
    std::vector<float> scratch_ { 0.0f };         //   default-VALID mono delay-0 state until prepare()
    int channels_ = 1, cap_ = 2, maxBlock_ = 1;
    int pos_ = 0;                                 // shared write cursor into ring_
};

} // namespace felitronics::core
