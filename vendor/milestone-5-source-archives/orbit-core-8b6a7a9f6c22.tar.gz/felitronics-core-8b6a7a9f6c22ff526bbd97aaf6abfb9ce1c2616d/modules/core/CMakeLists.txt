# felitronics::core — Sample alias + size config (SSOT), Math, Smoother, software denormal flush
# (+ optional desktop ScopedFlushToZero). Header-only, zero deps — the shared base.
add_library(felitronics_core INTERFACE)
add_library(felitronics::core ALIAS felitronics_core)
target_include_directories(felitronics_core INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_features(felitronics_core INTERFACE cxx_std_20)

if(FELITRONICS_BUILD_TESTS)
    add_executable(felitronics_core_tests tests/CoreTests.cpp)
    target_link_libraries(felitronics_core_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_tests COMMAND felitronics_core_tests)

    # P56 — the ONE polyphase FIR inner product. Its suite carries the cross-row bit constant, so it is
    # the test that goes red when a row loses the no-contraction pragma or the summation order moves.
    add_executable(felitronics_core_polyphasefir_tests tests/PolyphaseFirTests.cpp)
    target_link_libraries(felitronics_core_polyphasefir_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_polyphasefir_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_polyphasefir_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_polyphasefir_tests COMMAND felitronics_core_polyphasefir_tests)

    add_executable(felitronics_core_detmath_tests tests/DetMathTests.cpp)   # the deterministic transcendental floor
    target_link_libraries(felitronics_core_detmath_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_detmath_tests PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/../../test_support ${CMAKE_CURRENT_SOURCE_DIR}/tests)
    target_compile_features(felitronics_core_detmath_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_detmath_tests COMMAND felitronics_core_detmath_tests)

    add_executable(felitronics_core_fft_tests tests/FftTests.cpp)
    target_link_libraries(felitronics_core_fft_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_fft_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_fft_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_fft_tests COMMAND felitronics_core_fft_tests)

    add_executable(felitronics_core_streamresampler_tests tests/StreamResamplerTests.cpp)   # streaming polyphase windowed-sinc rate-match (from OrbitCab; was Catmull-Rom until P34)
    target_link_libraries(felitronics_core_streamresampler_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_streamresampler_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_streamresampler_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_streamresampler_tests COMMAND felitronics_core_streamresampler_tests)

    add_executable(felitronics_core_streamresampler_theory_tests tests/StreamResamplerTheoryTests.cpp)   # theory-first falsification suite (contract + DSP theory)
    target_link_libraries(felitronics_core_streamresampler_theory_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_streamresampler_theory_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_streamresampler_theory_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_streamresampler_theory_tests COMMAND felitronics_core_streamresampler_theory_tests)

    add_executable(felitronics_core_streamresampler_lptv_tests tests/StreamResamplerLptvTests.cpp)   # the phase-dependent-kernel COST, cubic vs sinc: carrier, modulation, period closure, decimation stopband
    target_link_libraries(felitronics_core_streamresampler_lptv_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_streamresampler_lptv_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_streamresampler_lptv_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_streamresampler_lptv_tests COMMAND felitronics_core_streamresampler_lptv_tests)

    add_executable(felitronics_core_streamresampler_falsify_tests tests/StreamResamplerFalsifyTests.cpp)   # adversarial falsification pass (external cases + precision attacks)
    target_link_libraries(felitronics_core_streamresampler_falsify_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_streamresampler_falsify_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_streamresampler_falsify_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_streamresampler_falsify_tests COMMAND felitronics_core_streamresampler_falsify_tests)

    # P57 — the rational L:M DELIVERY resampler. Contract + planner + latency + round-trip NULL.
    add_executable(felitronics_core_deliveryresampler_tests tests/DeliveryResamplerTests.cpp)
    target_link_libraries(felitronics_core_deliveryresampler_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_deliveryresampler_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_deliveryresampler_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_deliveryresampler_tests COMMAND felitronics_core_deliveryresampler_tests)

    # P57 — THE BAR: stopband and passband flatness measured through the converter on all 30 pairs.
    add_executable(felitronics_core_deliveryresampler_bar_tests tests/DeliveryResamplerBarTests.cpp)
    target_link_libraries(felitronics_core_deliveryresampler_bar_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_deliveryresampler_bar_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_deliveryresampler_bar_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_deliveryresampler_bar_tests COMMAND felitronics_core_deliveryresampler_bar_tests)

    add_executable(felitronics_core_dryaligner_tests tests/DryAlignerTests.cpp)   # PDC-aligned dry ring (bit-exact gate)
    target_link_libraries(felitronics_core_dryaligner_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_dryaligner_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_dryaligner_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_dryaligner_tests COMMAND felitronics_core_dryaligner_tests)

    add_executable(felitronics_core_dryaligner_theory_tests tests/DryAlignerTheoryTests.cpp)   # theory-first falsification (fuzz vs independent reference)
    target_link_libraries(felitronics_core_dryaligner_theory_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_dryaligner_theory_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_dryaligner_theory_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_dryaligner_theory_tests COMMAND felitronics_core_dryaligner_theory_tests)

    add_executable(felitronics_core_dryaligner_falsify_tests tests/DryAlignerFalsifyTests.cpp)
    target_link_libraries(felitronics_core_dryaligner_falsify_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_dryaligner_falsify_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_dryaligner_falsify_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_dryaligner_falsify_tests COMMAND felitronics_core_dryaligner_falsify_tests)

    add_executable(felitronics_core_flushpoison_theory_tests tests/FlushPoisonTheoryTests.cpp)   # theory-first falsification: flushPoison/flushDenormal contract
    target_link_libraries(felitronics_core_flushpoison_theory_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_flushpoison_theory_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_flushpoison_theory_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_flushpoison_theory_tests COMMAND felitronics_core_flushpoison_theory_tests)

    add_executable(felitronics_core_flushpoison_falsify_tests tests/FlushPoisonFalsifyTests.cpp)
    target_link_libraries(felitronics_core_flushpoison_falsify_tests PRIVATE felitronics::core)
    target_include_directories(felitronics_core_flushpoison_falsify_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
    target_compile_features(felitronics_core_flushpoison_falsify_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_core_flushpoison_falsify_tests COMMAND felitronics_core_flushpoison_falsify_tests)

    # The wasm tier under Eigen's SSE flags. A consumer that wants Eigen's SSE path in wasm (NAM) builds with
    # -msimd128 -msse4.1, and emscripten then defines __SSE2__ — which once sent FlushToZero.h to a _mm_setcsr
    # wasm does not have, so no TU including it compiled. Building this target is the gate; running it pins
    # that ScopedFlushToZero stays a no-op there and the software flush still covers denormals (law 8).
    # Emscripten only: natively these flags are just x86 flags, which the desktop rows already build.
    if(EMSCRIPTEN)
        add_executable(felitronics_core_wasm_sse_tests tests/WasmSseTests.cpp)
        target_link_libraries(felitronics_core_wasm_sse_tests PRIVATE felitronics::core)
        target_include_directories(felitronics_core_wasm_sse_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
        target_compile_features(felitronics_core_wasm_sse_tests PRIVATE cxx_std_20)
        target_compile_options(felitronics_core_wasm_sse_tests PRIVATE -msimd128 -msse4.1)
        add_test(NAME felitronics_core_wasm_sse_tests COMMAND felitronics_core_wasm_sse_tests)
    endif()

    # RT swap-discipline types — a suite that needs REAL threads (convolution's restart race is the other), so
    # it is outside the `wasm-audio` tier by construction: that tier is single-threaded by contract (no
    # pthreads, no SharedArrayBuffer, no COOP/COEP). Emscripten does NOT refuse this build without -pthread — it
    # links pthread stubs whose pthread_create returns ENOTSUP, so the target would compile, link, and abort at
    # runtime. Excluding it here says so once, instead of leaving a permanently red test that means nothing.
    if(NOT EMSCRIPTEN)
        add_executable(felitronics_core_rtstreams_tests tests/RtStreamsTests.cpp)
        target_link_libraries(felitronics_core_rtstreams_tests PRIVATE felitronics::core)
        target_include_directories(felitronics_core_rtstreams_tests PRIVATE ${felitronics_core_SOURCE_DIR}/test_support)
        target_compile_features(felitronics_core_rtstreams_tests PRIVATE cxx_std_20)
        find_package(Threads REQUIRED)
        target_link_libraries(felitronics_core_rtstreams_tests PRIVATE Threads::Threads)
        add_test(NAME felitronics_core_rtstreams_tests COMMAND felitronics_core_rtstreams_tests)
    endif()
endif()
