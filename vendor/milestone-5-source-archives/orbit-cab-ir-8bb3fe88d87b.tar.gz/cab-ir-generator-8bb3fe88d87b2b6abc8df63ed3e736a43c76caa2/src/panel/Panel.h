// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko <oleh@darwinscat.com> & Alisa Lafoks <alisa@darwinscat.com>. Part of Orbit Bass Cab Builder and Orbit Guitar Cab Builder — see LICENSE.

#pragma once

#include "ui/Ui.h"

#include <array>
#include "../synth/Response.h"
#include "../synth/State.h"
#include <panel/HelpText.h>   // made by the build from data/help.txt, data/guitar/help.txt

#include <functional>
#include <optional>
#include <string>
#include <vector>

namespace cabir
{

/** THE BASS'S CABINETS, DRAWN — one panel, the boxes at the left and the chosen one's speaker at the right.

    THE PILE: a box of each size, no maker's name over them (the owner, 05.11), to scale and stacked as a backline stands
    them, the small on the big; each with its speakers, its horn and its port where it has them; the chosen box's size
    big at their top left; under them DOWNLOAD IR, the cabinet that plays saved as a file; over them its BACK, CLOSED, PORTED or
    OPEN, each the box drawn cut through from the side, a click each — the back goes on from box to box unchanged, as
    the mics do, the box's own marked by a dot and DEFAULT's to go back to (the owner, 05.11); a sealed one turned
    ported gets a port at its foot. Every bass of the family offers the same ten (the owner, 05.11): none knows a
    cabinet of its own.
    A click on a box picks it, the mics staying where they stand, and the horn too — but a box whose horn comes off
    (Cab::hornOn, the 1x15-classic's and the 8x10's) takes it off, and the next box puts it back; a click on the chosen box's
    horn turns the horn off and on, its step kept.

    THE SPEAKER: the chosen box's first speaker, flat, its neighbours at its edge, its horn big in the corner on the horn's
    side — the speaker moved away from it — and beside it HORN's attenuator, OFF -12 -6 0; the mics in perspective on
    the speaker, each taken by any part of it, its capsule or its body, and dragged from where the hand took it across
    the speaker and just past its rim — a click on the bare cone moves none (the owner, 05.11); the hand on a mic brings
    its distance, a track beside it, and its angle, a knob on an arc over it — not there otherwise (the owner, 07.11);
    their two columns either side, each its mic and its places (CAP, EDGE, OFF, one click each), B's ALIGN, Ø and TIME;
    BLEND a track along the speaker's foot, the guitar's speakers a row of their curves over it; and two buttons: DEFAULT, the
    box's own mic back at its cap — SURE? at the first click, done at the second — and CLOSE. A mic's row clicked again
    while both are heard turns that mic off where it stands, its column dark, BLEND left where it is and not heard while
    one mic is (the owner, 04.11); a click in the dark column brings it back; the last one stays. While the hand moves,
    the cabinet is heard as it goes (onMove) — each position the worker reaches next, a tenth of a second for one mic,
    near a second for two on the 8x10 — and what is set is kept when the hand lets go (onSetup).

    UNDER THE HAND whatever a click there works is lit (the owner, 05.11): a box and a back framed, a word brighter, a
    button's line, a mic on the speaker ringed at its capsule — the same test the click goes by (hotAt).

    THE RESPONSE, across the panel under it all: what plays, 30 Hz to 12 kHz — the cabinet heard, following a moving
    hand, green where it is fine and red where it falls into a pit or its two mics cancel (the owner, 05.11), and the
    one kept before it a faint grey ghost, so every click and every drag reads as before and after; with two mics
    heard, green under it where they add in phase and red where they cancel.

    A dumb view: the cabinets in (cabs(), geometry from data/cabinets.txt — metres, the baffle's centre the
    origin, up positive), what plays in (show, showResponse), a pick out (onSetup). */
class Panel final
{
public:
    Panel() = default;

    // ---------------------------------------------------------------- what a host gives it
    // Its size, a call to draw it again, and the time — ticked about thirty times a second while it wants frames (DOWNLOAD
    // IR's pulse, the search map's fade, DEFAULT's question running out). A host draws it with paint and hands it the
    // hand's moves; JUCE's CabPicker is one host, the page's module another.
    void setSize (int width, int height) { wide = width; high = height; repaint(); }
    int getWidth() const { return wide; }
    int getHeight() const { return high; }
    ui::Rectangle<int> getLocalBounds() const { return { 0, 0, wide, high }; }
    std::function<void()> onRepaint;
    std::function<void (ui::Rectangle<int>)> onRepaintArea;   // ...or only a part, where it can say which

    void tick (double nowSeconds)
    {
        const double dt = clock > 0.0 ? ui::jlimit (0.0, 0.05, nowSeconds - clock) : 0.0;   // a long pause counts one frame
        clock = nowSeconds;
        if (defaultArmed && clock >= armedUntil)
            disarmDefault();
        timerCallback();
        stepMicZoom (dt);
        stepBackZoom (dt);
        stepHandles (dt);
        stepResponseFade (dt);
        stepHelp (dt);
        if (wheelUntil > 0.0 && clock >= wheelUntil)   // the wheel stopped: the width it left kept
        {
            wheelUntil = 0.0;
            send();
        }
    }

    /** True while something moves on its own: a host ticks it then, and need not otherwise. */
    bool wantsFrames() const
    {
        return ! downloadArea().isEmpty() || searchFade > 0.0f || defaultArmed || zoomMoving() || backZoomMoving()
            || (handlesOf >= 0 && ! handHolds) || responseFading() || (helpOpen >= 0 && ! helpPinned && ! helpHeld) || wheelUntil > 0.0;
    }

    /** The size it is drawn for — small enough to open over a cabin's face too. */
    static constexpr int panelW = 960, panelH = 472;   // 960 x 540 the app's, its header and strip round it: 16:9 (the owner, 07.11)

    struct Spot
    {
        float x = 0.0f, y = 0.0f, distance = 0.05f;   // across the first speaker in radii from the cap; in front of it, m
        bool horn = true;
        ui::String mic;                             // one of mics(), or empty for the cabinet's own
        float angle = 0.0f;                           // degrees it leans back toward the cap
        float hornDb = 0.0f;                          // the horn's attenuator while it is on: 0, -6, -12 (A's counts)
    };

    /** Two mics on the box (the engine's setup, as a host keeps it), each on or off: both on, B mixed into A by `blend` on one clock
        unless `align`, B turned over by `invert`; one on, that one alone, and `blend` not heard. The horn is A's. ALIGN
        from the start: two mics at two distances, unaligned, comb — rarely what a second mic is put up for. */
    struct Setup
    {
        Spot a { -0.3f, 0.0f, 0.05f, true, {} }, b { 0.4f, 0.0f, 0.25f, true, "u87" };   // A a little left of the cap, B right of it
        float blend = 0.5f;
        bool align = true, invert = false;
        bool aOn = true, bOn = false;
        int back = -1;   // the box's back as the player turned it — an index of backWords — or -1, the box's own (ownBack)
        float shiftMs = 0.0f;   // B moved in time against A, ms, later positive (TIME)
        int speaker = -1;   // the box's speaker as the player turned it — an index of the catalog's speakers — or -1, its own
        bool wall = false;  // the wall behind the box, the guitar's switch (WALL)
        bool cone = false;  // the speakers' cone as the catalog's variant has it (the guitar's PAPER, SPEAKER clicked)
        int room = -1;      // the room round the box — an index of the catalog's rooms — or -1, none (ROOM's OFF)
        Eq eq;              // the player's EQ, over the response (synth/State.h)
    };

    struct Cab
    {
        ui::String name;                       // as the table names it: "4x10-classic"
        int family = 0;                          // whose box it is, for its corners: 1 the rounded ones
        float w = 0.6f, h = 0.6f;                // the baffle
        std::vector<ui::Point<float>> drivers; // the first is the one the mic stands at
        float radius = 0.105f;                   // a cone's radiating radius
        bool horn = false;
        ui::Point<float> hornAt;
        bool port = false;
        ui::Point<float> portAt;
        ui::String mic = "md421";              // the one its table's cap section stands
        bool hornOn = true;                      // how its horn comes when the box is picked: the 1x15-classic's and the 8x10's off
        ui::String speaker;                      // its own speaker, one of the catalog's — empty where it offers none (the bass's)
    };

    /** WHAT A PANEL OFFERS: its boxes, how they stand, its mics, and which boxes the table seals and which it leaves open.
        The bass's (bassCatalog) unless a host hands it another before it draws one (useCatalog): the guitar's app hands
        its own (GuitarCatalog.h). One for the whole program — every panel and every static below reads it. */
    struct Catalog
    {
        std::vector<Cab> cabs;
        // The boxes it offers, as they stand: its columns left to right, each from the floor up. The table's other boxes
        // stay in cabs: a state that kept one still reads as its size.
        std::vector<ui::StringArray> pile;
        // The mics to choose from, as the table names them (its "mic-<name>" sections), and as the columns write them.
        ui::StringArray mics, micWords;
        // The boxes the table calls sealed and open (its `alignment`); every other one is ported.
        ui::StringArray sealed, open;
        // The speakers to choose from, as the table names them (its "speaker-<name>" sections), and as their row writes
        // them — the guitar's; none, no row (the bass's).
        ui::StringArray speakers, speakerWords;
        // The boxes whose own back is half closed (`alignment = half`), and the back's cells left to right by synth::Back
        // — none said, CLOSED PORTED OPEN (the bass's); the guitar's has HALF too.
        ui::StringArray half;
        std::vector<int> backRow;
        // WALL under BACK, the switch for a wall behind the box (the guitar's): false, none (the bass's).
        bool wallSwitch = false;
        // The speakers' other cone, its table's "speaker-<name>-<variant>" sections — SPEAKER itself the switch, lit
        // where it is on (the guitar's "paper"); empty, none.
        ui::String coneVariant;
        // How far a mic goes and where ROOM puts it: the bass's 30 cm, the guitar's a metre and a half, ROOM at one.
        float farthestCm = 30.0f, roomM = 0.30f;
        // The rooms round the box, as the table names them (its "room-<name>" sections), and as their row writes them after
        // OFF — the guitar's; none, no row (the bass's).
        ui::StringArray rooms, roomWords;
        // Where the response's line reddens with a pit, dB — the bass's 3; the guitar's 7, its speakers' own dips deeper
        // (the owner, 07.11 at 5; 08.11 at 7, as measured cabinets keep them). The table says the same (pit_red_db, synth::pitRedOf) for FIND and the tools.
        float pitRedDb = 3.0f;
        // Where its line reddens with a comb from 2 kHz up, dB — the bass's 3, as under it; the guitar's 6, a comb up there a
        // tone of its own (the owner, 07.11). The table says the same (comb_top_red_db, synth::combTopRedOf).
        float combTopRedDb = 3.0f;
        // Its name as a watermark across the response, so it reads at a glance which builder this is (the owner, 07.11).
        ui::String instrumentWord = "BASS CAB";
        // What its "?" say, a section each (helpSpot): its help file's text, the bass's data/help.txt, the guitar's
        // data/guitar/help.txt, baked in by the build.
        const char* help = helpText::bass;
        // FRED under FIND, one click to the Fredman pair (fredman) — the guitar's (the owner, 09.11); false, none (the bass's).
        bool fred = false;
    };

    static const Catalog& bassCatalog()
    {
        using P = ui::Point<float>;
        static const Catalog bass {
          {
            { "1x15-classic",   0, 0.61f, 0.56f, { P (0, 0.02f) }, 0.165f, true, P (0.22f, 0.20f), true, P (0, -0.22f), "re20", false },
            { "2x10-classic-tall",  0, 0.33f, 0.61f, { P (0, 0.14f), P (0, -0.14f) }, 0.105f, false, {}, false, {} },
            { "2x10-classic",  0, 0.61f, 0.46f, { P (-0.14f, 0), P (0.14f, 0) }, 0.105f, true, P (0, 0.16f), false, {} },
            { "4x10-classic",  0, 0.61f, 0.66f, { P (-0.145f, 0.145f), P (0.145f, 0.145f), P (-0.145f, -0.145f), P (0.145f, -0.145f) },
              0.105f, true, P (0, 0), false, {} },
            { "4x10-classic-tall", 0, 0.61f, 0.76f, { P (-0.145f, 0.19f), P (0.145f, 0.19f), P (-0.145f, -0.10f), P (0.145f, -0.10f) },
              0.105f, true, P (0, 0.045f), true, P (0, -0.31f) },
            { "6x10-classic", 0, 0.61f, 1.02f, { P (-0.145f, 0.32f), P (0.145f, 0.32f), P (-0.145f, 0.03f), P (0.145f, 0.03f),
                                                P (-0.145f, -0.26f), P (0.145f, -0.26f) },
              0.105f, true, P (0, 0.175f), true, P (0, -0.45f) },
            { "8x10-classic",    0, 0.66f, 1.22f, { P (-0.15f, 0.42f), P (0.15f, 0.42f), P (-0.15f, 0.14f), P (0.15f, 0.14f),
                                                P (-0.15f, -0.14f), P (0.15f, -0.14f), P (-0.15f, -0.42f), P (0.15f, -0.42f) },
              0.105f, true, P (0, 0.565f), false, {}, "re20", false },
            { "1x12-round",     1, 0.52f, 0.40f, { P (-0.09f, 0) }, 0.13f, true, P (0.17f, 0.08f), true, P (0.17f, -0.12f) },
            { "1x15-round",     1, 0.56f, 0.58f, { P (0, -0.04f) }, 0.165f, true, P (0.18f, 0.19f), true, P (0, -0.25f), "d112" },
            { "2x10-round",     1, 0.56f, 0.42f, { P (-0.135f, -0.02f), P (0.135f, -0.02f) }, 0.105f, true, P (0, 0.13f), true, P (0, -0.17f) },
            { "2x12-round",     1, 0.63f, 0.48f, { P (-0.155f, -0.02f), P (0.155f, -0.02f) }, 0.13f, true, P (0, 0.16f), true, P (0, -0.19f) },
            { "4x10-round",     1, 0.58f, 0.66f, { P (-0.14f, 0.145f), P (0.14f, 0.145f), P (-0.14f, -0.145f), P (0.14f, -0.145f) },
              0.105f, true, P (0, 0), true, P (0, -0.30f) },
            { "8x8-round",      1, 0.56f, 0.98f, { P (-0.13f, 0.33f), P (0.13f, 0.33f), P (-0.13f, 0.11f), P (0.13f, 0.11f),
                                                P (-0.13f, -0.11f), P (0.13f, -0.11f), P (-0.13f, -0.33f), P (0.13f, -0.33f) },
              0.085f, true, P (0, 0), true, P (0, -0.45f) },
            { "1x15-plain",     2, 0.60f, 0.66f, { P (0, 0.03f) }, 0.165f, false, {}, false, {}, "d112" },
            { "2x10-plain",     2, 0.60f, 0.40f, { P (-0.14f, 0), P (0.14f, 0) }, 0.105f, false, {}, false, {} },
            { "4x10-plain",     2, 0.64f, 0.64f, { P (-0.15f, 0.15f), P (0.15f, 0.15f), P (-0.15f, -0.15f), P (0.15f, -0.15f) },
              0.105f, false, {}, false, {} },
            { "8x10-plain",     2, 0.64f, 1.24f, { P (-0.15f, 0.43f), P (0.15f, 0.43f), P (-0.15f, 0.145f), P (0.15f, 0.145f),
                                                P (-0.15f, -0.145f), P (0.15f, -0.145f), P (-0.15f, -0.43f), P (0.15f, -0.43f) },
              0.105f, false, {}, false, {}, "re20" },
            { "4x10-neo",  3, 0.59f, 0.60f, { P (-0.14f, 0.16f), P (0.14f, 0.16f), P (-0.14f, -0.10f), P (0.14f, -0.10f) },
              0.105f, true, P (0, 0.03f), true, P (0, -0.265f) },
            { "2x10-neo",  3, 0.59f, 0.475f, { P (-0.14f, -0.03f), P (0.14f, -0.03f) }, 0.105f, true, P (0, 0.16f), true, P (0, -0.20f) },
            { "1x15-neo",  3, 0.59f, 0.65f, { P (0, -0.04f) }, 0.165f, true, P (0, 0.23f), false, {}, "d112" },
            { "4x6-neo",     3, 0.40f, 0.40f, { P (-0.09f, 0.07f), P (0.09f, 0.07f), P (-0.09f, -0.11f), P (0.09f, -0.11f) },
              0.06f, true, P (0, 0.165f), false, {} },
            { "2x12-neo",     3, 0.72f, 0.39f, { P (-0.17f, -0.01f), P (0.17f, -0.01f) }, 0.13f, true, P (0, 0.14f), false, {} },
            { "1x12-light", 4, 0.49f, 0.39f, { P (-0.06f, -0.01f) }, 0.13f, true, P (0.17f, 0.10f), true, P (0.17f, -0.13f) },
            { "1x15-light", 4, 0.49f, 0.49f, { P (0, -0.03f) }, 0.165f, true, P (0.17f, 0.19f), true, P (-0.17f, -0.21f), "d112" },
            { "2x10-light", 4, 0.49f, 0.53f, { P (-0.11f, 0.12f), P (0.11f, -0.11f) }, 0.105f, true, P (0.13f, 0.17f), true, P (-0.13f, -0.20f) },
            { "2x12-light", 4, 0.50f, 0.72f, { P (0, 0.13f), P (0, -0.19f) }, 0.13f, true, P (0, 0.31f), true, P (0.17f, -0.30f) },
            { "4x10-light", 4, 0.56f, 0.58f, { P (-0.13f, 0.15f), P (0.13f, 0.15f), P (-0.13f, -0.11f), P (0.13f, -0.11f) },
              0.105f, true, P (0, 0.02f), true, P (0, -0.26f) },
            { "2x15-light", 4, 0.49f, 0.87f, { P (0, 0.20f), P (0, -0.16f) }, 0.165f, true, P (0, 0.40f), true, P (0, -0.38f), "d112" },
          },
            // A box of each size, no maker's name over them (the owner, 05.11) — the small on the big, the tall ones
            // alone, the way a backline is stacked. Every size the table holds — 1x15, 1x12, 8x10, 4x10, 2x10, 6x10,
            // 2x12, 2x15, 4x6, 8x8 — the same for every bass of the family (the owner, 05.11).
          { { "1x15-classic", "1x12-round" }, { "8x10-classic" }, { "4x10-classic", "2x10-round" }, { "6x10-classic", "2x12-round" },
            { "2x15-light", "4x6-neo" }, { "8x8-round" } },
          { "md421", "sm57", "re20", "d112", "u87", "u47", "ribbon" },
          { "MD421", "SM57", "RE20", "D112", "U87", "U47", "RIBB" },
          { "2x10-classic-tall", "4x10-classic", "8x10-classic", "1x15-plain", "2x10-plain", "4x10-plain", "8x10-plain" },
          {} };
        return bass;
    }

    /** The catalog every panel draws from here on: before the first is made, and once — a program offers one set. */
    static void useCatalog (const Catalog& c) { current() = &c; }
    static const Catalog& catalog() { return *current(); }
private:
    static const Catalog*& current() { static const Catalog* c = &bassCatalog(); return c; }
public:

    static const std::vector<Cab>& cabs() { return catalog().cabs; }
    static const std::vector<ui::StringArray>& pile() { return catalog().pile; }
    static const ui::StringArray& mics() { return catalog().mics; }
    static const ui::StringArray& micWords() { return catalog().micWords; }

    /** A BOX AS THE PLAYER READS IT: its speakers and their size — "4x10" — and no maker's model (the owner, 05.11). The
        table's name stays the key a state keeps. */
    static ui::String wordOf (int cab)
    {
        const auto& c = cabs()[(size_t) cab];
        const int inches = c.radius > 0.15f ? 15 : c.radius > 0.12f ? 12 : c.radius > 0.095f ? 10 : c.radius > 0.07f ? 8 : 6;
        return ui::String ((int) c.drivers.size()) + "x" + ui::String (inches);
    }

    /** The boxes the table calls sealed (data/cabinets.txt, `alignment`). */
    static bool sealed (const ui::String& name) { return catalog().sealed.contains (name); }

    /** THE BOX'S BACK, as its switch is marked — a click each, the one it stands at in the block's orange; the index the
        engine's (synth::Back). A box comes with its own (ownBack) until one is turned, and that one stays from
        box to box; turned, a sealed one gets a port at its foot. */
    static constexpr const char* backWords[] { "CLOSED", "PORTED", "OPEN", "HALF" };
    static int backs() { return catalog().backRow.empty() ? 3 : (int) catalog().backRow.size(); }
    static int backAt (int cell) { return catalog().backRow.empty() ? cell : catalog().backRow[(size_t) cell]; }
    static int ownBackOf (const ui::String& name)
    {
        return sealed (name) ? 0 : catalog().open.contains (name) ? 2 : catalog().half.contains (name) ? 3 : 1;
    }
    static int ownBack (int cab) { return ownBackOf (cabs()[(size_t) cab].name); }
    static int backOf (int cab, const Setup& s) { return s.back >= 0 ? s.back : ownBack (cab); }

    /** THE BOX'S SPEAKER, the guitar's, as its row under the back is marked: the box's own (ownSpeaker) until one is
        turned, and that one stays from box to box, as the back does. -1 where the catalog offers none. */
    static bool hasSpeakers() { return ! catalog().speakers.isEmpty(); }
    static int ownSpeaker (int cab) { return cab < 0 ? -1 : catalog().speakers.indexOf (cabs()[(size_t) cab].speaker); }
    static int speakerOf (int cab, const Setup& s) { return s.speaker >= 0 ? s.speaker : ownSpeaker (cab); }

    /** Where a box's port is drawn: the table's, or the one a sealed box is given when turned ported — in the middle of
        its foot (synth::portAtFoot). */
    static ui::Point<float> portOf (const Cab& c) { return c.port ? c.portAt : ui::Point<float> (0.0f, -0.5f * c.h + 0.045f); }

    /** THE MICS A BOX IS PICKED WITH, `from` the one that was playing: where they stood — the same cap, the same
        centimetres, the way a cabinet is compared — only a mic never chosen following the box's own; the horn as it
        stood, unless the two boxes come with theirs otherwise (Cab::hornOn): the 1x15-classic's and the 8x10's go off, the
        next one's on — and the back as it stood: a box changed never changes it (the owner, 05.11), a back still the
        box's own becoming that one, said. A click in the pile picks by it. */
    static Setup pickedWith (int from, int to, Setup s)
    {
        if (s.back < 0 && from >= 0)
            s.back = ownBack (from);
        if (s.speaker < 0 && from >= 0)
            s.speaker = ownSpeaker (from);
        if (from < 0 || cabs()[(size_t) from].hornOn != cabs()[(size_t) to].hornOn)
            s.a.horn = cabs()[(size_t) to].hornOn;
        if (s.a.mic.isEmpty())
            s.a.mic = cabs()[(size_t) to].mic;
        return s;
    }

    /** THE STATE AND THE PANEL'S SETUP, one into the other (synth/State.h) — the horn and its step the panel keeps on
        A's spot. A state's box not in cabs() comes back as -1. */
    static std::pair<int, Setup> setupOf (const State& s)
    {
        const auto spot = [&s] (const Mic& m)
        { return Spot { (float) m.x, (float) m.y, (float) m.distance, s.horn, ui::String (m.model), (float) m.angle, (float) s.hornDb }; };
        return { indexOf (ui::String (s.box)), { spot (s.a), spot (s.b), (float) s.blend, s.align, s.invert, s.a.on, s.b.on, s.back,
                                                   (float) s.shiftMs, catalog().speakers.indexOf (ui::String (s.speaker)), s.wall,
                                                   ! s.cone.empty(), catalog().rooms.indexOf (ui::String (s.room)), s.eq } };
    }

    /** A STATE AS A LINE READS IT: its box's size, its back where turned from the box's own, and the mics heard —
        "4x10 · MD421", "4x10 PORTED · MD421+U87", B's alone with A off. */
    static ui::String labelOf (const State& s)
    {
        const int at = indexOf (ui::String (s.box));
        const auto word = [at] (const Mic& m)
        { return (m.model.empty() ? at >= 0 ? cabs()[(size_t) at].mic : ui::String() : ui::String (m.model)).toUpperCase(); };
        const int speaker = catalog().speakers.indexOf (ui::String (s.speaker));   // the guitar's, where turned from the box's own
        const auto box = at < 0 ? ui::String (s.box)
                       : wordOf (at) + (s.back >= 0 && s.back != ownBack (at) ? " " + ui::String (backWords[s.back]) : ui::String())
                             + (speaker >= 0 && speaker != ownSpeaker (at) ? " " + catalog().speakerWords[speaker] : ui::String())
                             + (s.wall ? " WALL" : "") + (s.cone.empty() ? ui::String() : " " + ui::String (s.cone).toUpperCase())
                             + (catalog().rooms.indexOf (ui::String (s.room)) >= 0
                                    ? " " + catalog().roomWords[catalog().rooms.indexOf (ui::String (s.room))] : ui::String());
        return box + ui::String::fromUTF8 (" \xc2\xb7 ")
             + (s.a.on ? word (s.a) : ui::String()) + (s.a.on && s.b.on ? "+" : "") + (s.b.on ? word (s.b) : ui::String());
    }

    static State stateOf (int cab, const Setup& su)
    {
        const auto mic = [] (const Spot& sp, bool on) { return Mic { on, sp.mic.toStdString(), sp.x, sp.y, sp.distance, sp.angle }; };
        State s;
        s.box = cabs()[(size_t) cab].name.toStdString();
        s.back = su.back;
        if (su.speaker >= 0 && su.speaker < catalog().speakers.size())
            s.speaker = catalog().speakers[su.speaker].toStdString();
        s.wall = su.wall;
        if (su.cone && ! catalog().coneVariant.isEmpty())
            s.cone = catalog().coneVariant.toStdString();
        if (su.room >= 0 && su.room < catalog().rooms.size())
            s.room = catalog().rooms[su.room].toStdString();
        s.horn = su.a.horn;
        s.hornDb = su.a.hornDb;
        s.a = mic (su.a, su.aOn);
        s.b = mic (su.b, su.bOn);
        s.blend = su.blend;
        s.align = su.align;
        s.invert = su.invert;
        s.shiftMs = su.shiftMs;
        s.eq = su.eq;
        return s;
    }

    static int indexOf (const ui::String& name)
    {
        for (int i = 0; i < (int) cabs().size(); ++i)
            if (cabs()[(size_t) i].name == name)
                return i;
        return -1;
    }

    /** What plays: a cabinet of cabs() and its mics — or none (an IR of the player's own, or the factory's). */
    void show (int cab, Setup setup)
    {
        if (dragging)
            return;   // the hand's, until it lets go
        chosen = cab;
        setup_ = setup;
        repaint();
    }

    std::function<void (int cab, Setup setup)> onSetup;

    /** A state the panel set on purpose, both mics where it put them (FRED): kept as onSetup is, but B turned on by it is
        not "taken up", so no search follows to move it. None, onSetup. */
    std::function<void (int cab, Setup setup)> onPlaced;

    /** The hand still moving: what it would sound like there, heard and not kept — onSetup follows when it lets go. */
    std::function<void (int cab, Setup setup)> onMove;

    /** CLOSE: whoever opened the panel takes it away. No button without it. */
    std::function<void()> onClose;

    /** DOWNLOAD IR: whoever opened the panel saves the cabinet that plays as a file — a button over the response's top
        right corner, its line pulsing gently. No button without it. */
    std::function<void()> onDownload;
    /** A host's format menu beside DOWNLOAD IR — rate, bits, length (the owner, 06.11) — its ▾ there only where this is
        set; and what the next download will be, said in a line under them. */
    std::function<void()> onDownloadFormat;
    ui::String downloadNote;
    /** Where the ▾ is, so a host anchors its menu there; empty where there is none. */
    ui::Rectangle<int> formatButton() const { return downloadFormatArea(); }

    /** WHERE A HOST'S HINT GOES (the site's rings over its live panel), in the panel's units, as it stands now: "cabinet",
        the boxes a click picks one in; "mic-a", mic A's glyph on the speaker as it leans — the speaker itself while A is
        not heard; "download", DOWNLOAD IR. Empty for another name, or for what the panel does not show. */
    ui::Rectangle<float> hintRect (const ui::String& name) const
    {
        if (name == "cabinet")
        {
            float x0 = 1e9f, y0 = 1e9f, x1 = -1e9f, y1 = -1e9f;
            for (const auto& column : pile())
                for (const auto& box : column)
                    if (const int i = indexOf (box); i >= 0)
                    {
                        const auto r = boxOf (i);
                        x0 = ui::jmin (x0, r.getX()); y0 = ui::jmin (y0, r.getY());
                        x1 = ui::jmax (x1, r.getRight()); y1 = ui::jmax (y1, r.getBottom());
                    }
            return x1 > x0 ? ui::Rectangle<float> { x0, y0, x1 - x0, y1 - y0 } : ui::Rectangle<float> {};
        }
        if (name == "mic-a" && chosen >= 0)
        {
            const auto o = coneCentre();
            const float R = radius();
            if (! heard (0))
                return { o.x - R, o.y - R, 2.0f * R, 2.0f * R };
            const auto gl = glyphOf (mic (0), o, R, 1.0f);
            const float c = std::cos (gl.lean), sn = std::sin (gl.lean);
            float x0 = 1e9f, y0 = 1e9f, x1 = -1e9f, y1 = -1e9f;
            const auto& g = gl.box;
            for (const auto& u : { ui::Point<float> (g.getX(), g.getY()), ui::Point<float> (g.getRight(), g.getY()),
                                   ui::Point<float> (g.getX(), g.getBottom()), ui::Point<float> (g.getRight(), g.getBottom()) })
            {
                const auto d = u - gl.at;   // as drawn: the upright glyph turned by its lean about its capsule
                const float x = gl.at.x + c * d.x - sn * d.y, y = gl.at.y + sn * d.x + c * d.y;
                x0 = ui::jmin (x0, x); y0 = ui::jmin (y0, y); x1 = ui::jmax (x1, x); y1 = ui::jmax (y1, y);
            }
            return { x0, y0, x1 - x0, y1 - y0 };
        }
        if (name == "download")
            return downloadArea().toFloat();
        return {};
    }

    /** WHETHER A PRESS AT `p` WOULD START A DRAG, as the panel stands now: a mic on the speaker, its distance track or angle
        knob while they are out, BLEND, B's TIME — so a touch screen's host knows, as the finger lands, that this touch is
        the panel's and not a scroll of its page. A click's things (a box, a back, a word) are not drags. */
    bool grabs (ui::Point<float> p) const
    {
        const auto part = hotAt (p).part;
        return part == Part::mic || part == Part::distance || part == Part::angle || part == Part::blend || part == Part::shift
            || part == Part::eqPass || part == Part::eqBell;
    }

    /** DEFAULT as a button in the foot — or not, where the host offers it another way (the app's preset menu). With
        neither DEFAULT nor CLOSE the foot's row goes, and the panel is footRowH shorter. */
    bool showDefault = true;
    static constexpr int footRowH = 26;

    /** FIND, asked of whoever opened the panel: with both mics heard where B combs least with A (synth::quietPlaceForB),
        with one where that one stands without a pit, about where it is (synth::smoothPlaceForMic, the owner, 05.11) — B
        is taken up by its column, and placed then on its own. No button without it. The search draws itself as it goes
        (showSearch) and lets go when it is done (endSearch). */
    std::function<void (int cab, Setup setup)> onFind;

    /** A place the search judged, across the first speaker in radii, and how much B there cancels against A — 0 none,
        the more negative the more: a dot on the speaker, green to red, the best of its distances. Message thread. */
    void showSearch (float x, float y, float score)
    {
        if (! searching)
        {
            searchDots.clear();
            searching = true;
        }
        searchFade = 1.0f;
        for (auto& d : searchDots)
            if (std::abs (d.x - x) < 1.0e-3f && std::abs (d.y - y) < 1.0e-3f)
            {
                d.score = ui::jmax (d.score, score);
                repaint();
                return;
            }
        searchDots.push_back ({ x, y, score });
        repaint();
    }

    /** ...and the search done: the map stays a moment, then fades. */
    void endSearch()
    {
        searching = false;
        searchEnded = -1.0;    // from the next tick: a second and a half held, then a second's fade, however often it comes
    }

    /** THE RESPONSE of what plays, in dB at responseHz — `now` the cabinet heard, `before` what was kept before it
        (empty, none): each level to its own middle, so the two read as shapes; and with two mics heard `comb`, where
        they meet: dB above nought where they add in phase, below where they cancel (empty, one mic). */
    static constexpr int responsePoints = synth::responsePoints;
    static float responseHz (int i) { return synth::responseHz (i); }

    void showResponse (std::vector<float> now, std::vector<float> before, std::vector<float> comb = {})
    {
        responseNow = std::move (now);
        responseBefore = std::move (before);
        responseComb = std::move (comb);
        // Pits judged in the cabinet, the EQ taken back out: a bell cut on purpose is no pit.
        auto cabinet = responseNow;
        if (const auto stages = synth::eqStages (setup_.eq); ! stages.empty() && (int) cabinet.size() == responsePoints)
            for (int i = 0; i < responsePoints; ++i)
                cabinet[(size_t) i] -= (float) synth::eqDb (stages, responseHz (i));
        responseBad = synth::pitsOf (cabinet);
        for (auto& b : responseBad)   // a pit judged from where this catalog's line reddens: the guitar's 7 dB, the bass's 3
            b = ui::jmax (0.0f, b - (catalog().pitRedDb - 3.0f));
        if (responseComb.size() == responseBad.size())
            for (size_t i = 0; i < responseBad.size(); ++i)   // from 2 kHz up as this catalog lets a comb cancel there
                responseBad[i] = ui::jmax (responseBad[i], -responseComb[i]
                                                             - (responseHz ((int) i) >= synth::combTopHz ? catalog().combTopRedDb - 3.0f : 0.0f));
        repaint (responseArea());
    }

    /** WHAT PLAYS, while the EQ is on (the owner, 09.11): its spectrum in dBFS at spectrumColumns points from 30 Hz to
        12 kHz, evenly on the log scale the response is drawn on — tilted as tabbyEQ tilts it — a wash under the curves;
        empty, none. A host with sound hands it in about thirty times a second; the page has none. */
    static constexpr int spectrumColumns = 360;
    static float spectrumHz (int i) { return 30.0f * std::pow (12000.0f / 30.0f, (float) i / (float) (spectrumColumns - 1)); }
    void showSpectrum (std::vector<float> db, std::vector<float> pre = {})
    {
        if (db.empty() && spectrumDb.empty() && pre.empty() && spectrumPreDb.empty())
            return;
        spectrumDb = std::move (db);
        spectrumPreDb = std::move (pre);   // ...and what goes into the cabinet, grey behind it, as tabbyEQ's pre
        repaint (responseArea());
    }
    bool eqOn() const { return chosen >= 0 && setup_.eq.on; }

    /** SPECTRUM (the owner, 09.11): what plays under the curves, the EQ on or off — a view of the player's, kept by the
        host between runs, nothing of the preset; switched in the host's menu alone, and drawn only where the host has sound. */
    bool hasSound = false;
    void setSpectrumOn (bool on)
    {
        spectrumWanted = on;
        if (! on)
        {
            spectrumDb.clear();
            spectrumPreDb.clear();
        }
        repaint (responseArea());
    }
    bool spectrumOn() const { return chosen >= 0 && spectrumWanted && hasSound; }

    /** A right click over the response (the owner, 09.11): the host's EQ menu — RESET EQ — where this is set. */
    std::function<void()> onEqMenu;
    /** EQ on or off, from the host's menu as from its switch. */
    void setEqOn (bool on)
    {
        if (chosen < 0 || setup_.eq.on == on)
            return;
        setup_.eq.on = on;
        send();
    }
    /** RESET EQ: its passes out at 12 dB an octave, its bells flat where they first stand; on or off as it was. */
    void resetEq()
    {
        if (chosen < 0)
            return;
        const bool on = setup_.eq.on;
        setup_.eq = {};
        setup_.eq.on = on;
        send();
    }


    void paint (ui::Graphics& g) const
    {
        paintPile (g);
        g.setColour (ui::look().hair);
        const float x = (float) leftW + 0.5f * gutter;
        g.fillRect (ui::Rectangle<float> (x, 0.0f, 1.0f, (float) bodyH()));
        g.fillRect (ui::Rectangle<float> (x, (float) (getHeight() - footHeight()), 1.0f, (float) footHeight()));
        paintSpeaker (g);
        paintResponse (g);
        paintMicZoom (g);
        paintHelp (g);
    }

    void mouseMove (const ui::MouseEvent& e)
    {
        const auto was = hot;
        hot = hotAt (e.position);
        if (hot.part == Part::micRow)   // the mic it grows big, as the hand comes on it — not a tick later
        {
            zoomM = hot.m;
            zoomI = hot.i;
        }
        if (backHot() >= 0)   // the cell it grows, as the hand comes on it
            backZoomI = backHot();
        overResponse = responseArea().toFloat().contains (e.position);
        keepHandles (e.position);
        keepHelp();
        if (hot != was)
            repaint();
    }

    void mouseExit (const ui::MouseEvent&)
    {
        hot = {};
        handlesOf = -1;
        handHolds = false;
        overResponse = false;
        helpHeld = helpQuiet = false;
        if (! helpPinned)
            helpOpen = -1;
        repaint();
    }

    void mouseDown (const ui::MouseEvent& e)
    {
        if (defaultArmed && ! defaultArea().contains (e.getPosition()))
            disarmDefault();   // a click anywhere else: DEFAULT's question withdrawn
        if (e.popup)
        {
            // A right click: over the response, the EQ's menu; anywhere else, nothing taken.
            if (chosen >= 0 && onEqMenu != nullptr && responseArea().contains (e.getPosition()))
                onEqMenu();
            return;
        }
        const auto h = hotAt (e.position);
        if (helpOpen >= 0 && h.part != Part::help && h.part != Part::helpBox)
            closeHelp();       // ...and a "?"'s window closed, the click going on to what it is on
        press (h, e);
    }

    void mouseDrag (const ui::MouseEvent& e)
    {
        if (chosen < 0 || drag == Drag::none)
            return;
        auto& m = mic (dragMic);
        if (drag == Drag::spot)
        {
            const auto o = coneCentre();
            const float R = radius();
            auto p = (e.position + grabOffset - o) / R;   // the capsule where it was against the hand: no jump to it
            micMoved = true;
            const float len = p.getDistanceFromOrigin();
            if (len > maxReach)
                p *= maxReach / len;
            m.x = p.x;
            m.y = -p.y;
        }
        else if (drag == Drag::distance)
        {
            const auto t = dragTrack;
            m.distance = minCm * std::pow (maxCm() / minCm, ui::jlimit (0.0f, 1.0f, (t.getBottom() - e.position.y) / t.getHeight())) / 100.0f;
        }
        else if (drag == Drag::angle)
        {
            // The knob round the capsule: straight up nought, out toward the mic's own side its lean.
            const auto d = e.position - spotOf (dragMic);
            const float deg = std::atan2 (leanSide (dragMic) * d.x, -d.y) * 180.0f / ui::MathConstants<float>::pi;
            m.angle = ui::jlimit (0.0f, maxAngle, deg);
        }
        else if (drag == Drag::shift)
        {
            const float v = (2.0f * along (timeTrack(), e.position.x) - 1.0f) * maxShiftMs;
            setup_.shiftMs = std::abs (v) < 0.03f * maxShiftMs ? 0.0f : v;   // a little stick at nought, where ALIGN leaves B
        }
        else if (drag == Drag::blend)
            setup_.blend = along (blendTrack(), e.position.x);
        else if (drag == Drag::eqPass)
        {
            // A pass along the frequencies, out at its own edge of the band (the high pass the left, the low the right).
            const auto p = responsePlot();
            const float x = e.position.x + grabOffset.x, hz = std::round (hzOfX (x));
            if (dragEq == 0)
                setup_.eq.highPassHz = x <= p.getX() + 3.0f ? 0.0 : (double) ui::jlimit (30.0f, maxHighPassHz, hz);
            else
                setup_.eq.lowPassHz = x >= p.getRight() - 3.0f ? 0.0 : (double) ui::jlimit (minLowPassHz, 12000.0f, hz);
            // ...and up and down its slope, a step each slopeStep px, up the steeper (the owner, 09.11).
            const int step = (int) std::lround ((grabY - e.position.y) / slopeStep);
            (dragEq == 0 ? setup_.eq.highPassSlope : setup_.eq.lowPassSlope) = passSlopes[ui::jlimit (0, 3, slopeIndex (grabSlope) + step)];
        }
        else if (drag == Drag::eqBell)
        {
            // A bell where the hand takes it: its frequency across, its gain up and down, a little stick at nought.
            auto& b = setup_.eq.bells[(size_t) dragEq];
            const auto at = e.position + grabOffset;
            b.hz = std::round (ui::jlimit (30.0f, 12000.0f, hzOfX (at.x)));
            const float db = ui::jlimit (-maxBellDb, maxBellDb, dbOfY (at.y));
            b.db = std::abs (db) < 0.5f ? 0.0 : std::round (db * 10.0f) / 10.0;
        }
        repaint();
        if (onMove != nullptr)
            onMove (chosen, setup_);
    }

    void mouseDoubleClick (const ui::MouseEvent& e)
    {
        if (const auto h = hotAt (e.position); h.part == Part::eqBell || h.part == Part::eqPass)
        {
            if (h.part == Part::eqBell)
                setup_.eq.bells[(size_t) h.i].db = 0.0;   // a bell flat again, where it stands
            else
                (h.i == 0 ? setup_.eq.highPassHz : setup_.eq.lowPassHz) = 0.0;   // a pass out
            send();
            return;
        }
        if (chosen >= 0 && timeTrack().expanded (2.0f, 10.0f).contains (e.position))
        {
            setup_.shiftMs = 0.0f;   // TIME back to where ALIGN leaves B
            send();
        }
        else if (chosen >= 0 && bothHeard() && blendTrack().expanded (8.0f, 8.0f).contains (e.position))
        {
            setup_.blend = 0.5f;     // BLEND back to the middle, the two even (the owner, 05.11)
            send();
        }
    }

    void mouseUp (const ui::MouseEvent& e)
    {
        if (drag != Drag::none)
        {
            // A mic taken and let go where it stood changes nothing: nothing kept, the ghost of before left as it was.
            const bool still = drag == Drag::spot && ! micMoved;
            drag = Drag::none;
            dragging = false;
            if (still)
                repaint();
            else
                send();
        }
        hot = hotAt (e.position);
        keepHandles (e.position);   // a mic tapped (a touch screen's, no hand hovering): its distance and angle come to it
        keepHelp();
    }

    /** The wheel over a bell: its width, narrower up (Q higher), heard as it turns and kept a moment after it stops. */
    void mouseWheelMove (const ui::MouseEvent& e, float deltaY)
    {
        const auto h = hotAt (e.position);
        if (h.part != Part::eqBell || deltaY == 0.0f)
            return;
        auto& b = setup_.eq.bells[(size_t) h.i];
        b.q = std::round (ui::jlimit (0.3, 8.0, b.q * std::pow (2.0, 4.0 * (double) deltaY)) * 100.0) / 100.0;
        hot = h;
        wheelUntil = clock + 0.4;
        repaint();
        if (onMove != nullptr)
            onMove (chosen, setup_);
    }

private:
    static constexpr float maxReach = 1.1f;    // how far from the cap the mic may go, in radii: just past the rim, in sight
    static constexpr float minCm = 1.0f, maxAngle = 60.0f;
    static float maxCm() { return catalog().farthestCm; }
    static constexpr int leftW = 466, gutter = 14;   // the pile's half; the hair between the halves
    static constexpr int footH = footRowH, responseH = 208;  // the foot's row under it all; the response's band over it
    int footHeight() const { return onClose != nullptr || showDefault ? footH : 0; }

    /** Down to the response's band: the pile, the columns and the speaker over it, the feet under it. */
    int bodyH() const { return getHeight() - footHeight() - responseH; }

    enum class Drag { none, spot, distance, angle, blend, shift, eqPass, eqBell };

    /** WHAT A CLICK AT A POINT WORKS — the one thing both the hand's light and its press go by (hotAt), so what is lit is
        what a click does. */
    enum class Part { none, download, downloadFormat, back, speaker, speakerCone, wall, room, cab, cabHorn, horn, distance, place, micRow, angle, shift, mic, close, reset, find,
                      fred, align, invert, blend, help, helpBox, eq, eqPass, eqBell };
    struct Hot
    {
        Part part = Part::none;
        int m = -1, i = -1;   // the mic's column; the box, the back, the step, the place or the row
        bool operator== (const Hot& o) const { return part == o.part && m == o.m && i == o.i; }
        bool operator!= (const Hot& o) const { return ! (*this == o); }
    };

    int chosen = -1;
    Hot hot;                          // under the hand while it moves with no button down
    int handlesOf = -1;               // the mic whose distance and angle are out on the speaker (keepHandles); -1 none
    ui::Point<float> grabOffset;      // a mic taken: its capsule against the hand, kept while it drags
    bool micMoved = false;            // ...and moved since, or let go where it stood
    bool isHot (Part p, int m = -1, int i = -1) const { return hot == Hot { p, m, i }; }

    /** A mic's distance and angle out on the speaker while the hand is on it, or on them — kept while it goes from the mic
        to its track or its knob anywhere round the three (handlesZone), and a moment more once it is out of there, so a
        hand on its way does not lose them (the owner, 07.11); another mic under the hand takes them. */
    static constexpr float handlesLinger = 0.4f;   // s
    bool handHolds = false;                         // the hand on the mic, its handles or round them
    float handlesLeft = 0.0f;                       // ...else how long they stay, counted down by the tick

    void keepHandles (ui::Point<float> p)
    {
        const int was = handlesOf;
        if (hot.part == Part::mic || hot.part == Part::distance || hot.part == Part::angle)
            handlesOf = hot.m;
        handHolds = handlesOf >= 0 && heard (handlesOf) && (hot.part == Part::mic || hot.part == Part::distance
                                                            || hot.part == Part::angle || handlesZone (handlesOf).contains (p));
        if (handHolds)
            handlesLeft = handlesLinger;
        if (handlesOf != was)
            repaint();
    }

    void stepHandles (double dt)
    {
        if (handlesOf < 0 || handHolds || drag != Drag::none)
            return;
        handlesLeft -= (float) dt;
        if (handlesLeft <= 0.0f)
        {
            handlesOf = -1;
            repaint();
        }
    }

    /** Round a mic and its handles: a square about its capsule as far as its knob and a little past — its glyph, however
        it leans, the arc and the knob in it — and its distance's track. */
    ui::Rectangle<float> handlesZone (int m) const
    {
        const auto at = spotOf (m);
        const float r = angleArcR (m) + 14.0f;
        const auto t = distHandle (m).expanded (12.0f, 8.0f);
        const float x0 = ui::jmin (at.x - r, t.getX()), y0 = ui::jmin (at.y - r, t.getY());
        const float x1 = ui::jmax (at.x + r, t.getRight()), y1 = ui::jmax (at.y + r, t.getBottom());
        return { x0, y0, x1 - x0, y1 - y0 };
    }

    /** ...the one shown: the hand's while it drags its track or knob, none while it moves a mic. */
    int handlesShown() const
    {
        if (drag == Drag::distance || drag == Drag::angle)
            return dragMic;
        return drag == Drag::none && handlesOf >= 0 && heard (handlesOf) ? handlesOf : -1;
    }

    /** A "?" AND ITS WINDOW (the owner, 07.11): the hand on the "?" opens it, and it stays while the hand is on either, a
        moment more once it is off them; a click keeps it open till a click anywhere else — a tap where no hand hovers, a
        touch screen's, the same. What it says is its section of the catalog's help text, plain paragraphs. */
    struct HelpSpot
    {
        const char* key;            // its section in the help text: [comb]
        ui::Rectangle<int> mark;    // the "?"
        ui::Rectangle<int> room;    // where its window opens: across it from the "?", up where it would run out
    };
    static constexpr int helpSpots = 1;
    static constexpr int helpMarkSize = 18, helpPad = 14, helpLineH = 18, helpGap = 8;
    static constexpr float helpLinger = 0.3f, helpTextSize = 13.0f;

    HelpSpot helpSpot (int) const
    {
        const auto r = responseArea();   // the response's corner, over its +10: what the comb is
        return { "comb", { r.getX() + 8, r.getY() + 3, helpMarkSize, helpMarkSize }, r };
    }

    int helpOpen = -1;          // the "?" whose window is out; -1 none
    bool helpPinned = false;    // ...kept open by a click
    bool helpHeld = false;      // the hand on the "?" or its window
    float helpLeft = 0.0f;      // ...else how long it stays, counted down by the tick
    bool helpQuiet = false;     // closed by a click on its "?": not opened again till the hand is off it

    void keepHelp()
    {
        const int was = helpOpen;
        const bool on = hot.part == Part::help || hot.part == Part::helpBox;
        if (! on)
            helpQuiet = false;
        if (hot.part == Part::help && ! helpQuiet && helpOpen != hot.i)
        {
            helpOpen = hot.i;
            helpPinned = false;
        }
        helpHeld = on && ! helpQuiet;
        if (helpHeld)
            helpLeft = helpLinger;
        if (helpOpen != was)
            repaint();
    }

    void closeHelp()
    {
        helpOpen = -1;
        helpPinned = helpHeld = false;
        repaint();
    }

    void stepHelp (double dt)
    {
        if (helpOpen < 0 || helpPinned || helpHeld)
            return;
        helpLeft -= (float) dt;
        if (helpLeft <= 0.0f)
            closeHelp();
    }

    /** The paragraphs of a help text's section: under its "[key]" to the next section, a blank line between two, the lines
        of one joined; a line from "#" a note, left out. */
    static std::vector<std::string> helpParagraphs (const char* text, const std::string& key)
    {
        std::vector<std::string> out;
        if (text == nullptr)
            return out;
        const std::string all (text);
        bool in = false, open = false;   // in its section; a paragraph begun
        for (size_t from = 0; from <= all.size();)
        {
            const size_t end = all.find ('\n', from), to = end == std::string::npos ? all.size() : end;
            std::string line = all.substr (from, to - from);
            from = to + 1;
            while (! line.empty() && (line.back() == '\r' || line.back() == ' ' || line.back() == '\t'))
                line.pop_back();
            line.erase (0, ui::jmin (line.size(), line.find_first_not_of (" \t")));
            if (! line.empty() && line.front() == '#')
                continue;
            if (line.size() > 1 && line.front() == '[' && line.back() == ']')
            {
                in = line.substr (1, line.size() - 2) == key;
                open = false;
                continue;
            }
            if (! in)
                continue;
            if (line.empty())
                open = false;
            else if (open)
                out.back() += " " + line;
            else
            {
                out.push_back (line);
                open = true;
            }
        }
        return out;
    }

    /** A "?"'s text wrapped to `width` as the host measures it: a line each, an empty one between two paragraphs — kept,
        as the hand's every move asks for its window. */
    struct HelpWrap { std::string key; int width = 0; std::vector<std::string> lines; };
    mutable HelpWrap helpWrap;

    const std::vector<std::string>& helpLines (int i, int width) const
    {
        const std::string key = helpSpot (i).key;
        if (helpWrap.key == key && helpWrap.width == width)
            return helpWrap.lines;
        helpWrap = { key, width, {} };
        const auto font = ui::look().font (helpTextSize);
        for (const auto& paragraph : helpParagraphs (catalog().help, key))
        {
            if (! helpWrap.lines.empty())
                helpWrap.lines.emplace_back();
            std::string line;
            for (size_t from = 0; from < paragraph.size();)
            {
                const size_t end = paragraph.find (' ', from), to = end == std::string::npos ? paragraph.size() : end;
                const std::string word = paragraph.substr (from, to - from);
                from = to + 1;
                if (word.empty())
                    continue;
                const std::string longer = line.empty() ? word : line + " " + word;
                if (! line.empty() && ui::look().trackedWidth (longer, font, 0.0f) > (float) width)
                {
                    helpWrap.lines.push_back (line);
                    line = word;
                }
                else
                    line = longer;
            }
            if (! line.empty())
                helpWrap.lines.push_back (line);
        }
        return helpWrap.lines;
    }

    /** Its window: from the "?" to its room's right, as high as its text; down from the "?", up as far as it must. */
    ui::Rectangle<int> helpBox (int i) const
    {
        const auto s = helpSpot (i);
        const int x = s.mark.getRight() + 8, w = s.room.getRight() - 12 - x;
        int h = 2 * helpPad - 4;
        for (const auto& line : helpLines (i, w - 2 * helpPad))
            h += line.empty() ? helpGap : helpLineH;
        const int y = ui::jmax (2, ui::jmin (s.mark.getY(), s.room.getBottom() - 3 - h));
        return { x, y, w, h };
    }

    int hoverCab() const { return hot.part == Part::cab || hot.part == Part::cabHorn ? hot.i : -1; }
    struct SearchDot { float x, y, score; };
    std::vector<SearchDot> searchDots;  // the search's map (showSearch), fading once it is done
    bool searching = false;
    float searchFade = 0.0f;
    double searchEnded = 0;            // the host's clock when it was done; -1 until the tick after

    /** A BACK'S CELL UNDER THE HAND (the owner, 07.11): the whole of it grown, the box cut through and its word, as a mic's
        name grows its glyph but less — 1.4 times, over about a tenth of a second, and back as fast; WALL's too. */
    static constexpr float backZoomBy = 0.4f, backZoomSeconds = 0.12f;
    float backZoom = 0.0f;               // 0 none .. 1 whole
    int backZoomI = -1;                  // the cell it shows — backs() for WALL — kept while it shrinks back
    int backHot() const { return chosen < 0 ? -1 : hot.part == Part::back ? hot.i : hot.part == Part::wall ? backs() : -1; }
    float backZoomTo() const { return backHot() >= 0 ? 1.0f : 0.0f; }
    bool backZoomMoving() const { return backZoom < backZoomTo() || backZoom > backZoomTo(); }
    int backZoomed() const { const int i = backHot() >= 0 ? backHot() : backZoomI; return backZoom > 0.0f ? i : -1; }

    void stepBackZoom (double dt)
    {
        if (backHot() >= 0)
            backZoomI = backHot();
        if (! backZoomMoving())
            return;
        const float to = backZoomTo(), by = (float) (dt / backZoomSeconds);
        backZoom = to > backZoom ? ui::jmin (to, backZoom + by) : ui::jmax (to, backZoom - by);
        repaint();
    }

    /** A MIC'S NAME UNDER THE HAND (the owner, 07.11): its glyph grown big beside it, left of the name — A's past its column,
        B's before its words — opaque, no box round it, growing in over about a sixth of a second and fading out as fast. */
    static constexpr float micZoomH = 120.0f, micZoomSeconds = 0.15f;
    float micZoom = 0.0f;               // 0 none .. 1 whole
    int zoomM = -1, zoomI = -1;          // the column and the mic it shows, kept while it fades
    float micZoomTo() const { return hot.part == Part::micRow ? 1.0f : 0.0f; }
    bool zoomMoving() const { return micZoom < micZoomTo() || micZoom > micZoomTo(); }

    void stepMicZoom (double dt)
    {
        if (hot.part == Part::micRow)
        {
            zoomM = hot.m;
            zoomI = hot.i;
        }
        const float to = micZoomTo(), by = (float) (dt / micZoomSeconds);
        if (! zoomMoving())
            return;
        micZoom = to > micZoom ? ui::jmin (to, micZoom + by) : ui::jmax (to, micZoom - by);
        repaint();
    }

    void paintMicZoom (ui::Graphics& g) const
    {
        // The one under the hand; the one it left while that fades.
        const int zm = hot.part == Part::micRow ? hot.m : zoomM, zi = hot.part == Part::micRow ? hot.i : zoomI;
        if (micZoom <= 0.0f || chosen < 0 || zm < 0 || zi < 0 || zi >= mics().size())
            return;
        const float e = micZoom * micZoom * (3.0f - 2.0f * micZoom);   // eased in and out
        const auto row = micRow (zm, zi).toFloat();
        const float h = 12.0f + (micZoomH - 12.0f) * e, w = h * 36.0f / 96.0f;   // the glyphs' own 36 x 96
        // Its backdrop clear of the words: A's out past its column's left edge, B's before the longest of its names.
        float longest = 0.0f;
        for (const auto& word : micWords())
            longest = ui::jmax (longest, ui::look().trackedWidth (word, ui::look().font (13.0f), 0.06f));
        const float right = zm == 0 ? row.getX() - 10.0f : row.getRight() - 12.0f - 8.0f - longest - 12.0f;
        const float top = ui::jlimit (6.0f, (float) bodyH() - 6.0f - h, row.getCentreY() - 0.5f * h);
        const ui::Rectangle<float> box (right - w, top, w, h);
        // No box round it: the mic itself opaque — its silhouette in the panel's colour first (MicSvgs.h's "-solid"), the
        // glyph over it — so what lies under it does not show through (the owner, 07.11).
        paintMicGlyph (g, mics()[zi] + "-solid", box, ui::look().panel.withMultipliedAlpha (e), 0.0f, {});
        const auto& sp = mic (zm);
        const auto heardBy = sp.mic.isNotEmpty() ? sp.mic : cabs()[(size_t) chosen].mic;
        const auto tint = mics()[zi] == heardBy ? colourOf (zm) : ui::look().tx;
        paintMicGlyph (g, mics()[zi], box, tint.withMultipliedAlpha (e), 0.0f, {});
    }

    void timerCallback()
    {
        if (const auto d = downloadArea(); ! d.isEmpty())
            repaint (d);
        if (searchFade <= 0.0f || searching)
            return;
        if (searchEnded < 0.0)
            searchEnded = clock;
        const double since = clock - searchEnded;
        if (since < 1.5)
            return;
        searchFade = (float) (1.0 - (since - 1.5));
        if (searchFade <= 0.0f)
        {
            searchFade = 0.0f;
            searchDots.clear();
        }
        repaint();
    }
    ui::Rectangle<float> dragTrack;   // the distance track a drag began on: the column's, or the one out on the speaker
    Setup setup_;
    bool dragging = false;
    Drag drag = Drag::none;
    int dragMic = 0;
    bool defaultArmed = false;   // DEFAULT asked SURE? and waits for its second click
    double armedUntil = 0;       // ...for three seconds
    int wide = panelW, high = panelH;
    double clock = 0;            // seconds, the host's (tick)

    void repaint() const { if (onRepaint != nullptr) onRepaint(); }
    void repaint (ui::Rectangle<int> r) const { if (onRepaintArea != nullptr) onRepaintArea (r); else repaint(); }

    void disarmDefault()
    {
        if (! defaultArmed)
            return;
        defaultArmed = false;
        repaint();
    }

    Spot& mic (int m) { return m == 0 ? setup_.a : setup_.b; }
    const Spot& mic (int m) const { return m == 0 ? setup_.a : setup_.b; }

    void send()
    {
        repaint();
        if (onSetup != nullptr && chosen >= 0)
            onSetup (chosen, setup_);
    }

    void toggleHorn()
    {
        setup_.a.horn = ! setup_.a.horn;
        send();
    }

    // ---------------------------------------------------------------- the pile
    // Over it the chosen box's back, in the room the pile leaves there (the owner, 05.11); under it the box's size.
    static constexpr int backTop = 6, backIconH = 40, nameH = footH;
    static constexpr int pileTop = backTop + backIconH + 6;
    // ...and under the back, where the catalog offers rooms, their row: the pile a row lower.
    static constexpr int speakerRowH = 24;
    static int pileTopNow() { return pileTop + (hasRooms() ? speakerRowH : 0); }

    ui::Rectangle<int> pileArea() const { return { 0, pileTopNow(), leftW, bodyH() - pileTopNow() - 2 }; }

    /** The line under the pile: DOWNLOAD IR at its right. */
    ui::Rectangle<int> nameRow() const { return { 0, getHeight() - nameH + 4, leftW, nameH - 4 }; }

    ui::Rectangle<int> downloadArea() const
    {
        if (onDownload == nullptr || chosen < 0)
            return {};
        const auto plot = responsePlot().toNearestInt();
        const int w = wordW ("DOWNLOAD IR") + 14, menu = onDownloadFormat != nullptr ? 24 + 4 : 0;
        return { plot.getRight() - w - menu - 6, plot.getY() + 6, w, 24 };
    }

    /** ...and its format's ▾ at its right, where a host offers one. */
    ui::Rectangle<int> downloadFormatArea() const
    {
        const auto d = downloadArea();
        if (onDownloadFormat == nullptr || d.isEmpty())
            return {};
        return { d.getRight() + 4, d.getY(), 24, d.getHeight() };
    }

    /** THE BACK over the pile, centred: a picture each, the box cut through from the side (paintBack), no words — under
        the hand it grows and its word comes under it, as a speaker's curve does (the owner, 07.11); WALL, the guitar's, a
        fifth, narrower, after them. */
    static constexpr float backCellW = 64.0f, backGap = 26.0f, wallCellW = 22.0f;     // a cell, the hand's
    static constexpr float backIconW = 56.0f, backIconHigh = 34.0f, wallIconW = 12.0f;  // the picture in it

    static float backRowW()
    {
        return (float) backs() * backCellW + (float) (backs() - 1) * backGap + (catalog().wallSwitch ? backGap + wallCellW : 0.0f);
    }

    ui::Rectangle<float> backCell (int i) const
    {
        const float x = 0.5f * ((float) leftW - backRowW()) + (float) i * (backCellW + backGap);
        return { x, (float) backTop, backCellW, (float) backIconH };
    }

    /** WALL, the guitar's: the fifth cell, after the backs. */
    ui::Rectangle<float> wallArea() const
    {
        return { backCell (backs() - 1).getRight() + backGap, (float) backTop, wallCellW, (float) backIconH };
    }

    /** THE SPEAKERS, the guitar's: a row of their curves along the speaker's top, each grown with its word under it
        while the hand is on it (the owner, 07.11) — the cone's switch after them where the catalog has a variant. */
    static constexpr float speakerIconW = 24.0f, speakerIconH = 14.0f, speakerIconGap = 9.0f, speakerRowTop = 4.0f;
    static constexpr int iconRowH = 24;   // the scene's top the row takes

    static int speakerIcons() { return catalog().speakers.size() + (catalog().coneVariant.isNotEmpty() ? 1 : 0); }

    /** Icon `i`, the cone's switch the last: -1 for it. */
    ui::Rectangle<float> speakerCell (int i) const
    {
        const auto sc = scene();
        const int n = speakerIcons(), k = i < 0 ? n - 1 : i;
        const float total = (float) n * speakerIconW + (float) (n - 1) * speakerIconGap;
        return { sc.getCentreX() - 0.5f * total + (float) k * (speakerIconW + speakerIconGap), sc.getY() + speakerRowTop + 2.0f,
                 speakerIconW, speakerIconH };
    }

    /** THE ROOM under the back, the guitar's once (none now): ROOM, then OFF and a word a room. Cell -1 is OFF. */
    static constexpr float speakerGap = 12.0f, backLabelGap = 16.0f;
    static bool hasRooms() { return ! catalog().rooms.isEmpty(); }
    ui::String roomWord (int i) const { return i < 0 ? ui::String ("OFF") : catalog().roomWords[i]; }

    ui::Rectangle<float> roomWordArea() const
    {
        const auto font = ui::look().font (13.0f);
        float total = ui::look().trackedWidth ("ROOM", font, 0.08f) + 4.0f + backLabelGap;
        for (int i = -1; i < catalog().rooms.size(); ++i)
            total += ui::look().trackedWidth (roomWord (i), font, 0.06f) + speakerGap;
        total -= speakerGap;
        return { 0.5f * ((float) leftW - total), (float) pileTop - 2.0f, ui::look().trackedWidth ("ROOM", font, 0.08f) + 4.0f,
                 (float) speakerRowH - 4.0f };
    }

    ui::Rectangle<float> roomCell (int i) const
    {
        const auto font = ui::look().font (13.0f);
        float x = roomWordArea().getRight() + backLabelGap;
        for (int k = -1; k < i; ++k)
            x += ui::look().trackedWidth (roomWord (k), font, 0.06f) + speakerGap;
        return { x, roomWordArea().getY(), ui::look().trackedWidth (roomWord (i), font, 0.06f), roomWordArea().getHeight() };
    }

    /** A BOX CUT THROUGH FROM THE SIDE, as its back is: the baffle at the left with the speaker on it in profile, its cone
        narrowing in to the magnet, the top and the bottom, and at the right the back — whole (CLOSED); whole, the port's
        tube in from the baffle under the speaker (PORTED); gone but for a lip at the top, the sound out of it (OPEN); its
        upper half, the sound out of the lower (HALF, the guitar's). Its speaker and its port by its height, so a wide cell
        keeps their shape and leaves its room for a word. */
    static void paintBack (ui::Graphics& g, int kind, ui::Rectangle<float> b, ui::Colour colour)
    {
        const float x0 = b.getX(), x1 = b.getRight(), y0 = b.getY(), y1 = b.getBottom(), h = b.getHeight();
        const float w = ui::jmin (b.getWidth(), 1.6f * h);
        const float line = 1.2f, baffle = 1.8f;
        g.setColour (colour);
        g.drawLine (x0, y0, x1, y0, line);
        g.drawLine (x0, y1, x1, y1, line);

        const float portTop = y1 - 0.30f * h, portBottom = y1 - 0.12f * h;
        if (kind == 1)
        {
            g.drawLine (x0, y0, x0, portTop, baffle);
            g.drawLine (x0, portBottom, x0, y1, baffle);
            g.drawLine (x0, portTop, x0 + 0.45f * w, portTop, line);
            g.drawLine (x0, portBottom, x0 + 0.45f * w, portBottom, line);
        }
        else
            g.drawLine (x0, y0, x0, y1, baffle);

        if (kind == 3)
        {
            g.drawLine (x1, y0, x1, y0 + 0.5f * h, line);
            ui::Path out;
            out.addCentredArc (x1 - 1.0f, y0 + 0.78f * h, 4.0f, 4.0f, 0.0f, 0.5f * ui::MathConstants<float>::pi - 0.7f,
                               0.5f * ui::MathConstants<float>::pi + 0.7f, true);
            g.strokePath (out, ui::PathStrokeType (line));
        }
        else if (kind != 2)
            g.drawLine (x1, y0, x1, y1, line);
        else
        {
            g.drawLine (x1, y0, x1, y0 + 0.22f * h, line);
            ui::Path out;
            for (const float r : { 4.0f, 7.5f })   // within the gap to the next cell
                out.addCentredArc (x1 - 1.0f, y0 + 0.62f * h, r, r, 0.0f, 0.5f * ui::MathConstants<float>::pi - 0.7f,
                                   0.5f * ui::MathConstants<float>::pi + 0.7f, true);
            g.strokePath (out, ui::PathStrokeType (line));
        }

        const float cy = kind == 1 ? y0 + 0.40f * h : b.getCentreY(), half = 0.27f * h;
        ui::Path cone;
        cone.startNewSubPath (x0, cy - half);
        cone.lineTo (x0 + 0.22f * w, cy - 0.09f * h);
        cone.lineTo (x0 + 0.22f * w, cy + 0.09f * h);
        cone.lineTo (x0, cy + half);
        g.strokePath (cone, ui::PathStrokeType (line));
        g.fillRect (ui::Rectangle<float> (0.10f * w, 0.18f * h).withPosition (x0 + 0.22f * w, cy - 0.09f * h));
    }

    /** A SPEAKER'S CHARACTER AS ITS CURVE, the level across the band left to right (the owner, 07.11): MID a hump in the
        middle, BRIGHT its top rising, DARK its top falling, SCOOP a dip, FLAT a line, SNAP a narrow peak high up; the
        cone's switch (`name` empty) the cone in profile, as the back's cells draw it. */
    static void paintSpeakerIcon (ui::Graphics& g, const ui::String& name, ui::Rectangle<float> r, ui::Colour colour, float line)
    {
        g.setColour (colour);
        const auto at = [&r] (float x, float y) { return ui::Point<float> (r.getX() + x * r.getWidth(), r.getY() + y * r.getHeight()); };
        ui::Path p;
        if (name.isEmpty())
        {
            p.startNewSubPath (at (0.25f, 0.0f));
            p.lineTo (at (0.25f, 1.0f));
            p.startNewSubPath (at (0.25f, 0.05f));
            p.lineTo (at (0.55f, 0.36f));
            p.lineTo (at (0.55f, 0.64f));
            p.lineTo (at (0.25f, 0.95f));
            g.strokePath (p, ui::PathStrokeType (line, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));
            g.fillRect (ui::Rectangle<float> (0.17f * r.getWidth(), 0.32f * r.getHeight()).withPosition (at (0.55f, 0.34f)));
            return;
        }
        const auto bump = [] (float t, float c, float w) { return std::exp (-((t - c) / w) * ((t - c) / w)); };
        const auto rise = [] (float t, float from) { const float u = ui::jmax (0.0f, (t - from) / (1.0f - from)); return u * u; };
        const auto level = [&] (float t)
        {
            if (name == "mid")    return 0.75f - 0.6f * bump (t, 0.5f, 0.17f);
            if (name == "bright") return 0.8f - 0.72f * rise (t, 0.35f);
            if (name == "dark")   return 0.25f + 0.68f * rise (t, 0.4f);
            if (name == "scoop")  return 0.15f + 0.7f * bump (t, 0.5f, 0.22f);
            if (name == "snap")   return 0.7f - 0.65f * bump (t, 0.7f, 0.08f);
            return 0.5f;   // flat
        };
        constexpr int n = 24;
        for (int i = 0; i <= n; ++i)
        {
            const float t = (float) i / (float) n;
            if (i == 0)
                p.startNewSubPath (at (t, level (t)));
            else
                p.lineTo (at (t, level (t)));
        }
        g.strokePath (p, ui::PathStrokeType (line, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));
    }

    /** The chosen box's horn over its speaker, big, always in the scene's top right corner, wherever it stands on the
        box — a horn that moves with the box jumps under the eye (the owner, 05.11); none where the box has none. */
    ui::Rectangle<float> hornCorner() const
    {
        if (chosen < 0 || ! cabs()[(size_t) chosen].horn)
            return {};
        const auto sc = scene();
        const float w = 0.30f * sc.getWidth(), h = 0.54f * w;
        return { sc.getRight() - 6.0f - w, sc.getY() + 6.0f, w, h };
    }

    /** HORN's attenuator, as a cabinet's switch is marked: OFF, -12, -6, 0 — a click each. */
    static constexpr const char* hornWords[] { "OFF", "-12", "-6", "0" };
    static constexpr float hornSteps[] { 0.0f, -12.0f, -6.0f, 0.0f };   // dB; OFF takes the horn out instead
    static constexpr float hornGap = 8.0f;

    int hornStep() const
    {
        if (! setup_.a.horn)
            return 0;
        return setup_.a.hornDb < -9.0f ? 1 : setup_.a.hornDb < -3.0f ? 2 : 3;
    }

    /** Left of the horn, two lines: HORN, then its steps — flush to the horn's side. */
    ui::Rectangle<float> hornBlock() const
    {
        const auto hc = hornCorner();
        const auto font = ui::look().font (13.0f);
        float w = 3.0f * hornGap;
        for (const auto* word : hornWords)
            w += ui::look().trackedWidth (word, font, 0.06f) + 4.0f;
        return { hc.getX() - 8.0f - w, hc.getCentreY() - 15.0f, w, 30.0f };
    }

    ui::Rectangle<float> hornWordArea() const { return hornBlock().withHeight (14.0f); }

    ui::Rectangle<float> hornStepArea (int i) const
    {
        const auto font = ui::look().font (13.0f);
        const auto block = hornBlock();
        float x = block.getX();
        for (int k = 0; k < i; ++k)
            x += ui::look().trackedWidth (hornWords[k], font, 0.06f) + 4.0f + hornGap;
        return { x, block.getBottom() - 14.0f, ui::look().trackedWidth (hornWords[i], font, 0.06f) + 4.0f, 14.0f };
    }

    /** The speaker's centre: the middle of what the speakers' row and BLEND leave of the scene — under a horn, of what its
        HORN and steps leave there, so the horn has its room. */
    ui::Point<float> coneCentre() const
    {
        const auto sc = coneArea();
        if (! underHorn())
            return sc.getCentre();
        const float top = hornBlock().getBottom() + 2.0f;
        return { sc.getCentreX(), 0.5f * (top + sc.getBottom()) };
    }

    bool underHorn() const { return chosen >= 0 && cabs()[(size_t) chosen].horn; }

    static constexpr float columnGapM = 0.04f;   // between a pile's columns, m
    static constexpr float stackGapPx = 2.0f;    // between a box and the one on it

    /** One scale for the whole pile, so a box is as big as itself against the others: its width and its tallest column
        fitted to the area. */
    float pileScale() const
    {
        const auto area = pileArea().toFloat();
        float w = 0, h = 0;
        for (const auto& column : pile())
        {
            float cw = 0, ch = 0;
            for (const auto& name : column)
            {
                const auto& c = cabs()[(size_t) indexOf (name)];
                cw = ui::jmax (cw, c.w);
                ch += c.h;
            }
            w += cw;
            h = ui::jmax (h, ch);
        }
        w += columnGapM * (float) (pile().size() - 1);
        return ui::jmin ((area.getWidth() - 8.0f) / w, (area.getHeight() - 8.0f) / h);
    }

    /** Each box, to scale, standing as pile() stacks them, the pile centred on its floor. */
    std::vector<std::pair<int, ui::Rectangle<float>>> layOut() const
    {
        const auto area = pileArea().toFloat();
        const float s = pileScale();
        const auto& columns = pile();

        float width = columnGapM * (float) (columns.size() - 1);
        for (const auto& column : columns)
        {
            float cw = 0;
            for (const auto& name : column)
                cw = ui::jmax (cw, cabs()[(size_t) indexOf (name)].w);
            width += cw;
        }

        std::vector<std::pair<int, ui::Rectangle<float>>> out;
        float x = area.getCentreX() - 0.5f * width * s;
        const float floor = area.getBottom() - 2.0f;
        for (const auto& column : columns)
        {
            float cw = 0;
            for (const auto& name : column)
                cw = ui::jmax (cw, cabs()[(size_t) indexOf (name)].w);
            float bottom = floor;
            for (const auto& name : column)
            {
                const int i = indexOf (name);
                const auto& c = cabs()[(size_t) i];
                out.push_back ({ i, { x + 0.5f * (cw - c.w) * s, bottom - c.h * s, c.w * s, c.h * s } });
                bottom -= c.h * s + stackGapPx;
            }
            x += (cw + columnGapM) * s;
        }
        return out;
    }

    ui::Rectangle<float> boxOf (int index) const
    {
        for (const auto& [i, box] : layOut())
            if (i == index)
                return box;
        return {};
    }

    int cabAt (ui::Point<float> p) const
    {
        for (const auto& [i, box] : layOut())
            if (box.expanded (1.0f).contains (p))
                return i;
        return -1;
    }

    static ui::Point<float> onBox (ui::Rectangle<float> box, float s, ui::Point<float> p)
    {
        return { box.getCentreX() + p.x * s, box.getCentreY() - p.y * s };
    }

    /** What a click at `p` works, in the order a click looks for it. */
    Hot hotAt (ui::Point<float> p) const
    {
        const auto pos = p.roundToInt();
        // A "?"'s window over all else while it is out, then the "?" themselves.
        if (helpOpen >= 0 && helpBox (helpOpen).contains (pos))
            return { Part::helpBox, -1, helpOpen };
        for (int i = 0; i < helpSpots; ++i)
            if (helpSpot (i).mark.expanded (3).contains (pos))
                return { Part::help, -1, i };
        if (downloadArea().contains (pos))
            return { Part::download };
        if (downloadFormatArea().contains (pos))
            return { Part::downloadFormat };
        // The EQ over the response: its switch, then while it is on its bells over its passes.
        if (eqBoxArea().contains (pos))
            return { Part::eq };
        if (eqOn() && responsePlot().expanded (6.0f).contains (p))
        {
            for (int i = 0; i < eqBells; ++i)
                if (p.getDistanceFrom (bellAt (i)) < 9.0f)
                    return { Part::eqBell, -1, i };
            for (int i = 0; i < 2; ++i)
                if (passTab (i).expanded (2.0f).contains (p) || std::abs (p.x - passX (i)) < 6.0f)
                    return { Part::eqPass, -1, i };
        }

        if (p.x < (float) leftW)
        {
            // The chosen box's back, a cell each.
            if (chosen >= 0)
                for (int i = 0; i < backs(); ++i)
                    if (backCell (i).expanded (backGap / 2, 2.0f).contains (p))
                        return { Part::back, -1, i };
            // ...the wall behind it, where the catalog has the switch...
            if (chosen >= 0 && catalog().wallSwitch && wallArea().expanded (backGap / 2, 2.0f).contains (p))
                return { Part::wall };
            // ...and the room round it, OFF first.
            if (chosen >= 0 && hasRooms())
                for (int i = -1; i < catalog().rooms.size(); ++i)
                    if (roomCell (i).expanded (speakerGap / 2, 2.0f).contains (p))
                        return { Part::room, -1, i };

            const int at = cabAt (p);
            if (at < 0)
                return {};
            // The chosen box again: its horn, where it has one.
            const auto& cab = cabs()[(size_t) at];
            const auto box = boxOf (at);
            const float s = box.getWidth() / cab.w;
            if (at == chosen && cab.horn && p.getDistanceFrom (onBox (box, s, cab.hornAt)) < ui::jmax (7.0f, 0.06f * s))
                return { Part::cabHorn, -1, at };
            return { Part::cab, -1, at };
        }
        if (chosen < 0)
            return {};

        // On the speaker the mics first, drawn over everything else there: a mic's distance and angle while they are out,
        // then the mic itself — never the horn's steps, a speaker's icon or BLEND under it (the owner, 07.11).
        if (scene().contains (p))
        {
            if (const int m = handlesShown(); m >= 0)
            {
                if (p.getDistanceFrom (angleKnob (m)) < 10.0f)
                    return { Part::angle, m };
                if (distHandle (m).expanded (8.0f, 6.0f).contains (p))
                    return { Part::distance, m };
            }
            if (const int m = micAt (p); m >= 0)
                return { Part::mic, m };
        }

        if (! hornCorner().isEmpty())
            for (int i = 0; i < 4; ++i)
                if (hornStepArea (i).expanded (hornGap / 2, 3.0f).contains (p))
                    return { Part::horn, -1, i };

        // FIND, in A's column under its places: before the column, which keeps every other click in it for its own.
        if (findArea().contains (pos))
            return { Part::find };
        if (fredArea().contains (pos))
            return { Part::fred };

        for (int m = 0; m < 2; ++m)
        {
            if (! column (m).contains (pos))
                continue;
            for (int i = 0; i < placeCount; ++i)
                if (placeArea (m, i).contains (pos))
                    return { Part::place, m, i };
            for (int i = 0; i < mics().size(); ++i)
                if (micRow (m, i).contains (pos))
                    return { Part::micRow, m, i };
            if (m == 1 && alignArea().expanded (2, 2).contains (pos))  return { Part::align };
            if (m == 1 && invertArea().expanded (2, 2).contains (pos)) return { Part::invert };
            if (m == 1 && timeTrack().expanded (2.0f, 10.0f).contains (p))
                return { Part::shift, 1 };
            return {};
        }

        if (onClose != nullptr && closeArea().contains (pos)) return { Part::close };
        if (defaultArea().contains (pos))                     return { Part::reset };

        // The speakers' row over the speaker, the guitar's: a curve each, the cone's switch the last.
        if (hasSpeakers())
            for (int i = 0; i < catalog().speakers.size(); ++i)
                if (speakerCell (i).expanded (0.5f * speakerIconGap, 4.0f).contains (p))
                    return { Part::speaker, -1, i };
        if (hasSpeakers() && catalog().coneVariant.isNotEmpty() && speakerCell (-1).expanded (0.5f * speakerIconGap, 4.0f).contains (p))
            return { Part::speakerCone };

        if (bothHeard() && blendTrack().expanded (8.0f, 6.0f).contains (p)) return { Part::blend };
        return {};
    }

    /** A drag begun: the hand's until it lets go, heard as it goes. */
    void grab (Drag d, int m, const ui::MouseEvent& e)
    {
        drag = d;
        dragMic = m;
        dragging = true;
        mouseDrag (e);
    }

    void press (Hot h, const ui::MouseEvent& e)
    {
        switch (h.part)
        {
            case Part::none:
                return;

            // A "?": its window kept open; clicked again, closed, and not opened till the hand has been off it.
            case Part::help:
                if (helpPinned && helpOpen == h.i)
                {
                    closeHelp();
                    helpQuiet = true;
                }
                else
                {
                    helpOpen = h.i;
                    helpPinned = true;
                    helpQuiet = false;
                    repaint();
                }
                return;

            case Part::helpBox:   // a click in it keeps it, as one on its "?"
                helpPinned = true;
                repaint();
                return;

            case Part::download:
                onDownload();
                return;

            case Part::downloadFormat:
                onDownloadFormat();
                return;

            // The back: kept as turned, its own one too, so every box after comes with it.
            case Part::back:
                setup_.back = backAt (h.i);
                send();
                return;

            // The speakers' other cone, on and off; kept from box to box as the speaker is.
            case Part::speakerCone:
                setup_.cone = ! setup_.cone;
                send();
                return;

            // The wall behind the box, on and off; kept from box to box as the back is.
            case Part::wall:
                setup_.wall = ! setup_.wall;
                send();
                return;

            // The speaker, kept as the back is.
            case Part::speaker:
                setup_.speaker = h.i;
                send();
                return;

            // The room round the box, or none; kept from box to box as the back is.
            case Part::room:
                setup_.room = h.i;
                send();
                return;

            case Part::cab:
                if (h.i != chosen)
                {
                    setup_ = pickedWith (chosen, h.i, setup_);
                    chosen = h.i;
                    send();
                }
                return;

            case Part::cabHorn:
                toggleHorn();
                return;

            case Part::horn:
                setup_.a.horn = h.i > 0;
                if (h.i > 0)
                    setup_.a.hornDb = hornSteps[h.i];
                send();
                return;

            case Part::distance:
                takeUp (h.m);
                dragTrack = distHandle (h.m);
                grab (Drag::distance, h.m, e);
                return;

            case Part::place:
                putAt (h.m, placeAt (h.i));
                return;

            case Part::micRow:
            {
                // The lit one clicked again, with both mics heard: that mic goes off where it stands, the other stays
                // where it is, BLEND too. The last mic never goes.
                const auto& own = mic (h.m).mic.isNotEmpty() ? mic (h.m).mic : cabs()[(size_t) chosen].mic;
                if (bothHeard() && mics()[h.i] == own)
                    (h.m == 0 ? setup_.aOn : setup_.bOn) = false;
                else
                {
                    takeUp (h.m);
                    mic (h.m).mic = mics()[h.i];
                }
                send();
                return;
            }

            case Part::angle:
                takeUp (h.m);
                grab (Drag::angle, h.m, e);
                return;

            case Part::shift:
                takeUp (1);
                grab (Drag::shift, 1, e);
                return;

            // A mic taken by any part of it moves with the hand from there — its capsule does not jump under it.
            case Part::mic:
                grabOffset = spotOf (h.m) - e.position;
                micMoved = false;
                drag = Drag::spot;
                dragMic = h.m;
                dragging = true;
                repaint();
                return;

            case Part::close:
                onClose();
                return;

            // DEFAULT asks first: the first click turns it into SURE? for three seconds, the second resets.
            case Part::reset:
                if (! defaultArmed)
                {
                    defaultArmed = true;
                    armedUntil = clock + 3.0;
                    repaint();
                    return;
                }
                disarmDefault();
                setup_ = {};
                setup_.a.mic = cabs()[(size_t) chosen].mic;
                setup_.a.horn = cabs()[(size_t) chosen].hornOn;
                send();
                return;

            // With both mics heard B is looked for, with one that one (the host's: synth::BSearch, synth::MicSearch).
            case Part::find:
                onFind (chosen, setup_);
                return;

            case Part::fred:
                fredman();
                return;

            case Part::align:
                setup_.align = ! setup_.align;
                send();
                return;

            case Part::invert:
                setup_.invert = ! setup_.invert;
                send();
                return;

            case Part::blend:
                grab (Drag::blend, dragMic, e);
                return;

            // The EQ on and off, its settings kept either way.
            case Part::eq:
                setup_.eq.on = ! setup_.eq.on;
                send();
                return;

            // A pass taken by its line or its handle: the line does not jump under the hand.
            case Part::eqPass:
                dragEq = h.i;
                grabOffset = { passX (h.i) - e.position.x, 0.0f };
                grabY = e.position.y;
                grabSlope = h.i == 0 ? setup_.eq.highPassSlope : setup_.eq.lowPassSlope;
                grab (Drag::eqPass, dragMic, e);
                return;

            // A bell taken where the hand is on it: its dot does not jump under the hand.
            case Part::eqBell:
                dragEq = h.i;
                grabOffset = bellAt (h.i) - e.position;
                grab (Drag::eqBell, dragMic, e);
                return;
        }
    }

    /** A HF horn as it faces the player: its mouth a rounded rectangle, its walls narrowing to the throat, the driver a
        dark slot at the bottom of it — `s` px a metre; dim when it is turned off. */
    static void paintHorn (ui::Graphics& g, ui::Point<float> c, float s, ui::Colour colour)
    {
        // A tunnel: the mouth, the flare narrowing inside it a little above the centre, the throat dark at its end.
        const auto mouth  = ui::Rectangle<float> (0.12f * s, 0.065f * s).withCentre (c);
        const auto flare  = ui::Rectangle<float> (0.075f * s, 0.038f * s).withCentre (c.translated (0, -0.004f * s));
        const auto throat = ui::Rectangle<float> (0.03f * s, 0.016f * s).withCentre (c.translated (0, -0.007f * s));
        const float line = ui::jlimit (0.7f, 1.2f, 0.01f * s);
        g.setColour (ui::Colours::black.withAlpha (0.6f));
        g.fillRoundedRectangle (mouth, 0.014f * s);
        g.setColour (colour.withMultipliedAlpha (0.10f));
        g.fillRoundedRectangle (mouth.reduced (line), 0.012f * s);
        g.setColour (ui::Colours::black.withAlpha (0.45f));
        g.fillRoundedRectangle (flare, 0.009f * s);
        g.setColour (ui::Colours::black);
        g.fillRoundedRectangle (throat, 0.005f * s);
        g.setColour (colour.withMultipliedAlpha (0.45f));
        g.drawRoundedRectangle (flare, 0.009f * s, line * 0.7f);
        g.setColour (colour.withMultipliedAlpha (0.8f));
        g.drawRoundedRectangle (throat, 0.005f * s, line * 0.7f);
        g.setColour (colour);
        g.drawRoundedRectangle (mouth, 0.014f * s, line);
    }

    void paintPile (ui::Graphics& g) const
    {
        const auto font = ui::look().font (13.0f);
        const auto area = pileArea();
        g.setColour (ui::look().hair);
        g.fillRect (ui::Rectangle<float> ((float) area.getX(), (float) area.getBottom() - 1.0f, (float) area.getWidth(), 1.0f));
        // The back over the pile kept apart from it, as the halves are, by a hair across up to theirs (the owner, 05.11).
        g.fillRect (ui::Rectangle<float> (0.0f, (float) pileTopNow() - 3.0f, (float) leftW + 0.5f * gutter, 1.0f));

        for (const auto& [index, box] : layOut())
            paintCab (g, cabs()[(size_t) index], box, setup_, index == chosen, index == hoverCab(), 1.0f, false,
                      isHot (Part::cabHorn, -1, index));

        // In the pile at its top left, big: the box under the hand, else the chosen one — its letters' tops level with the
        // pile's top, the 2x12's (the owner, 05.11).
        const int named = hoverCab() >= 0 ? hoverCab() : chosen;
        if (named >= 0)
        {
            const auto big = ui::look().font (24.0f);
            float left = (float) area.getRight(), top = (float) area.getBottom();
            for (const auto& [index, box] : layOut())
            {
                left = ui::jmin (left, box.getX());
                top = ui::jmin (top, box.getY());
            }
            const float capGap = big.getAscent() - 0.72f * big.getHeight();   // the ascent over the capitals' tops
            g.setColour (named == chosen ? ui::look().tx : ui::look().txDim);
            ui::look().drawTracked (g, wordOf (named), { left, top - capGap, (float) leftW - left, big.getHeight() }, big, 0.06f,
                                ui::Justification::topLeft);
        }

        // Over the pile the chosen box's back, a cell each: the box cut through, its word inside it, the one it stands at
        // in the block's orange line; WALL after them. The one under the hand drawn last, grown (backZoomed).
        if (chosen >= 0)
        {
            const int zi = backZoomed();
            for (int i = 0; i < backs(); ++i)
            {
                if (i != zi)
                    paintBackCell (g, i, backIcon (i));
                // The box's own back, a dot before its picture: where DEFAULT goes back to.
                if (backAt (i) == ownBack (chosen))
                {
                    g.setColour (ui::look().txDim);
                    g.fillEllipse (ui::Rectangle<float> (4.0f, 4.0f).withCentre ({ backIcon (i).getX() - 8.0f, backIcon (i).getCentreY() }));
                }
            }
            if (catalog().wallSwitch && zi != backs())
                paintWallCell (g, backIcon (backs()));
            if (zi >= 0)
            {
                // The one under the hand grown, its word under it, over what lies there.
                const float e = backZoom * backZoom * (3.0f - 2.0f * backZoom), k = 1.0f + backZoomBy * e;   // eased in and out
                auto big = backIcon (zi, k);
                const float right = (float) leftW + 0.5f * gutter - 1.0f;
                big = big.translated (ui::jmax (0.0f, 1.0f - big.getX()) - ui::jmax (0.0f, big.getRight() - right),
                                      ui::jmax (0.0f, 1.0f - big.getY()));
                const auto font13 = ui::look().font (13.0f);
                const ui::String word = zi < backs() ? ui::String (backWords[backAt (zi)]) : ui::String ("WALL");
                const float w = ui::look().trackedWidth (word, font13, 0.06f) + 12.0f;
                const float x = ui::jlimit (1.0f, right - w, big.getCentreX() - 0.5f * w);
                const ui::Rectangle<float> label (x, big.getBottom() + 2.0f, w, 18.0f);
                g.setColour (ui::look().panel);   // what is under them hidden, no box of their own
                g.fillRoundedRectangle (big.expanded (4.0f, 3.0f), 4.0f);
                g.setColour (ui::look().panel.withMultipliedAlpha (e));
                g.fillRoundedRectangle (label, 3.0f);
                if (zi < backs())
                    paintBackCell (g, zi, big);
                else
                    paintWallCell (g, big);
                const bool on = zi < backs() ? backAt (zi) == backOf (chosen, setup_) : setup_.wall;
                g.setColour ((on ? ui::look().orange : ui::look().tx).withMultipliedAlpha (e));
                ui::look().drawTracked (g, word, label, font13, 0.06f, ui::Justification::centred);
            }
        }

        // ...and under them the room, where the catalog has rooms: ROOM, then OFF and theirs, the one round the box lit.
        if (chosen >= 0 && hasRooms())
        {
            g.setColour (ui::look().txFaint);
            ui::look().drawTracked (g, "ROOM", roomWordArea(), font, 0.08f, ui::Justification::centredLeft);
            for (int i = -1; i < catalog().rooms.size(); ++i)
            {
                const bool on = i == setup_.room, over = ! on && isHot (Part::room, -1, i);
                const auto cell = roomCell (i);
                if (over)
                {
                    g.setColour (ui::look().violet.withAlpha (0.7f));
                    g.drawRoundedRectangle (cell.expanded (6.0f, 0.0f), 3.0f, 1.0f);
                }
                g.setColour (on ? ui::look().orange : over ? ui::look().tx : ui::look().txDim);
                ui::look().drawTracked (g, roomWord (i), cell, font, 0.06f, ui::Justification::centred);
            }
        }
    }

    /** A back's picture in `icon`: the box cut through — orange where the box stands at it, brighter under the hand. */
    void paintBackCell (ui::Graphics& g, int i, ui::Rectangle<float> icon) const
    {
        const bool on = backAt (i) == backOf (chosen, setup_), over = isHot (Part::back, -1, i);
        paintBack (g, backAt (i), icon, on ? ui::look().orange : ui::look().violet.withAlpha (over ? 0.95f : 0.6f));
    }

    /** WALL's picture in `icon`, the guitar's: the wall itself, upright, laid in bricks — orange on, violet off, faint with
        the back closed, nothing gets out there. */
    void paintWallCell (ui::Graphics& g, ui::Rectangle<float> icon) const
    {
        const bool over = isHot (Part::wall), closed = backOf (chosen, setup_) == 0;
        const auto ink = setup_.wall ? (closed ? ui::look().orange.withAlpha (0.45f) : ui::look().orange)
                                     : ui::look().violet.withAlpha (closed ? 0.35f : over ? 0.95f : 0.6f);
        g.setColour (ink);
        g.drawRoundedRectangle (icon, 1.5f, setup_.wall ? 1.5f : 1.2f);
        constexpr int rows = 6;
        const float brickH = icon.getHeight() / (float) rows, x = icon.getX(), w = icon.getWidth();
        for (int r = 1; r < rows; ++r)
            g.drawLine (x, icon.getY() + (float) r * brickH, x + w, icon.getY() + (float) r * brickH, 0.9f);
        for (int r = 0; r < rows; ++r)   // the joints, every other row offset
        {
            const float y0 = icon.getY() + (float) r * brickH, y1 = y0 + brickH;
            if (r % 2 == 0)
                g.drawLine (x + 0.5f * w, y0, x + 0.5f * w, y1, 0.9f);
            else
            {
                g.drawLine (x + 0.25f * w, y0, x + 0.25f * w, y1, 0.9f);
                g.drawLine (x + 0.75f * w, y0, x + 0.75f * w, y1, 0.9f);
            }
        }
    }

    /** The picture in cell `i` (backs() for WALL) as the row stands it, `k` times its size about its middle. */
    ui::Rectangle<float> backIcon (int i, float k = 1.0f) const
    {
        const auto cell = i < backs() ? backCell (i) : wallArea();
        const float w = i < backs() ? backIconW : wallIconW;
        return cell.withSizeKeepingCentre (k * w, k * backIconHigh);
    }

public:
    /** One box as the pile draws it, `setup` its mics and horn when it is the chosen one, framed in the block's orange
        unless `plainFrame`; its tolex `body` opaque — the block's picture draws it over its IR (paintSketch) with the IR
        showing through, in a plain frame: alone there, it has nothing to be told from. */
    static void paintCab (ui::Graphics& g, const Cab& c, ui::Rectangle<float> box, const Setup& setup, bool isChosen, bool isHover,
                          float body = 1.0f, bool plainFrame = false, bool hornHover = false, float micDot = 5.0f)
    {
        const float s = box.getWidth() / c.w;

        // The box: the tolex, a grille's hint, its outline — the chosen one in the block's orange line.
        g.setColour (ui::look().panel2.withMultipliedAlpha (body));
        g.fillRoundedRectangle (box, c.family == 1 ? 4.0f : 2.0f);
        g.setColour (ui::look().bezel.withMultipliedAlpha (body));
        g.fillRoundedRectangle (box.reduced (ui::jmax (1.5f, 0.025f * s)), 1.5f);
        const bool orange = isChosen && ! plainFrame;
        g.setColour (orange ? ui::look().orange : isHover ? ui::look().violet.withAlpha (0.7f) : ui::look().hair2);
        g.drawRoundedRectangle (box, c.family == 1 ? 4.0f : 2.0f, orange ? 1.5f : 1.0f);

        // The port where the back the chosen one is turned to has one: none closed, at its foot on a sealed box ported.
        if (const int back = isChosen ? setup.back : -1; back < 0 || back == ownBackOf (c.name) ? c.port : back == 1)
        {
            const auto at = portOf (c);
            g.setColour (ui::Colours::black);
            const float w = ui::jmin (0.20f, 2.0f * (0.5f * c.w - std::abs (at.x)) - 0.04f);
            g.fillRoundedRectangle (ui::Rectangle<float> (w * s, ui::jmax (2.0f, 0.035f * s)).withCentre (onBox (box, s, at)), 1.0f);
        }

        const auto line = ui::look().violet.withAlpha (isChosen ? 0.85f : 0.5f);
        for (const auto& d : c.drivers)
        {
            const auto o = onBox (box, s, d);
            const float r = c.radius * s;
            g.setColour (line);
            g.drawEllipse (ui::Rectangle<float> (2 * r, 2 * r).withCentre (o), 1.0f);
            g.drawEllipse (ui::Rectangle<float> (0.5f * r, 0.5f * r).withCentre (o), 0.8f);
        }

        if (c.horn)
        {
            // Under the hand on the chosen box, where a click turns it over: brighter.
            const bool off = isChosen && ! setup.a.horn;
            const auto colour = off ? ui::look().txFaint.withAlpha (hornHover ? 0.8f : 0.4f)
                                    : ui::look().lilac.withAlpha (isChosen ? 0.9f : 0.55f);
            paintHorn (g, onBox (box, s, c.hornAt), s, hornHover && ! off ? colour.brighter (0.4f) : colour);
        }

        // The mics where they stand on the first speaker, A orange and B lilac.
        if (isChosen)
        {
            const auto o = onBox (box, s, c.drivers.front());
            const float r = c.radius * s;
            for (int m = 1; m >= 0; --m)
            {
                if (! (m == 0 ? setup.aOn : setup.bOn))
                    continue;
                const auto& sp = m == 0 ? setup.a : setup.b;
                g.setColour (m == 0 ? ui::look().orange : ui::look().lilac);
                g.fillEllipse (ui::Rectangle<float> (micDot, micDot).withCentre (o + ui::Point<float> (sp.x * r, -sp.y * r)));
            }
        }
    }

    /** A speaker, flat as the player faces it — its surround, its cone in rings, its cap — `R` its radius; its paper
        `body` opaque (the sketch over the IR lets the IR through). */
    static void paintCone (ui::Graphics& g, ui::Point<float> o, float R, float body = 1.0f)
    {
        g.setColour (ui::look().panel2.withMultipliedAlpha (body));
        g.fillEllipse (ui::Rectangle<float> (2.12f * R, 2.12f * R).withCentre (o));
        g.setGradientFill (ui::ColourGradient (ui::look().panel.withMultipliedAlpha (body), o.x, o.y, ui::look().bezel.withMultipliedAlpha (body), o.x + R, o.y, true));
        g.fillEllipse (ui::Rectangle<float> (2 * R, 2 * R).withCentre (o));
        g.setColour (ui::look().violet.withAlpha (0.8f));
        g.drawEllipse (ui::Rectangle<float> (2 * R, 2 * R).withCentre (o), 1.2f);
        g.setColour (ui::look().violet.withAlpha (0.18f));
        for (float k : { 0.45f, 0.7f, 0.88f })
            g.drawEllipse (ui::Rectangle<float> (2 * k * R, 2 * k * R).withCentre (o), 0.8f);
        g.setColour (ui::look().panel2.brighter (0.15f));
        g.fillEllipse (ui::Rectangle<float> (0.5f * R, 0.5f * R).withCentre (o));
        g.setColour (ui::look().violet.withAlpha (0.6f));
        g.drawEllipse (ui::Rectangle<float> (0.5f * R, 0.5f * R).withCentre (o), 1.0f);
    }

    /** The mics on a speaker drawn at `o`, radius `R`, in perspective, the farther from the cone drawn last (nearest the
        eye): its shadow on the cone, then the glyph, its capsule over the spot, as tall as it is near the eye, leaning back
        toward the cap; each only while it is on. `k` the scene's size, the panel's 1. */
    static void paintMicsOn (ui::Graphics& g, const Cab& cab, const Setup& setup, ui::Point<float> o, float R, float k, int lit = -1)
    {
        for (int m : drawOrder (setup))
        {
            if (! (m == 0 ? setup.aOn : setup.bOn))
                continue;
            const auto& sp = m == 0 ? setup.a : setup.b;
            const float near = nearness (sp.distance);
            const auto gl = glyphOf (sp, o, R, k);
            const auto colour = m == lit ? colourOf (m).brighter (0.3f) : colourOf (m);

            const float sh = (6.0f + 26.0f * near) * k;
            g.setColour (ui::Colours::black.withAlpha (0.55f - 0.35f * near));
            g.fillEllipse (ui::Rectangle<float> (sh, sh * 0.6f).withCentre (gl.at + ui::Point<float> (10.0f * near, 8.0f * near) * k));
            g.setColour (colour.withAlpha (0.9f));
            g.fillEllipse (ui::Rectangle<float> (5, 5).withCentre (gl.at));
            if (m == lit)   // under the hand, or in it: ringed at its capsule
            {
                g.setColour (colour.withAlpha (0.85f));
                g.drawEllipse (ui::Rectangle<float> (16.0f, 16.0f).withCentre (gl.at), 1.2f);
            }
            paintMicGlyph (g, sp.mic.isNotEmpty() ? sp.mic : cab.mic, gl.box, colour, gl.lean, gl.at);
        }
    }

    /** The two mics in the order they are drawn: the farther from the cone last, nearest the eye, over the other. */
    static std::array<int, 2> drawOrder (const Setup& setup)
    {
        return setup.b.distance < setup.a.distance ? std::array<int, 2> { 1, 0 } : std::array<int, 2> { 0, 1 };
    }

    /** Where a mic's glyph is drawn: its capsule over the spot, as tall as it is near the eye, leaning back from the cap
        by its angle — its top away from the centre — about the spot. */
    struct Glyph { ui::Point<float> at; ui::Rectangle<float> box; float lean; };
    static Glyph glyphOf (const Spot& sp, ui::Point<float> o, float R, float k)
    {
        const auto at = o + ui::Point<float> (sp.x * R, -sp.y * R);
        const float h = (30.0f + 70.0f * nearness (sp.distance)) * k, w = h * 36.0f / 96.0f;
        const float side = at.x >= o.x ? 1.0f : -1.0f;
        return { at, ui::Rectangle<float> (w, h).withPosition (at.x - w * 0.5f, at.y - h * 0.94f),
                 side * sp.angle * ui::MathConstants<float>::pi / 180.0f };
    }

    /** THE CABINET THAT PLAYS, SMALL, in `area` (the band of the IR's picture between its words): its speaker at the
        right edge, the mics on it as the panel's scene stands them (a tall one over the band's top); the box beside it on
        the band's floor, its mics' dots on its first speaker, every box at one scale — the tallest as tall as the band — so an 8x10 stands
        taller than a 2x10. A host's cabinet block draws it over its IR, the IR showing through the tolex. */
    static void paintSketch (ui::Graphics& g, int cab, const Setup& setup, ui::Rectangle<float> area)
    {
        if (cab < 0 || cab >= (int) cabs().size())
            return;

        const auto& c = cabs()[(size_t) cab];
        const float R = ui::jmax (8.0f, ui::jmin (0.45f * area.getHeight(), 0.09f * area.getWidth() + 18.0f));
        const ui::Point<float> o (area.getRight() - R - 28.0f, area.getCentreY());   // clear of the picture's dB marks

        static const auto tallest = [] { float h = 0.0f, w = 0.0f; for (const auto& b : cabs()) { h = ui::jmax (h, b.h); w = ui::jmax (w, b.w); } return ui::Point<float> (w, h); }();
        const float right = o.x - R - 10.0f;
        const float s = ui::jmin (area.getHeight() / tallest.y, 0.3f * area.getWidth() / tallest.x);
        paintCab (g, c, ui::Rectangle<float> (c.w * s, c.h * s).withPosition (right - c.w * s, area.getBottom() - c.h * s),   // on the floor
                  setup, true, false, 0.55f, true);

        paintCone (g, o, R, 0.55f);
        paintMicsOn (g, c, setup, o, R, R / 80.0f);   // the panel's speaker is about 80 px across its radius
    }

    /** THE CABINET THAT PLAYS, THE BOX ALONE, at the right of `area` and as tall as it (OrbitAmp's CAB, the owner, 10.11):
        no speaker beside it, its mics' dots on its first speaker twice the pile's; its tolex see-through, as the sketch's
        (the host lays the whole of it a little see-through over the IR: CabPicker::paintBoxSketch). Every box at one
        scale, the tallest as tall as the area, clear of the picture's dB marks at the right. */
    static void paintBoxSketch (ui::Graphics& g, int cab, const Setup& setup, ui::Rectangle<float> area)
    {
        if (cab < 0 || cab >= (int) cabs().size())
            return;

        const auto& c = cabs()[(size_t) cab];
        static const auto tallest = [] { float h = 0.0f, w = 0.0f; for (const auto& b : cabs()) { h = ui::jmax (h, b.h); w = ui::jmax (w, b.w); } return ui::Point<float> (w, h); }();
        const float right = area.getRight() - 28.0f;   // clear of the picture's dB marks
        const float s = ui::jmin (area.getHeight() / tallest.y, 0.5f * area.getWidth() / tallest.x);
        paintCab (g, c, ui::Rectangle<float> (c.w * s, c.h * s).withPosition (right - c.w * s, area.getBottom() - c.h * s),   // on the floor
                  setup, true, false, 0.55f, true, false, 10.0f);
    }

private:

    // ---------------------------------------------------------------- the speaker
    // Its mics in two columns, A at the left in the block's orange and B at the right in lilac, B's a mirror of A's —
    // each its list of mics, its distance standing beside the list, its places and its angle; between them the speaker,
    // flat, as the player faces it, and on it the mics in perspective: the nearer the cone, the smaller (the farther
    // from the eye), a shadow on the cone that grows and fades with the distance, the glyph leaning back toward the cap
    // by the angle, its centimetres under it. BLEND right under the speaker, ALIGN and Ø
    // after it (the owner, 05.11).
    static constexpr int colW = 108, rowH = 18, edge = 6;   // edge: B's column off the panel's

    static ui::Colour colourOf (int m) { return m == 0 ? ui::look().orange : ui::look().lilac; }

    int rightX() const { return leftW + gutter; }

    ui::Rectangle<int> column (int m) const
    {
        const int h = bodyH();
        return m == 0 ? ui::Rectangle<int> (rightX(), 0, colW, h) : ui::Rectangle<int> (getWidth() - edge - colW, 0, colW, h);
    }

    ui::Rectangle<int> micRow (int m, int i) const
    {
        const auto c = column (m);
        return { c.getX(), c.getY() + rowH + 4 + i * rowH, c.getWidth(), rowH };
    }

    /** A column's places under its mics, on one line: CAP at its left, OFF at its right, EDGE between (the owner, 07.11). */
    ui::Rectangle<int> placeArea (int m, int i) const
    {
        const auto c = column (m);
        const int top = micRow (m, mics().size() - 1).getBottom() + 4;
        int w[placeCount], sum = 0;
        for (int k = 0; k < placeCount; ++k)
            sum += (w[k] = wordW (places[k].word));
        const int gap = (c.getWidth() - sum) / (placeCount - 1);
        int x = c.getX();
        for (int k = 0; k < i; ++k)
            x += w[k] + gap;
        if (i == placeCount - 1)
            x = c.getRight() - w[i];
        return { x, top, w[i], rowH };
    }

    /** B's ALIGN and Ø, under its places: ALIGN at the left, Ø at the right (the owner, 07.11). */
    ui::Rectangle<int> alignArea() const
    {
        return { column (1).getX(), placeArea (1, 0).getBottom() + 4, wordW ("ALIGN"), rowH };
    }

    ui::Rectangle<int> invertArea() const { return { column (1).getRight() - 20, alignArea().getY(), 20, rowH }; }

    /** ...and its TIME under them: B moved against A, -1 ms to +1, nought in the middle (the owner, 05.11) — its value and
        its word over a track. */
    static constexpr float maxShiftMs = 1.0f;
    ui::Rectangle<float> timeTrack() const
    {
        const auto c = column (1);
        const int top = alignArea().getBottom() + 2 + rowH + 3;
        return { (float) c.getX() + 6.0f, (float) top, (float) c.getWidth() - 12.0f, 6.0f };
    }

    /** THE MIC'S DISTANCE AND ANGLE, ON THE SPEAKER, while the hand is on the mic (handlesShown): its distance a track
        upright beside it, on the side toward the cap — its glyph leans the other way — the near at the foot, kept inside
        the scene; its angle a knob on an arc round its capsule just past the glyph's top, as a turning handle stands
        over what it turns — straight up nought, out toward the lean 60 (the owner, 07.11) — no farther than the scene
        keeps it in sight. */
    static constexpr float distHandleH = 80.0f, distHandleOff = 23.0f;

    float angleArcR (int m) const
    {
        const float tip = 0.94f * glyphOf (mic (m), coneCentre(), radius(), 1.0f).box.getHeight() + 12.0f;
        return ui::jlimit (30.0f, ui::jmax (30.0f, spotOf (m).y - coneArea().getY() - 7.0f), tip);   // under the speakers' row
    }

    float leanSide (int m) const { return spotOf (m).x >= coneCentre().x ? 1.0f : -1.0f; }   // the way its glyph leans

    ui::Rectangle<float> distHandle (int m) const
    {
        const auto at = spotOf (m);
        const auto sc = scene();
        const float top = ui::jlimit (sc.getY() + 4.0f, sc.getBottom() - 4.0f - distHandleH, at.y + 2.0f - distHandleH);
        return { at.x - leanSide (m) * distHandleOff - 3.0f, top, 6.0f, distHandleH };
    }

    ui::Point<float> angleKnob (int m) const
    {
        const float a = mic (m).angle * ui::MathConstants<float>::pi / 180.0f;
        const float r = angleArcR (m);
        return spotOf (m) + ui::Point<float> (leanSide (m) * r * std::sin (a), -r * std::cos (a));
    }

    void paintHandles (ui::Graphics& g) const
    {
        const int m = handlesShown();
        if (m < 0)
            return;
        const auto colour = colourOf (m);
        // The distance: its track, its knob where the mic stands, the far at the top.
        const auto t = drag == Drag::distance ? dragTrack : distHandle (m);
        const bool distOver = drag == Drag::distance || isHot (Part::distance, m);
        g.setColour (ui::look().violet.withAlpha (distOver ? 0.7f : 0.45f));
        g.fillRoundedRectangle (t.withSizeKeepingCentre (3.0f, t.getHeight()), 1.5f);
        g.setColour (distOver ? colour.brighter (0.3f) : colour);
        g.fillRoundedRectangle (ui::Rectangle<float> (14.0f, 6.0f).withCentre ({ t.getCentreX(), t.getBottom() - nearness (mic (m).distance) * t.getHeight() }), 2.0f);
        // The angle: its arc from straight up out to 60, its knob where the mic leans.
        const auto at = spotOf (m);
        const bool angleOver = drag == Drag::angle || isHot (Part::angle, m);
        const float side = leanSide (m), pi = ui::MathConstants<float>::pi, to = maxAngle * pi / 180.0f;
        ui::Path arc;
        const float r = angleArcR (m);
        arc.addCentredArc (at.x, at.y, r, r, 0.0f, side > 0.0f ? 0.0f : -to, side > 0.0f ? to : 0.0f, true);
        g.setColour (ui::look().violet.withAlpha (angleOver ? 0.7f : 0.45f));
        g.strokePath (arc, ui::PathStrokeType (3.0f, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));
        g.setColour (angleOver ? colour.brighter (0.3f) : colour);
        g.fillEllipse (ui::Rectangle<float> (10.0f, 10.0f).withCentre (angleKnob (m)));
        // ...its degrees beside the knob, out on its side.
        const auto deg = ui::String (ui::roundToInt (mic (m).angle)) + ui::String::fromUTF8 ("\xc2\xb0");
        const auto font = ui::look().font (13.0f);
        const float w = ui::look().trackedWidth (deg, font, 0.0f) + 4.0f;
        const auto k = angleKnob (m);
        g.drawTracked (deg, ui::Rectangle<float> (w, 16.0f).withCentre ({ k.x + side * (10.0f + 0.5f * w), k.y }), font, 0.0f,
                       ui::Justification::centred);
    }

    static ui::String cmOf (float distance)   // a metre and on, in metres: "1.2 m"
    {
        const int cm = ui::roundToInt (distance * 100.0f);
        return cm >= 100 ? ui::String (cm / 100) + "." + ui::String ((cm % 100) / 10) + " m" : ui::String (cm) + " cm";
    }

    /** ...and by the mic on the speaker, under its spot — a word to read, no slider (the owner, 05.11). */
    ui::Rectangle<float> distLabel (int m) const
    {
        const auto at = spotOf (m);
        const float w = ui::look().trackedWidth (cmOf (mic (m).distance), ui::look().font (13.0f), 0.0f) + 8.0f;
        return { at.x - 0.5f * w, at.y + 8.0f, w, 16.0f };
    }

    /** Both heard mics' centimetres, each under its own — and where the two would run into each other, pushed apart,
        half the overlap each, each to its mic's side (A to the left where the two stand level), kept inside the scene
        (the owner, 05.11). */
    std::array<ui::Rectangle<float>, 2> distLabels() const
    {
        std::array<ui::Rectangle<float>, 2> r { distLabel (0), distLabel (1) };
        if (! bothHeard())
            return r;
        const bool aLeft = ! (spotOf (1).x < spotOf (0).x);
        auto& left = r[aLeft ? 0 : 1];
        auto& right = r[aLeft ? 1 : 0];
        constexpr float gap = 6.0f;
        const bool level = left.getY() < right.getBottom() && right.getY() < left.getBottom();
        if (const float overlap = left.getRight() + gap - right.getX(); level && overlap > 0.0f)
        {
            left = left.translated (-0.5f * overlap, 0.0f);
            right = right.translated (0.5f * overlap, 0.0f);
            const auto sc = scene();
            if (const float under = sc.getX() + 2.0f - left.getX(); under > 0.0f)
            {
                left = left.translated (under, 0.0f);
                right = right.translated (ui::jmax (0.0f, left.getRight() + gap - right.getX()), 0.0f);
            }
            if (const float over = right.getRight() - (sc.getRight() - 2.0f); over > 0.0f)
            {
                right = right.translated (-over, 0.0f);
                left = left.translated (-ui::jmax (0.0f, left.getRight() + gap - right.getX()), 0.0f);
            }
        }
        return r;
    }

    /** THE SPEAKER'S SCENE, between the columns, the body's height: the guitar's speakers along its top (speakerCell),
        BLEND along its foot (blendTrack), the speaker in what they leave (coneArea, the owner, 07.11). */
    static constexpr int blendInH = 22;   // the scene's foot BLEND takes

    ui::Rectangle<float> scene() const
    {
        const int x0 = column (0).getRight() + 8, x1 = column (1).getX() - 8;
        return ui::Rectangle<int> (x0, 4, x1 - x0, bodyH() - 8).toFloat();
    }

    ui::Rectangle<float> coneArea() const
    {
        return scene().withTrimmedTop (hasSpeakers() ? (float) iconRowH : 0.0f).withTrimmedBottom ((float) blendInH);
    }

    float radius() const
    {
        const auto s = coneArea();
        float r = ui::jmin (s.getWidth(), s.getHeight()) * 0.5f / 1.2f;
        if (underHorn())   // its surround clear of HORN and its steps
            r = ui::jmin (r, (s.getBottom() - hornBlock().getBottom() - 2.0f) / 2.12f);
        return ui::jmax (10.0f, r);
    }

    ui::Rectangle<int> foot() const { return { rightX(), getHeight() - footHeight() + 4, getWidth() - rightX(), footHeight() - 4 }; }

    /** The foot: CLOSE and DEFAULT, buttons, at the right. */
    static int wordW (const char* word) { return ui::roundToInt (ui::look().trackedWidth (word, ui::look().font (13.0f), 0.06f)) + 4; }

    ui::Rectangle<int> closeArea() const
    {
        const int w = onClose != nullptr ? wordW ("CLOSE") + 14 : 0;
        return { getWidth() - w, foot().getY(), w, foot().getHeight() };
    }

    ui::Rectangle<int> defaultArea() const
    {
        if (! showDefault)
            return {};
        const int w = wordW ("DEFAULT") + 14;
        return { closeArea().getX() - (onClose != nullptr ? 6 : 0) - w, foot().getY(), w, foot().getHeight() };
    }

    /** BLEND, along the speaker's foot inside its scene: a track, no word — A's orange at its left, B's lilac at its right
        in the knob's colour (the owner, 07.11). */
    ui::Rectangle<float> blendTrack() const
    {
        const auto sc = scene();
        return { sc.getX() + 18.0f, sc.getBottom() - 0.5f * (float) blendInH - 3.0f, sc.getWidth() - 36.0f, 6.0f };
    }

    /** FIND, under A's places, its column's width — level with B's ALIGN and TIME (the owner, 07.11): orange, the panel's
        one call to act, its words on two lines where one is too narrow for them at the reading size. */
    static constexpr int findLineH = 15;   // FIND's two lines, at the reading size, a little closer than a row

    ui::Rectangle<int> findArea() const
    {
        if (onFind == nullptr)
            return {};
        const auto c = column (0);
        const int h = 2 * findLineH + 4;
        const int top = ui::jmin (placeArea (0, 0).getBottom() + 8, bodyH() - 2 - h - (catalog().fred ? fredGap + fredH : 0));
        return { c.getX() + 4, top, c.getWidth() - 8, h };
    }

    /** FRED under FIND, its width, a plain button — FIND stays the one orange (the owner, 09.11): the guitar's. */
    static constexpr int fredH = 26, fredGap = 6;

    ui::Rectangle<int> fredArea() const
    {
        if (! catalog().fred || chosen < 0)
            return {};
        const auto f = findArea();
        if (! f.isEmpty())
            return { f.getX(), f.getBottom() + fredGap, f.getWidth(), fredH };
        const auto c = column (0);
        return { c.getX() + 4, ui::jmin (placeArea (0, 0).getBottom() + 8, bodyH() - 2 - fredH), c.getWidth() - 8, fredH };
    }

    /** THE FREDMAN PAIR (the owner, 09.11): two SM57s close on the cap's edge, capsule to capsule — A straight at it, B
        turned 45° — so both hear the cone there at one time; ALIGN on, TIME nought, not turned over, BLEND even. B on A's
        own spot: two centimetres out, at two from the cone, the pair cancels 10-15 dB up top. The box, its speaker, its
        back and the EQ as they were. */
    void fredman()
    {
        constexpr float capEdge = 0.25f, near = 0.02f, lean = 45.0f;   // the cap as paintCone draws it, in radii
        const float side = setup_.a.x < 0.0f ? -1.0f : 1.0f;   // on A's side of the cap, as it stood
        setup_.a.mic = setup_.b.mic = "sm57";
        setup_.a.x = setup_.b.x = side * capEdge;
        setup_.a.y = setup_.b.y = 0.0f;
        setup_.a.distance = setup_.b.distance = near;
        setup_.a.angle = 0.0f;
        setup_.b.angle = lean;
        setup_.aOn = setup_.bOn = true;
        setup_.align = true;
        setup_.shiftMs = 0.0f;
        setup_.invert = false;
        setup_.blend = 0.5f;
        repaint();
        // Placed, not taken up: B turned on here would send the host looking for a place for it, off A's spot (the site, 10.11).
        if (const auto& kept = onPlaced != nullptr ? onPlaced : onSetup; kept != nullptr)
            kept (chosen, setup_);
    }

    void paintFind (ui::Graphics& g) const
    {
        const auto r = findArea();
        if (r.isEmpty())
            return;
        const auto b = r.toFloat().reduced (0.5f);
        const auto font = ui::look().font (13.0f);
        const auto ink = searching || isHot (Part::find) ? ui::look().orange.brighter (0.3f) : ui::look().orange;
        g.setColour (ui::look().panel2);
        g.fillRoundedRectangle (b, 4.0f);
        g.setColour (ink);
        g.drawRoundedRectangle (b, 4.0f, searching ? 1.6f : 1.2f);
        if (ui::look().trackedWidth ("FIND BEST POSITION", font, 0.06f) + 14.0f <= b.getWidth())
            ui::look().drawTracked (g, "FIND BEST POSITION", b, font, 0.06f, ui::Justification::centred);
        else
        {
            const auto lines = b.withSizeKeepingCentre (b.getWidth(), 2.0f * (float) findLineH);
            ui::look().drawTracked (g, "FIND BEST", lines.withHeight ((float) findLineH), font, 0.06f, ui::Justification::centred);
            ui::look().drawTracked (g, "POSITION", lines.withTrimmedTop ((float) findLineH), font, 0.06f, ui::Justification::centred);
        }
    }

    /** The places a mic is put at with one click, as the table's positions stand them: at the cap, at the cone's edge,
        half way out and turned 35° to the cap — ROOM gone, the distance out on the speaker reaching as far (the owner,
        07.11). Across the cone on the mic's own side. */
    struct Place { const char* word; float r, distance, angle; };
    static constexpr Place places[] { { "CAP", 0.0f, 0.05f, 0.0f }, { "EDGE", 0.8f, 0.04f, 0.0f }, { "OFF", 0.5f, 0.05f, 35.0f } };
    static constexpr int placeCount = 3;
    static Place placeAt (int i) { return places[i]; }
    /** Where a place puts mic `m` across the speaker, in radii — on the mic's own side, on the axis the side away from the
        other mic while that one is on; a dark B where taking it up would stand it first (takeUp). */
    ui::Point<float> placeSpot (int m, const Place& p) const
    {
        float x = mic (m).x;
        if (m == 1 && ! heard (1) && std::hypot (setup_.b.x - setup_.a.x, setup_.b.y - setup_.a.y) < 0.4f)
            x = ui::jmin (1.05f, setup_.a.x + 0.7f);
        float side = x > 0.0f ? 1.0f : -1.0f;
        if (std::abs (x) <= 0.05f)
            side = mic (1 - m).x > 0.0f && heard (1 - m) ? -1.0f : 1.0f;
        return { side * p.r, 0.0f };
    }

    void putAt (int m, const Place& p)
    {
        takeUp (m);
        const auto at = placeSpot (m, p);
        auto& sp = mic (m);
        sp.x = at.x;
        sp.y = at.y;
        sp.distance = p.distance;
        sp.angle = p.angle;
        send();
    }

    bool standsAt (const Spot& sp, const Place& p) const
    {
        return std::abs (std::abs (sp.x) - p.r) < 0.02f && std::abs (sp.y) < 0.02f
            && std::abs (sp.distance - p.distance) < 0.004f && std::abs (sp.angle - p.angle) < 1.0f;
    }

    static float along (ui::Rectangle<float> t, float x) { return ui::jlimit (0.0f, 1.0f, (x - t.getX()) / t.getWidth()); }

    /** Where a mic stands on the cone, on the screen. */
    ui::Point<float> spotOf (int m) const
    {
        const auto o = coneCentre();
        const float R = radius();
        return o + ui::Point<float> (mic (m).x * R, -mic (m).y * R);
    }

    static float nearness (float distance)   // 0 at the cone, 1 at 30 cm
    {
        return std::log (ui::jlimit (minCm, maxCm(), distance * 100.0f) / minCm) / std::log (maxCm() / minCm);
    }

    bool heard (int m) const { return m == 0 ? setup_.aOn : setup_.bOn; }
    bool bothHeard() const { return setup_.aOn && setup_.bOn; }

    /** A dark column taken up: its mic heard again where it stood, BLEND where it was left. B taken up on top of A
        stands to A's right, not where it was only waiting — and a host may then move it where the two comb least
        (synth::quietPlaceForB). */
    void takeUp (int m)
    {
        if (heard (m))
            return;
        if (m == 0)
        {
            setup_.aOn = true;
            return;
        }
        setup_.bOn = true;
        if (std::hypot (setup_.b.x - setup_.a.x, setup_.b.y - setup_.a.y) < 0.4f)
        {
            setup_.b.x = ui::jmin (1.05f, setup_.a.x + 0.7f);
            setup_.b.y = 0.0f;
        }
    }

    /** The heard mic under `p` — its glyph, leaning as it is drawn, or its capsule — the one drawn over the other taken
        first; -1 for none. */
    int micAt (ui::Point<float> p) const
    {
        const auto o = coneCentre();
        const float R = radius();
        const auto order = drawOrder (setup_);
        for (int k = 1; k >= 0; --k)
        {
            const int m = order[(size_t) k];
            if (! heard (m))
                continue;
            const auto gl = glyphOf (mic (m), o, R, 1.0f);
            const auto d = p - gl.at;
            const float c = std::cos (gl.lean), s = std::sin (gl.lean);
            const ui::Point<float> upright (gl.at.x + d.x * c + d.y * s, gl.at.y - d.x * s + d.y * c);   // turned back
            if (gl.box.expanded (4.0f).contains (upright) || p.getDistanceFrom (gl.at) < 9.0f)
                return m;
        }
        return -1;
    }

    static void paintMicGlyph (ui::Graphics& g, const ui::String& name, ui::Rectangle<float> box, ui::Colour colour, float lean,
                               ui::Point<float> pivot)
    {
        g.drawGlyph (name, box, colour, lean, pivot);
    }

    void paintColumn (ui::Graphics& g, int m) const
    {
        const auto font = ui::look().font (13.0f);
        const auto c = column (m);
        const auto colour = colourOf (m);
        const bool live = heard (m);
        const float dim = live ? 1.0f : 0.45f;
        const auto& sp = mic (m);
        const auto& cab = cabs()[(size_t) chosen];
        const auto heardBy = sp.mic.isNotEmpty() ? sp.mic : cab.mic;

        // B's a mirror of A's: its words at the right, each mic's glyph after its name (the owner, 05.11).
        const auto side = m == 0 ? ui::Justification::centredLeft : ui::Justification::centredRight;
        g.setColour (colour.withMultipliedAlpha (dim));
        ui::look().drawTracked (g, m == 0 ? "MIC A" : "MIC B", c.toFloat().withHeight ((float) rowH), font, 0.08f, side);

        for (int i = 0; i < mics().size(); ++i)
        {
            auto r = micRow (m, i).toFloat();
            const bool lit = mics()[i] == heardBy, over = isHot (Part::micRow, m, i);
            const auto tint = (lit ? (over ? colour.brighter (0.3f) : colour) : over ? ui::look().tx : ui::look().txFaint).withMultipliedAlpha (dim);
            const auto glyph = m == 0 ? r.removeFromLeft (12.0f) : r.removeFromRight (12.0f);
            paintMicGlyph (g, mics()[i], glyph.reduced (0, 1), tint, 0.0f, {});
            g.setColour (tint);
            ui::look().drawTracked (g, micWords()[i], m == 0 ? r.withTrimmedLeft (8.0f) : r.withTrimmedRight (8.0f), font, 0.06f, side);
        }

        // Its places, in its colour where it stands.
        for (int i = 0; i < placeCount; ++i)
        {
            const bool over = isHot (Part::place, m, i);
            g.setColour ((standsAt (sp, placeAt (i)) ? (over ? colour.brighter (0.3f) : colour) : over ? ui::look().tx : ui::look().txDim)
                             .withMultipliedAlpha (dim));
            ui::look().drawTracked (g, placeAt (i).word, placeArea (m, i).toFloat(), font, 0.06f, ui::Justification::centred);
        }

        // B's ALIGN and Ø, then its TIME: the value, the word, a track with nought marked in its middle — faint while one
        // mic is heard, the two not mixed then.
        if (m == 1)
        {
            const auto toggle = [this] (bool on, Part part)
            {
                const bool over = isHot (part);
                return on ? (over ? ui::look().orange.brighter (0.3f) : ui::look().orange) : over ? ui::look().tx : ui::look().txFaint;
            };
            g.setColour (toggle (bothHeard() && setup_.align, Part::align));
            ui::look().drawTracked (g, "ALIGN", alignArea().toFloat(), font, 0.06f, ui::Justification::centredLeft);
            g.setColour (toggle (bothHeard() && setup_.invert, Part::invert));
            ui::look().drawTracked (g, ui::String::fromUTF8 ("\xc3\x98"), invertArea().toFloat(), font, 0.0f, ui::Justification::centredRight);

            const auto t = timeTrack();
            const auto label = ui::Rectangle<float> ((float) c.getX(), t.getY() - (float) rowH - 3.0f, (float) c.getWidth(), (float) rowH);
            g.setColour (ui::look().txFaint.withMultipliedAlpha (dim));
            ui::look().drawTracked (g, "TIME", label, font, 0.06f, side);
            g.setColour ((std::abs (setup_.shiftMs) > 0.0f ? colour : ui::look().txDim).withMultipliedAlpha (dim));
            ui::look().drawTracked (g, (setup_.shiftMs > 0.0f ? "+" : "") + ui::String (setup_.shiftMs, 2) + " ms", label, font, 0.0f,
                                ui::Justification::centredLeft);
            g.setColour (ui::look().hair2);
            g.fillRoundedRectangle (t.withSizeKeepingCentre (t.getWidth(), 2.0f), 1.0f);
            g.fillRect (ui::Rectangle<float> (1.0f, 8.0f).withCentre (t.getCentre()));
            g.setColour (colour.withMultipliedAlpha (dim));
            const float at = t.getX() + (0.5f + 0.5f * setup_.shiftMs / maxShiftMs) * t.getWidth();
            g.fillRoundedRectangle (ui::Rectangle<float> (6.0f, 12.0f).withCentre ({ at, t.getCentreY() }), 2.0f);
        }
    }

    void paintSpeaker (ui::Graphics& g) const
    {
        const auto font = ui::look().font (13.0f);
        if (chosen < 0)
        {
            // An IR of the player's own plays (or the factory's): the speaker waits for a box.
            g.setColour (ui::look().txFaint);
            ui::look().drawTracked (g, "CHOOSE A CABINET", ui::Rectangle<int> (rightX(), 0, getWidth() - rightX(), bodyH()).toFloat(),
                                font, 0.08f, ui::Justification::centred);
            return;
        }

        const auto& cab = cabs()[(size_t) chosen];
        paintColumn (g, 0);
        paintColumn (g, 1);

        const auto sc = scene();
        const float R = radius();
        const auto o = coneCentre();
        const float s = R / cab.radius;   // px a metre

        // The neighbours and the horn, at the same scale, cut off at the scene's edge.
        {
            ui::Graphics::ScopedSaveState keep (g);
            g.reduceClipRegion (sc.toNearestInt());
            g.setColour (ui::look().bezel);
            g.fillRoundedRectangle (sc, 4.0f);
            for (size_t i = 1; i < cab.drivers.size(); ++i)
            {
                const auto d = cab.drivers[i] - cab.drivers.front();
                g.setColour (ui::look().violet.withAlpha (0.25f));
                g.drawEllipse (ui::Rectangle<float> (2 * R, 2 * R).withCentre (o + ui::Point<float> (d.x * s, -d.y * s)), 1.0f);
            }
            // The horn, big, in its corner; beside it HORN and its steps, the one it stands at in the block's orange.
            if (const auto hc = hornCorner(); ! hc.isEmpty())
            {
                paintHorn (g, hc.getCentre(), hc.getWidth() / 0.12f, setup_.a.horn ? ui::look().lilac.withAlpha (0.8f) : ui::look().txFaint.withAlpha (0.35f));
                const auto side = ui::Justification::centredRight;
                g.setColour (ui::look().txFaint);
                ui::look().drawTracked (g, "HORN", hornWordArea(), font, 0.08f, side);
                for (int i = 0; i < 4; ++i)
                {
                    const bool over = isHot (Part::horn, -1, i);
                    g.setColour (i == hornStep() ? (over ? ui::look().orange.brighter (0.3f) : ui::look().orange) : over ? ui::look().tx : ui::look().txDim);
                    ui::look().drawTracked (g, hornWords[i], hornStepArea (i), font, 0.06f, ui::Justification::centred);
                }
            }

            paintCone (g, o, R);

            // The search's map: each place it judged a dot, green where B and A add, red where they cancel.
            if (searchFade > 0.0f)
                for (const auto& d : searchDots)
                {
                    const float t = ui::jlimit (0.0f, 1.0f, -d.score / 60.0f);
                    const auto at = o + ui::Point<float> (d.x * R, -d.y * R);
                    const auto dot = ui::Rectangle<float> (12.0f, 12.0f).withCentre (at);
                    g.setColour (ui::Colour (0xff3fae6a).interpolatedWith (ui::Colour (0xffd5455a), t).withMultipliedAlpha (0.85f * searchFade));
                    g.fillEllipse (dot);
                    g.setColour (ui::Colours::black.withAlpha (0.5f * searchFade));
                    g.drawEllipse (dot, 1.0f);
                }

            // The guitar's speakers along the scene's top.
            paintSpeakerRow (g);

            // BLEND along the speaker's foot: its track, A's orange at one end and B's lilac at the other, the knob between
            // them in their mix — faint while one mic is heard, the blend not heard then.
            {
                const float dim = bothHeard() ? 1.0f : 0.45f;
                const bool over = drag == Drag::blend || isHot (Part::blend);
                const auto t = blendTrack();
                g.setColour (ui::look().hair2);
                g.fillRoundedRectangle (t.withSizeKeepingCentre (t.getWidth(), 2.0f), 1.0f);
                g.setColour (ui::look().orange.withMultipliedAlpha (0.8f * dim));
                g.fillEllipse (ui::Rectangle<float> (4.0f, 4.0f).withCentre ({ t.getX() - 6.0f, t.getCentreY() }));
                g.setColour (ui::look().lilac.withMultipliedAlpha (0.8f * dim));
                g.fillEllipse (ui::Rectangle<float> (4.0f, 4.0f).withCentre ({ t.getRight() + 6.0f, t.getCentreY() }));
                const auto knob = ui::look().orange.interpolatedWith (ui::look().lilac, setup_.blend);
                g.setColour ((over ? knob.brighter (0.3f) : knob).withMultipliedAlpha (dim));
                g.fillRoundedRectangle (ui::Rectangle<float> (6.0f, 14.0f).withCentre ({ t.getX() + setup_.blend * t.getWidth(), t.getCentreY() }), 2.0f);
            }

            // The mics over all of it, as a click finds them first (hotAt).
            paintMicsOn (g, cab, setup_, o, R, 1.0f, drag == Drag::spot ? dragMic : hot.part == Part::mic ? hot.m : -1);

            // Each heard mic's centimetres under it, the two kept apart.
            const auto labels = distLabels();
            for (int m = 0; m < 2; ++m)
                if (heard (m))
                {
                    g.setColour (colourOf (m));
                    ui::look().drawTracked (g, cmOf (mic (m).distance), labels[(size_t) m], font, 0.0f, ui::Justification::centred);
                }

            // The hand's mic: its distance and its angle out beside it.
            paintHandles (g);

            // A place under the hand (CAP, EDGE, OFF): where it would put its mic, a dot ringed in the mic's colour (the
            // owner, 07.11).
            if (hot.part == Part::place)
            {
                const auto to = placeSpot (hot.m, placeAt (hot.i));
                const auto at = o + ui::Point<float> (to.x * R, -to.y * R);
                g.setColour (colourOf (hot.m));
                g.fillEllipse (ui::Rectangle<float> (7.0f, 7.0f).withCentre (at));
                g.drawEllipse (ui::Rectangle<float> (16.0f, 16.0f).withCentre (at), 1.4f);
            }
        }

        paintFind (g);
        paintButton (g, "FRED", fredArea(), false, isHot (Part::fred));
        paintButton (g, defaultArmed ? "SURE?" : "DEFAULT", defaultArea(), defaultArmed, isHot (Part::reset));
        paintButton (g, "CLOSE", closeArea(), false, isHot (Part::close));
    }

    /** THE GUITAR'S SPEAKERS along the scene's top: a curve each, the box's in the block's orange, its own a dot under it;
        the one under the hand grown, its word under it; the cone's switch after them, orange while it is on. */
    void paintSpeakerRow (ui::Graphics& g) const
    {
        if (! hasSpeakers())
            return;
        const int own = ownSpeaker (chosen), on = speakerOf (chosen, setup_);
        const bool cone = catalog().coneVariant.isNotEmpty();
        const auto colourAt = [&] (int i)
        {
            const bool lit = i < 0 ? setup_.cone : i == on;
            const bool over = i < 0 ? isHot (Part::speakerCone) : isHot (Part::speaker, -1, i);
            return lit ? (over ? ui::look().orange.brighter (0.3f) : ui::look().orange) : over ? ui::look().tx : ui::look().violet.withAlpha (0.75f);
        };
        const auto nameAt = [] (int i) { return i < 0 ? ui::String() : catalog().speakers[i]; };
        const int grown = hot.part == Part::speaker ? hot.i : hot.part == Part::speakerCone ? -1 : -2;

        for (int i = cone ? -1 : 0; i < catalog().speakers.size(); ++i)
        {
            const auto cell = speakerCell (i);
            if (i != grown)
                paintSpeakerIcon (g, nameAt (i), cell, colourAt (i), 1.4f);
            if (i >= 0 && i == own)
            {
                g.setColour (ui::look().txDim);
                g.fillEllipse (ui::Rectangle<float> (3.0f, 3.0f).withCentre ({ cell.getCentreX(), cell.getBottom() + 3.5f }));
            }
        }
        if (grown < -1)
            return;

        // The one under the hand, grown over its neighbours, its word under it.
        const auto sc = scene();
        const auto cell = speakerCell (grown);
        auto big = cell.withSizeKeepingCentre (1.7f * cell.getWidth(), 1.7f * cell.getHeight());
        big = big.withPosition (big.getX(), ui::jmax (sc.getY() + 2.0f, big.getY()));
        const auto font = ui::look().font (13.0f);
        const auto word = grown < 0 ? catalog().coneVariant.toUpperCase() : catalog().speakerWords[grown];
        const float w = ui::look().trackedWidth (word, font, 0.06f) + 12.0f;
        const float x = ui::jlimit (sc.getX() + 2.0f, sc.getRight() - 2.0f - w, cell.getCentreX() - 0.5f * w);
        const ui::Rectangle<float> label (x, big.getBottom() + 3.0f, w, 18.0f);
        g.setColour (ui::look().bezel);
        g.fillRoundedRectangle (big.expanded (4.0f, 3.0f), 3.0f);
        g.setColour (ui::look().bezel.withAlpha (0.9f));
        g.fillRoundedRectangle (label, 3.0f);
        paintSpeakerIcon (g, nameAt (grown), big, colourAt (grown), 1.8f);
        g.setColour (ui::look().tx);
        ui::look().drawTracked (g, word, label, font, 0.06f, ui::Justification::centred);
    }

    /** A button: a box round its word — DEFAULT, CLOSE, DOWNLOAD IR — orange while it asks. */
    static void paintButton (ui::Graphics& g, const char* word, ui::Rectangle<int> r, bool asking, bool over = false)
    {
        if (r.isEmpty())
            return;
        const auto b = r.toFloat().reduced (0.5f, 1.5f);
        g.setColour (ui::look().panel2);
        g.fillRoundedRectangle (b, 4.0f);
        g.setColour (asking ? ui::look().orange : over ? ui::look().txDim : ui::look().txFaint);   // under the hand: its line up
        g.drawRoundedRectangle (b, 4.0f, asking ? 1.2f : 1.0f);
        g.setColour (asking ? ui::look().orange : over ? ui::look().tx : ui::look().txDim);
        ui::look().drawTracked (g, word, b, ui::look().font (13.0f), 0.06f, ui::Justification::centred);
    }

    // ---------------------------------------------------------------- the response
    // Across the panel under it all: the cabinet's response, 30 Hz to 12 kHz on a log scale, +15 to -30 dB — the one
    // heard green to red, the one kept before it a faint grey ghost; dB at the left, the frequencies under.
    std::vector<float> responseNow, responseBefore, responseComb;
    std::vector<float> responseBad;   // dB, each point: how far it falls into a pit, or its two mics cancel there — the deeper
    // +15 over the middle, -30 under it: a cabinet's response rarely climbs past +10, its roll-offs and a comb's dips
    // go to -20 and -30, and under that nothing more is heard (the owner, 05.11).
    static constexpr float responseTop = 15.0f, responseBottom = -30.0f;

    ui::Rectangle<int> responseArea() const { return { 0, bodyH(), getWidth(), responseH }; }

    ui::Rectangle<float> responsePlot() const
    {
        return responseArea().toFloat().withTrimmedLeft (36.0f).withTrimmedRight (12.0f).withTrimmedTop (9.0f).withTrimmedBottom (20.0f);
    }

    // ---------------------------------------------------------------- the EQ over the response
    // EQ's switch in the band's top left corner, as DOWNLOAD IR is in its right (the owner, 09.11). While it is on, its
    // line in orange over the cabinet's — its passes dashed across the band, each out at its own edge, its three bells
    // a dot each at their own gain — and what plays a violet wash under them all.
    static constexpr int eqBells = 3;
    static constexpr float maxHighPassHz = 800.0f, minLowPassHz = 800.0f, maxBellDb = 15.0f;
    int dragEq = 0;                 // the pass (0 the high, 1 the low) or the bell a drag holds
    static constexpr int passSlopes[] { 6, 12, 24, 48 };   // a pass's slopes, dB an octave
    static constexpr float slopeStep = 28.0f;               // ...a step each this far up or down a pass's drag
    static int slopeIndex (int slope) { return slope <= 6 ? 0 : slope <= 12 ? 1 : slope <= 24 ? 2 : 3; }
    float grabY = 0;                // a pass taken: where the hand was, and its slope then
    int grabSlope = 12;
    double wheelUntil = 0;          // a bell's width turned by the wheel, kept once it has stood till then; 0 none
    std::vector<float> spectrumDb;  // what plays (showSpectrum)
    std::vector<float> spectrumPreDb;   // ...and what goes in
    bool spectrumWanted = true;     // SPECTRUM ticked (setSpectrumOn)

    float xOfHz (float hz) const
    {
        const auto p = responsePlot();
        return p.getX() + p.getWidth() * std::log (hz / 30.0f) / std::log (12000.0f / 30.0f);
    }
    float hzOfX (float x) const
    {
        const auto p = responsePlot();
        return 30.0f * std::pow (12000.0f / 30.0f, ui::jlimit (0.0f, 1.0f, (x - p.getX()) / p.getWidth()));
    }
    float yOfDb (float db) const
    {
        const auto p = responsePlot();
        return p.getY() + (responseTop - db) / (responseTop - responseBottom) * p.getHeight();
    }
    float dbOfY (float y) const
    {
        const auto p = responsePlot();
        return responseTop - (y - p.getY()) / p.getHeight() * (responseTop - responseBottom);
    }

    ui::Rectangle<int> eqBoxArea() const
    {
        if (chosen < 0)
            return {};
        const auto plot = responsePlot().toNearestInt();
        return { plot.getX() + 6, plot.getY() + 6, eqTickSize + 6 + wordW ("EQ") + 8, 24 };
    }
    static constexpr int eqTickSize = 12;

    ui::Point<float> bellAt (int i) const
    {
        const auto& b = setup_.eq.bells[(size_t) i];
        return { xOfHz ((float) b.hz), yOfDb ((float) b.db) };
    }

    float passX (int i) const
    {
        const auto p = responsePlot();
        const double hz = i == 0 ? setup_.eq.highPassHz : setup_.eq.lowPassHz;
        return hz > 0 ? xOfHz ((float) hz) : i == 0 ? p.getX() : p.getRight();
    }

    /** A pass's handle at the band's foot, HPF or LPF on it, against its line — so a pass out at its edge is still seen
        and taken (the owner, 09.11). */
    ui::Rectangle<float> passTab (int i) const
    {
        const auto p = responsePlot();
        const float w = (float) wordW (passWords[i]) + 12.0f, h = 22.0f, x = passX (i);
        return { i == 0 ? x : x - w, p.getBottom() - 6.0f - h, w, h };
    }
    static constexpr const char* passWords[] { "HPF", "LPF" };

    static ui::String hzWord (double hz)
    {
        return hz >= 1000.0 ? ui::String ((float) (hz / 1000.0), hz >= 10000.0 ? 1 : 2) + " KHZ" : ui::String ((int) std::lround (hz)) + " HZ";
    }

    /** The switch: a box ticked while the EQ is on and its word, straight on the band (the owner, 09.11). */
    void paintEqBox (ui::Graphics& g) const
    {
        const auto r = eqBoxArea();
        if (r.isEmpty())
            return;
        const bool on = setup_.eq.on, over = isHot (Part::eq);
        const auto b = r.toFloat();
        const auto tick = ui::Rectangle<float> (b.getX() + 2.0f, b.getCentreY() - 0.5f * eqTickSize, (float) eqTickSize, (float) eqTickSize);
        g.setColour (on ? ui::look().orange : over ? ui::look().tx : ui::look().txDim);
        g.drawRoundedRectangle (tick, 2.0f, 1.3f);
        if (on)
            g.fillRoundedRectangle (tick.reduced (3.0f), 1.0f);
        ui::look().drawTracked (g, "EQ", b.withTrimmedLeft (2.0f + eqTickSize + 6.0f), ui::look().font (13.0f), 0.06f, ui::Justification::centredLeft);
    }

    /** What plays, under the curves: a wash from 0 dBFS at the band's top to -84 at its foot, its edge a faint line —
        violet; and behind it what goes into the cabinet, grey and fainter, as tabbyEQ draws its pre and post. */
    void paintSpectrum (ui::Graphics& g, ui::Rectangle<float> p) const
    {
        if (! spectrumOn())
            return;
        // Below -84 it goes under the band's foot, out of the frame, not along it (the owner, 09.11) — as the curves do.
        ui::Graphics::ScopedSaveState keep (g);
        g.reduceClipRegion (p.toNearestInt());
        const auto wash = [&g, p, this] (const std::vector<float>& db, ui::Colour c, float fill, float edge)
        {
            if ((int) db.size() != spectrumColumns)
                return;
            const auto yOf = [p] (float v) { return p.getY() + ui::jlimit (0.0f, 1.5f, -v / 84.0f) * p.getHeight(); };
            g.setGradientFill (ui::ColourGradient (c.withAlpha (fill), 0.0f, p.getY(), c.withAlpha (0.12f * fill), 0.0f, p.getBottom(), false));
            ui::Path top;
            for (int i = 0; i < spectrumColumns; ++i)
            {
                // Each column from a whole pixel to the next one's: a wash that neither overlaps nor gaps reads as one.
                const float x = xOfHz (spectrumHz (i)), y = yOf (db[(size_t) i]);
                const float x0 = std::round (i == 0 ? p.getX() : 0.5f * (xOfHz (spectrumHz (i - 1)) + x));
                const float x1 = std::round (i == spectrumColumns - 1 ? p.getRight() : 0.5f * (x + xOfHz (spectrumHz (i + 1))));
                if (x1 > x0 && y < p.getBottom())
                    g.fillRect (ui::Rectangle<float> (x0, y, x1 - x0, p.getBottom() - y));
                if (i == 0)
                    top.startNewSubPath (x, y);
                else
                    top.lineTo (x, y);
            }
            g.setColour (c.withAlpha (edge));
            g.strokePath (top, ui::PathStrokeType (1.0f, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));
        };
        wash (spectrumPreDb, ui::look().tx, 0.06f, 0.24f);
        wash (spectrumDb, ui::look().violet, 0.18f, 0.42f);
    }

    /** The EQ's line, its passes and its bells, while it is on — and what the one under the hand or held is set to. */
    void paintEq (ui::Graphics& g, ui::Rectangle<float> p) const
    {
        if (! eqOn())
            return;
        const auto stages = synth::eqStages (setup_.eq);
        ui::Path line;
        for (int i = 0; i < responsePoints; ++i)
        {
            const float hz = responseHz (i);
            const ui::Point<float> at (xOfHz (hz), yOfDb (ui::jlimit (3.0f * responseBottom, 3.0f * responseTop, (float) synth::eqDb (stages, hz))));
            if (i == 0)
                line.startNewSubPath (at);
            else
                line.lineTo (at);
        }
        g.setColour (ui::look().orange.withAlpha (0.85f));
        g.strokePath (line, ui::PathStrokeType (1.4f, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));

        const auto held = [this] (Part part, int i) { return (drag == (part == Part::eqPass ? Drag::eqPass : Drag::eqBell) && dragEq == i) || isHot (part, -1, i); };
        // The passes, dashed across the band: bright while in, faint out at their edge.
        for (int i = 0; i < 2; ++i)
        {
            const bool in = (i == 0 ? setup_.eq.highPassHz : setup_.eq.lowPassHz) > 0, lit = held (Part::eqPass, i);
            const float x = passX (i) + (in ? 0.0f : i == 0 ? 1.0f : -2.0f);
            g.setColour (ui::look().orange.withAlpha (lit ? 1.0f : in ? 0.7f : 0.3f));
            for (float y = p.getY(); y < p.getBottom(); y += 8.0f)
                g.fillRect (ui::Rectangle<float> (x - 0.6f, y, lit ? 1.8f : 1.2f, ui::jmin (4.0f, p.getBottom() - y)));
            // ...and its handle, lit as the EQ's switch is: orange while in, grey while out.
            const auto t = passTab (i).reduced (0.5f);
            g.setColour (ui::look().panel2.withAlpha (0.92f));
            g.fillRoundedRectangle (t, 4.0f);
            g.setColour (in ? ui::look().orange.withAlpha (lit ? 1.0f : 0.6f) : lit ? ui::look().txDim : ui::look().txFaint);
            g.drawRoundedRectangle (t, 4.0f, 1.0f);
            g.setColour (in ? ui::look().orange : lit ? ui::look().tx : ui::look().txDim);
            ui::look().drawTracked (g, passWords[i], t, ui::look().font (13.0f), 0.06f, ui::Justification::centred);
        }
        // The bells: a dot each, solid once off nought, a ring while flat.
        for (int i = 0; i < eqBells; ++i)
        {
            const auto c = bellAt (i);
            const bool lit = held (Part::eqBell, i), flat = setup_.eq.bells[(size_t) i].flat();
            const float r = lit ? 6.0f : 5.0f;
            const auto dot = ui::Rectangle<float> (c.x - r, c.y - r, 2.0f * r, 2.0f * r);
            g.setColour (ui::look().panel2);
            g.fillEllipse (dot);
            g.setColour (lit ? ui::look().orange.brighter (0.3f) : ui::look().orange);
            if (flat)
                g.drawEllipse (dot.reduced (0.7f), 1.4f);
            else
                g.fillEllipse (dot);
        }
        // What the one under the hand, or held, is set to — over it, or under it near the band's top.
        ui::String word;
        ui::Point<float> near;
        for (int i = 0; i < eqBells; ++i)
            if (held (Part::eqBell, i))
            {
                const auto& b = setup_.eq.bells[(size_t) i];
                word = hzWord (b.hz) + "  " + (b.db > 0 ? "+" : "") + ui::String ((float) b.db, 1) + " DB  Q " + ui::String ((float) b.q, 2);
                near = bellAt (i);
            }
        for (int i = 0; i < 2; ++i)
            if (held (Part::eqPass, i))
            {
                const double hz = i == 0 ? setup_.eq.highPassHz : setup_.eq.lowPassHz;
                word = ui::String (passWords[i]) + " " + (hz > 0 ? hzWord (hz) : ui::String ("OFF")) + "  "
                       + ui::String (i == 0 ? setup_.eq.highPassSlope : setup_.eq.lowPassSlope) + " DB/OCT";
                near = { passX (i), p.getY() + 0.5f * p.getHeight() };
            }
        if (word.isEmpty())
            return;
        const float w = (float) wordW (word.toRawUTF8()) + 16.0f, h = 22.0f;
        const float x = ui::jlimit (p.getX() + 2.0f, p.getRight() - w - 2.0f, near.x - 0.5f * w);
        const float y = near.y - 14.0f - h < p.getY() ? near.y + 14.0f : near.y - 14.0f - h;
        const ui::Rectangle<float> box (x, y, w, h);
        g.setColour (ui::look().panel2.withAlpha (0.94f));
        g.fillRoundedRectangle (box, 4.0f);
        g.setColour (ui::look().orange.withAlpha (0.6f));
        g.drawRoundedRectangle (box.reduced (0.5f), 4.0f, 1.0f);
        g.setColour (ui::look().tx);
        ui::look().drawTracked (g, word, box, ui::look().font (13.0f), 0.04f, ui::Justification::centred);
    }

    /** THE INSTRUMENT'S NAME across the response, a watermark — BASS CAB, GUITAR CAB, big, solid and pale, under the curve,
        the comb's colours and the grid — so the two builders are never taken one for the other (the owner, 07.11);
        brighter while the hand is over the response. */
    void paintInstrument (ui::Graphics& g, ui::Rectangle<float> plot) const
    {
        const float e = responseFade * responseFade * (3.0f - 2.0f * responseFade);   // eased in and out
        g.setColour (ui::look().violet.withAlpha (instrumentAlpha + (instrumentAlphaOver - instrumentAlpha) * e));
        ui::look().drawTracked (g, catalog().instrumentWord, plot, ui::look().font (instrumentSize), 0.08f, ui::Justification::centred);
    }
    static constexpr float instrumentSize = 102.0f, instrumentAlpha = 0.11f, instrumentAlphaOver = 0.22f;

    /** The hand over the response, and the watermark brightening toward it: 0 none .. 1 whole, a quarter of a second. */
    bool overResponse = false;
    float responseFade = 0.0f;
    static constexpr float responseFadeSeconds = 0.25f;
    bool responseFading() const { return overResponse ? responseFade < 1.0f : responseFade > 0.0f; }

    void stepResponseFade (double dt)
    {
        if (! responseFading())
            return;
        const float by = (float) (dt / responseFadeSeconds);
        responseFade = overResponse ? ui::jmin (1.0f, responseFade + by) : ui::jmax (0.0f, responseFade - by);
        repaint (responseArea());
    }

    void paintResponse (ui::Graphics& g) const
    {
        const auto font = ui::look().font (13.0f);
        const auto area = responseArea().toFloat();
        const auto p = responsePlot();
        g.setColour (ui::look().hair);
        g.fillRect (area.withHeight (1.0f));

        const auto xOf = [p] (float hz) { return p.getX() + p.getWidth() * std::log (hz / 30.0f) / std::log (12000.0f / 30.0f); };
        const auto yOf = [p] (float db) { return p.getY() + (responseTop - db) / (responseTop - responseBottom) * p.getHeight(); };

        paintInstrument (g, p);

        // Under it all, with two mics heard, where they meet (the owner, 05.11): green where they add in phase, red
        // where they cancel — the stronger, the deeper, full at 6 dB.
        if ((int) responseComb.size() == responsePoints)
            for (int i = 0; i < responsePoints; ++i)
            {
                const float x0 = i == 0 ? p.getX() : 0.5f * (xOf (responseHz (i - 1)) + xOf (responseHz (i)));
                const float x1 = i == responsePoints - 1 ? p.getRight() : 0.5f * (xOf (responseHz (i)) + xOf (responseHz (i + 1)));
                const float v = responseComb[(size_t) i];
                g.setColour ((v > 0.0f ? ui::Colour (0xff3fae6a) : ui::Colour (0xffd5455a)).withAlpha (0.45f * ui::jmin (1.0f, std::abs (v) / 6.0f)));
                g.fillRect (ui::Rectangle<float> (x0, p.getY(), x1 - x0 + 0.5f, p.getHeight()));
            }
        paintSpectrum (g, p);

        struct Mark { float hz; const char* word; };
        static constexpr Mark marks[] { { 50.0f, "50" }, { 100.0f, "100" }, { 200.0f, "200" }, { 500.0f, "500" },
                                        { 1000.0f, "1k" }, { 2000.0f, "2k" }, { 5000.0f, "5k" }, { 10000.0f, "10k" } };
        for (const auto& m : marks)
        {
            const float x = xOf (m.hz);
            g.setColour (ui::look().hair);
            g.fillRect (ui::Rectangle<float> (x, p.getY(), 1.0f, p.getHeight()));
            g.setColour (ui::look().txFaint);
            ui::look().drawTracked (g, m.word, { x - 20.0f, p.getBottom() + 3.0f, 40.0f, 16.0f }, font, 0.0f, ui::Justification::centred);
        }
        struct Level { float db; const char* word; };
        static constexpr Level levels[] { { 10.0f, "+10" }, { 0.0f, "0" }, { -10.0f, "-10" }, { -20.0f, "-20" }, { -30.0f, "-30" } };
        for (const auto& l : levels)
        {
            const float y = yOf (l.db);
            g.setColour (std::abs (l.db) < 1.0f ? ui::look().hair2 : ui::look().hair);
            g.fillRect (ui::Rectangle<float> (p.getX(), y, p.getWidth(), 1.0f));
            g.setColour (ui::look().txFaint);
            ui::look().drawTracked (g, l.word, { area.getX() + 2.0f, y - 8.0f, 28.0f, 16.0f }, font, 0.0f, ui::Justification::centredRight);
        }

        const auto curve = [&] (const std::vector<float>& db, ui::Colour colour, float width, int from = 0, int to = responsePoints - 1)
        {
            if ((int) db.size() != responsePoints)
                return;
            ui::Path path;
            for (int i = from; i <= to; ++i)
            {
                // Past the scale it goes out of the frame, as a dip does, not along its floor (the owner, 05.11).
                const ui::Point<float> at (xOf (responseHz (i)), yOf (ui::jlimit (3.0f * responseBottom, 3.0f * responseTop, db[(size_t) i])));
                if (i == from)
                    path.startNewSubPath (at);
                else
                    path.lineTo (at);
            }
            g.setColour (colour);
            g.strokePath (path, ui::PathStrokeType (width, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));
        };
        ui::Graphics::ScopedSaveState keep (g);
        g.reduceClipRegion (p.toNearestInt().expanded (0, 2));
        curve (responseBefore, ui::look().txDim.withAlpha (0.3f), 1.2f);   // barely there: a second line reads as a second mic
        // What plays, green where it is fine and red where it falls into a pit or its two mics cancel — from 3 dB, full
        // red at 6, the bounds the presets are held to (the owner, 05.11): drawn in runs of one shade, each segment as
        // red as the worse of its two ends.
        if (responseBad.size() == responseNow.size())
        {
            const auto shade = [this] (int i)
            {
                // Past 3 dB at all, a shade at least: the line reddens where FIND would move a mic (synth::MicSearch).
                const auto at = [this] (int k) { return ui::jlimit (0, 8, (int) std::ceil ((responseBad[(size_t) k] - 3.0f) / 3.0f * 8.0f)); };
                return ui::jmax (at (i), at (i + 1));
            };
            for (int from = 0; from < (int) responseNow.size() - 1;)
            {
                const int level = shade (from);
                int to = from + 1;
                while (to < (int) responseNow.size() - 1 && shade (to) == level)
                    ++to;
                curve (responseNow, ui::Colour (0xff3fae6a).interpolatedWith (ui::Colour (0xffd5455a), (float) level / 8.0f), 1.6f, from, to);
                from = to;
            }
        }
        paintEq (g, p);
        paintEqBox (g);

        // DOWNLOAD IR over the corner, its line pulsing slowly — the one thing the response invites a hand to do.
        if (const auto d = downloadArea(); ! d.isEmpty())
        {
            const float pulse = isHot (Part::download) ? 1.0f   // under the hand: full, still
                                                       : 0.5f + 0.5f * (float) std::sin (ui::MathConstants<double>::twoPi * 0.5 * clock);
            const auto b = d.toFloat().reduced (0.5f);
            {
                ui::Graphics::ScopedSaveState clip (g);
                g.reduceClipRegion (d.expanded (2));
                g.setColour (ui::look().panel2.withAlpha (0.92f));
                g.fillRoundedRectangle (b, 4.0f);
                g.setColour (ui::look().orange.withAlpha (0.35f + 0.55f * pulse));
                g.drawRoundedRectangle (b, 4.0f, 1.3f);
                g.setColour (ui::look().orange.withAlpha (0.75f + 0.25f * pulse));
                ui::look().drawTracked (g, "DOWNLOAD IR", b, ui::look().font (13.0f), 0.06f, ui::Justification::centred);
            }
            // Its format's ▾, still — it answers the hand only.
            if (const auto f = downloadFormatArea(); ! f.isEmpty())
            {
                const auto m = f.toFloat().reduced (0.5f);
                const bool over = isHot (Part::downloadFormat);
                g.setColour (ui::look().panel2.withAlpha (0.92f));
                g.fillRoundedRectangle (m, 4.0f);
                g.setColour (ui::look().orange.withAlpha (over ? 0.9f : 0.45f));
                g.drawRoundedRectangle (m, 4.0f, 1.3f);
                ui::Path down;
                down.startNewSubPath (m.getCentreX() - 4.5f, m.getCentreY() - 2.0f);
                down.lineTo (m.getCentreX(), m.getCentreY() + 2.5f);
                down.lineTo (m.getCentreX() + 4.5f, m.getCentreY() - 2.0f);
                g.setColour (ui::look().orange.withAlpha (over ? 1.0f : 0.8f));
                g.strokePath (down, ui::PathStrokeType (1.6f, ui::PathStrokeType::curved, ui::PathStrokeType::rounded));
            }
            // ...and what the next download will be, under them.
            if (downloadNote.isNotEmpty())
            {
                const float right = (float) (downloadFormatArea().isEmpty() ? d : downloadFormatArea()).getRight();
                g.setColour (ui::look().txDim);
                ui::look().drawTracked (g, downloadNote, { right - 320.0f, (float) d.getBottom() + 4.0f, 320.0f, 16.0f },
                                        ui::look().font (13.0f), 0.0f, ui::Justification::centredRight);
            }
        }
    }

    /** The "?" — an orange ring, so it is seen (the owner, 07.11), brighter under the hand and while its window is out, and
        thicker once a click keeps it — and over everything the window out, its text at 13 px. */
    void paintHelp (ui::Graphics& g) const
    {
        const auto font = ui::look().font (helpTextSize);
        for (int i = 0; i < helpSpots; ++i)
        {
            const auto m = helpSpot (i).mark.toFloat().reduced (0.5f);
            const bool open = helpOpen == i, lit = open || isHot (Part::help, -1, i);
            g.setColour (ui::look().panel2);
            g.fillEllipse (m);
            const auto ink = lit ? ui::look().orange.brighter (0.3f) : ui::look().orange;
            g.setColour (ink);
            g.drawEllipse (m.reduced (open && helpPinned ? 0.3f : 0.0f), open && helpPinned ? 1.8f : 1.3f);
            ui::look().drawTracked (g, "?", m, font, 0.0f, ui::Justification::centred);
        }
        if (helpOpen < 0)
            return;
        const auto b = helpBox (helpOpen).toFloat();
        g.setColour (ui::look().panel2.withAlpha (0.97f));
        g.fillRoundedRectangle (b, 6.0f);
        g.setColour (helpPinned ? ui::look().orange.withAlpha (0.7f) : ui::look().violet.withAlpha (0.6f));
        g.drawRoundedRectangle (b.reduced (0.5f), 6.0f, 1.0f);
        g.setColour (ui::look().tx);
        float y = b.getY() + (float) helpPad - 2.0f;
        for (const auto& line : helpLines (helpOpen, (int) b.getWidth() - 2 * helpPad))
        {
            if (line.empty())
            {
                y += (float) helpGap;
                continue;
            }
            ui::look().drawTracked (g, line, { b.getX() + (float) helpPad, y, b.getWidth() - 2.0f * (float) helpPad, (float) helpLineH },
                                    font, 0.0f, ui::Justification::centredLeft);
            y += (float) helpLineH;
        }
    }

};

/** A STATE FROM ITS TEXT, as the panel can draw and the synthesis render it: none where the text is none, or where it
    names a box the table has not — one kept by an older version under a name since changed, say (0.1.3 named the boxes by
    size and family), which would render a box of no cones — or a mic the panel has not, which it has no glyph to draw
    (a hand-made or mangled text, the site found 07.11). Wherever a state comes in from outside — a run's workspace, a
    preset file, a host's session, a page — it comes through here, and a caller falls back to its default. */
inline std::optional<State> knownState (const std::string& toml)
{
    auto s = fromToml (toml);
    const auto knownMic = [] (const Mic& m) { return m.model.empty() || Panel::mics().contains (ui::String (m.model)); };
    if (s && (Panel::indexOf (ui::String (s->box)) < 0 || ! knownMic (s->a) || ! knownMic (s->b)))
        return std::nullopt;
    return s;
}

} // namespace cabir
