// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-appkit — see LICENSE.

#pragma once

//==============================================================================
// felitronics::appkit::LevelHistory — a scrolling peak-level history strip (dBFS), generalized from
// OrbitCapture's per-mic MicHistory for the family's calibrators. Feed contract mirrors LevelMeter:
// the GUI timer calls push(linearPeak) once per tick on the message thread; every push scrolls one
// column, so the visible window is capacityTicks over the feed rate (default 600 ≈ 30 s at 20 Hz,
// 20 s at 30 Hz). setRange() zooms the dBFS window like LevelMeter.
//
// Two optional overlays tint the trace (default is a plain grey trace):
//   • setRefLines({(dB, colour)…}) — the FIXED calibration grid (the primary calibrator surface):
//     dashed coloured reference lines that never move, with the trace fill/stroke gradient-tinted to
//     match them (dark low → red high). Pair with setNoiseFloor(dB) for a black room-quiet line and
//     setCurrentDb(dB) for a live level readout in the bottom-right corner.
// setTargetBand(lo, hi, colour) fills the window a level is being placed in, under the trace and under
// the grid; setSecondBand(lo, hi, colour) fills another beside it, for a strip that carries two aims
// read at different moments.
//   • setGreenZone(loDb, hiDb) — an alternate MOVING corridor: dashed green-floor / amber-ceiling
//     lines with the trace tinted grey→green→red around them; a non-finite or inverted pair CLEARS it.
// setClipCeiling(dB) marks a hard "too hot" line independent of the mode: every column that broke it
// gets a full-height red bar (an overload can't hide in the trace); in corridor mode it also opens a
// yellow band up to the line. peakDb() exposes the held peak (sticks ~1.5 s, then decays) for a
// readout or shared verdict. Header-only; the consumer supplies juce_audio_basics + juce_gui_basics.
//==============================================================================

#include "DbGradient.h"

#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_gui_basics/juce_gui_basics.h>

#include <algorithm>
#include <cmath>
#include <initializer_list>
#include <limits>
#include <utility>
#include <vector>

namespace felitronics::appkit
{

class LevelHistory final : public juce::Component
{
public:
    explicit LevelHistory (int capacityTicks = 600)
        : hist_ ((size_t) juce::jmax (2, capacityTicks), kSilenceDb) {}

    // Zoom the dBFS window (floor .. ceiling). Default −60..0 — the MicHistory window.
    void setRange (float floorDb, float ceilDb)
    {
        if (! std::isfinite (floorDb) || ! std::isfinite (ceilDb) || floorDb >= ceilDb)
            return;

        minDb_ = floorDb;
        maxDb_ = ceilDb;
        repaint();
    }

    // The calibration corridor: dashed green floor + dashed red ceiling, trace/fill tinted around
    // them. An invalid pair (non-finite or loDb >= hiDb) clears the corridor — plain grey trace.
    void setGreenZone (float loDb, float hiDb)
    {
        if (std::isfinite (loDb) && std::isfinite (hiDb) && loDb < hiDb) { zoneLo_ = loDb; zoneHi_ = hiDb; }
        else { zoneLo_ = zoneHi_ = std::numeric_limits<float>::quiet_NaN(); }
        repaint();
    }

    // A hard "too hot" ceiling, independent of the displayed corridor: any history column whose peak
    // exceeded ceilDb is painted a FULL-HEIGHT red bar (an overload can't hide down in the trace). A
    // non-finite value clears it. Distinct from the green zone's red ceiling line, which only tints.
    void setClipCeiling (float ceilDb)
    {
        clipCeiling_ = ceilDb;
        repaint();
    }

    // One GUI tick: append the latest linear peak (0..~1+) and advance the strip one column.
    void push (float linearPeak)
    {
        const float db = juce::Decibels::gainToDecibels (juce::jmax (0.0f, linearPeak), kSilenceDb);
        hist_[(size_t) head_] = db;
        head_ = (head_ + 1) % (int) hist_.size();

        if (db >= peakHold_) { peakHold_ = db; peakAge_ = 0; }                       // stick…
        else if (++peakAge_ > kHoldTicks)                                            // …then walk down
        {
            peakAge_  = kHoldTicks + 1;                                              // cap: no unbounded growth over long silence
            peakHold_ = juce::jmax (db, peakHold_ - kDecayDbPerTick);
        }

        repaint();
    }

    void clear()
    {
        std::fill (hist_.begin(), hist_.end(), kSilenceDb);
        head_ = 0;
        peakHold_ = kSilenceDb;
        peakAge_ = 0;
        repaint();
    }

    // The held peak (dBFS) — the stable read for a readout or a shared calibration verdict.
    float peakDb() const { return peakHold_; }

    // The instant return level (dBFS) drawn as a big readout in the bottom-right corner (coloured by
    // loudness). Set from the GUI timer; a change under 0.05 dB is ignored to avoid churn repaints.
    void setCurrentDb (float db) { if (std::abs (db - curDb_) > 0.05f) { curDb_ = db; repaint(); } }

    // A fixed reference line (dBFS) — the noise-floor threshold to calibrate the room against with the
    // tone off. Drawn as a black line across the strip; a non-finite value hides it.
    void setNoiseFloor (float db) { noiseFloor_ = db; repaint(); }

    // Fixed dBFS reference lines (the calibration grid) — always drawn, never move: each entry is a
    // dashed coloured line across the strip, and the trace is gradient-tinted to match. The entry
    // order does not matter (endpoints are chosen by dB); non-finite dB entries are dropped. Takes
    // paint precedence over the setGreenZone corridor; an empty list clears the grid. A non-empty
    // label is captioned bottom-left UNDER the line ("-15 dB") in the line's colour.
    // `dash` scales the dash pattern: 1 is the grid's own, larger is sparser. A line that is NOT part
    // of a regular grid — a single level somebody chose, sitting between two of its rungs — needs to
    // say so at a glance, and a longer stride says it without another colour or another weight.
    struct RefLine { float db {}; juce::Colour colour {}; juce::String label {}; float dash { 1.0f }; };

    void setRefLines (std::vector<RefLine> lines)
    {
        refLines_.clear();
        for (auto& l : lines) if (std::isfinite (l.db)) refLines_.push_back (std::move (l));
        repaint();
    }

    void setRefLines (std::vector<std::pair<float, juce::Colour>> lines)   // label-less convenience
    {
        std::vector<RefLine> rl;
        rl.reserve (lines.size());
        for (auto& l : lines) rl.push_back ({ l.first, l.second, {} });
        setRefLines (std::move (rl));
    }

    // A braced call — setRefLines({{-15.0f, colour}, …}) or setRefLines({}) — is otherwise ambiguous
    // between the two vector overloads above (each inner {dB, colour} initializes a RefLine OR a pair
    // equally). An initializer_list overload wins that list-initialization, so the terse form this
    // header documents stays legal; it forwards to the labelled overload with empty labels.
    void setRefLines (std::initializer_list<RefLine> lines) { setRefLines (std::vector<RefLine> (lines)); }

    // THE TARGET WINDOW: "leave the level in here". A translucent band between two dBFS, drawn under
    // the trace and independent of BOTH the reference grid and the setGreenZone corridor — a surface
    // that already carries a 6 dB grid can still say where the hand is aiming, without a fourth kind of
    // line to tell apart. An invalid pair (non-finite, or lo >= hi) clears it.
    void setTargetBand (float loDb, float hiDb, juce::Colour colour)
    {
        if (std::isfinite (loDb) && std::isfinite (hiDb) && loDb < hiDb) { bandLo_ = loDb; bandHi_ = hiDb; }
        else { bandLo_ = bandHi_ = std::numeric_limits<float>::quiet_NaN(); }
        bandColour_ = colour;
        repaint();
    }

    // A SECOND window, drawn exactly like the first and under it. Two are wanted when a strip carries
    // two aims at once that are read at different moments — a capture bench sets its reamp send while
    // watching one, then turns the input up and lands the take in the other. Drawing the second as
    // dashed lines instead was tried and read as part of the grid; a window is a window, and the
    // colour is what says which. Non-finite or inverted CLEARS it, like the first.
    void setSecondBand (float loDb, float hiDb, juce::Colour colour)
    {
        if (std::isfinite (loDb) && std::isfinite (hiDb) && loDb < hiDb) { band2Lo_ = loDb; band2Hi_ = hiDb; }
        else { band2Lo_ = band2Hi_ = std::numeric_limits<float>::quiet_NaN(); }
        band2Colour_ = colour;
        repaint();
    }

    // How heavy the dashed grid is drawn. A calibration surface that carries a line every 6 dB reads
    // as a cage at the default weight — a hairline says the same thing and leaves the trace the
    // loudest thing on the strip. Applies to the reference lines only; the corridor keeps its own.
    void setRefLineThickness (float px)
    {
        const float t = juce::jlimit (0.5f, 4.0f, px);
        if (std::abs (t - refThickness_) < 0.001f) return;
        refThickness_ = t;
        repaint();
    }

    // Override the trace fill/stroke gradient stops INDEPENDENTLY of the dashed reference lines: each
    // entry is (dB, colour); the gradient runs lowest-dB colour at the strip bottom → highest at the top,
    // with a stop at each entry's dB. Lets a product tune where the trace turns green without adding a
    // dashed line there. Empty (default) = derive the gradient from setRefLines (legacy behaviour).
    void setFillStops (std::vector<std::pair<float, juce::Colour>> stops) { fillStops_ = std::move (stops); repaint(); }

    void paint (juce::Graphics& g) override
    {
        auto b = getLocalBounds().toFloat();
        g.setColour (juce::Colour (0xff141417));
        g.fillRoundedRectangle (b, 2.0f);
        b = b.reduced (1.0f);

        const int n = (int) hist_.size();
        // No LOW clamp: a level under the display floor maps BELOW the strip and the component
        // clip swallows it — silence dives under the floor instead of lying on it as a fake
        // at-floor trace. Only the ceiling is clamped (an overload must not escape upward).
        auto yOf = [&] (float db)
        {
            return juce::jmap (juce::jmin (db, maxDb_), minDb_, maxDb_, b.getBottom(), b.getY());
        };
        // openSubpath=true: this path is fresh, so vertex 0 opens the subpath and the rest extend it.
        // false: the caller pre-seeded a corner (the fill), so EVERY vertex is a lineTo — opening a
        // new subpath here would orphan that corner. Note we must key off i==0, NOT p.isEmpty():
        // Path::isEmpty() skips lone move markers, so after startNewSubPath it stays true until the
        // first lineTo — using it would turn every vertex into a move and collapse the trace to
        // nothing (no line/fill drawn at all).
        auto trace = [&] (juce::Path& p, float clampY, bool openSubpath)   // oldest → newest, left → right
        {
            for (int i = 0; i < n; ++i)
            {
                const float x = b.getX() + (float) i / (float) (n - 1) * b.getWidth();
                const float y = juce::jmin (yOf (hist_[(size_t) ((head_ + i) % n)]), clampY);
                if (openSubpath && i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
            }
        };
        // The target window goes down FIRST, under the trace and under the grid: it is the ground the
        // level is being placed on, not another mark competing with it.
        const auto fillBand = [&] (float lo, float hi, juce::Colour c)
        {
            if (! (std::isfinite (lo) && std::isfinite (hi) && lo < hi)) return;
            const float yTop = yOf (hi), yBot = yOf (lo);
            g.setColour (c);
            g.fillRect (juce::Rectangle<float> (b.getX(), yTop, b.getWidth(), juce::jmax (1.0f, yBot - yTop)));
        };
        fillBand (band2Lo_, band2Hi_, band2Colour_);   // …the second one under the first
        fillBand (bandLo_, bandHi_, bandColour_);

        const juce::Colour grey (0xff8a8f98), green (0xff33d13f), red (0xffe0402e);
        const float h = juce::jmax (1.0f, b.getBottom() - b.getY());
        auto fB = [&] (float y) { return juce::jlimit (0.001, 0.999, (double) ((b.getBottom() - y) / h)); };

        // The fill/stroke gradient comes from setFillStops when set, else from the reference lines —
        // so a product can tune where the trace turns green independently of which dashed lines show.
        std::vector<std::pair<float, juce::Colour>> stops;
        if (! fillStops_.empty()) stops = fillStops_;
        else for (const auto& l : refLines_) stops.emplace_back (l.db, l.colour);

        if (! stops.empty())
        {
            // Fill + stroke share ONE dB-keyed gradient (appkit::dbGradient): the fill fades translucent
            // (bottom 0.10 → interior 0.42 → top 0.80), the stroke is opaque — the SAME colour per dB the
            // meter bar reads. (fB(yOf(db)) reduces exactly to dbGradient's (db-minDb)/span.)
            juce::Path fill;
            fill.startNewSubPath (b.getX(), b.getBottom());
            trace (fill, b.getBottom(), false);
            fill.lineTo (b.getRight(), b.getBottom());
            fill.closeSubPath();
            g.setGradientFill (dbGradient (stops, minDb_, maxDb_, 0.0f, b.getY(), b.getBottom(), 0.10f, 0.80f, 0.42f));
            g.fillPath (fill);

            juce::Path line;
            trace (line, b.getBottom() + kBelowFloorPx, true);   // may dip under the floor (clipped)
            g.setGradientFill (dbGradient (stops, minDb_, maxDb_, 0.0f, b.getY(), b.getBottom()));
            g.strokePath (line, juce::PathStrokeType (1.6f));
        }
        else if (hasZone())
        {
            const juce::Colour amber (0xfff5c57a);
            // zoneLo_..zoneHi_ is the GREEN band; clipCeiling_ (when above zoneHi_) opens a YELLOW band
            // up to it, red beyond. No clip / clip ≤ band-top ⇒ the old green→red-at-band-top strip.
            const bool  hasYellow = std::isfinite (clipCeiling_) && clipCeiling_ > zoneHi_;
            const float yLo   = yOf (zoneLo_);                            // floor → green dashed line
            const float yMid  = yOf (zoneHi_);                            // green→yellow → amber line
            const float yClip = hasYellow ? yOf (clipCeiling_) : yMid;    // yellow→red → red dashed line
            const float yGA   = yOf (zoneLo_ - 11.0f);                    // grey fade-in floor
            const float yG1   = yOf (juce::jmin (zoneLo_ + 3.0f, zoneHi_));   // full green just inside
            const float yYel  = hasYellow ? yOf ((zoneHi_ + clipCeiling_) * 0.5f) : yMid;   // mid-yellow
            const float yR1   = yOf ((hasYellow ? clipCeiling_ : zoneHi_) + 3.0f);          // full red

            // fill only where the trace rises above the fade-in floor
            juce::Path fill;
            fill.startNewSubPath (b.getX(), yGA);
            trace (fill, yGA, false);              // continue the pre-seeded corner
            fill.lineTo (b.getRight(), yGA);
            fill.closeSubPath();
            juce::ColourGradient fg (green.withAlpha (0.05f), 0.0f, b.getBottom(),
                                     red.withAlpha (0.82f), 0.0f, b.getY(), false);
            fg.addColour (fB (yGA),  green.withAlpha (0.06f));
            fg.addColour (fB (yLo),  green.withAlpha (0.30f));
            fg.addColour (fB (yMid), green.withAlpha (0.48f));
            if (hasYellow) {
                fg.addColour (fB (yYel),  amber.withAlpha (0.55f));
                fg.addColour (fB (yClip), amber.withAlpha (0.62f));
            }
            fg.addColour (fB (yR1),  red.withAlpha (0.80f));
            g.setGradientFill (fg);
            g.fillPath (fill);

            juce::Path line;
            trace (line, b.getBottom() + kBelowFloorPx, true);   // may dip under the floor (clipped)
            juce::ColourGradient lg (grey, 0.0f, b.getBottom(), red, 0.0f, b.getY(), false);
            lg.addColour (fB (yGA),  grey);
            lg.addColour (fB (yLo),  grey.interpolatedWith (green, 0.5f));
            lg.addColour (fB (yG1),  green);
            lg.addColour (fB (yMid), green);
            if (hasYellow) {
                lg.addColour (fB (yYel),  amber);
                lg.addColour (fB (yClip), amber);
            }
            lg.addColour (fB (yR1),  red);
            g.setGradientFill (lg);
            g.strokePath (line, juce::PathStrokeType (1.4f));

            const float dashes[] = { 5.0f, 4.0f };
            g.setColour (juce::Colours::limegreen.withAlpha (0.85f));
            g.drawDashedLine (juce::Line<float> (b.getX(), yLo, b.getRight(), yLo), dashes, 2, 1.2f);
            if (hasYellow) {
                g.setColour (amber.withAlpha (0.9f));
                g.drawDashedLine (juce::Line<float> (b.getX(), yMid, b.getRight(), yMid), dashes, 2, 1.2f);
            }
            g.setColour (juce::Colours::red.withAlpha (0.85f));
            g.drawDashedLine (juce::Line<float> (b.getX(), yClip, b.getRight(), yClip), dashes, 2, 1.2f);
        }
        else
        {
            juce::Path line;
            trace (line, b.getBottom() + kBelowFloorPx, true);   // may dip under the floor (clipped)
            g.setColour (grey);
            g.strokePath (line, juce::PathStrokeType (1.4f));
        }

        // Fixed calibration grid: DASHED coloured reference lines at their dBFS, always in the same
        // place; a labelled line gets its dB captioned bottom-left just under it.
        for (const auto& l : refLines_)
        {
            const float y = yOf (l.db);
            const float k = juce::jlimit (0.5f, 8.0f, l.dash);
            const float refDash[] = { 6.0f * k, 4.0f * k };
            g.setColour (l.colour.withAlpha (0.92f));
            g.drawDashedLine (juce::Line<float> (b.getX(), y, b.getRight(), y), refDash, 2, refThickness_);
            if (l.label.isNotEmpty())
            {
                g.setFont (juce::FontOptions (13.0f));
                g.drawText (l.label, (int) b.getX() + 4, (int) y + 2, 74, 15,
                            juce::Justification::centredLeft, false);
            }
        }

        // Noise-floor reference: a black line across the strip (with a faint light edge so it reads on
        // the dark background) — calibrate the room's quiet against it with the tone off. Its dB is
        // captioned under it like a labelled grid line (light grey — black text would vanish).
        if (std::isfinite (noiseFloor_))
        {
            const float y = yOf (noiseFloor_);
            g.setColour (juce::Colours::white.withAlpha (0.18f));
            g.fillRect (b.getX(), y - 1.5f, b.getWidth(), 3.0f);
            g.setColour (juce::Colours::black);
            g.fillRect (b.getX(), y - 0.75f, b.getWidth(), 1.5f);
            g.setColour (juce::Colours::white.withAlpha (0.55f));
            g.setFont (juce::FontOptions (10.0f));
            g.drawText (juce::String ((int) std::lround (noiseFloor_)) + " dB",
                        (int) b.getX() + 4, (int) y + 3, 60, 11, juce::Justification::centredLeft, false);
        }

        // Hard-ceiling overloads: full-height red bars for every column that broke the ceiling — an
        // overload spike is visible even when it lasted a single tick. Painted OVER the trace.
        if (std::isfinite (clipCeiling_))
        {
            g.setColour (juce::Colour (0xffe0402e).withAlpha (0.6f));
            for (int i = 0; i < n; ++i)
                if (hist_[(size_t) ((head_ + i) % n)] > clipCeiling_)
                {
                    const float x = b.getX() + (float) i / (float) (n - 1) * b.getWidth();
                    g.fillRect (x - 0.5f, b.getY(), 1.5f, b.getHeight());
                }
        }

        // Current return level — in the bottom-right corner, coloured by loudness (green → yellow →
        // orange → red as it climbs the -9/-6/-3 dBFS danger marks): the calibrator's live number.
        if (curDb_ > kSilenceDb + 0.5f && getWidth() >= 60)
        {
            juce::Colour c (0xff33d13f);                            // green — comfortably low
            if      (curDb_ >= -3.0f) c = juce::Colour (0xffe0402e);   // red
            else if (curDb_ >= -6.0f) c = juce::Colour (0xffff8a3d);   // orange
            else if (curDb_ >= -9.0f) c = juce::Colour (0xffffd54f);   // yellow
            g.setColour (c);
            g.setFont (juce::FontOptions ((float) juce::jlimit (18, 34, getHeight() / 6), juce::Font::bold));
            g.drawText (juce::String (curDb_, 1) + " dB",
                        getLocalBounds().reduced (12, 8), juce::Justification::bottomRight, false);
        }
    }

private:
    bool hasZone() const
    {
        return std::isfinite (zoneLo_) && std::isfinite (zoneHi_) && zoneLo_ < zoneHi_;
    }

    static constexpr float kSilenceDb      = -120.0f;
    static constexpr int   kHoldTicks      = 30;      // ~1.5 s at a 20 Hz feed
    static constexpr float kDecayDbPerTick = 0.8f;
    // How far below the strip a trace vertex may go before it is clamped: enough that the stroke
    // (and its join back up) is fully outside the clip, small enough to keep path bounds sane.
    static constexpr float kBelowFloorPx   = 24.0f;

    // dBFS window (per-instance, like LevelMeter's setRange)
    float minDb_ = -60.0f;
    float maxDb_ =   0.0f;

    std::vector<float> hist_;
    int   head_     = 0;
    int   peakAge_  = 0;
    float peakHold_ = kSilenceDb;
    float curDb_    = kSilenceDb;   // instant level for the big centred overlay
    float noiseFloor_ = std::numeric_limits<float>::quiet_NaN();   // fixed reference line; NaN = hidden
    float refThickness_ = 1.8f;                 // dashed grid weight (setRefLineThickness)
    std::vector<RefLine> refLines_;                                // fixed calibration grid lines
    std::vector<std::pair<float, juce::Colour>> fillStops_;        // fill/stroke gradient (decoupled from lines)

    // Corridor thresholds (dBFS). NaN = no corridor → plain grey trace (default).
    float zoneLo_ = std::numeric_limits<float>::quiet_NaN();
    float zoneHi_ = std::numeric_limits<float>::quiet_NaN();

    // The target window (setTargetBand). NaN = none.
    float bandLo_ = std::numeric_limits<float>::quiet_NaN();
    float bandHi_ = std::numeric_limits<float>::quiet_NaN();
    juce::Colour bandColour_ { 0x2233d13f };

    // …and the second window (setSecondBand). NaN = none.
    float band2Lo_ = std::numeric_limits<float>::quiet_NaN();
    float band2Hi_ = std::numeric_limits<float>::quiet_NaN();
    juce::Colour band2Colour_ { 0x229778ff };

    // Hard overload ceiling (dBFS). NaN = off. Columns above it get a full-height red bar.
    float clipCeiling_ = std::numeric_limits<float>::quiet_NaN();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LevelHistory)
};

} // namespace felitronics::appkit
