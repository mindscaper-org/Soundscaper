// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.
#pragma once
// felitronics::rigplayer — ONE DEVICE OF A PACK, PLAYING. Hand it the pack's structures
// (namz::rig — the manifest as the canonical reader returns it) and a way to get a file's bytes, tell it
// where the knobs stand, feed it audio. It does, in signal order:
//
//     in → pack in → dry copy → pre tone (bands, curve) → chain trim → ┬→ trim A → model A → align ─┐
//                                                                      └→ trim B → model B → align ─┴→ mix
//        → post tone (bands, curve) → dry/wet blend → crossover blend → pack out → out
//
//   • WHICH files play is namz::rig's policy (a turned control is law) joined to ModelBlend.h's pair
//     along the gain dial — RigSelection.h, pure.
//   • WHEN a model may be replaced, and how loudly each is heard, is felitronics::nam::BlendLaw —
//     run here once per block on the audio thread, the only writer of the weight. The message thread
//     posts a request and answers load asks; two one-way mailboxes, no locks. A load itself — bytes
//     fetched, a network built and warmed, some twenty milliseconds for a WaveNet — is a JOB the
//     player hands out (takeLoadJob) and the host runs where it likes (run, any thread) before
//     bringing it back (deliver): no thread of its own, no policy, no hiccup on the drawing thread.
//   • A slot that has stood silent under an unchanged request for kColdAfterSeconds goes COLD and its
//     model stops being run on audio — a dial parked on a capture costs one network, not two. It is
//     still HANDED the call, at width zero, until the stage has drained the silence it owes (law 11c);
//     sleeping is inaudible AT THE MODEL RATE and, off it, costs the woken slot's rate-matcher latency
//     once on the block of the wake (4.97e-03 at 44.1 kHz against a 0.1 input) — see warmFor;
//     that is one bounded drain per sleep and nothing after it, and without it the slot replayed what
//     it was holding when it fell asleep — 0.500000 out of digital silence. The law owns the flag
//     (BlendState::cold) and wakes the slot, warm-up first, the moment the request changes; the model
//     stays where it is throughout. slotCold() and coldBlocks() read it out.
//   • A host that can afford ONE network says so (setMaxModels(1)): the dial steps to the nearest
//     capture, the other slot is asked for nothing, and a change of capture is a dip — down, swap, up —
//     instead of a crossfade (nam::blendStepSingle). runBlocks() and pairBlocks() read out the cost,
//     a resting capture's drain included.
//   • A tone knob is applied as the pack describes it — a curve becomes a minimum-phase FIR, bands
//     become biquads — on the side of the models its circuit puts it. ToneKnobs.h, pure.
//   • A blend knob mixes the DI the models were fed, through the dry path's own response. BlendKnob.h.
//   • The crossover blend — the host's, not the pack's (setCrossoverAmount): below a frequency the CLEAN input,
//     above it the device, split by one Linkwitz–Riley pair, the clean leg held back by what the models carry.
//   • THE PACK'S OWN TWO LEVELS BRACKET EVERYTHING IT DOES. `chain[].input_db` is the level of the
//     guitar into this device, and it goes FIRST — ahead of the dry copy, because a blend knob mixes
//     one guitar with itself and both ends must be fed the same signal. `chain[].output_db` is the
//     level the device leaves at, and it goes LAST, after the mix, so balancing one pack against
//     another cannot move the blend the pack was told to hold. Neither is behind setInputTrims():
//     they are the author's statement about the pack, not a listener's option.
//   • The slot trims are the files' own `input_db` — a linked setting plays its neighbour softer, and
//     this is the one thing setInputTrims() switches off — and the chain trim is the extension past
//     the ends of the captured range, which the dry path never saw either.
//   • The models' offsets are measured from the bytes (AlignmentTable.h) by the host, on any thread,
//     and handed in; each slot's delay travels with its model and lands when the slot is silent.
//
// NOTHING OF THE LIBRARY IS KNOWN HERE — no take, no database, no file system, no JUCE. The bytes come
// through ModelSource by `files[].id`, when the law asks and never before: a swept dial fetches each
// capture once. This is the unit that leaves for the plugin as one directory.
//
// Threads, exactly as NamStage: prepare() / load() / the knob setters / service() / takeLoadJob() /
// deliver() on the message thread; run() on any thread but the audio one; process() alone on the audio
// thread — it locks nothing, touches no file, and allocates nothing while the captures are Linear or
// WaveNet (an LSTM or ConvNet capture allocates inside the pinned NAM: NamStage.h). The read-outs are atomics.

#include <felitronics/rigplayer/AlignmentTable.h>
#include <felitronics/rigplayer/BlendKnob.h>
#include <felitronics/rigplayer/CrossoverBlend.h>
#include <felitronics/rigplayer/RigSelection.h>
#include <felitronics/rigplayer/ToneKnobs.h>

#include <felitronics/convolution/CabConvolver.h>
#include <felitronics/core/DryAligner.h>
#include <felitronics/core/StreamResampler.h>
#include <felitronics/core/StateGrid.h>
#include <felitronics/eq/MatchedBiquad.h>
#include <felitronics/lineareq/MagnitudeCurve.h>
#include <felitronics/nam/BlendLaw.h>
#include <felitronics/nam/NamStage.h>
#include <namz_rig.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace felitronics::rigplayer {

class RigPlayer {
public:
    static constexpr int kMaxChannels = 2;
    // Biquads per side. Every band of every `sections` knob on that side is one; a pack carrying more
    // than this on one side would be a first, and the rest are left out (bandsDropped() says so).
    static constexpr int kMaxBands = 24;

    // HOW LONG A COEFFICIENT MOVE TAKES, and it is READ OFF THE BAND rather than chosen or inherited.
    //
    // It used to be the host's block: the coefficients travelled linearly across whatever `process()`
    // was handed, so the same turn of the same knob took 0.33 ms at a block of 16 and 85 ms at 4096 —
    // 180 SECONDS on the whole-file call an offline driver makes. A spread of 500000x is not a
    // behaviour, so there was nothing to preserve; what there was instead was a question with no
    // number in the file, and this is that number.
    //
    // WHAT SETS IT. A biquad cannot be moved faster than it forgets: its poles sit at radius
    // r = sqrt(|a2|), the impulse response decays as r^n, and a move completed well inside that decay
    // asks the filter to be somewhere its own state has not caught up to. So ONE ring time — the
    // filter's own -60 dB memory — is the length, and the two rails below are what keep that honest.
    //
    // THERE IS NO KNEE, AND THE FIRST VERSION OF THIS NOTE CLAIMED ONE. The transient a fast move adds
    // over the ideal is +14.88 dB at L = 1, +3.13 at 64, +0.93 at 256, +0.50 at 512, +0.13 at 2048 —
    // which LOOKS like it flattens, and does not: as a linear excess it is L x excess = 27.8, 28.9,
    // 30.3, 30.9, i.e. a plain 1/L all the way down. So no length is "where the artefact stops"; every
    // doubling halves it, for ever, and the number is a CHOSEN TOLERANCE dressed as physics if it is
    // stated any other way. The adiabatic error behaves the same, ~3 dB per doubling with no knee
    // either.
    //
    // WHAT THE MULTIPLIER IS, then: a responsiveness policy, and ONE ring is defended UNIVERSALLY rather
    // than from the only pack that exists — appealing to that pack is over-fitting, and an earlier
    // version of this note did exactly that on a reading taken at a BLIND PROBE FREQUENCY. It said the
    // pack's bass shelf "overshoots 0.00 dB at every length"; that was measured at 90 Hz and 1400 Hz,
    // both outside the shelf's transition band. Inside it the same move reads +3.04 dB at L = 1, +1.41
    // at 64 and +0.20 at one ring (436 samples) on a 334 Hz probe, and the OTHER direction (+6 -> -12)
    // reads +17.19 dB at 42 Hz on an instantaneous jump. The pack's own knob was never free.
    //
    // The universal statement, measured across every shape tried (Q 1.4 bell, the pack shelf, a 400 Hz
    // Q 0.3 bell, a 300 Hz Q 0.5, a 1 kHz Q 0.7 at -24 dB, a 100 Hz Q 8, a Q 2, an 80 Hz Q 0.3 shelf):
    // AT EXACTLY ONE RING the peak excess over the ideal move on a FULL-SWING SLAM is +0.24 to +1.06 dB.
    // That is a property of the ramp-to-ring ratio, not of a pack, because the excess falls as 1/L.
    // Five rings buys 5x less (+0.05 to +0.25) for 5x the lag. One ring also lands the pack's bass knob
    // at 9.1 ms, which is what a 512-sample host was already producing — a tie-breaker, not the reason.
    //
    // ⚠️ AND IT DOES NOT COVER THE PACK'S SWITCH, whatever an earlier version of this note said. That
    // switch's two positions carry ZERO and ONE section, so flipping it changes the BAND COUNT, and
    // `takeBands` starts an appearing band AT its coefficients with reset state — measured through the
    // player, the output matches a static "smooth" render from ELEVEN samples after the flip, where a
    // 64-sample ramp would need at least 64. An appearance is a hard step today. Ramping it from
    // identity (a stable endpoint, and the stability triangle is convex so the linear path stays
    // stable) and draining a disappearing band back to identity is a separate policy — P26 follow-up.
    //
    // THE FLOOR IS A RAIL, NOT A GUARANTEE, and the difference is the part that is easy to overclaim.
    // Every band in the reference pack (namz conformance `rig-measured`: a 167 Hz Q 0.58 low shelf
    // travelling [-12, +6] dB with its corner over [120, 240] Hz, a 1077 Hz Q 0.65 tilt, a 10 kHz
    // Q 0.8 switch position) is a shelf or tilt with Q BELOW ONE, and on those the adiabatic error is
    // already -47 dB at an INSTANTANEOUS jump. But 64 samples does NOT bound the artefact in general:
    // a schema-legal 5 kHz bell at Q 1.4 swept +12 -> -12 dB is handed exactly 64 by the rule above and
    // overshoots by 0.67 dB there (1.49 dB at the worst edit phase), falling as 1/L to 0.11 dB at 512.
    // 64 is where the lag budget starts, chosen so an ordinary knob is not made sluggish; a move large
    // and sharp enough will exceed it, and that is stated rather than hidden.
    //
    // THE CEILING IS A LAG BUDGET, not a DSP one, which is why it is a named constant and not a
    // formula: a band that rings 176 ms (a 100 Hz bell at Q 8 — the pack schema permits it, nothing
    // in `namz_rig_load.h` bounds `hz` or `q` beyond "positive") would ask for 880 ms, and a knob that
    // trails the hand by a second is broken in a different way. Past the ceiling the move is honestly
    // too fast for the filter and the overshoot above is what it costs.
    // THE RAILS ARE TIME, and the first version had them in SAMPLES — which is the same defect as the
    // one this whole change removes, one scale down. A ring is a duration: a 167 Hz shelf rings 9.08 ms
    // at every rate. Rails in samples do not: 2048 is 46.4 ms at 44.1 kHz, 42.7 at 48, **21.3 at 96 and
    // 10.7 at 192**, so the same pack gets a quarter of the budget on a 192 kHz session, and a 100 Hz
    // Q 2 bell swept +-12 dB costs +1.5 dB of overshoot at 42.7 ms against **+4.7 dB at 10.7**.
    static constexpr double kBandRampMinSeconds =   64.0 / 48000.0;   // 1.33 ms — the responsiveness rail
    static constexpr double kBandRampMaxSeconds = 2048.0 / 48000.0;   // 42.7 ms — the lag budget, the only taste in here
    static constexpr double kBandRampRings = 1.0;   // ONE ring; see the note above for why not five

    // `sampleRate` has no default on purpose: a caller that forgets it would silently get the 48 kHz
    // rails at every rate, which is the defect the note above describes.
    static int bandRampLength(const felitronics::rigplayer::SectionBiquad& from,
                              const felitronics::rigplayer::SectionBiquad& to,
                              double sampleRate) {
        const double fs   = sampleRate > 0.0 ? sampleRate : 48000.0;
        const int kBandRampMin = std::max(1,  (int) (kBandRampMinSeconds * fs));
        const int kBandRampMax = std::max(kBandRampMin, (int) (kBandRampMaxSeconds * fs));
        // THE DOMINANT ROOT, and `sqrt(|a2|)` is NOT it. a2 is the pole PRODUCT, so its square root is
        // the GEOMETRIC MEAN of the two magnitudes — right only when they are equal, which is exactly
        // the complex-conjugate case and no other. A real pair is what a LOW-Q design gives, and packs
        // are full of low-Q shelves. `matched::highShelfQDb(1 kHz, 48 kHz, +12 dB, Q 0.05)` has real
        // poles at 0.99346 and 0.07343 — BOTH POSITIVE, and it is the FAST one that the mean drags the
        // answer down to: the mean says 5.28 samples where the slow pole rings for 1052.78, a 199x
        // underestimate. Its -12 dB sibling (poles 0.99670 and 0.39809) misses by 140x: 14.95 against
        // 2090.39. Two shapes, two different factors — quoting one shape's pair with the other's factor
        // is how the first draft of this note was wrong.
        auto ring = [kBandRampMax] (double a1, double a2) {
            const double disc = a1 * a1 - 4.0 * a2;
            const double rho  = disc >= 0.0 ? (std::fabs(a1) + std::sqrt(disc)) * 0.5   // real pair: the larger root
                                            : std::sqrt(std::fabs(a2));                 // complex pair: both are sqrt(a2)
            if (! (rho > 0.0)) return 0.0;                     // no pole at all: nothing to outrun
            if (! (rho < 1.0)) return (double) kBandRampMax;    // marginal or worse: take the ceiling
            return std::log(1.0e-3) / std::log(rho);            // samples to -60 dB of the SLOWEST mode
        };
        const double n = kBandRampRings * std::max(ring(from.a1, from.a2), ring(to.a1, to.a2));
        if (! (n > (double) kBandRampMin)) return kBandRampMin;
        if (n >= (double) kBandRampMax)    return kBandRampMax;
        return (int) n;
    }

    // The curve form's FIR: 1024 taps designed through 8192 points, the numbers the bench auditions with.
    static constexpr int kFirTaps = 1024, kFirDesign = 8192;
    static constexpr int kMaxDelay = felitronics::nam::kBlendMaxDelay;
    // How long a slot may stand at exactly zero, its request unchanged, before its model stops being
    // run (BlendLaw.h, "and one economy"). Long against a hand — a pause this long IS the dial at rest
    // — and short against a session, so the saving is there whenever nobody is turning. A host may set
    // its own (setColdAfterSeconds); zero or less = never.
    static constexpr double kColdAfterSeconds = 2.0;
    // THE DIP of a one-model player (setMaxModels(1)): how long the sound takes to fall before a capture
    // is replaced, and to rise after. Not a new number: OrbitAmp's BypassFade (src/core/BypassFade.h,
    // `lengthMs = 15.0f`) is "THE ONE FADE, for every link that REPLACES the signal rather than adding
    // to it" — long enough that no step survives it, short enough that a switch still feels like a
    // switch — and a capture swapped under a dip is exactly such a link. In seconds, so the dip is the
    // same at every block size (BypassFade's own lesson: a fade spread over a whole 4096-sample block
    // was eighty-five milliseconds, not fifteen). The app's other two moves set no figure of their own:
    // a pack change is unload() + load(), whose fade-in is the law's cold start, and a channel switch is
    // the law's crossfade, a quarter per block.
    static constexpr double kDipSeconds = 0.015;
    // …and the DEADBAND of its step (steppedSelection): the capture sounding stays until the pair's weight is this far
    // past the handover — a tenth of the gap, 9 degrees of a 90-degree gap on the default shape — so a hand resting on
    // the handover does not dip at every tremor. A dial whose shape is a switch (width zero) has no band to rest in.
    static constexpr double kStepDeadband = 0.1;

    // STAND-BY (setStandby): OrbitAmp's PARK as its captured block plays it (src/PluginProcessor.cpp:1397-1559, the
    // `captured` lambda): the block is crossfaded against a WIRE — its own input, delayed by the block's latency, at
    // unity — over BypassFade's length (src/core/BypassFade.h:32, `lengthMs = 15.0f`, linear, both ways), and once
    // the fade is down the block is not run at all. Spelled in milliseconds and computed as BypassFade::prepare
    // computes it (`1000 / (rate · 15)` per sample), so the two walk the same floats.
    static constexpr double kStandbyFadeMs = 15.0;

    // THE SCOPE TAP (scopeRead): OrbitAmp's ScopeTap (src/core/ScopeTap.h:25, `size = 2048`) — the newest this many
    // samples of the dry and the wet, channel 0. prepare() takes another length; zero is no tap and no memory.
    static constexpr int kScopeSize = 2048;
    static constexpr int kMaxScopeSize = 1 << 20;   // refused above: the tap is a picture, not a recorder
    static constexpr int kScopeTries = 4;           // a read the writer kept overtaking is retried this often

    // 🔴 THE CEILING ON A HOST RATE, and every buffer derived from one is bounded by it. Far above any
    // audio rate — 3 MHz is sixteen times the highest a DAW offers — and its job is not to judge taste
    // but to keep `(int) f(sampleRate)` inside int and the rings it sizes inside memory. A rate above
    // it falls back to 48 kHz the same way a negative or non-finite one does.
    //
    // The VALUE is the house convention, not a new number: dynamics::Compressor::kMaxSampleRate and
    // limiter::TruePeakLimiter::kMaxSampleRate are both 3.0e6 with the same stated reason, and
    // eq::EqBand::prepare refuses past the same figure as a literal. That it now has a FOURTH spelling
    // is the very disease this branch exists to treat, and consolidating the four is its own task —
    // rigplayer links neither dynamics nor limiter, so it cannot simply ask.
    static constexpr double kMaxSampleRate = 3.0e6;

    // The ONE place a host rate is judged, so that nothing downstream re-decides it. A rate outside
    // the accepted range becomes the factory rate rather than a refusal, which is what this class did
    // for a non-positive rate before and what stereo::MonoBass and the dynamics detectors do too.
    //
    // Spelled as a RANGE and positively — the idiom TruePeakLimiter documents: `> 0.0` is false for a
    // NaN and `<= kMaxSampleRate` is false for an infinity, so between them they exclude everything
    // std::isfinite would have, and an isfinite here would be a clause no test could distinguish.
    static double usableSampleRate (double hostSR) noexcept
    {
        return (hostSR > 0.0 && hostSR <= kMaxSampleRate) ? hostSR : 48000.0;
    }

    // 🔴 THE DRY ALIGNER'S CAPACITY — ASKED, NOT DERIVED, and the whole of it is now one question
    // put to the module that owns the answer. Pure and public for the reason rateMatch() is: it is the
    // only way to pin the number at rates this repository does not itself run.
    //
    // 🔴 WHAT USED TO BE HERE AND WHY IT IS GONE. This was
    // `max(256, ceil(pairDelayHostSamples(fs, kModelSampleRate)) + 2)`, and both halves of that
    // existed for ONE reason, named in its own comment: NamStage::install() accepted a model within
    // half a hertz of the CURRENT run rate and prepare() then adopted it, so repeated loads walked the
    // run rate away from the factory value without bound. A lower run rate is a longer round trip, so a
    // capacity derived from 48 kHz could come up a slot short of a delay the stage really reports —
    // and DryAligner clamps silently. The floor and the spare slot were a MITIGATION with a measured
    // price, not a proof: the first silent clamp arrived after 82256 half-hertz steps at a 48 kHz host,
    // 68511 at 96 kHz, 41021 at 192 kHz, 560 at 384 kHz and 72 at a 3 MHz one.
    //
    // P38 closed the walk at its source — the gate's reference is the constant now, so an accepted
    // model's rate lies in [kModelSampleRate - kModelRateTolerance, kModelSampleRate +
    // kModelRateTolerance] for the life of the process — and a mitigation outlives its defect only as
    // a number nobody can re-derive. So it goes, together with the fix rather than after it.
    //
    // What replaces it is not a smaller guess but the contract's own consequence:
    // NamStage::maxLatencySamples(fs) is an upper bound on what any ACCEPTED model can report at this
    // host, +1 because DryAligner's usable range is capacity-1 (it clamps to [0, capacity-1], and does
    // it in silence — which is exactly how a downstream repository shipped a bypass path that
    // under-delayed every host rate above 48 kHz). One reason for the "+1", none for anything else, and
    // no copy of 48000 or of the half hertz on this side of the seam. The bound's floating-point
    // environment precondition applies here too: capacity prepared to nearest at
    // nextafter(96748.9921875, 0) carries 96, but a model prepared upward asks for 97 and clamps.
    // See NamStage::maxLatencySamples; this function supplies no extra margin.
    static int dryAlignerCapacity (double hostSR) noexcept
    {
        return felitronics::nam::NamStage::maxLatencySamples (usableSampleRate (hostSR)) + 1;
    }

    RigPlayer() = default;
    RigPlayer(const RigPlayer&) = delete;
    RigPlayer& operator=(const RigPlayer&) = delete;

    // ---------------------------------------------------------------- message thread: setup ----

    // Sizes every buffer and (re)builds anything designed for a rate. Never while process() runs.
    // LAW 11(b): BINDING, and it used to CLAMP — `prepare(48000, 256, 4)` was accepted as a 2-channel
    // player, after which every `process(io, 4, n)` was refused forever and the caller was told only at
    // the second call. That is the defect the law's own text describes, in this file.
    // `scopeSamples` is the scope tap's length (kScopeSize by default; 0 = no tap), refused outside 0 … kMaxScopeSize.
    [[nodiscard]] bool prepare(double sampleRate, int maxBlock, int numChannels, int scopeSamples = kScopeSize) {
        prepared_ = false;                       // law 11(b): disarm FIRST, then validate, then write
        if (numChannels < 1 || numChannels > kMaxChannels) return false;
        if (maxBlock < 1) return false;
        if (scopeSamples < 0 || scopeSamples > kMaxScopeSize) return false;
        // 🔴 IN RANGE, not merely finite — and the difference is the whole point, because an earlier
        // version of this line said `isfinite` and that is NOT the property the code below depends on.
        // The dry-aligner capacity is `(int) ceil(<a function of fs_>)`, and an out-of-range float→int
        // conversion is undefined: `isfinite` lets 1e300 through, and 1e300 converts just as badly as
        // an infinity does. Measured through this very function with UBSan, before this line was
        // widened: prepare(1e300, 64, 2) returned TRUE while firing twice — "6.66667e+296 is outside
        // the range of representable values of type 'int'", then "signed integer overflow: 2147483647
        // + 2". On the base commit, where the capacity was a literal, neither fired: the exposure came
        // in with the computation, and half of it survived the fix that was written for it.
        //
        // The second face of the same line is not undefined at all and is worse for being legal: the
        // capacity used to be a CONSTANT and is now a function of the argument, so the ring it sizes
        // grew without an upper bound. Measured on the same probe — heap requested inside one
        // prepare() call: 0 bytes at 1e11 on the base commit, 533 333 608 (508.6 MiB) here.
        //
        // kMaxSampleRate closes both, and it is the house number rather than a new one. Spelled as a
        // RANGE and positively, which is the same idiom TruePeakLimiter documents: `sampleRate > 0.0`
        // is false for a NaN and `sampleRate <= kMaxSampleRate` is false for an infinity, so the two
        // comparisons already exclude everything `std::isfinite` would have — an explicit isfinite
        // here would be a clause no test could ever distinguish.
        fs_       = usableSampleRate (sampleRate);
        maxBlock_ = maxBlock;
        channels_ = numChannels;   // validated above — law 11(b) forbids the clamp that was here
        coldAfter_.store(coldSamples(coldSeconds_), std::memory_order_release);
        dipSamples_ = std::max(1LL, (long long) std::llround(kDipSeconds * fs_));
        for (auto& n : nam_) n.prepare(fs_, maxBlock_, channels_);   // a mono host's slots run one network each
        retiredStages_.clear();                                   // never concurrent with process(): nothing runs them
        for (auto& n : poolStages_) n->prepare(fs_, maxBlock_, channels_);   // the preload's captures, re-prepared in place
        // Not normalised: a tone curve's broadband level is part of what the pack says, and a dry path's
        // level rides in its gain. Reference-unity RMS is for cabinets, which these are not.
        // AND THE TAPS ARE DESIGNED AT `fs_`, WHICH IS WHY THAT IS ENOUGH. The other half of an
        // un-normalized load's loudness contract is the rate factor the loader applies when it RESAMPLES
        // (convolution::convolutionRateGain — P68), and these never resample: magnitudeCurveToFir designs
        // at fs_ and loadIR is handed fs_. Hand one of these a pack's own rate instead and it silently
        // acquires that factor, which is correct but is a different number than today's.
        prepared_ = false;                       // a refused sub-prepare leaves the player unprepared
        for (auto& f : fir_) if (! f.prepare(fs_, maxBlock_, channels_, 0.1, false)) return false;
        if (! dry_.prepare(fs_, maxBlock_, channels_, 0.1, false)) return false;
        // 🔴 THE DRY PATH HAS TO BE DELAYED BY WHAT THE WET PATH COSTS, or the blend is a COMB FILTER.
        // The mix in process() sums `a` (through the models, hence through their rate-match) with `d`
        // (the DI, through the dry FIR only). Those two are misaligned by exactly latencySamples(), and
        // summing them notches at fs/(2·D) with every odd multiple above it.
        //
        // This was ALREADY wrong before P34 and nobody had put a number on it: with the cubic's 3.84
        // samples the first null sat at 5742 Hz. P34's 61.4 samples move it to 359 Hz — the body of a
        // guitar, not a phasey top — and the host cannot fix it, because latencySamples() reports the
        // whole player's PDC outward while this notch is INTERNAL to the blend. Measured on a 50/50
        // blend, ripple across 100 Hz … 10 kHz: 9.54 dB unaligned against 0.324 dB aligned — and the
        // remaining 0.324 dB is not slop, it is the ALIGNMENT'S OWN RESIDUAL: the dry leg is delayed by
        // the INTEGER latencySamples() (61 at 44.1 kHz) while the wet geometry is fractional (61.4000),
        // so 0.4 sample of relative offset survives by construction. The suite prints this number every
        // run — "response spans … = 0.324 dB" — and gates it at 0.5, so the gate passes on the residual
        // rather than on the claim. Do not write 0.00 here again: nothing in this design can reach it
        // while the dry delay is an integer.
        //
        // Capacity: it must EXCEED the delay it will ever hold — DryAligner clamps to [0, capacity-1]
        // and does it SILENTLY, which is exactly how a downstream repository shipped a bypass path
        // that under-delayed every host rate above 48 kHz.
        //
        // 🔴 THE PREVIOUS VERSION OF THESE LINES WAS THE SAME MISTAKE, WRITTEN BY THE FIX FOR IT. It
        // said "the largest this can report is a 192 kHz host against a 48 kHz model — D·(1 + 4) = 160
        // — so 256 covers it with margin", and that sentence is a RESTATEMENT of the round-trip
        // formula sitting in front of a silent clamp. It was true when written and would have stopped
        // being true the moment the kernel length became a function of the ratio. Ask instead — and
        // the asking now lives in dryAlignerCapacity(), where it can be pinned at rates this file
        // never runs, because inline arithmetic here is exactly what could not be.
        dryLatency_.prepare(channels_, maxBlock_, dryAlignerCapacity (fs_));
        // The stand-by WIRE is the same length for the same reason: what a stood-by device hands on is its input at
        // the latency it reports (the app's `wire`, PluginProcessor.cpp:1409-1467 — "a wire the same LENGTH as the
        // block it replaces").
        wire_.prepare(channels_, maxBlock_, dryAlignerCapacity (fs_));
        retimeFade_ = std::max(1, (int) (0.010 * fs_));
        xo_.prepare(fs_, maxBlock_, channels_);           // the crossover blend's ring, lines and pair (CrossoverBlend.h)
        fadeStep_ = (float) (1000.0 / (fs_ * kStandbyFadeMs));   // BypassFade::prepare, spelled the same
        // The scope's two rings: the tap's length plus two blocks of slack, so a read overtaken by the writer by a
        // block and a half is still whole (scopeRead). Atomic floats — relaxed loads and stores are plain moves on
        // every target this builds for, and they make the reader's copy a race the language defines.
        scopeN_   = scopeSamples;
        scopeCap_ = scopeSamples > 0 ? (std::size_t) scopeSamples + 2u * (std::size_t) maxBlock_ : 0u;
        scopeDry_ = scopeCap_ > 0 ? std::make_unique<std::atomic<float>[]>(scopeCap_) : nullptr;
        scopeWet_ = scopeCap_ > 0 ? std::make_unique<std::atomic<float>[]>(scopeCap_) : nullptr;
        scopeIn_.assign(scopeCap_ > 0 ? (std::size_t) maxBlock_ : 0u, 0.0f);   // the dry is taken first, written last
        scopeW_ = 0;
        scopeClaim_.store(0, std::memory_order_relaxed);
        scopeWritten_.store(0, std::memory_order_release);
        for (int c = 0; c < kMaxChannels; ++c) {
            slotB_[c].assign((std::size_t) maxBlock_, 0.0f);
            dryBuf_[c].assign((std::size_t) maxBlock_, 0.0f);
            spare_[c].assign((std::size_t) maxBlock_, 0.0f);
            lineTmp_.assign((std::size_t) maxBlock_, 0.0f);
            quietBuf_[c].assign((std::size_t) maxBlock_, 0.0f);
        }
        quietRun_ = kQuietForever;
        // The half of a restart that does not depend on the rate, spelled ONCE — see reset(), which is
        // the other caller. The two verbs used to be able to drift; a shared body is what stops them.
        clearAudioState();
        // ...AND RETIRES THE BANDS THEMSELVES, which cancelling the ramp alone does not. `bandTo_` and
        // `bandCur_` survive a prepare() otherwise, `rebuildBands` republishes the same COUNT, and
        // `takeBands` re-initialises only the bands beyond that count — so the first block after a
        // restart GLIDES from the previous stream's coefficients to the new ones. At a new sample rate
        // that is worse than stale: a 167 Hz shelf's 48 kHz coefficients ARE a 334 Hz shelf at 96 kHz,
        // and the band slides down from there over a ring. Measured on a dial published before
        // prepare(): 5951 samples differ, worst 0.54. Zeroing the count makes every band re-appear AT
        // its coefficients on the first block, which is what a restart means. prepare() is
        // contractually never concurrent with process().
        for (int s = 0; s < 2; ++s) bandRt_[s].count = 0;
        snapGains();
        xo_.snap();
        snapStandby();                                   // BypassFade::snapTo — no fade on the first block
        prepared_ = true;
        if (loaded_) {                                   // the FIRs and the bands were designed for the old rate
            for (int s = 0; s < 2; ++s) { rebuildCurves(s); rebuildBands(s); }
            rebuildDry();
        }
        // …AND EVERYTHING THIS PLAYER COUNTS IN HOST SAMPLES IS RESTATED IN THE NEW ONES. See
        // restateInHostSamples(): the FIRs and the bands above were the half of a rate change anybody
        // would think of, and the warm-up ledger and the two alignment delays were the half nothing
        // touched.
        restateInHostSamples();
        if (loaded_) publishCrossoverLags();             // the captures' own lags, restated in the new host samples
        return true;
    }
    // 🔴 THE STREAM RESTART, AND UNTIL P86 THIS CLASS DID NOT HAVE ONE. A consumer reaching a
    // `nam::NamStage` through this player — which is how the product reaches it — had no way to ask
    // for the restart P47 made exact: there was no verb here, and nothing called `nam_[i].reset()`.
    // So the fix existed and could not be spent. This is the door.
    //
    // WHAT IT PROMISES: nothing the caller fed before this call can be heard after it. Every place in
    // this player that holds samples is emptied — both models and their rate-matchers, the three
    // convolvers (bypassed or not — a bypassed one is SKIPPED, so its history freezes and is replayed
    // when the curve comes back), the dry path's alignment ring, the two per-slot whole-sample
    // alignment tails, the band filters, and the block scratch. The exceptions are the NAM stage's
    // three, word for word, because they are its: a recurrent cell, a capture whose conditioner is a
    // model of its own, and NAM's own partitioned-FFT clock.
    //
    // WHAT IT DELIBERATELY DOES NOT TOUCH, because none of it is audio the caller fed:
    //   · THE BLEND LAW's state — which capture is held, which is wanted, the applied weight, the cold
    //     flags, a load in flight, a load refused. A restart is not a device change. In particular it
    //     does NOT re-arm `fed[]` for a slot that is ALREADY AUDIBLE — a slot still WARMING is the one
    //     exception, re-armed below, see the end of this function and nam::blendRestated. The case for
    //     re-arming an audible slot is that after `nam_[i].reset()` the network is back in the
    //     just-landed state, so the law's ledger reads "warm" for a flushed network.
    //     The case against won, on three counts, and the third is the one that decides it:
    //       (1) invariant 3 protects the stream's CONSISTENCY — a slot that missed the last 132 ms
    //           beside one that heard it. A restart zeroes the past of both slots AND the dry ring
    //           together, so there is nothing for the incoming slot to be inconsistent with;
    //       (2) every other stage here (the convolvers, the bands, the dry ring) restarts to the zero
    //           state and is heard on the very next block. A model is not special;
    //       (3) re-arming would not even deliver the invariant. With `fed = 0` on both slots the law
    //           holds the weight and ramps its gain DOWN over 1/maxDeltaPerBlock = 4 blocks, so the
    //           by-hypothesis wrong-sounding network is audible anyway, at up to unity, for those four
    //           blocks. What it buys is a hole: simulated on a 6859-sample field at 48 kHz with a
    //           512-sample block, 18 blocks disturbed — 43 ms of fade-out, 107 ms of mute, 43 ms of
    //           fade-in — at every restart. Re-arming only the SOUNDING slot is worse still: the law
    //           rails the goal to the neighbour (`unsafe0 && ! unsafe1` -> goal 1.0) and plays a full
    //           spurious crossfade to the other capture and back.
    //     `blendLanded()` is in any case the wrong tool for it: it also clears `inFlight` (a second
    //     load could then be asked for a slot that already has one out), `cold`, `still` and `refused`
    //     (a capture that deterministically fails would be asked for again — the storm the law exists
    //     to prevent).
    //   · the request, the pack, the alignment table, the dials, the host's trims, the gains' TARGETS.
    //
    // WHAT IT SNAPS rather than clears: the gain ramps and the band ramps. Those are control history,
    // not audio, but a restart restarts the parameter epoch too — `eq::EqBand::reset()` settled this
    // for the house, and it settled it with a number: a band left mid-ramp made a second render of the
    // same programme differ from a fresh one by 0.51 FULL SCALE. The numbers snapped to are exactly
    // the ones prepare() snaps to, so the two verbs agree by construction rather than by review.
    //
    // ⚠️ THE PRICE IS FOUR NETWORKS, not one. Each `NamStage` charges a whole drain length of inference
    // per lane that has been fed, and this player holds TWO of them, each of which can be running two
    // lanes — so a stereo host with both slots sounding pays 4 x that stage's figure (a real Standard
    // WaveNet is 3.77 ms per lane at a 64-sample block). It is idempotent exactly as the stage's is:
    // the debt is re-armed only by audio actually being fed, a sleeping slot mid-drain pays only the
    // remainder, and a mono host pays for half of it — and a lane whose falling-edge drain already ran
    // to the end pays nothing here (its debt is spent). Until P90 such a lane was billed again by the NEXT
    // prepare() — 5124 where 2562 was owed — because only a restart cleared the stage's "may be holding
    // audio" flag; this verb itself never charged it. Callable from the audio thread — nothing here
    // allocates, locks, throws or touches a field the message thread owns — and NOT free there. The
    // natural place is where prepareToPlay is; `prepare()` already performs this restart itself.
    void reset() noexcept {
        if (! prepared_) return;         // nothing is sized yet, so there is no state to restart
        quietRun_ = kQuietForever;       // a restart is silence: what came before it is not heard by anything after
        // THE EXPENSIVE HALF, and the reason this verb exists. Both slots, including one the law has
        // put to SLEEP: a cold slot is handed a width-zero call rather than run, so its networks hold
        // whatever was playing when it fell asleep, and the stage's own ledger knows exactly how much
        // of that is left (a spent drain is not a clean lane for a recurrent capture — the stage reads
        // the state, not the counter). A slot whose re-prepare was REFUSED writes nothing, and needs no
        // parked intent: the next prepare() that CAN honour it restarts of its own accord.
        for (auto& n : nam_) n.reset();
        // …and a preloaded capture a slot runs (setPreload). An audio-thread entry as process() is: the clock ticks
        // BEFORE the slots are read (audioClock_), so a copy unload() or an eviction retires is never freed under it.
        audioClock_.fetch_add(1, std::memory_order_seq_cst);
        for (int i = 0; i < 2; ++i)
            if (auto* st = slotStage_[i].load(std::memory_order_seq_cst); st != &nam_[i]) st->reset();
        // …AND THE FILTERS' HISTORY. When this was written, `reset()` on these also dropped an IR
        // published a block ago and still fading in — a tone-knob move lost for good, because the retry
        // flag is already clear after a successful publish — and clearAudioState() was added for this
        // call. `reset()` now adopts that IR instead (law 11e), and clearAudioState() leaves the fade
        // running, which a restart mid-fade answers differently from one after it settled (law 11a).
        // Which verb this call should use is registered on its own (P110), not changed here.
        for (auto& f : fir_) f.clearAudioState();
        dry_.clearAudioState();
        dryLatency_.reset();             // the dry leg's ring: a LITERAL replay of the previous stream
        wire_.reset();                   // …and the stand-by wire's, for the same reason
        clearAudioState();
        // THE BANDS SNAP, THEY DO NOT RETIRE. prepare() zeroes `bandRt_.count` because its
        // coefficients were designed for the old rate and `rebuildBands()` follows it; here the rate
        // has not moved and nothing follows, so zeroing the count would leave the tone stack switched
        // OFF until the next message-thread publish — `runBands` walks `count`, and only
        // `rebuildBands` ever raises it again (a load, a prepare, a knob). What a restart owes these
        // is the RAMP, and `clearAudioState()` above has already ended it: `bandPos_ == bandLen_ == 0`
        // makes `runBandSegment` take its ARRIVED path on the next block, and that path writes both
        // `bq.c` and `bandCur_` from `bandTo_` before the first sample is filtered.
        //
        // 🔴 SO THIS LINE IS THE ONLY PART OF THAT SNAP THAT IS NOT ALREADY DONE, and it was four
        // assignments until a review round traced which of them anything reads. `runBands`'s arrival
        // loop reads `bandCur_` to start the NEXT ramp from — BEFORE the arrived path overwrites it —
        // so a target published AFTER this restart would otherwise glide from coefficients the filter
        // abandoned mid-travel and never actually reached. Writing `bandTo_`, `bandFrom_` or `bq.c`
        // here was decoration: between two process() calls `bandTo_[s][k] == bandRt_[s].c[k]` already
        // holds for every band in the set, and the other two are overwritten before they are read.
        //
        // ⚠️ AND THE TWO VERBS DIFFER IN ONE WINDOW, which is stated because an adversarial round
        // measured it rather than because anyone would guess it: a set published by the message thread
        // AFTER the last block and BEFORE this call has not been taken yet, so this restart snaps the
        // set the audio thread still holds and `takeBands` then re-initialises only bands past
        // `rt.count` — an existing band whose coefficients changed therefore GLIDES to them over its
        // declared ramp. `prepare()` zeroes the count instead, so there every band re-appears AT its
        // target. Measured on a 60 Hz Q10 bell with a 2048-sample ramp: 10239 of 10240 samples differ
        // from a player whose band had settled, worst 0.031 against a 0.338 peak. That is an ordinary
        // 43 ms knob glide and not a leak — a restart LANDING inside a ramp is bit-identical to one
        // after it settled, which is what this line buys — but "every band arrives at its target" is
        // false in that one window and is not claimed here.
        for (int s = 0; s < 2; ++s)
            for (int k = 0; k < bandRt_[s].count; ++k) bandCur_[s][k] = bandTo_[s][k];
        snapGains();
        xo_.snap();
        snapStandby();                   // the stand-by fade lands too: a restart restarts the parameter epoch
        // 🔴 …AND A SLOT CAUGHT MID-WARM-UP IS RE-ARMED, exactly as prepare() re-arms it. This restart has
        // just flushed both networks, so a slot that was part-way through its receptive field is holding
        // NOTHING — and the law, left alone, goes on crediting it every sample it heard before the
        // flush, marking it audible with one block of real material in an empty network. That is
        // invariant 3 broken by up to a whole field, and unlike the ALREADY-WARM case it costs nothing
        // to close: a warming slot is at weight zero by construction, so re-arming it is inaudible.
        // Measured on a 2001-tap capture at a 256-sample block, restarting 1, 2 and 3 blocks into the
        // field: the warm-up that followed was 14, 13 and 12 blocks against the 15 a restart at the
        // instant of the landing costs — it fell with the depth, which is the progress being carried.
        //
        // THE NEED IS HANDED BACK UNCHANGED, which is what separates this call from prepare()'s: the
        // rate has not moved, so `warmFor` would answer the same number, and re-deriving it here would
        // be a second copy of that arithmetic rather than a use of it. blendRestated() maps `fed` by its
        // predicate either way — an audible slot stays audible, a warming one starts over — so the two
        // verbs share this sentence without sharing a rate argument.
        for (int i = 0; i < 2; ++i)
            felitronics::nam::blendRestated(blend_, i, blend_.need[(std::size_t) i], 1.0);
    }

    bool   prepared()   const { return prepared_; }
    double sampleRate() const { return fs_; }
    int    channels()   const { return channels_; }

    // The first stage of the chain this player can run. False = nothing to play (no NAM stage, or one
    // with no files) and the player is left empty.
    bool load(const namz::rig::Rig& rig, ModelSource source) {
        for (const auto& st : rig.chain)
            if (st.kind == namz::rig::StageKind::Nam) return load(st, std::move(source));
        unload();
        return false;
    }

    bool load(const namz::rig::Stage& stage, ModelSource source) {
        unload();
        if (stage.kind != namz::rig::StageKind::Nam || stage.device.files.empty()) return false;
        stage_  = stage;
        publishLevels();          // the new pack's levels stand from here, not from the end of load()
        source_ = std::move(source);
        const auto& d = stage_.device;
        // One model per DISTINCT file: several settings pointing at one file — the pack's link — share
        // its bytes, its id and its delay; only their trims differ, and those belong to the slot.
        fileModel_.assign(d.files.size(), -1);
        for (std::size_t i = 0; i < d.files.size(); ++i) {
            const auto& id = d.files[i].id;
            int m = -1;
            for (std::size_t k = 0; k < models_.size(); ++k) if (models_[k].id == id) { m = (int) k; break; }
            if (m < 0) { models_.push_back({ id, {} }); m = (int) models_.size() - 1; }
            fileModel_[i] = m;
        }
        // Where every knob starts: the pack says, the player never invents (namz::rig::defaultSettings,
        // and `default`-else-`reference` for the linear knobs).
        axes_ = namz::rig::defaultSettings(d);
        if (const auto* dial = crossfadeDial(d)) {
            dial_ = dial->name;
            dialSweep_ = dial->sweep;
            const int deg = degreesOf(axes_[dial_]);
            dialDeg_ = deg >= 0 ? (double) deg : 0.0;
        }
        // …and the defaults are per CONTROL, not a promise that the combination was captured. If no
        // file stands there, pin the first control at its default and let resolve() find the closest
        // captured combination — the pack opens on something sounding, never on a silent panel.
        if (select(d, axes_, dial_, dialDeg_, shape_, topExtend_).fileA < 0)
            for (const auto& c : d.controls)
                if (namz::rig::resolve(d, axes_, c.name, axes_[c.name]) != nullptr) break;
        for (const auto& t : tones())      toneAt_[t.name]  = toneStart(t);
        for (const auto& b : stage_.blend) blendAt_[b.name] = blendStart(b);
        // The models' offsets, from the pack when it carries them — measured once, when it was built.
        // A pack without them leaves the table empty; the host may measure and setAlignment().
        align_ = AlignmentTable::fromDevice(d);
        modelRate_.assign(models_.size(), std::numeric_limits<double>::quiet_NaN());   // learned when it lands
        // THE PACK'S IDENTITY for the reference offset: its stamped rigId, else this very load (an unstamped pack cannot be
        // told from another with the same file names and lags — a fingerprint of the table would call them one).
        xoPack_ = ! d.rigId.empty() ? "rig:" + d.rigId : "load:" + std::to_string(gen_);
        bindReferenceLag(align_, true);
        publishCrossoverLags();
        loaded_ = true;
        preloadCap_ = preloadNext_;                      // the set is made by the apply() below
        preloadStale_ = true;
        preloadBuilt_ = false;                           // …and is free to fill until it is first ready
        if (prepared_) {
            for (int s = 0; s < 2; ++s) { rebuildCurves(s); rebuildBands(s); }
            rebuildDry();
        }
        apply();
        return true;
    }

    // Forget the device: both models cleared, the law told to start over, every filter a wire.
    void unload() {
        loaded_ = false;
        stayFile_ = -1;                                  // a file entry of the pack going away
        ++gen_;                                          // a job out for this pack comes back to be dropped
        setRequest(0, 0, 0.0f);
        // A landing (or a failure) published and not yet consumed dies with its pack — and it must die
        // BEFORE the forget is posted: consumed after it, it would land a stale model in a law that was
        // just wiped and a stage that was just emptied, and an empty stage carried is the raw DI.
        landFlag_.store(false, std::memory_order_release);
        landFail_.store(0, std::memory_order_release);
        // The slots go back to their own stages BEFORE the forget is posted (a block that takes the forget runs these),
        // and every preloaded copy is retired whole (retireStage): one no slot ever ran is freed here, one a slot ran by
        // the first service() after the audio thread has entered process() again.
        for (int i = 0; i < 2; ++i) slotStage_[i].store(&nam_[i], std::memory_order_seq_cst);
        for (auto& e : pool_) retireStage(e);
        pool_.clear(); preloadPanel_.clear(); preloadAxes_.clear(); preloadCap_ = 0; preloadBuilt_ = false;
        forget_.store(true, std::memory_order_release);
        loadAsk_.store(0, std::memory_order_release);    // …and an ask for it is void with it
        // …and so is what the law last said it holds. held_ is written by the law alone, and a device that stands by
        // runs no law: left alone, the old pack's model ids would outlive it there and name the NEW pack's models
        // once load() fills models_ again — heldFileId() and fc_rig_held saying "held" of captures never loaded.
        for (auto& h : held_) h.store(0, std::memory_order_relaxed);
        for (auto& n : nam_) n.clearModel();
        models_.clear(); fileModel_.clear();
        axes_.clear(); dial_.clear(); dialSweep_ = 0; dialDeg_ = 0.0;
        toneAt_.clear(); blendAt_.clear(); toneOverride_.clear();
        sel_ = {}; plan_ = {};
        stage_ = {};
        source_ = nullptr;
        align_ = {};
        for (int s = 0; s < 2; ++s) {
            curveSum_[s].clear();
            firBypass_[s].store(true, std::memory_order_release);
            publishBands(s, BandSet {});
        }
        bandsDropped_ = 0;
        dryActive_.store(false, std::memory_order_release);
        dryFirBypass_.store(true, std::memory_order_release);
        dryGain_.store(0.0f, std::memory_order_release);
        wetGain_.store(1.0f, std::memory_order_release);
        // …and with no stage there is nothing to be fed or delivered: an empty player is a wire,
        // whatever hand the host is holding. The hand itself is kept — it is the bench's, not the
        // pack's — and lands again on the next load(). The FEED stays applied: it is in front of the
        // device (setFeedDb), and the wire is behind it. publishLevels() says so for an empty player,
        // so a setter called while nothing is loaded publishes the same two numbers this does.
        publishLevels();
        chainGain_.store(1.0f, std::memory_order_release);
        for (auto& g : slotGain_) g.store(1.0f, std::memory_order_release);
        for (auto& p : pendDelay_) p.store(0, std::memory_order_release);
        modelRate_.clear();
        xoFits_ = alignFits_ = true;                     // no pack, nothing out of reach
        for (auto& c : slotCold_) c.store(false, std::memory_order_release);
    }
    bool loaded() const { return loaded_; }
    const namz::rig::Stage& stage() const { return stage_; }

    /// THE HOST'S OWN HAND ON THE PACK'S TWO LEVELS — the WHOLE number it wants this device played
    /// at, never a difference from what the pack states. Absent (the default) leaves the pack's own
    /// number standing, which is what a plugin wants and why a plugin needs none of this. The feed
    /// (setFeedDb) rides on top of the input one: the device is fed the hand plus the feed.
    ///
    /// A host with a fader used to subtract: it sent `hand - what the pack says`, and applied that
    /// outside the player. That cannot be made correct. The subtraction needs to know which pack is
    /// loaded RIGHT NOW, and a host reads that from its own document — which changes when somebody
    /// edits it, when a rebuild is in flight, when a device is switched mid-build. Every one of those
    /// left the level wrong, silently, in the same class as the double application this pair of keys
    /// was added to end. The player is the one applying the level and the only place that cannot
    /// disagree with itself about which pack it holds, so the subtraction lives here or nowhere.
    ///
    /// Message thread, like every other setter. Survives a load: the hand belongs to the bench and
    /// not to the pack, so the next pack is played at the same number without the host restating it.
    void setHostInputDb (std::optional<double> db) { hostIn_  = db; publishLevels(); }
    void setHostOutputDb(std::optional<double> db) { hostOut_ = db; publishLevels(); }
    std::optional<double> hostInputDb()  const { return hostIn_; }
    std::optional<double> hostOutputDb() const { return hostOut_; }

    /// THE FEED — how hard the bench drives this device, ON TOP of its input level (the pack's, or the host's hand
    /// above): OrbitAmp's block IN, the trim it applies to the block's input before the block plays
    /// (PluginProcessor.cpp:1497). The app applies it outside its player; a host with no such stage of its own (fc_rig,
    /// fc_rig_set_feed_db) hands it here, for two reasons. The stand-by WIRE is taken before it — a parked device hands
    /// the input on untrimmed, as the app's wire is fed before its IN (PluginProcessor.cpp:1423-1426) — and the scope's
    /// dry is taken after it, where the app copies the block's input (CapturedBlock.h:543-544), and before the input
    /// level, which is the player's own.
    ///
    /// The sound is one gain, as it was when a host stated the feed as its hand (`setHostInputDb(stageInputDb() +
    /// feed)`): the input level plus the feed, summed here in that order, so the two spellings play the same bytes.
    /// It belongs to the bench like the hand: kept across load() and unload() — an empty player is a wire behind it.
    /// Message thread; a non-finite dB is refused (false) and changes nothing. 0 (the default) is no feed.
    bool setFeedDb(double db) {
        if (! std::isfinite(db)) return false;
        feedDb_ = db;
        feedGain_.store(linOf(db), std::memory_order_release);
        publishLevels();
        return true;
    }
    double feedDb() const { return feedDb_; }
    // The pack's own two levels, for a host that prints or draws them. These are what the player IS
    // applying: a host with a fader of its own applies only its deviation from them, or the level
    // lands twice — which is exactly the bug that made these keys necessary.
    double stageInputDb()  const { return stage_.inputDb; }
    double stageOutputDb() const { return stage_.outputDb; }

    // ---------------------------------------------------------------- message thread: the panel ----

    // A dial, in degrees of its rotation. The crossfade dial moves continuously; any other captured dial
    // selects its nearest captured position; a tone or blend dial moves its own filter. False = no such
    // dial on this device, or a value it cannot take.
    bool setDial(const std::string& control, double degrees) {
        if (! loaded_) return false;
        if (! dial_.empty() && control == dial_) {
            dialDeg_ = std::clamp(degrees, 0.0, (double) dialSweep_);
            apply();
            return true;
        }
        for (const auto& c : stage_.device.controls)
            if (c.name == control) {
                const auto v = nearestValue(c, degrees);
                return ! v.empty() && setSwitch(control, v);
            }
        for (const auto& t : tones())
            if (t.name == control && t.sweep > 0) {
                toneAt_[control] = degreeValue(degrees, t.sweep);
                if (prepared_) rebuildKnob(t);
                return true;
            }
        for (const auto& b : stage_.blend)
            if (b.name == control && b.sweep > 0) {
                blendAt_[control] = degreeValue(degrees, b.sweep);
                applyBlendGains();
                return true;
            }
        return false;
    }

    // A control set to one of its values. For a captured axis this is namz::rig::resolve: the turned
    // control is pinned, everything else stays where the hand left it, and the closest captured
    // combination is chosen — the crossfade dial keeps its angle and follows along the new knots. False
    // = no such control, or a value nothing was captured at (then nothing changes).
    bool setSwitch(const std::string& control, const std::string& value) {
        if (! loaded_) return false;
        for (const auto& c : stage_.device.controls)
            if (c.name == control) {
                if (! dial_.empty() && control == dial_) {
                    const int deg = degreesOf(value);
                    return deg >= 0 && setDial(control, (double) deg);
                }
                if (namz::rig::resolve(stage_.device, axes_, control, value) == nullptr) return false;
                apply();
                return true;
            }
        for (const auto& t : tones())
            if (t.name == control) {
                // A SWITCH ONLY HAS THE POSITIONS IT DECLARES. Accepting any word and storing it read
                // back as a setting the knob does not have, while the sound was the reference — the
                // caller was told `true` and heard nothing. A dial keeps taking any degree: every angle
                // of its travel is playable, swept or not.
                if (t.sweep <= 0 && ! t.positions.empty()) {
                    bool found = false;
                    for (const auto& p : t.positions) if (p.value == value) { found = true; break; }
                    if (! found) return false;
                }
                toneAt_[control] = value;
                if (prepared_) rebuildKnob(t);
                return true;
            }
        for (const auto& b : stage_.blend)
            if (b.name == control) {
                blendAt_[control] = value;
                applyBlendGains();
                return true;
            }
        return false;
    }

    // What the panel reads back. `settings()` is the captured combination — for the crossfade dial it
    // names the knot at or below the hand, the angle itself is `dialDegrees()`.
    const Settings&    settings()    const { return axes_; }
    const std::string& dialName()    const { return dial_; }
    int                dialSweep()   const { return dialSweep_; }
    double             dialDegrees() const { return dialDeg_; }
    // A tone or blend knob's position as the pack spells it ("150", or a switch's token). Empty = no
    // such knob.
    std::string knobValue(const std::string& control) const {
        if (const auto t = toneAt_.find(control); t != toneAt_.end()) return t->second;
        if (const auto b = blendAt_.find(control); b != blendAt_.end()) return b->second;
        if (const auto a = axes_.find(control); a != axes_.end()) return a->second;
        return {};
    }
    const Selection& selection() const { return sel_; }
    const SlotPlan&  plan()      const { return plan_; }

    // TONE HANDED IN BESIDE THE MANIFEST — the same structures the pack carries, from another source: a
    // bench fitting bands by ear hands them here and hears them at once, then packs and hears them from
    // the file. ONE path applies tone; only where the knob's description came from differs. A knob named
    // here replaces the pack's block of that name (its `positions` or `sections`, whichever it had); a
    // name the pack has no block for is a new knob, starting at its default. The pack's own blocks are
    // untouched and return with clearToneOverride().
    void setToneOverride(std::vector<namz::rig::Tone> tone) {
        toneOverride_ = std::move(tone);
        for (const auto& t : tones()) if (! toneAt_.count(t.name)) toneAt_[t.name] = toneStart(t);
        if (prepared_ && loaded_) for (int s = 0; s < 2; ++s) { rebuildCurves(s); rebuildBands(s); }
    }
    void clearToneOverride() {
        if (toneOverride_.empty()) return;
        toneOverride_.clear();
        if (prepared_ && loaded_) for (int s = 0; s < 2; ++s) { rebuildCurves(s); rebuildBands(s); }
    }
    bool toneOverridden() const { return ! toneOverride_.empty(); }
    // The tone knobs as they PLAY: the pack's, with any handed-in block of the same name in its place,
    // and the handed-in knobs the pack does not have after them.
    std::vector<namz::rig::Tone> tones() const {
        std::vector<namz::rig::Tone> out;
        for (const auto& t : stage_.tone) {
            const namz::rig::Tone* use = &t;
            for (const auto& o : toneOverride_) if (o.name == t.name) { use = &o; break; }
            out.push_back(*use);
        }
        for (const auto& o : toneOverride_)
            if (std::none_of(stage_.tone.begin(), stage_.tone.end(), [&o](const namz::rig::Tone& t) { return t.name == o.name; }))
                out.push_back(o);
        return out;
    }

    // THE SHAPE OF THE HANDOVER — where the 50/50 lands between two captures and how wide the fade is.
    // The default is the original law (midpoint, full span); the bench turns these, a plugin need not.
    void setBlendShape(BlendShape s) { shape_ = s; if (loaded_) apply(); }
    BlendShape blendShape() const { return shape_; }
    // How much harder the top capture is driven per degree past it (ModelBlend.h explains the guess).
    void setTopExtendDbPerDeg(double v) { topExtend_ = v; if (loaded_) apply(); }
    double topExtendDbPerDeg() const { return topExtend_; }

    // Apply each model's loudness tag. Off, the models play raw, as the hardware returned them.
    void setNormalize(bool on) { normalize_.store(on, std::memory_order_release); }
    bool normalize() const { return normalize_.load(std::memory_order_acquire); }

    // Apply the pack's per-file input trims (`input_db` — a linked setting plays its neighbour
    // softer). OFF feeds every capture at unity instead: for a library shot at one honest level
    // the stated attenuations are somebody else's story, and into a nonlinear model a few dB
    // less in is a lot less out. Read on the audio side, so the toggle lands on the next block.
    void setInputTrims(bool on) { inputTrims_.store(on, std::memory_order_release); }
    bool inputTrims() const { return inputTrims_.load(std::memory_order_acquire); }

    // The rest after which a silent slot's model is no longer run (kColdAfterSeconds). A slot that
    // sounds at all is never cold; between two captures both models run, on one they do not. Zero or
    // less = never. Takes effect from the next block; a slot already asleep stays asleep until woken.
    void   setColdAfterSeconds(double seconds) {
        coldSeconds_ = seconds;
        coldAfter_.store(coldSamples(seconds), std::memory_order_release);
    }
    double coldAfterSeconds() const { return coldSeconds_; }

    // HOW MANY MODELS MAY RUN — 2, the default, is the player as it always was: the two captures either
    // side of the gain dial, crossfaded by angle, the neighbour of a capture warm at weight zero (until
    // it rests, kColdAfterSeconds). 1 is for a host that can afford one network and not two — a browser
    // audio thread on a slow machine: the dial is STEPPED to the nearest capture (by the handover the
    // blend shape sets, with a deadband around the capture sounding — kStepDeadband), the other slot is
    // asked for nothing — no neighbour is ever loaded, and ONE network runs on audio, plus the outgoing
    // capture's bounded drain as it rests, which overlaps the incoming warm-up — and a change of capture
    // is a DIP (kDipSeconds down, the incoming capture loaded or woken and fed its field while nothing is
    // heard, kDipSeconds up) instead of a crossfade. The pair's slots go by parity, so crossing a LINK —
    // one file at two angles — is a change of slot: a dip and a load of the same file. See
    // nam::blendStepSingle for the order and the one exception.
    //
    // Either way while playing. 1 -> 2: the neighbour is asked for at weight zero and nothing of it is
    // heard until it is fed; on a capture the sound then does not change until the dial moves, between
    // two captures the weight glides — a quarter per block at most — to the dial's blend. 2 -> 1 on a
    // capture: the neighbour rests, and the sound does not change; between two captures: a dip to the
    // nearer one. False = not 1 or 2, and nothing changes. Message thread; survives load() — it is the
    // host's budget, not the pack's.
    bool setMaxModels(int n) {
        if (n != 1 && n != 2) return false;
        maxModels_ = n;
        stayFile_ = -1;                                  // the step's deadband starts from the nearer capture
        single_.store(n == 1, std::memory_order_release);
        if (loaded_) apply();
        return true;
    }
    int maxModels() const { return maxModels_; }

    // THE PRELOAD — every capture of the pack, prepared before it is asked for, for a host whose loads stall its audio
    // (a browser AudioWorklet runs the load job on the audio thread: 24 – 49 ms per capture in Chromium, so a turn of
    // DRIVE across captures underran at every capture it reached). Off by default: the player above, bit for bit.
    //
    // On, from the next load(): the player hands out jobs (the same LoadJob, run and delivered as ever) for the SET, one
    // at a time, until every copy in it is prepared — preloadProgress() counts them — and from then on neither a turn of
    // the gain dial nor a switch within the set hands out one: a slot that wants a capture takes its prepared copy at
    // the next service(), the instant a delivered job would have landed it, and the law warms and crossfades it as
    // before (BlendLaw, the dip, the rest — all unchanged). THE SET is, in order: the panel sounding (the files of the
    // gain axis at the other controls' current settings) — every capture the dial can put in either slot, one copy per
    // (capture, slot), since the two slots hold the same file at once at the dial's ends and across a link (eleven
    // copies for a pack of eleven positions and nine files); then the other panels of the pack (every captured
    // combination of the other controls), nearest first, while the set stays within `maxModels` copies. The default,
    // kPreloadWholePack, is the whole pack: every panel. The sounding panel is always whole, whatever the cap.
    //
    // Under a cap, a switch to a panel outside the set makes the set again around it: copies it still holds stay, the
    // rest are freed (a copy a slot is running once the slot moves off it), and the copies it lacks are handed out only
    // as the law asks for them — as many jobs as the player without the preload runs there, never more — unless the
    // host says its jobs cost nothing now (setPreloadIdle). The same holds for a file that could not be fetched: it is
    // fetched again when the law asks for it. Those two are the only jobs after the set is ready.
    //
    // Memory: one copy is one NamStage with its capture — measured 2.8 MB natively for the site's WaveNets (both NAM
    // instances: NamStage builds two, stereo). The whole pack is 11 copies (~31 MB) for X88-IR Crunch and V4 Sheriff
    // Ch1, 44 (~123 MB) for IR-X Ch2, 66 (~185 MB) for IR-X Ch1 PowerAmp. A copy is freed whole when it leaves the set
    // or the pack goes (retireStage): at once if no slot ever ran it, otherwise by the first service() after the audio
    // thread has entered process() again.
    // A job that cannot fetch its file ("unfetched") or whose bytes are not a capture ("failed") settles its copy: the
    // set is ready without it, and the law is told the load failed when it asks.
    // Message thread. False = a negative cap.
    static constexpr int kPreloadWholePack = std::numeric_limits<int>::max();
    bool setPreload(bool on, int maxModels = kPreloadWholePack) {
        if (maxModels < 0) return false;
        preloadNext_ = on ? std::max(1, maxModels) : 0;
        return true;
    }
    // The host's word that a job costs its sound nothing now — it is silent, or it runs jobs on a worker thread. While
    // it is set, the copies the set lacks are handed out after ready too, as they are before; off (the default), after
    // ready only the law's own ask is. Message thread; read by the next takeLoadJob().
    void setPreloadIdle(bool idle) { preloadIdle_ = idle; }
    bool preload() const { return preloadNext_ > 0; }
    struct PreloadProgress {
        int total = 0;       // copies in the set; 0 = the pack loaded is not preloading
        int settled = 0;     // …of them prepared, or settled as failed or unfetched
        int failed = 0;      // …of the settled, the failed and the unfetched
        int held = 0;        // copies the pool holds prepared, the set's and those a slot still runs
        bool ready() const { return total > 0 && settled == total; }
    };
    PreloadProgress preloadProgress() const {
        PreloadProgress p;
        if (preloadCap_ <= 0 || ! loaded_) return p;
        for (const auto& e : pool_) {
            if (e.state == Pre::Ready) ++p.held;
            if (! e.wanted) continue;
            ++p.total;
            if (e.state == Pre::Ready) ++p.settled;
            if (e.state == Pre::Failed || e.state == Pre::Unfetched) { ++p.settled; ++p.failed; }
        }
        return p;
    }

    // The models' measured offsets (AlignmentTable.h), for a pack that does not carry its own. A delay travels with a
    // model: a slot silent at both ends of a block takes it at once, as a model lands; a slot that is HEARD takes a delay
    // of the capture it is playing (a table handed in mid-mix, a model rate learned at a landing) through a 10 ms
    // crossfade of its line — never a splice; a capture on its way out keeps its delay until it is silent. A prepare()
    // lands every slot's at once, because a prepare leaves nothing to splice (see restateInHostSamples).
    void setAlignment(AlignmentTable table) {
        bindReferenceLag(table, false);
        align_ = std::move(table);
        if (loaded_) stageDelays();
        publishCrossoverLags();
    }
    const AlignmentTable& alignment() const { return align_; }
    bool alignmentFromPack() const { return align_.fromPack && ! align_.empty(); }

    // Regular message-thread housekeeping: frees models the audio thread has stepped past, retries a
    // filter the convolver rejected mid-fade. Call from a timer, a few times a second at least — and
    // ask for the load job after it (takeLoadJob), because the law waits for that.
    void service() {
        for (auto& n : nam_) n.collectGarbage();
        freeRetired();                                       // the preload's copies unload() and an eviction retired
        {
            const auto now = audioClock_.load(std::memory_order_seq_cst);
            std::erase_if(xoRetired_, [now] (const auto& r) { return now > r.second; });   // the crossover's outgrown tables
        }
        servePreloadAsk();
        for (auto& f : fir_) f.flushPending();
        dry_.flushPending();
    }

    // ---------------------------------------------------------------- message thread: loading ----

    // A MODEL THE LAW ASKED FOR, as work for the host to run where it likes — a worker thread, or right
    // here. The job carries everything the work needs (the source, the bytes if already fetched, the
    // numbers the stages were prepared with) and nothing of the player, so run() is a pure function of
    // it. At most ONE job is out at a time, and a job taken MUST come back through deliver() — with a
    // null model if it failed — or the law waits for it forever.
    struct LoadJob {
        int           slot = 0;
        std::uint64_t model = 0;                                   // BlendModelId: models_ index + 1
        std::string   fileId;                                      // the pack's `files[].id`
        std::shared_ptr<const std::vector<std::byte>> bytes;       // null = not fetched yet
        ModelSource   source;
        double        sampleRate = 48000.0;
        int           maxBlock = 512;
        int           channels = 2;                                // the host's: 1 builds ONE network (v0.7.0)
        std::uint64_t generation = 0;                              // the load() it belongs to
        bool          preload = false;                             // a copy for the preload (setPreload), not the slot
    };
    struct Loaded {
        LoadJob job;
        std::shared_ptr<const std::vector<std::byte>> bytes;       // the job's own, or what run() fetched
        bool    fetched = false;                                   // …and whether it had to
        felitronics::nam::NamStage::PreparedModel model;           // null = the bytes were not a model
    };

    std::optional<LoadJob> takeLoadJob() {
        if (jobOut_ || ! loaded_) return std::nullopt;
        if (preloadCap_ > 0) return takePreloadJob();
        const auto ask = loadAsk_.load(std::memory_order_acquire);
        if (ask == 0) return std::nullopt;
        const auto id = ask >> 1;
        if (id == 0 || id > models_.size()) {                      // an ask that outlived its pack
            loadAsk_.store(0, std::memory_order_release);
            landFail_.store((int) (ask & 1u) + 1, std::memory_order_release);
            return std::nullopt;
        }
        const auto& m = models_[(std::size_t) id - 1];
        LoadJob job;
        job.slot = (int) (ask & 1u); job.model = id; job.fileId = m.id; job.bytes = m.bytes;
        job.source = source_; job.sampleRate = fs_; job.maxBlock = maxBlock_; job.channels = channels_;
        job.generation = gen_;
        jobOut_ = true;
        return job;
    }

    // Any thread but the audio one. The bytes through the source when the job has none, then the heavy
    // half of a load (NamStage::prepareModel). Touches nothing of any player.
    // Since v0.7.0 the half is lighter, on two counts. ONE network on a mono host (job.channels, the player's own
    // channel count): a mono stream never runs a second. And NO NAM ZERO-PREWARM for a non-recurrent capture
    // (NamStage::Warm::Caller): no slot of this player is heard before warmFor() of live input has run through it,
    // and warmFor covers the receptive field, so the prewarm's silence was overwritten before anyone could hear it —
    // what plays is bit-identical (tools/wasm-rig/rig-compare.mjs holds v0.6.0 and this to it, session by session).
    static Loaded run(LoadJob job) {
        Loaded out;
        out.bytes = job.bytes;
        if (out.bytes == nullptr && job.source) {
            out.bytes = std::make_shared<const std::vector<std::byte>>(job.source(job.fileId));
            out.fetched = true;
        }
        // The bytes go in SHARED: a mono model keeps them for a later second network as one more owner of the file
        // this player already holds (models_[k].bytes), not as a private copy of it.
        if (out.bytes != nullptr && ! out.bytes->empty())
            out.model = felitronics::nam::NamStage::prepareModel(out.bytes, job.sampleRate, job.maxBlock, 0.0f,
                                                                 job.channels, felitronics::nam::NamStage::Warm::Caller);
        out.job = std::move(job);
        return out;
    }

    // Message thread. The light half: the bytes kept (fetched once per file, however many times the
    // dial crosses it), the model installed in its slot, the law told it landed — or failed. A job from
    // a pack that is gone is dropped whole: the law was told to start over when the pack left. An EMPTY
    // answer is not kept: it is the source's "could not fetch it", not the file, so the file is asked for
    // again the next time the law wants it (bytes that are not a model ARE kept — they are the file).
    void deliver(Loaded loaded) {
        jobOut_ = false;
        auto& job = loaded.job;
        if (job.generation != gen_ || ! loaded_) return;
        if (loaded.fetched && loaded.bytes != nullptr && ! loaded.bytes->empty()
                && job.model >= 1 && job.model <= models_.size()) {
            auto& m = models_[(std::size_t) job.model - 1];
            if (m.bytes == nullptr) { m.bytes = loaded.bytes; ++loads_; }
        }
        if (job.preload) { deliverPreload(std::move(loaded)); return; }
        loadSlot(job.slot, std::move(loaded.model), job.model);
    }

    // A FILE HANDED IN UP FRONT (v0.7.0). Message thread. The pack's file `id`, kept exactly as a fetched one is
    // (deliver): from here a job for it carries the bytes and the source is never asked for it. A host that has a
    // pack's files in hand — a page that fetched them with the manifest — gives them here and no load waits on a
    // fetch. True when these bytes are now the file's; false for no pack, empty bytes, an id the pack does not name,
    // or a file already held (the first bytes stay — a file is a file). A job already out keeps what it carried.
    // Whether putFile(id, …) would keep bytes now: a pack is loaded, it names `id`, and the file is not held yet. A host
    // asks this BEFORE it makes room for the bytes (fc_rig_put_file), so a bogus id or size never grows its memory.
    bool wantsFile(const std::string& id) const {
        if (! loaded_) return false;
        for (const auto& m : models_)
            if (m.id == id && m.bytes == nullptr) return true;
        return false;
    }

    bool putFile(const std::string& id, std::shared_ptr<const std::vector<std::byte>> bytes) {
        if (! loaded_ || bytes == nullptr || bytes->empty()) return false;
        bool kept = false;
        for (auto& m : models_)
            if (m.id == id && m.bytes == nullptr) { m.bytes = bytes; kept = true; }
        return kept;
    }

    // service() with every job due run right here, on this thread — for a host without a worker, and
    // for a test. The same path on one thread, not a second one.
    void serviceHere() {
        service();
        while (auto job = takeLoadJob()) deliver(run(std::move(*job)));
    }

    // Host-rate latency: the models' own rate-matching (the filters are minimum-phase, the alignment
    // delays are relative and the reference model carries none). Message thread, or inside process(): it reads the
    // stages the slots run, which only those two may (a copy the preload retires is freed by the message thread once
    // the audio thread has entered process() again — a third thread reading here could outlive it).
    int latencySamples() const {
        return std::max(slotStage_[0].load(std::memory_order_seq_cst)->latencySamples(),
                        slotStage_[1].load(std::memory_order_seq_cst)->latencySamples());
    }

    // ---- read-outs of the audio thread, for a strip or a dump ----
    float liveMix() const { return liveMix_.load(std::memory_order_acquire); }        // applied weight of slot 1
    // Applied blend gains — what the audio thread multiplied by on the last block, not what was asked for.
    // Same read-out contract as liveMix() above: a strip can show the gain that is actually in the sound
    // while the ramp is still travelling, and it is the only place a law-8 regression on these ramps is
    // visible at all (the stuck value is a subnormal that adds nothing to a normal sample).
    float liveDry() const { return liveDry_.load(std::memory_order_acquire); }
    float liveWet() const { return liveWet_.load(std::memory_order_acquire); }
    // The file id held in a slot right now ("" = nothing yet).
    std::string heldFileId(int slot) const {
        const auto id = held_[(std::size_t) (slot & 1)].load(std::memory_order_relaxed);
        return id == 0 || id > models_.size() ? std::string() : models_[(std::size_t) id - 1].id;
    }
    int appliedSlotDelay(int slot) const { return slotDelay_[(std::size_t) (slot & 1)].load(std::memory_order_relaxed); }
    // THE LOUDNESS TAG OF WHAT IS SOUNDING — of the slot the sound actually leaves by, which is not
    // always slot 0. Slots are handed out by the PARITY of a capture's place on the dial (slotPlan,
    // RigSelection.h), so on an odd rung the whole sound comes out of slot 1 while slot 0 holds the
    // silent neighbour: a face that read slot 0 named the wrong capture, or warned "plays raw" about a
    // model that carries a tag.
    //
    // DURING A CROSSFADE THERE IS NO SINGLE HONEST NUMBER, and this does not invent one. `db` and
    // `tagged` are the slot carrying MOST of the sound, and `blended` says the other slot holds a
    // DIFFERENT capture and is audible beside it — so a face can say "one of two" instead of stating a
    // level the sound has not got. At the ends of the dial both slots hold the same capture, and there
    // `blended` is false however the weight sits.
    //
    // The weight is the APPLIED one (liveMix()), not the one asked for: while a model is still loading
    // or warming the slot that IS the sound is the old one, and its tag is what a face should show.
    // `tagged` is false both for a model without a tag and for a slot with no model at all —
    // heldFileId(slot) tells those two apart. This is the model mix alone: a blend knob at its dry end
    // takes every model out of the sound and says nothing here. Message thread.
    struct SoundingLoudness {
        double db      = 0.0;      // the tag of the slot carrying most of the sound, in dB
        bool   tagged  = false;    // …and whether that slot carries one at all
        bool   blended = false;    // …and whether a second, different capture is audible beside it
        int    slot    = 0;        // which slot that was
    };
    SoundingLoudness soundingLoudness() const {
        // unload() empties both stages at once while the audio thread clears its own numbers a block
        // later: with no pack there is nothing sounding to carry a tag.
        if (! loaded_) return {};
        const float mix = liveMix_.load(std::memory_order_acquire);
        const auto  h0  = held_[0].load(std::memory_order_relaxed);
        const auto  h1  = held_[1].load(std::memory_order_relaxed);
        const int   s   = mix > 0.5f ? 1 : 0;
        const auto& st = *slotStage_[s].load(std::memory_order_acquire);
        return { st.modelLoudness(), st.modelHasLoudness(),
                 mix > 0.0f && mix < 1.0f && h0 != 0 && h1 != 0 && h0 != h1, s };
    }
    // Instrumentation, for a bench's dump: blocks in which a slot was still warming, weight moves of
    // more than 2 % inside one block and the biggest of them — a whole swing inside one block is a step
    // in all but name. Counted since the last clearCounters().
    int   warmBlocks()  const { return warmBlocks_.load(std::memory_order_relaxed); }
    int   mixJumps()    const { return mixJumps_.load(std::memory_order_relaxed); }
    float biggestJump() const { return biggestJump_.load(std::memory_order_relaxed); }
    // Whether a slot is COLD right now — held, silent, its model no longer run on AUDIO
    // (kColdAfterSeconds; it is still clocked at width zero until its drain is spent) — and the blocks
    // it has slept since the last clearCounters(), for the dump beside warmBlocks().
    bool  slotCold(int slot)   const { return slotCold_[(std::size_t) (slot & 1)].load(std::memory_order_relaxed); }
    int   coldBlocks(int slot) const { return coldBlocks_[(std::size_t) (slot & 1)].load(std::memory_order_relaxed); }
    // What the CPU actually paid: the blocks in which a slot's network ran — on audio, or draining the
    // silence of a rest (NamStage::drainedSamples moved) — and the blocks in which both did. One model
    // holds the second at the outgoing capture's drain per change of slot. Since clearCounters().
    int   runBlocks(int slot) const { return runBlocks_[(std::size_t) (slot & 1)].load(std::memory_order_relaxed); }
    int   pairBlocks()        const { return pairBlocks_.load(std::memory_order_relaxed); }
    // Whether the law let anything of the models be heard at the end of the last block run (its gain above zero):
    // false from a load until the first capture is fed its field, true once it may be heard. Stand-by does not move it.
    bool  audible()           const { return audible_.load(std::memory_order_relaxed); }
    // The architecture signature (NamStage::architectureSignature) of the capture slot `slot` holds; 0 when it holds
    // none. Message thread.
    std::uint32_t heldSignature(int slot) const {
        const auto i = (std::size_t) (slot & 1);
        return held_[i].load(std::memory_order_relaxed) != 0 ? slotStage_[i].load(std::memory_order_seq_cst)->architectureSignature() : 0u;
    }

    // THE QUIET WARM (v0.7.0). A capture with a receptive field is not heard before warmFor() samples of input have
    // run through it (THE WARM-UP LEDGER). When the models' input has been EXACTLY ZERO for at least that long — at a
    // start, after reset(), after a stand-by (park() stops everything else to silence too), in a pause once the tone
    // stack's tail has decayed to an exact 0 (hundreds of ms after the last note: no flush-to-zero in wasm) — that input is
    // known in advance: silence. So the warm-up need not wait for it in real time: this feeds a warming slot's stage up
    // to `maxBlocks` more blocks of silence (maxBlock samples each) and counts them as fed, and the slot may be heard
    // as soon as the ledger is paid — a few calls instead of the field's length in real time. What it is then heard
    // with is BIT-IDENTICAL to what the live warm-up would have given it: the same blocks of silence through the same
    // stage, only sooner, and silence was what the input held over the whole stretch they stand for (quietRun_ covers
    // the slot's whole need, so nothing it was really fed since its landing was anything but zero). Mid-riff the run
    // is short and nothing happens: the live warm-up stays. Returns the blocks it ran (0: no slot warming, the input
    // not quiet long enough, stood by, or maxBlocks <= 0). AUDIO THREAD, between two process() calls (it touches the
    // law's ledger and runs the stages) — the worklet calls it after each render. A host that never calls it plays as
    // before. No allocation. Each block costs one network render.
    int warmQuiet(int maxBlocks) noexcept {
        if (! prepared_ || parkedRt_ || maxBlocks <= 0 || ranNch_ <= 0) return 0;
        const bool norm = normalize_.load(std::memory_order_acquire);
        int ran = 0;
        for (int i = 0; i < 2; ++i) {
            while (ran < maxBlocks && blend_.held[i] != 0 && ! blend_.inFlight[i] && ! blend_.cold[i]
                   && blend_.fed[i] < blend_.need[i] && quietRun_ >= blend_.need[i]) {
                float* z[kMaxChannels];
                for (int c = 0; c < ranNch_; ++c) {
                    std::fill(quietBuf_[c].begin(), quietBuf_[c].end(), 0.0f);
                    z[c] = quietBuf_[c].data();
                }
                if (! slotStage_[i].load(std::memory_order_seq_cst)->process(z, ranNch_, maxBlock_, norm)) return ran;
                blend_.fed[i] += maxBlock_;
                ++ran;
            }
        }
        return ran;
    }
    void  clearCounters() {
        warmBlocks_.store(0, std::memory_order_relaxed);
        mixJumps_.store(0, std::memory_order_relaxed);
        biggestJump_.store(0.0f, std::memory_order_relaxed);
        for (auto& c : coldBlocks_) c.store(0, std::memory_order_relaxed);
        for (auto& c : runBlocks_) c.store(0, std::memory_order_relaxed);
        pairBlocks_.store(0, std::memory_order_relaxed);
    }
    long long modelLoads() const { return loads_; }                                   // how many the source was asked for
    int bandsDropped() const { return bandsDropped_; }                                // sections past kMaxBands

    // The tone as it stands, for drawing: the summed curve of the curve-form knobs on a side (dB on
    // `commonGrid()`, empty = nothing on that side) and the bands of the section-form knobs.
    const std::vector<double>& commonGrid() const { return commonGrid_; }
    const std::vector<double>& curveDb(int side) const { return curveSum_[side & 1]; }
    bool curveActive(int side) const { return ! firBypass_[side & 1].load(std::memory_order_acquire); }   // …and whether it is a FIR or a wire
    const std::vector<felitronics::rigplayer::SectionBiquad>& bands(int side) const { return bandsShown_[side & 1]; }
    BlendGains blendGains() const { return { (double) dryGain_.load(std::memory_order_relaxed),
                                             (double) wetGain_.load(std::memory_order_relaxed) }; }

    // ------------------------------------------------------------------- stand-by: OrbitAmp's PARK ----
    // On: the device's output fades to the WIRE — its own input at its latency, at unity, none of the pack's levels —
    // over kStandbyFadeMs, and then the device is not run: no tone, no models on audio, no law, no ramps, no scope.
    // Off: it fades back in over the same 15 ms and runs every block again. Exactly the app's captured block under
    // PARK (PluginProcessor.h:774 `linkWorks` false for every row but the tuner, IN and OUT; the block not run once
    // its BypassFade is down, PluginProcessor.cpp:1515-1516; the fade 15 ms, BypassFade.h:32).
    //
    // Knobs moved while it stands by — dials, switches, a gain dial that wants another capture, a pack loaded — are
    // taken on the first block back, as the app's frozen player takes them: the law steps from where it stood, a
    // band glides from its old coefficients, a gain ramps from its old value. One exception, also the app's: the
    // pack's input level (and the host's, setHostInputDb) ARRIVES on the first block back rather than sliding
    // into it — the app's block IN trim, `lastInGain = inTarget` when the block was off (PluginProcessor.cpp:1494-1495).
    //
    // WHERE THIS PLAYER IS STRICTER THAN THE APP, and why. The app simply stops calling the player, so its networks
    // and filters hold what they heard before PARK and replay it on the return — the THIRD way this file would stop
    // clocking a NamStage, and the other two are closed above (a plane taken away, a sleeping slot). Here a pause
    // is silence (law 11c): on the block the fade-out ends, the filters, the dry ring and the per-slot delay lines
    // are STOPPED (clearAudioState — a stop, not a restart: no ramp snaps, no law resets), and both stages are
    // handed the width-zero call every stood-by block, so each drains the silence it owes ONCE and costs nothing
    // after it — what the cold rest pays, per park. The return is then what it would be after silence.
    void setStandby(bool on) { standby_.store(on, std::memory_order_release); }
    bool standby() const { return standby_.load(std::memory_order_acquire); }          // what was asked
    bool standingBy() const { return standingBy_.load(std::memory_order_acquire); }    // faded out, not running

    // ------------------------------------------------------------------------------ the crossover blend ----
    //
    // A BASS AMP'S CLEAN LOW END: below `crossoverHz()` the output carries the CLEAN input — the dry copy, the input
    // at the pack's input level (and the host's, the feed) before the pre tone — and above it the device. The host's
    // setting, not the pack's: nothing here reads or writes a manifest field. It sits after the blend knob and before
    // the pack's output level, so that level rides both bands:
    //
    //     out = HP4(device) + LP4((1 − amount) · device + amount · clean)
    //
    // `clean` is the slots' clean taps (each at its capture's lag and polarity) mixed as the slots are, plus the pack's
    // own dry part mixed in by the blend knob exactly as it is mixed into the device. The mechanism is CrossoverBlend.h.
    //
    // ONE PAIR SPLITS BOTH SIDES: LP4 and HP4 are core's eq::Crossover2 — two Butterworth SVFs a side, a 4th-order
    // Linkwitz–Riley — run on the clean leg's low half and the device's high half, so both carry the filters' own phase
    // and a device that is a wire sums to that pair's all-pass: flat magnitude, at every amount.
    //
    // THE CLEAN LEG IS HELD BACK BY WHAT THE DEVICE'S OUTPUT CARRIES: the rate-match (latencySamples(), as the blend
    // knob's dry), and per slot the capture's own lag — its `lag_samples` against the stage's first file, plus
    // setCrossoverLag() — and the slot's alignment delay, through a line that mirrors the slot's own (cleared where it is
    // cleared). The two slots' taps are then mixed by the law's own weight and gain, sample for sample as the models are
    // mixed, so the bands meet in time while two captures blend, through a one-model dip, across a landing or a retime. A
    // capture's lag that changes while its slot is heard — a table handed in, setCrossoverLag — crossfades the tap over
    // 10 ms rather than splice it.
    //
    // AMOUNT 0 IS THE PLAYER WITHOUT IT, bit for bit, and costs one atomic load a block. Leaving 0 fades the split in
    // with the pair at 1 Hz (an all-pass that is a wire across the audible band) and then sweeps it up to the frequency;
    // returning to 0 sweeps down, fades out and, once every glide has arrived, stops the filters (crossoverRunning()).
    // The amount, the frequency, the clean level and the polarity glide (10 ms); a lag crossfades its tap (10 ms). What the player cannot do is the
    // device's own phase near the seam — a coupling cap, a tone stack: that is in the capture, and only measured.
    //
    // Message thread. A non-finite value is refused (false) and changes nothing; the range is clamped. The frequency, the
    // amount, the clean level and the polarity are kept across load() and unload() — the bench's, like the host's
    // levels; the lag trim belongs to the table's reference (setCrossoverLag).
    static constexpr double kCrossoverMinHz = CrossoverBlend::kMinHz, kCrossoverMaxHz = CrossoverBlend::kMaxHz;
    static constexpr int    kMaxCrossoverLag = 2048;       // table samples: setCrossoverLag's outer bound (the reach is a time)
    bool setCrossoverHz(double hz) {
        if (! std::isfinite(hz)) return false;
        xoHzSet_ = std::clamp(hz, kCrossoverMinHz, kCrossoverMaxHz);
        xo_.setHz((float) xoHzSet_);
        return true;
    }
    bool setCrossoverAmount(double amount) {
        if (! std::isfinite(amount)) return false;
        xoAmountSet_ = std::clamp(amount, 0.0, 1.0);
        xo_.setAmount((float) xoAmountSet_);
        return true;
    }
    // POLARITY IS A CAPTURE'S, applied per slot. A device that hands its input back inverted puts its low band against
    // the clean one, and the sum then NOTCHES at the crossover (LP4 − HP4 is zero there) instead of meeting. A capture
    // whose table reading says it inverts (AlignmentTable::invertedByFile) gets an inverted clean tap in its slot; this
    // inverts every slot's on top of that — the host's word, for captures nothing has read. The pack's own dry part
    // (blend knob) is never inverted. Glides.
    void setCrossoverInvert(bool on) { xoInvertSet_ = on; xoInvert_.store(on, std::memory_order_release); }
    // TWO NUMBERS, KEPT APART. Every capture's lag is its absolute reading (AlignmentTable::absoluteLagByFile — how late
    // against its own DI) when it has one; otherwise its relative reading (`lag_samples`, counted from the table's
    // reference, crossoverLagReference()) plus the REFERENCE OFFSET — how late that reference trails its DI. The HOST
    // TRIM is then added to every capture, absolute or relative. An absolute reading never takes the offset, so a
    // calibration of the relative table cannot be counted twice once the pack carries its own readings.
    //
    // setCrossoverLag(trim): the bench's, kept across load(); 0 by default.
    // setCrossoverReferenceLag(offset): the PACK's — bound to the pack it was set on (its stamped rigId, else that very
    // load), the reference and the table's samples; a table counted from another file rebases it when it still reads the
    // old reference in the same samples, else drops it to 0; another pack drops it to 0. Set while nothing is loaded, it
    // is the next pack's.
    // Both in the table's samples. REFUSED (false, nothing changes) past ±kMaxCrossoverLag, or once prepared if it would
    // put a capture before its DI or past the clean leg's reach (CrossoverBlend::kMaxLagSeconds at the host rate) — and
    // when a later table or rate does that, crossoverLagFits() says so. A slot that is heard crossfades to it.
    bool setCrossoverLag(int samples) {
        if (samples < -kMaxCrossoverLag || samples > kMaxCrossoverLag) return false;
        const int was = xoTrim_;
        xoTrim_ = samples;
        if (prepared_ && loaded_ && ! crossoverLagsFit()) { xoTrim_ = was; return false; }
        publishCrossoverLags();
        return true;
    }
    bool setCrossoverReferenceLag(int samples) {
        if (samples < -kMaxCrossoverLag || samples > kMaxCrossoverLag) return false;
        const int was = xoRefOffset_;
        xoRefOffset_ = samples;
        if (prepared_ && loaded_ && ! crossoverLagsFit()) { xoRefOffset_ = was; return false; }
        xoRefPending_ = ! loaded_;
        if (loaded_) { xoRefPack_ = xoPack_; xoRefFile_ = align_.reference; xoRefRate_ = align_.sampleRate; xoRefTable_ = align_.lagByFile; }
        publishCrossoverLags();
        return true;
    }
    // THE CLEAN LEVEL against the device, in dB, 0 by default: the clean leg's gain, so the amount trades the low end
    // instead of also turning it up or down. measureLowBandGainDb (AlignmentTable.h) reads what a capture does to its low
    // end, offline; a host may propose that. Clamped to ±24 dB; non-finite refused. Glides with the amount.
    bool setCrossoverCleanDb(double db) {
        if (! std::isfinite(db)) return false;
        xoCleanDbSet_ = std::clamp(db, -24.0, 24.0);
        xo_.setCleanGain(linOf(xoCleanDbSet_));
        return true;
    }
    double crossoverCleanDb() const { return xoCleanDbSet_; }
    const std::string& crossoverLagReference() const { return align_.reference; }
    int    crossoverReferenceLag() const { return xoRefOffset_; }
    bool   crossoverLagFits() const { return xoFits_; }
    // Every capture's ALIGNMENT delay (the slots' lines, kMaxDelay host samples) within its reach at this rate; false =
    // a table or a rate asks more, and the line holds the capture back by kMaxDelay instead. Message thread.
    bool   alignmentFits() const { return alignFits_; }   // every capture's lag within [0, the reach] at this rate
    double crossoverHz()     const { return xoHzSet_; }
    double crossoverAmount() const { return xoAmountSet_; }
    bool   crossoverInvert() const { return xoInvertSet_; }
    int    crossoverLag()    const { return xoTrim_; }
    bool   crossoverRunning() const { return xo_.runningFlag(); }   // any thread

    // --------------------------------------------------------------------- the scope: OrbitAmp's ScopeTap ----
    // The newest samples of what went INTO the player and what came OUT of it, channel 0, for a picture (the app's
    // SHAPE) — at the app's own two points, around the whole player: CapturedBlock::process copies the block's input
    // before the drive and before player.process (CapturedBlock.h:543-544) and writes the scope after it (:554-556).
    // Written on the audio thread once per block the device runs (not while it stands by — the tap keeps the last it
    // heard, the fade-out included):
    //   dry  the input as the block was handed it, behind the feed (setFeedDb — the app's block IN,
    //        PluginProcessor.cpp:1497) and before everything of the player's own: the pack's input level, the pre
    //        tone. UNDELAYED, as the app's copy is.
    //   wet  the player's output: the pre tone, the models, the post tone, the blend knob, the pack's output level —
    //        before the stand-by fade, which the app blends after the block has tapped (PluginProcessor.cpp:1538).
    // So the two stand side by side as they do in the app, and no closer: the wet trails the dry by a capture's own
    // lag (the player never takes it out of the sound, AlignmentTable.h) and, at a host rate other than the pack's,
    // by latencySamples() — the app's picture is misaligned by the rate-match exactly so, and this follows it.
    // (v0.5.0 tapped around the models instead — the dry after the input level and held back by latencySamples(),
    // the wet before the post tone — the app's web spec and the site's tap around TONE3000's node, not its code.)
    //
    // scopeRead copies the newest min(n, scopeSize(), written) of both, oldest first, with the wet scaled to the
    // dry's RMS — the app's ScopeTap::read (ScopeTap.h:42-72), which matches on the way OUT, in the reader: "a boost
    // that is merely louder would drown" what the device DID. Answers how many it copied: 0 = never written since
    // prepare() (or no tap, or n < 1, or a null pointer) — or the writer overtook the read kScopeTries times in a row.
    // That last 0 does NOT leave the caller's arrays as they were: every try copies straight into them, so after it
    // they hold a copy the writer may have torn, and are not a frame. A caller that wants to keep its previous frame
    // reads into scratch of its own and copies out on a non-zero answer — as the worklet does (fcrig-worklet.js,
    // the module's own two halves). Under one thread (process() and the read never concurrent, as fc_rig is driven)
    // the writer cannot overtake and the 0 never comes. scopeFrames() is the count published at the moment it is
    // read, not tied to the snapshot a concurrent reader got: read it before scopeRead() and the frame is at least
    // that fresh.
    //
    // NO TORN FRAME, NO LOCK. The writer claims the samples it is about to write (a relaxed store, then a release
    // fence), writes them (relaxed atomic floats), and publishes how far it got (a release store). The reader takes
    // the published end (acquire), copies, fences (acquire) and reads the claim: if the writer may have reached any
    // slot of what was copied, the copy is thrown away. The rings carry two blocks of slack, so a writer one whole
    // block and a part ahead does not spoil a read. The audio side pays one fence and two stores per block, and
    // one copy of channel 0's block for the dry (times the feed's gain when one is set).
    // Any thread may read; prepare() must not run meanwhile (it never may beside process() either).
    int scopeSize() const { return scopeN_; }
    std::uint64_t scopeFrames() const { return scopeWritten_.load(std::memory_order_acquire); }   // samples written since prepare()
    int scopeRead(float* dry, float* wet, int n) const noexcept {
        if (dry == nullptr || wet == nullptr || n < 1 || scopeN_ == 0) return 0;
        const std::uint64_t cap = (std::uint64_t) scopeCap_;
        for (int t = 0; t < kScopeTries; ++t) {
            const std::uint64_t end = scopeWritten_.load(std::memory_order_acquire);
            if (end == 0) return 0;
            const int m = (int) std::min({ (std::uint64_t) n, (std::uint64_t) scopeN_, end });
            const std::uint64_t from = end - (std::uint64_t) m;
#ifdef FELITRONICS_RIGPLAYER_TEST_SCOPE_READING
            // A test's seam, never defined in a product (ScopeStandbyTests.cpp): the end is taken, nothing is copied
            // yet — a writer that moves HERE is a writer racing the whole copy, the worst a concurrent one can do.
            FELITRONICS_RIGPLAYER_TEST_SCOPE_READING(*this);
#endif
            std::size_t at = (std::size_t) (from % cap);
            for (int i = 0; i < m; ++i) {
                dry[i] = scopeDry_[at].load(std::memory_order_relaxed);
                wet[i] = scopeWet_[at].load(std::memory_order_relaxed);
                if (++at == scopeCap_) at = 0;
            }
            std::atomic_thread_fence(std::memory_order_acquire);
            if (scopeClaim_.load(std::memory_order_relaxed) > from + cap) continue;   // overtaken: a slot was rewritten
            // ScopeTap::read's level match, word for word: sums in double, the same floor, one float factor.
            double dr = 0.0, wr = 0.0;
            for (int i = 0; i < m; ++i) {
                dr += (double) dry[i] * dry[i];
                wr += (double) wet[i] * wet[i];
            }
            if (wr > 1.0e-12 && dr > 1.0e-12) {
                const float k = (float) std::sqrt(dr / wr);
                for (int i = 0; i < m; ++i) wet[i] *= k;
            }
            return m;
        }
        return 0;
    }

    // ---------------------------------------------------------------------- the audio thread ----

    // In place. `numChannels` up to what prepare() was given (fewer is fine: the missing planes are
    // silent). Any `numSamples`; longer than maxBlock is walked in pieces.
    //
    // THE MODELS RUN ON THE PLANES THEY ARE GIVEN, not on the width the player was prepared for.
    // A host prepared for a stereo bus that plays one plane — a mono chain — used to push the silent
    // second plane through both networks as well: four WaveNet passes a block for one channel of
    // sound, and a quarter of a core gone to nothing. The convolvers still take the prepared width
    // (the convolvers take the prepared width and REFUSE any other — law 11c), and the spare planes stay
    // zeroed for them; only the expensive part — the two models — shrinks to what is playing.
    [[nodiscard]] bool process(float* const* io, int numChannels, int numSamples) {
        // THE AUDIO CLOCK ticks first, before anything below reads a slot's stage (latencySamples() for the wire, the
        // stand-by path, the models): the preload frees a retired copy only once this has moved past the moment the
        // slots let go of it (retireStage). One atomic add a block.
        audioClock_.fetch_add(1, std::memory_order_seq_cst);
        if (numChannels < 0 || numSamples < 0) return false;         // malformed — law 11
        if (! prepared_ || io == nullptr) return false;
        if (numChannels > channels_) return false;                   // width is a LIMIT — law 11(b)
        if (numSamples == 0) return true;               // law 11(d): no samples, no time, no edge
        // `numChannels == 0` is NOT short-circuited here: it is a GAP, and the pipeline below is what
        // makes the gap real — the per-slot lagTail_ fill on the falling edge, and the three convolvers,
        // which run on the zeroed spare planes and go on decaying. Returning early left both slots
        // frozen: measured 0.2317 out of DIGITAL SILENCE (-12.7 dBFS) on the return, on both slots.
        const int nch = numChannels;
        bool ok = true;                                              // the stages' verdicts, ANDed

        // A PLANE THAT STOPS PLAYING AND PLAYS AGAIN. The models run on the planes they are given, and so
        // do the per-slot alignment delay lines beside them — `for (int c = 0; c < nch; …)` below. A plane
        // the host stops handing over therefore keeps its `lagTail_` frozen rather than draining it, and
        // hands it back when the host widens again. The tail is exactly the slot's delay in samples, so its
        // loudness is whatever the plane was carrying — a ceiling, not a sample: it sits after the slot's
        // gain and before the blend, so it cannot exceed amplitude x slot weight, and a sweep of all 218
        // leaving phases at sample resolution reaches 99.99% of that. Out of DIGITAL SILENCE: up to 0.25,
        // which is -12.0 dBFS, in the first three samples of the return, none of it on the plane that stayed.
        //
        // 🔴 THAT ARITHMETIC IS THIS LINE'S OWN AND IT DOES NOT COVER THE MODELS' HALF — a whole paragraph
        // here used to spend it on both, and it was wrong by a factor of 3.8. Both are stated now because
        // the two ceilings are DIFFERENT SHAPES, not one number applied twice:
        //
        //     the delay line   only ONE slot carries the delay (delayOf() is maxLag − lag), and the tail is
        //                      a literal replay, so the operator's gain is exactly 1: A · w = 0.5 · 0.5.
        //     the models       BOTH slots freeze at once, so the weights SUM rather than pick — and the
        //                      frozen rate-matcher is not a replay: a phase row of the polyphase table is
        //                      normalised by its SUM, not by its modulus, so its peak gain exceeds one.
        //
        // In one formula, with `g_s` the frozen return operator of slot s (the capture's impulse response,
        // convolved with the rate-matcher pair where one is installed):
        //
        //          ceiling  =  A · Σ_s w_s · ‖g_s‖₁
        //
        // and it is ATTAINABLE, because the whole path is linear in the pre-gap input for a Linear capture:
        // the return is `y[n] = Σ_k h_n[k]·x[−k]`, so `A·max_n ‖h_n‖₁` is reached exactly by the input
        // `x[−k] = A·sign(h_n[k])`. Measured that way, `A` = 0.5, both slots at 0.5, a unit capture:
        //
        //     host      44100     48000    88200    96000   176400   192000
        //     ‖h‖₁    1.898766  1.000000 1.685674 1.612676 1.505512 1.492565   (48 kHz: no rate-matcher)
        //     ceiling 0.949383  0.500000 0.842837 0.806338 0.752756 0.746283
        //     reached  100.00%   100.00%  100.00%  100.00%  100.00%  100.00%   by the sign pattern
        //     a sine     55.4%    99.91%    62.4%    65.0%    69.0%    70.0%   swept over EVERY leaving phase
        //
        // The last row is why the number above is not the ceiling of this half: the phase sweep that closed
        // the delay line reaches 55 % here, and would have published 0.5257. It agreed there because THAT
        // operator is a pure delay — a property of the operator, not of the method.
        //
        // 🟢 THE MODELS' HALF IS CLOSED, in nam::NamStage rather than here: a lane the host stops handing
        // over is fed the digital silence it is actually receiving, for exactly as long as its state can
        // still be heard (its receptive field, plus the rate-matcher's tap windows at each end). Out of
        // digital silence the return is now EXACTLY zero at 8 · 22.05 · 44.1 · 48 · 88.2 · 96 · 176.4 ·
        // 192 kHz, with a memoryless capture and with a real 6332-sample WaveNet, at gap widths 0 and 1
        // and on both slots. The SLEEPING slot — this file's other way of not clocking a stage — is closed
        // beside the models below. What is not: an LSTM's recurrent cell has no finite drain, so its
        // number is a bound on NAM's own heuristic (0.419 against 0.023 for a lane clocked throughout).
        // The comment beside those lines says the history is "advanced every block including at zero" —
        // true for the planes that are playing, which is exactly the gap. Dropping it here matches what
        // this file already does in three other places where a slot's delay line stops being valid: a
        // landing, a retime, and falling asleep all fill it. The convolvers and the tone are not touched:
        // they are handed the PREPARED width with the spare planes zeroed, so they never stop running.
        if (nch < ranNch_) {
            for (int i = 0; i < 2; ++i)
                for (int c = nch; c < ranNch_; ++c) line_[i].clearPlane(c);
            for (int c = nch; c < ranNch_; ++c) xo_.stopPlane(c);   // the crossover's lines, ring and filter memory too
        }
        ranNch_ = nch;
        const bool norm = normalize_.load(std::memory_order_acquire);
        const bool works = ! standby_.load(std::memory_order_acquire);   // read once a call, as the app reads `linkWorks` once a block
        float* a[kMaxChannels]; float* b[kMaxChannels]; float* d[kMaxChannels];
        for (int c = 0; c < kMaxChannels; ++c) { b[c] = slotB_[c].data(); d[c] = dryBuf_[c].data(); }

        int done = 0;
        while (done < numSamples) {
            const int count = std::min(maxBlock_, numSamples - done);
            for (int c = 0; c < channels_; ++c) {
                if (c < nch && io[c] != nullptr) a[c] = io[c] + done;
                else { a[c] = spare_[c].data(); std::fill(a[c], a[c] + count, 0.0f); }
            }

            // STAND-BY (setStandby, and the app's `captured` lambda it follows). The wire is FED every block, as
            // the app feeds its own (PluginProcessor.cpp:1440-1467): a window filled only once a fade starts is
            // cold and hands out its length in silence. It reads the input before anything here touches it.
            wire_.advance((const float* const*) a, channels_, count, latencySamples());
            const StandbySpan span = standbyAdvance(count, works);
            if (! works && ! span.moving) {
                // Stood by: the wire IS the output, and nothing else runs. On the first such block the stages
                // that hold audio are stopped (park()); every block the two stages get the width-zero call, which
                // drains what each still owes once and is free after that — counted like any other drain.
                if (! parkedRt_) park();
                for (int c = 0; c < nch; ++c) std::copy_n(wire_.delayed(c), count, a[c]);
                auto& s0 = *slotStage_[0].load(std::memory_order_seq_cst);
                auto& s1 = *slotStage_[1].load(std::memory_order_seq_cst);
                const long long drained[2] { s0.drainedSamples(), s1.drainedSamples() };
                ok = s0.process(a, 0, count, norm) && ok;
                ok = s1.process(b, 0, count, norm) && ok;
                const bool ran0 = s0.drainedSamples() != drained[0];
                const bool ran1 = s1.drainedSamples() != drained[1];
                if (ran0) runBlocks_[0].fetch_add(1, std::memory_order_relaxed);
                if (ran1) runBlocks_[1].fetch_add(1, std::memory_order_relaxed);
                if (ran0 && ran1) pairBlocks_.fetch_add(1, std::memory_order_relaxed);
                done += count;
                continue;
            }
            if (parkedRt_) {
                // Back: the host's level ARRIVES (the app's IN trim, `lastInGain = inTarget`), everything else
                // resumes from where it stood and takes what moved meanwhile — under the fade-in.
                parkedRt_ = false;
                xo_.setParked(false);
                curIn_ = inGain_.load(std::memory_order_acquire);
                curFeed_ = feedGain_.load(std::memory_order_acquire);
                standingBy_.store(false, std::memory_order_release);
            }
            for (int s = 0; s < 2; ++s) takeBands(s);

            // THE PACK'S INPUT LEVEL, and it goes first: before the dry block, before the pre-model
            // tone, before everything. It is the level of the GUITAR into this device, and a blend
            // knob mixes one guitar with itself — feed the models less and the dry side the same as
            // ever and the mix becomes two instruments at two volumes. `extendDb` is a different
            // animal and stays in chainGain_ below: a trick played inside the pack past the top
            // capture, which the dry path leaving at the input jack never saw.
            //
            // THE SCOPE'S DRY is taken first: the input as the block was handed it, behind the feed alone — the app's
            // CapturedBlock::process copies the block's input before the drive and before player.process
            // (CapturedBlock.h:543-544), behind its block IN (PluginProcessor.cpp:1497), which is the feed here
            // (setFeedDb). UNDELAYED, as the app's copy is. The feed's own ramp is advanced every block the device
            // runs, tapped or not, so a tap that resumes does not glide from a stale gain.
            const bool tap = nch > 0 && scopeN_ > 0;
            if (tap) std::copy_n(a[0], count, scopeIn_.data());
            {
                float* const s[1] { scopeIn_.data() };
                rampInto(s, tap ? 1 : 0, count, feedGain_.load(std::memory_order_acquire), curFeed_);
            }
            rampInto(a, nch, count, inGain_.load(std::memory_order_acquire), curIn_);

            // Keep the DRY block before anything touches it: the same DI the models are fed, which is
            // the whole economy of a blend. Taken ahead of the pre-model tone — the hardware's dry path
            // leaves at the input jack.
            const bool mixDry = dryActive_.load(std::memory_order_acquire);

            // 🔴 THE DRY PATH IS DELAYED BY WHAT THE WET PATH COSTS, and the delay is taken UNCONDITIONALLY.
            // The blend below sums `a` (through the models, hence through their rate-match) with `d`; those
            // two are misaligned by exactly latencySamples() unless something holds the dry back, and
            // summing them notches at fs/(2·D). See prepare() for the numbers and the history.
            // Advancing only while the blend is ON would be the classic cold-ring bug — DryAligner.h says
            // it in as many words: a ring fed only while a stage runs is COLD the moment it is first read
            // and emits its latency in zeros. Turning the dry knob up would then start with D samples of
            // silence in the dry leg. The copy costs one pass over the block when the blend is off, which
            // is nothing beside two neural models.
            for (int c = 0; c < channels_; ++c) std::copy(a[c], a[c] + count, d[c]);
            dryLatency_.advance((const float* const*) d, channels_, count, latencySamples());
            for (int c = 0; c < channels_; ++c) std::copy_n(dryLatency_.delayed(c), count, d[c]);
            // THE CROSSOVER'S CLEAN LEG is this same dry, rung so each slot can tap it at its own lag below. While the
            // crossover is off nothing here runs: one atomic load, and the block is the player without it.
            // A FORGET (unload, load) is taken here, before the clean leg is rung: the outgoing device's crossover audio
            // goes with it — its ring, lines and filters (its settings stay, they are the bench's). The law takes the
            // same forget below, as it always did.
            const bool forgetting = forget_.exchange(false, std::memory_order_acquire);
            if (forgetting && xo_.running()) xo_.clear();
            const bool xo = xo_.begin();
            if (xo) xo_.ring(d, count);

            // The knobs that sit BEFORE the distortion in the hardware, shaping what gets distorted.
            runBands(0, a, count);
            if (! firBypass_[0].load(std::memory_order_acquire)) ok = fir_[0].process(a, channels_, count) && ok;

            // The chain's trim: past the top capture it rises with the angle, and a fast hand moves
            // tens of degrees between two events — so it is smoothed like every other gain here.
            rampInto(a, nch, count, chainGain_.load(std::memory_order_acquire), curChain_);
            // THE QUIET RUN (warmQuiet): how long the models' input has been exactly zero, this block included.
            // "Not zero" is spelled with the orderings, as BlendLaw.h does, so that gcc's -Wfloat-equal has
            // nothing to say: ±0 is quiet, anything else — a NaN included — is not.
            {
                bool quiet = true;
                for (int c = 0; c < nch && quiet; ++c)
                    for (int k = 0; k < count; ++k)
                        if (! (a[c][k] <= 0.0f && a[c][k] >= 0.0f)) { quiet = false; break; }
                quietRun_ = quiet ? std::min(kQuietForever, quietRun_ + count) : 0;
            }

            // THE LAW, once per block, and the only writer of the weight. Everything it needs arrives
            // through atomics; everything it asks for leaves the same way.
            if (forgetting) { blend_ = {}; coldRt_[0] = coldRt_[1] = false; }
            if (const int f = landFail_.exchange(0, std::memory_order_acquire); f != 0)
                felitronics::nam::blendLoadFailed(blend_, f - 1);
            if (landFlag_.exchange(false, std::memory_order_acquire)) {
                const int ls = landSlot_.load(std::memory_order_relaxed);
                const int nd = landDelay_.load(std::memory_order_relaxed);
                slotDelay_[(std::size_t) (ls & 1)].store(nd, std::memory_order_relaxed);
                pendDelay_[(std::size_t) (ls & 1)].store(staged(landModel_.load(std::memory_order_relaxed), nd), std::memory_order_release);
                line_[(std::size_t) (ls & 1)].clear(); line_[(std::size_t) (ls & 1)].set(nd);
                xo_.clearSlotLine(ls);                 // the crossover's clean line, cleared with it
                xo_.setLine(ls, nd, 0);
                felitronics::nam::blendLanded(blend_, ls, landModel_.load(std::memory_order_relaxed),
                                              landWarm_.load(std::memory_order_relaxed));
            }
            // ACQUIRE FIRST: the writer publishes the two ids and then releases on the target.
            felitronics::nam::BlendRequest req;
            req.targetB = (double) reqTarget_.load(std::memory_order_acquire);
            req.want[0] = reqWant_[0].load(std::memory_order_relaxed);
            req.want[1] = reqWant_[1].load(std::memory_order_relaxed);
            felitronics::nam::BlendPolicy policy;
            policy.coldAfterSamples = coldAfter_.load(std::memory_order_relaxed);
            const bool single = single_.load(std::memory_order_acquire);
            if (single) {
                policy.single = true;
                policy.dipDownSamples = policy.dipUpSamples = dipSamples_;
            }
            const auto law = felitronics::nam::blendStep(blend_, req, count, policy);
            audible_.store(law.endGain > 0.0, std::memory_order_relaxed);
            // The law's ask is PUBLISHED only after both stages have run this block (below): the two-slot law asks
            // when a slot's weight ARRIVES at zero, at the block's end, and the block can begin with it audible.
            // Published here, a job thread that pre-empts this one could prepare and deliver the model before the
            // stage reads it — NeuralStage takes a newly installed model at the start of its next call — and the
            // new, unfed capture would be heard at that weight. (An AudioWorklet cannot; a native host can.)
#ifdef FELITRONICS_RIGPLAYER_TEST_AFTER_LAW
            FELITRONICS_RIGPLAYER_TEST_AFTER_LAW(*this);   // a test's seam; never defined in a product (RigPlayerTests.cpp)
#endif
            for (int i = 0; i < 2; ++i) {
                held_[(std::size_t) i].store(blend_.held[i], std::memory_order_relaxed);
                slotCold_[(std::size_t) i].store(blend_.cold[i], std::memory_order_relaxed);
                // FALLING ASLEEP CLEARS THE DELAY LINE, exactly as a landing does (above): the tail would
                // otherwise hold the slot's last samples from before the rest, and a model that declares
                // no field (need == 0) is heard on the very block it wakes in — with those samples first.
                if (blend_.cold[i] && ! coldRt_[i]) {
                    line_[(std::size_t) i].clear();
                    xo_.clearSlotLine(i);              // the crossover's clean line, cleared with it
                }
                coldRt_[i] = blend_.cold[i];
                if (blend_.cold[i]) coldBlocks_[(std::size_t) i].fetch_add(1, std::memory_order_relaxed);
            }
            // …and a staged retime. A slot silent at BOTH ends of the block takes it at once, its line cleared, as a model
            // lands. A slot that is HEARD takes it only when the delay belongs to the capture it is playing (a table read
            // again, a model rate learned): crossfaded over 10 ms, line and clean line alike. A capture on its way out keeps
            // its delay until it is silent — the staged one is the incoming capture's.
            for (int i = 0; i < 2; ++i) {
                const double w0 = i == 0 ? 1.0 - law.beginB : law.beginB, w1 = i == 0 ? 1.0 - law.endB : law.endB;
                // ONE publication: the staged delay WITH the capture it was computed for — the request is published
                // apart, so a dial edit between the two could otherwise lend the playing capture another's delay.
                const std::uint64_t st = pendDelay_[(std::size_t) i].load(std::memory_order_acquire);
                const int want = pendDelayOf(st);
                if (want == slotDelay_[(std::size_t) i].load(std::memory_order_relaxed)) continue;
                if (w0 <= 0.0 && w1 <= 0.0) {                  // exactly zero: the law clamps to [0, 1]
                    slotDelay_[(std::size_t) i].store(want, std::memory_order_relaxed);
                    line_[(std::size_t) i].clear(); line_[(std::size_t) i].set(want);
                    xo_.clearSlotLine(i);
                    xo_.setLine(i, want, 0);
                } else if (blend_.held[i] != 0 && blend_.held[i] == pendModelOf(st)) {
                    slotDelay_[(std::size_t) i].store(want, std::memory_order_relaxed);
                    line_[(std::size_t) i].set(want, retimeFade_);
                    xo_.setLine(i, want, retimeFade_);
                }
            }
            liveMix_.store((float) law.endB, std::memory_order_release);
            if (blend_.fed[0] < blend_.need[0] || blend_.fed[1] < blend_.need[1])
                warmBlocks_.fetch_add(1, std::memory_order_relaxed);
            if (const float jump = (float) std::abs(law.endB - law.beginB); jump > 0.02f) {
                mixJumps_.fetch_add(1, std::memory_order_relaxed);
                float prev = biggestJump_.load(std::memory_order_relaxed);
                while (jump > prev && ! biggestJump_.compare_exchange_weak(prev, jump, std::memory_order_relaxed)) {}
            }

            // THE SECOND CAPTURE'S COPY is taken here, after the pre-model tone and the chain trim, so
            // both models are fed the identical signal — and only now do the two part company, each
            // through its own trim: a linked setting plays its neighbour's model with less going in.
            // A COLD SLOT IS NOT RUN ON AUDIO — not copied into, not trimmed, not modelled, not delayed,
            // not even mixed: the law holds its weight at exactly zero for as long as it sleeps, so the
            // other slot IS the sound, and its buffer — whatever it holds, however old — is left out
            // rather than multiplied by zero (a NaN times zero is a NaN, for ever). What it IS handed is
            // a width-zero call (below), so the stage can drain the silence the slot is receiving; that
            // is law 11(d)'s clock-only call and it stops of its own accord. Its trim ramp resumes from
            // where it stopped and settles within its block, like any other gain change; its delay line
            // was cleared on the way to sleep. (The rail is checked as well as the flag: the flag says
            // what the law decided, the weights say what this block sounds like.)
            // ONE MODEL AT A TIME runs only what the law can hear or is warming: a slot with no model
            // (the two-slot player hands an empty stage the block, which passes it through) and a slot
            // whose replacement is in flight (the two-slot player runs its old model at weight zero)
            // are not run either — the law counts neither as fed, so neither has a field to keep.
            const bool run[2] { ! blend_.cold[0] && (! single || (blend_.held[0] != 0 && ! blend_.inFlight[0])),
                                ! blend_.cold[1] && (! single || (blend_.held[1] != 0 && ! blend_.inFlight[1])) };
            const bool aAlone = ! run[1] && law.beginB <= 0.0 && law.endB <= 0.0;
            const bool bAlone = ! run[0] && law.beginB >= 1.0 && law.endB >= 1.0;
            const bool hush   = single && law.beginGain <= 0.0 && law.endGain <= 0.0;
            const bool trims = inputTrims_.load(std::memory_order_acquire);
            if (run[1]) for (int c = 0; c < nch; ++c) std::copy(a[c], a[c] + count, b[c]);
            if (run[0]) rampInto(a, nch, count, trims ? slotGain_[0].load(std::memory_order_acquire) : 1.0f, curSlot_[0]);
            if (run[1]) rampInto(b, nch, count, trims ? slotGain_[1].load(std::memory_order_acquire) : 1.0f, curSlot_[1]);
            // 🔴 A SLEEPING SLOT IS STILL HANDED THE CALL, at width ZERO. Skipping it entirely is the
            // SECOND way this file stops clocking a NamStage — the first is a plane the host takes away
            // — and it has the same consequence: the slot's models and rate-matchers freeze holding
            // whatever was playing when the law put it to sleep, and a wake hands it back. Measured on a
            // three-knot device whose 240 capture has a 2001-sample memory: the dial parked at 150 until
            // slot 0 slept, eight blocks of DIGITAL SILENCE, then a turn to 240 — per-block peaks
            // 0.114 · 0.22 · 0.366 · 0.486 · 0.5 · 0.5 · 0.5 · 0.5, i.e. **0.500000 out of digital
            // silence** for exactly one receptive field, under the law's own 0.25-per-call ramp. A
            // TWO-knot device cannot show it: both slots end up holding the same capture, so the turn
            // SWAPS the backend rather than waking it, and a swap has nothing to leak. That is why the
            // first fixture read a clean zero, and it is a fixture fault, not a property of the code.
            // Width zero is law 11(d)'s clock-only call: the stage drains the lane and stops, so this
            // costs one bounded drain per sleep and nothing thereafter — a sleeping slot is still free.
            // Measured on a real 6332-sample capture: 12.9 ms of CPU at 48 kHz and 9.3 at 44.1 for the
            // whole sleep, and 0.0000 ms per block once the debt is spent.
            // ⚠️ ONE CONTRACT CONSEQUENCE, stated because nobody would look for it: a cold slot's verdict
            // is now ANDed too, and `NamStage::process` refuses for an UNPREPARED backend. A slot whose
            // live re-prepare was refused (a low-memory `configureRates`) used to be silent-and-accepted
            // while it slept and now fails every block instead. That is law 11's answer — a call that
            // cannot be honoured says so — and it is not constructible in a test without exhausting
            // memory, so it is written here rather than gated.
            // The stage each slot runs is read HERE, after the law: a landing's stage is published before its flag, and an
            // unload() resets these before its forget — so a block that took the landing or the forget runs its stage.
            auto& s0 = *slotStage_[0].load(std::memory_order_seq_cst);
            auto& s1 = *slotStage_[1].load(std::memory_order_seq_cst);
            const long long drained[2] { s0.drainedSamples(), s1.drainedSamples() };
            ok = s0.process(a, run[0] ? nch : 0, count, norm) && ok;
            ok = s1.process(b, run[1] ? nch : 0, count, norm) && ok;
            // WHAT THE CPU PAID — a slot's network ran if it was handed the audio holding a model, OR if its stage
            // spent part of a drain on it (a slot put to rest is fed its field of silence once, width-zero call
            // above): one network on audio in one-model mode, plus the outgoing capture's bounded drain. Two relaxed
            // loads of the stage's own odometer, which it keeps on this thread.
            {
                const bool ran0 = (run[0] && blend_.held[0] != 0) || s0.drainedSamples() != drained[0];
                const bool ran1 = (run[1] && blend_.held[1] != 0) || s1.drainedSamples() != drained[1];
                if (ran0) runBlocks_[0].fetch_add(1, std::memory_order_relaxed);
                if (ran1) runBlocks_[1].fetch_add(1, std::memory_order_relaxed);
                if (ran0 && ran1) pairBlocks_.fetch_add(1, std::memory_order_relaxed);
            }
            // …and only now may a job thread see the law's ask (see above, at the law).
            if (law.load.wanted && loadAsk_.load(std::memory_order_relaxed) == 0)
                loadAsk_.store((law.load.model << 1) | (std::uint64_t) (law.load.slot & 1), std::memory_order_release);
            const MixRecipe recipe { &law, { run[0], run[1] }, hush, aAlone, bAlone };
            // Align BEFORE the weights: during a ramp the two gains must sum to one at the SAME instant.
            // Each slot carries its own history per channel, advanced every block including at zero.
            for (int c = 0; c < nch; ++c) {
                if (run[0]) line_[0].process(c, a[c], count, lineTmp_.data());
                if (run[1]) line_[1].process(c, b[c], count, lineTmp_.data());
                // …then the two slots become one plane, as the law says: mixSlots (CrossoverBlend.h), the one
                // spelling of it — the crossover's clean leg goes through the same lines.
                mixSlots(a[c], b[c], count, recipe);
            }
            for (auto& l : line_) l.advance(count);       // the lines' clocks run on audio time, planes handed over or not

            // THE CROSSOVER'S CLEAN LEG for this block, as the models' part was just mixed: each slot's tap through its
            // mirrored line, the same recipe. The pack's dry part joins it at the blend knob below.
            if (xo) {
                // The per-model table is read SEQ_CST, once, as the slots' stages are read: the same proof as the preload's
                // retired copies (retireStage) — the clock ticked seq_cst at the top of this call, the publication and the
                // retirement stamp are seq_cst on the message thread, so a block whose tick is past the stamp reads the new
                // pointer, and service() frees an old table only once such a block has begun.
                const XoModels* xt = xoModelsRt_.load(std::memory_order_seq_cst);
                const std::uint64_t held[2] { blend_.held[0], blend_.held[1] };
                const int own[2] { ownLagRt(xt, held[0]), ownLagRt(xt, held[1]) };
                xo_.taps(held, own, law);
                const bool inv[2] { invertRt(xt, held[0]), invertRt(xt, held[1]) };
                xo_.clean(nch, count, recipe, inv);
            }

            // The knobs AFTER the distortion, shaping what came out.
            runBands(1, a, count);
            if (! firBypass_[1].load(std::memory_order_acquire)) ok = fir_[1].process(a, channels_, count) && ok;

            // The blend, as the hardware sums it: the dry path through its own response, then the two
            // gains the pack states for this position.
            if (mixDry) {
                if (! dryFirBypass_.load(std::memory_order_acquire)) ok = dry_.process(d, channels_, count) && ok;
                const float wantDry = dryGain_.load(std::memory_order_acquire);
                const float wantWet = wetGain_.load(std::memory_order_acquire);
                const float decay   = std::exp(-(float) count / (float) (0.010 * fs_));
                const float endDry  = rampEnd(wantDry, curDry_, decay);   // law 8 — see rampEnd
                const float endWet  = rampEnd(wantWet, curWet_, decay);
                const float stepDry = (endDry - curDry_) / (float) count;
                const float stepWet = (endWet - curWet_) / (float) count;
                for (int c = 0; c < channels_; ++c) {
                    float gd = curDry_, gw = curWet_;
                    for (int i = 0; i < count; ++i) {
                        gd += stepDry; gw += stepWet;
                        a[c][i] = a[c][i] * gw + d[c][i] * gd;
                    }
                }
                // …and the same two ramps into the crossover's clean leg: the pack's dry part is clean already, so the
                // clean leg carries it with the timing, the level and the polarity it has in the device.
                if (xo)
                    for (int c = 0; c < channels_; ++c) {
                        float gd = curDry_, gw = curWet_;
                        float* cl = xo_.cleanPlane(c);
                        for (int i = 0; i < count; ++i) {
                            gd += stepDry; gw += stepWet;
                            cl[i] = cl[i] * gw + d[c][i] * gd;
                        }
                    }
                curDry_ = endDry; curWet_ = endWet;
                liveDry_.store(endDry, std::memory_order_release);
                liveWet_.store(endWet, std::memory_order_release);
            }

            // THE CROSSOVER BLEND (setCrossoverAmount): the clean leg tapped at each slot's lag and mixed by this block's
            // law exactly as the models were, then split with the device by one Linkwitz–Riley pair.
            if (xo) xo_.run(a, count);

            // THE PACK'S OUTPUT LEVEL, and it goes last: after the mix. One number for the whole
            // stage, and applied any earlier it would ride the wet side alone and move a blend the
            // pack states for this position.
            rampInto(a, nch, count, outGain_.load(std::memory_order_acquire), curOut_);

            // THE SCOPE'S WET: the player's output — everything above, the pre tone, the models, the post tone, the
            // blend knob, the output level — as the app's CapturedBlock::process writes it after player.process
            // (CapturedBlock.h:554-556), beside the dry taken at the top of the block. The stand-by fade is not in it:
            // the app's BypassFade blends after the block has tapped (PluginProcessor.cpp:1516, :1538). At a host rate
            // other than the pack's the wet trails the dry by latencySamples(), in the app's picture as in this one.
            if (tap) scopeWrite(scopeIn_.data(), a[0], count);

            // …and a stand-by fade under way: the device against its wire, BypassFade::blend's own arithmetic
            // (BypassFade.h:87-108) — `dry + (wet - dry) · g`, g walking for the fade's own samples and then held.
            if (span.moving) {
                const int ramp = std::clamp(span.ramp, 1, count);
                const float step = (span.to - span.from) / (float) ramp;
                for (int c = 0; c < nch; ++c) {
                    const float* w = wire_.delayed(c);
                    for (int i = 0; i < count; ++i) {
                        const float g = i < ramp ? span.from + step * (float) i : span.to;
                        a[c][i] = w[i] + (a[c][i] - w[i]) * g;
                    }
                }
            }
            done += count;
        }
        return ok;
    }

private:
    // ------------------------------------------------------------------------- the crossover blend ----
    // Message thread. Every capture's own lag in host samples — its reading in the table plus setCrossoverLag, at the
    // rate it runs at (learned at its landing; before that the host's rate is assumed, and the landing corrects it).
    // Published per model, so the audio thread reads the lag of whatever a slot HOLDS, whichever thread moved it last.
    int ownLagOf(std::size_t k) const {
        if (k >= models_.size()) return 0;
        const double rate = k < modelRate_.size() ? modelRate_[k] : std::numeric_limits<double>::quiet_NaN();
        // Not landed yet: the rate NAM assumes for a capture that names none, as an untagged one runs (the landing corrects it).
        const double runSR = felitronics::nam::NamStage::rateMatch(fs_, std::isnan(rate) ? -1.0 : rate).modelRunSR;
        return align_.lagOf(models_[k].id, fs_, runSR, xoRefOffset_, xoTrim_);
    }
    // Per model, for the audio thread: its lag in host samples (clamped to the reach) and whether it inverts.
    struct XoModels {
        explicit XoModels(std::size_t count)
            : n(count), lag(std::make_unique<std::atomic<int>[]>(count)), inv(std::make_unique<std::atomic<bool>[]>(count)) {}
        std::size_t n;
        std::unique_ptr<std::atomic<int>[]>  lag;
        std::unique_ptr<std::atomic<bool>[]> inv;
    };
    // A staged delay and the capture it belongs to, in one word: the model id above, the delay (0 … kMaxDelay) below.
    static std::uint64_t staged(std::uint64_t model, int delay) noexcept {
        return (model << 32) | (std::uint64_t) (std::uint32_t) std::clamp(delay, 0, kMaxDelay);
    }
    static int           pendDelayOf(std::uint64_t s) noexcept { return (int) (std::uint32_t) (s & 0xffffffffu); }
    static std::uint64_t pendModelOf(std::uint64_t s) noexcept { return s >> 32; }

    // Audio thread: the lag of the capture a slot holds, as published.
    static int ownLagRt(const XoModels* t, std::uint64_t held) noexcept {
        return t != nullptr && held >= 1 && held <= t->n ? t->lag[(std::size_t) held - 1].load(std::memory_order_relaxed) : 0;
    }
    bool invertRt(const XoModels* t, std::uint64_t held) const noexcept {
        const bool own = t != nullptr && held >= 1 && held <= t->n && t->inv[(std::size_t) held - 1].load(std::memory_order_relaxed);
        return own != xoInvert_.load(std::memory_order_acquire);
    }
    void publishCrossoverLags() {
        // THE TABLE IS SIZED FOR THE PACK (grow only): one a pack outgrows is retired and freed by service() once the
        // audio clock has passed — process() ticks the clock before it reads the pointer, as it does for a slot's stage.
        // A grown table is FILLED before it is published, so the audio thread never reads an entry not yet written.
        std::unique_ptr<XoModels> grown;
        if (! xoModels_ || xoModels_->n < models_.size())
            grown = std::make_unique<XoModels>(std::max<std::size_t>(models_.size(), 16));
        XoModels& into = grown ? *grown : *xoModels_;
        bool fits = true;
        for (std::size_t k = 0; k < models_.size(); ++k) {
            const int own = ownLagOf(k);
            if (prepared_ && (own < 0 || own > xo_.maxLag())) fits = false;
            const auto inv = align_.invertedByFile.find(models_[k].id);
            into.lag[k].store(std::clamp(own, 0, xo_.maxLag()), std::memory_order_relaxed);
            into.inv[k].store(inv != align_.invertedByFile.end() && inv->second, std::memory_order_relaxed);
        }
        xoFits_ = fits;
        // THE SLOTS' ALIGNMENT DELAYS have a reach too (kMaxDelay host samples): a table or a rate that asks more is
        // clamped in the line — said here, not silently.
        bool lines = true;
        for (std::size_t k = 0; k < models_.size() && prepared_; ++k) if (rawDelayOf(k) >= (double) kMaxDelay + 0.5) lines = false;   // as lround rounds
        alignFits_ = lines;
        if (grown) {
            xoModelsRt_.store(grown.get(), std::memory_order_seq_cst);
            if (xoModels_) xoRetired_.push_back({ std::move(xoModels_), audioClock_.load(std::memory_order_seq_cst) });
            xoModels_ = std::move(grown);
        }
    }
    // THE REFERENCE OFFSET BELONGS TO A PACK, a reference and a table's samples. load(): another pack drops it (a pending
    // one is adopted); setAlignment(): another reference in the same samples rebases it when the new table still reads the
    // old reference — the old one is `rel` later than the new, so the new trails its DI by offset − rel — else drops it.
    //
    // A PENDING offset (set with nothing loaded) has no coordinates yet: no table rebases it, and the next load binds it
    // as it is. A load of the SAME pack (its rigId) is a table like any other: unchanged when it counts from the same
    // reference in the same samples, rebased or dropped otherwise — never kept in the coordinates of the last table.
    //
    // THE SAME RIG LOADED AGAIN brings its table back: the offset is KEPT only when that table is the one it was bound
    // to, word for word; REBASED when the old reference is still read in the same samples and every other file stands
    // where it stood against it (the anchor moved, nothing was recaptured); DROPPED otherwise — a recapture moves what
    // the offset measured. (A reference file retrained under the same numbers cannot be told without its bytes.) A
    // rebase that leaves ±kMaxCrossoverLag drops it too: the arithmetic is wide, the stored value representable.
    void bindReferenceLag(const AlignmentTable& t, bool newPack) {
        if (xoRefPending_) {
            if (! newPack) return;
            xoRefPending_ = false;
            bindTo(t);
            return;
        }
        const bool otherPack = newPack && xoRefPack_ != xoPack_;
        const bool sameUnits = felitronics::core::exactlyEqual(t.sampleRate, xoRefRate_);
        const auto old = t.lagByFile.find(xoRefFile_);
        const bool readable = old != t.lagByFile.end() && sameUnits;
        if (otherPack) xoRefOffset_ = 0;
        else if (newPack) {
            const bool identical = t.reference == xoRefFile_ && sameUnits && t.lagByFile == xoRefTable_;
            if (! identical) xoRefOffset_ = readable && sameShape(t) ? rebased(old->second) : 0;
        }
        else if (t.reference != xoRefFile_ || ! sameUnits) xoRefOffset_ = readable ? rebased(old->second) : 0;
        bindTo(t);
    }
    void bindTo(const AlignmentTable& t) {
        xoRefPack_ = xoPack_; xoRefFile_ = t.reference; xoRefRate_ = t.sampleRate; xoRefTable_ = t.lagByFile;
    }
    int rebased(int oldReferenceLag) const {
        const long long r = (long long) xoRefOffset_ - (long long) oldReferenceLag;
        return r < -kMaxCrossoverLag || r > kMaxCrossoverLag ? 0 : (int) r;
    }
    // Every file of the bound table stands where it stood against the old reference, in `t` as well (and no file came or went).
    bool sameShape(const AlignmentTable& t) const {
        if (t.lagByFile.size() != xoRefTable_.size()) return false;
        const auto oldNew = t.lagByFile.find(xoRefFile_);
        const auto oldOld = xoRefTable_.find(xoRefFile_);
        if (oldNew == t.lagByFile.end() || oldOld == xoRefTable_.end()) return false;
        for (const auto& [id, lag] : xoRefTable_) {
            const auto it = t.lagByFile.find(id);
            if (it == t.lagByFile.end()) return false;
            if ((long long) it->second - oldNew->second != (long long) lag - oldOld->second) return false;
        }
        return true;
    }
    // A model's alignment delay in host samples, before the line clamps it.
    double rawDelayOf(std::size_t k) const {
        const double rate = k < modelRate_.size() ? modelRate_[k] : std::numeric_limits<double>::quiet_NaN();
        const double runSR = felitronics::nam::NamStage::rateMatch(fs_, std::isnan(rate) ? -1.0 : rate).modelRunSR;
        if (align_.derivedFromAbsolute) {
            const double unknown = felitronics::nam::NamStage::rateMatch(fs_, -1.0).modelRunSR;
            return align_.delayOfAbsoluteRaw(models_[k].id, fs_, [&] (const std::string& file) {
                for (std::size_t j = 0; j < models_.size() && j < modelRate_.size(); ++j)
                    if (models_[j].id == file)
                        return std::isnan(modelRate_[j]) ? unknown : felitronics::nam::NamStage::rateMatch(fs_, modelRate_[j]).modelRunSR;
                return unknown;
            });
        }
        const double at = align_.sampleRate > 0.0 ? align_.sampleRate : runSR;
        return (double) align_.delayOf(models_[k].id) * (at > 0.0 && fs_ > 0.0 ? fs_ / at : 1.0);
    }
    bool crossoverLagsFit() const {
        for (std::size_t k = 0; k < models_.size(); ++k)
            if (const int own = ownLagOf(k); own < 0 || own > xo_.maxLag()) return false;
        return true;
    }

    // ------------------------------------------------------- the restart, where both verbs share ----

    // What a restart clears that does NOT depend on the rate: the per-slot alignment tails, the band
    // filters' memory, the audio-time grid the band ramps are maintained on, any ramp in flight, and
    // the record of how wide the previous call was. prepare() and reset() both call it, which is the
    // point — the two used to be able to disagree about what a restart means, and a shared body is a
    // cheaper guarantee than a review.
    //
    // `ranNch_ = 0` is the one line prepare() did not have. Nothing has run since a restart, so nothing
    // can be STOPPING — the same sentence `eq::EqBand::clearAudioState()` spells for its own `ran*`
    // ledgers. It is inert in prepare() (the tails it guards have just been zeroed, so the fill it
    // would trigger writes zeros over zeros) and it is honest, which is why it is here and not only in
    // reset().
    void clearAudioState() noexcept {
        for (auto& l : line_) l.clear();
        for (auto& side : bq_) for (auto& band : side) for (auto& b : band) b.reset();
        for (auto& g : bandGrid_) g.reset();             // a stream restart re-anchors the audio-time grid
        for (int s = 0; s < 2; ++s)
            for (int k = 0; k < kMaxBands; ++k) bandPos_[s][k] = bandLen_[s][k] = 0;
        ranNch_ = 0;
        xo_.clear();
        for (int c = 0; c < kMaxChannels; ++c) {
            std::fill(slotB_[c].begin(),  slotB_[c].end(),  0.0f);
            std::fill(dryBuf_[c].begin(), dryBuf_[c].end(), 0.0f);
            std::fill(spare_[c].begin(),  spare_[c].end(),  0.0f);
        }
    }

    // Every smoothed gain lands ON its target. A restart restarts the parameter epoch as well as the
    // audio — see reset() for the house precedent and the 0.51 full scale that bought it. The targets
    // read here are the ones process() reads, spelling for spelling, so that "a restart leaves the
    // player where prepare() leaves it" is true by construction.
    //
    // 🔴 AND THE SLOT TRIM IS SNAPPED THROUGH THE SWITCH THAT TURNS IT OFF, which it was not until P89.
    // `curSlot_[i]` used to be snapped to the pack's per-file trim whatever `inputTrims_` said, and
    // process() reads that same switch every block (`trims ? slotGain_[i] : 1.0f`), so with trims OFF
    // both verbs landed the ramp on a value the audio path was never going to travel to and then ramped
    // AWAY from it to unity. A freshly CONSTRUCTED player starts at unity and does not. Measured by an
    // adversarial round on a −6 dB trim with trims off: the first sample after a restart is −5.99 dB and
    // it takes about 43 ms to come within 0.3 dB of unity, identically for both verbs — a restart that
    // audibly ducked the slot it was restarting. P86 made it reachable at every transport start.
    //
    // The earlier note here registered this rather than fixing it, on the ground that a fix would put
    // prepare() and reset() back in disagreement. That was FALSE, and this shared body is exactly why:
    // both verbs snap through these lines, so spelling the switch once corrects both at once and keeps
    // "a restart leaves the player where prepare() leaves it" true by construction. The switch is read
    // the way process() reads it (`inputTrims_`, acquire) and chooses between the same two values
    // (`slotGain_[i]` or unity); only the load order of the gain itself differs, `relaxed` here against
    // `acquire` there, which is harmless for a lone float read under the stopped-audio contract.
    void snapGains() noexcept {
        const bool trims = inputTrims_.load(std::memory_order_acquire);
        curIn_    = inGain_.load(std::memory_order_relaxed);
        curFeed_  = feedGain_.load(std::memory_order_relaxed);
        curOut_   = outGain_.load(std::memory_order_relaxed);
        curChain_ = chainGain_.load(std::memory_order_relaxed);
        for (int i = 0; i < 2; ++i) curSlot_[i] = trims ? slotGain_[i].load(std::memory_order_relaxed) : 1.0f;
        curDry_   = dryGain_.load(std::memory_order_relaxed);
        curWet_   = wetGain_.load(std::memory_order_relaxed);
    }

    // ------------------------------------------------------------- stand-by and the scope, audio side ----

    // Where the stand-by fade stands at the start of a block and at its end, and for how many of its samples it
    // moves: BypassFade::Span and BypassFade::advance (BypassFade.h:47-81), the same floats in the same order.
    struct StandbySpan { float from = 1.0f, to = 1.0f; bool moving = false; int ramp = 0; };
    StandbySpan standbyAdvance(int numSamples, bool works) noexcept {
        const float want = works ? 1.0f : 0.0f;
        if (atFadeEnd(fadeG_, want)) return { fadeG_, fadeG_, false, 0 };
        const float from   = fadeG_;
        const float needed = std::abs(want - fadeG_) / std::max(1.0e-9f, fadeStep_);
        const int   ramp   = std::clamp((int) std::ceil(needed), 1, numSamples);
        const float step   = fadeStep_ * (float) ramp;
        fadeG_ = works ? std::min(want, fadeG_ + step) : std::max(want, fadeG_ - step);
        return { from, fadeG_, true, ramp };
    }

    // The fade's end, as BypassFade::advance tests it (BypassFade.h:62): juce::approximatelyEqual at its defaults —
    // an absolute FLT_MIN, a relative FLT_EPSILON. Not `>= 1`: the walk up adds perSample·ramp in float and can stop
    // one ulp short of 1 (0.99999988 at 48 kHz in 60-sample blocks); the app calls that the end and stops blending,
    // and so must this, or the device is heard one block longer through a gain one ulp off unity.
    // (JUCE's non-finite branch is left out: `want` is 0 or 1, and g only ever walks between them, clamped.)
    static bool atFadeEnd(float g, float want) noexcept {
        const float diff = std::abs(g - want);
        return diff <= std::numeric_limits<float>::min()
            || diff <= std::numeric_limits<float>::epsilon() * std::max(std::abs(g), std::abs(want));
    }

    // BypassFade::snapTo: the fade lands on the request, and a device that starts stood by is stood by from its first
    // sample. Both restarts call it; neither leaves anything to stop (they clear it all themselves).
    void snapStandby() noexcept {
        const bool by = standby_.load(std::memory_order_acquire);
        fadeG_ = by ? 0.0f : 1.0f;
        parkedRt_ = by;
        xo_.setParked(by);
        standingBy_.store(by, std::memory_order_release);
    }

    // The fade-out is over: everything that holds audio, other than the two stages (which drain), is STOPPED — the
    // filters' memory, the convolvers' history (clearAudioState: a stop, P19's verb, not a restart: an IR fading
    // in keeps fading), the dry ring and the per-slot delay lines. Ramps, targets, the law: untouched.
    void park() noexcept {
        parkedRt_ = true;
        quietRun_ = kQuietForever;       // the device resumes from silence, as everything it stops here does
        for (auto& f : fir_) f.clearAudioState();
        dry_.clearAudioState();
        dryLatency_.reset();
        for (auto& side : bq_) for (auto& band : side) for (auto& q : band) q.reset();
        for (auto& l : line_) l.clear();
        xo_.clear();                     // the crossover's filters, ring and lines stop as the others do; its glides do not snap
        xo_.setParked(true);
        ranNch_ = 0;
        standingBy_.store(true, std::memory_order_release);
    }

    // One block into the tap (see scopeRead for the protocol): claim, fence, write, publish.
    void scopeWrite(const float* dry, const float* wet, int count) noexcept {
        if (scopeN_ == 0) return;
        const std::uint64_t w = scopeW_;
        scopeClaim_.store(w + (std::uint64_t) count, std::memory_order_relaxed);
        std::atomic_thread_fence(std::memory_order_release);
        std::size_t at = (std::size_t) (w % (std::uint64_t) scopeCap_);
        for (int i = 0; i < count; ++i) {
            scopeDry_[at].store(dry[i], std::memory_order_relaxed);
            scopeWet_[at].store(wet[i], std::memory_order_relaxed);
            if (++at == scopeCap_) at = 0;
        }
        scopeW_ = w + (std::uint64_t) count;
        scopeWritten_.store(scopeW_, std::memory_order_release);
    }

    // ------------------------------------------------------------------ the decision, applied ----

    static std::string degreeValue(double degrees, int sweep) {
        return std::to_string((int) std::lround(std::clamp(degrees, 0.0, (double) sweep)));
    }

    static float linOf(double db) { return std::abs(db) < 0.0005 ? 1.0f : (float) std::pow(10.0, db / 20.0); }

    /// WHAT THE PLAYER IS APPLYING, decided in ONE place: the host's hand if it has one, else the
    /// pack's own number. Called from apply(), from the host setters, and from load() before anything
    /// slow — a pack swap used to publish unity here (unload's reset) and the real gains only at the
    /// end of load(), so a callback landing in between heard neither pack's level.
    ///
    /// An EMPTY player (no stage: unload(), or a load() that found nothing to play) is a wire behind the feed: the
    /// feed alone in, unity out, whatever hand the host holds — the hand is kept and lands on the next load(). Said
    /// here and not only in unload(), so a setter called while nothing is loaded cannot add the hand back in.
    void publishLevels() {
        if (stage_.kind != namz::rig::StageKind::Nam) {
            inGain_ .store(linOf(feedDb_), std::memory_order_release);
            outGain_.store(1.0f, std::memory_order_release);
            return;
        }
        inGain_ .store(linOf((hostIn_  ? *hostIn_  : stage_.inputDb) + feedDb_), std::memory_order_release);
        outGain_.store(linOf(hostOut_ ? *hostOut_ : stage_.outputDb), std::memory_order_release);
    }

    std::uint64_t modelIdOf(int file) const {
        return file < 0 || (std::size_t) file >= fileModel_.size() ? 0 : (std::uint64_t) fileModel_[(std::size_t) file] + 1;
    }

    const std::string& fileIdOfModel(std::uint64_t id) const {
        static const std::string none;
        return id == 0 || id > models_.size() ? none : models_[(std::size_t) id - 1].id;
    }

    // In HOST samples. A pack's numbers are in the model's own rate, which the stage knows once the
    // model is loaded; a measured table carries the rate it was measured at.
    int delayOfModel(std::uint64_t id, const felitronics::nam::NamStage& st) const {
        // Same reason as warmFor(): a pack's lag is written in the model's OWN rate, and for an
        // untagged capture that rate is not the -1 the stage reports — it is the rate the stage will
        // actually run it at. AlignmentTable falls back to scale 1.0 when handed a non-positive rate,
        // which for an untagged model at 96 kHz would apply a 48 kHz lag unscaled.
        const double runSR = felitronics::nam::NamStage::rateMatch(fs_, st.modelSampleRate()).modelRunSR;
        if (! align_.derivedFromAbsolute) return align_.delayOf(fileIdOfModel(id), fs_, runSR);
        // A table derived from ABSOLUTE readings (namz 5) compares them in time, each in its own model's rate: this one's
        // from its stage, the others' as learned at their landing, NAM's default for one not landed yet.
        const std::string& me = fileIdOfModel(id);
        const double unknown = felitronics::nam::NamStage::rateMatch(fs_, -1.0).modelRunSR;
        return align_.delayOfAbsolute(me, fs_, [&] (const std::string& file) {
            if (file == me) return runSR;
            for (std::size_t k = 0; k < models_.size() && k < modelRate_.size(); ++k)
                if (models_[k].id == file)
                    return std::isnan(modelRate_[k]) ? unknown
                                                     : felitronics::nam::NamStage::rateMatch(fs_, modelRate_[k]).modelRunSR;
            return unknown;
        });
    }

    // The whole decision for the panel as it stands, handed to the audio thread as a request. What the
    // law does with it — in what order, and whether a model may be replaced yet — is its business.
    void apply() {
        const auto& d = stage_.device;
        publishLevels();   // ahead of the early return: they are the stage's, not the selection's
        sel_  = select(d, axes_, dial_, dialDeg_, shape_, topExtend_);
        // ONE MODEL: the nearer capture alone, in the slot its parity names (targetB is then a rail),
        // and the other slot asked for NOTHING — the law never loads a slot that wants nothing.
        // Stepped with a deadband around the capture sounding now, which is remembered by its FILE ENTRY: an entry
        // has one setting per control, so a switch to another panel cannot find it among the new knots and the step
        // starts afresh there; unload() and setMaxModels() forget it.
        if (maxModels_ == 1) {
            int stay = -1;
            for (std::size_t i = 0; i < sel_.knots.size(); ++i)
                if (sel_.knots[i].file == stayFile_) { stay = (int) i; break; }
            sel_ = steppedSelection(sel_, stay, kStepDeadband);
            stayFile_ = sel_.pick.lo >= 0 ? sel_.knots[(std::size_t) sel_.pick.lo].file : -1;
        }
        // THE PRELOAD'S SET follows the PANEL, never the dial: the knots' files are compared in place (no allocation, a
        // dozen ints), and only another panel — a switch, a pack — makes the set again.
        if (preloadCap_ > 0 && (preloadStale_ || ! samePanel())) rebuildPreload();
        plan_ = slotPlan(sel_, d);
        if (plan_.file[0] < 0) { setRequest(0, 0, 0.0f); return; }
        std::uint64_t want[2] { modelIdOf(plan_.file[0]), modelIdOf(plan_.file[1]) };
        if (maxModels_ == 1) want[plan_.targetB >= 0.5 ? 0 : 1] = 0;
        setRequest(want[0], want[1], (float) plan_.targetB);
        for (int i = 0; i < 2; ++i) slotGain_[i].store(linOf(plan_.inputDb[i]), std::memory_order_release);
        chainGain_.store(linOf(sel_.extendDb), std::memory_order_release);
        stageDelays();
        // The dial's own entry names the knot at (or below) the hand, so a later resolve() on another
        // control scores "keep what the user had" against the capture actually sounding.
        if (! dial_.empty() && sel_.fileA >= 0)
            if (const auto v = d.files[(std::size_t) sel_.fileA].settings.find(dial_);
                v != d.files[(std::size_t) sel_.fileA].settings.end())
                axes_[dial_] = v->second;
    }

    // For the slots as loaded now; a model still to come brings its own delay when it lands.
    void stageDelays() {
        for (int i = 0; i < 2; ++i)
            pendDelay_[(std::size_t) i].store(staged(modelIdOf(plan_.file[i]), delayOfModel(modelIdOf(plan_.file[i]), slotStageOf(i))),
                                              std::memory_order_release);
    }

    // 🔴 EVERY NUMBER THIS PLAYER HOLDS IN HOST SAMPLES, RESTATED AT THE RATE IT NOW RUNS AT. This is
    // prepare()'s other half, and until P89 it did not exist.
    //
    // WHAT prepare() PROMISES ABOUT HOST-DEPENDENT STATE, which is the sentence the mechanism below
    // serves: after it returns, NOTHING the player will act on is expressed in the samples of a rate it
    // is no longer running at. The rate-designed things were already covered — the FIRs are redesigned,
    // the bands redesigned and retired, the dry aligner re-sized, both stages re-prepared, the cold
    // threshold recomputed from its SECONDS. What was not covered is everything that is a COUNT of host
    // samples, and there are two such families, both written once and read for ever:
    //
    //   · THE WARM-UP LEDGER — `blend_.need[i]`, latched from warmFor() at the landing, and read again at
    //     every WAKE of a cold slot. See nam::blendRestated, which owns the numbers and the reasoning:
    //     the warm-up did not depend on the new rate at all, so a slot woken after 48 -> 96 kHz warmed
    //     for half the field it owes, and after 48 -> 192 for a quarter.
    //   · THE ALIGNMENT DELAYS — `pendDelay_` and `slotDelay_`, which AlignmentTable::delayOf scales by
    //     the host rate, and which only stageDelays() and a landing ever wrote. Left stale, the two
    //     captures of one device are held apart by a number measured for a different rate, so the
    //     crossfade combs by (ratio − 1) x the delay. A staged delay lands only on a slot at weight zero,
    //     so a SOUNDING slot kept the stale number until the dial moved it to silence.
    //
    // WHY THE TWO DELAYS ARE DERIVED FROM DIFFERENT MODELS, which looks like an inconsistency and is the
    // point: `pendDelay_` is the PLAN's — the model the dial is asking for — because that is what a
    // staged retime is, while `slotDelay_` is the delay of the model actually IN the slot. In the common
    // case they name one capture and get one number. When a load is in flight they do not, and taking
    // both from the plan would apply the incoming model's delay to the one still playing. Snapping
    // `slotDelay_` outright is right here and only here: prepare() is never concurrent with process(),
    // clearAudioState() has just zeroed `lagTail_`, so there is no signal to splice and no click to hide
    // from — which is the same reason snapGains() snaps rather than ramps.
    //
    // ⚠️ AND A LANDING CAN BE IN FLIGHT ACROSS THIS CALL. `loadSlot()` runs on the message thread and
    // latches `landWarm_`/`landDelay_` at the rate of the moment; the audio thread consumes them on its
    // next block. A prepare() landing between those two instants would hand the law a warm-up and a
    // delay measured for the rate that has just gone. The model itself is fine — it is re-prepared —
    // so only the two numbers need restating, and they are restated from the stage that now holds it.
    //
    // ⚠️ AND A FORGET IN FLIGHT MEANS THERE IS NO LEDGER TO RESTATE. load() and unload() post `forget_`
    // and rebuild `models_` at once, but the audio thread wipes `blend_` only on its NEXT block — so a
    // prepare() in that window finds `blend_.held[]` naming the PREVIOUS pack's models, as indices into a
    // `models_` that now belongs to the new one. Resolving them here reads the old slot's delay out of
    // the NEW pack's table: measured, a pack whose table owed 96 was applied to both slots of the pack
    // before it. That is muted and heals within a block, and it is still a change to base behaviour in a
    // window this function was never written for — so it stands back, and leaves the audio thread to
    // wipe what it was always going to wipe. The PLAN's delays are still restated: `plan_` is the new
    // pack's, and they are exactly what that first block will snap into place.
    //
    // `still` is the one count here that is RESCALED rather than recomputed — see nam::blendRestated for
    // why it is exact for that count and a trap for `need`. The ratio needs the rate the ledger was
    // COUNTED in, and that is not reliably `fs_` from before this call: prepare() writes `fs_` ahead of
    // two sub-prepares whose refusal it honours by returning false (no input reaches that refusal today,
    // since their channel and rate arguments are validated first — the order is what is relied on, not
    // the luck), and a refused prepare leaves the player unable to process, so the ledger never advanced
    // at the rate it wrote. `ledgerFs_` moves only here, at the end of a
    // prepare that succeeded — and it moves even with no pack loaded, because a pack loaded afterwards
    // counts at the rate prepared now.
    void restateInHostSamples() {
        const double timeScale = ledgerFs_ > 0.0 ? fs_ / ledgerFs_ : 1.0;
        ledgerFs_ = fs_;
        if (! loaded_) return;
        // The plan's delays first: stageDelays() is the one place that arithmetic is spelled.
        stageDelays();
        // The guard covers `blend_` and nothing else. A landing pending below belongs to the NEW pack if
        // it exists at all — unload() voids the old one before posting the forget, and no job for the new
        // pack can be taken before the audio thread has run once — so it is restated either way, rather
        // than leaning on that ordering to make a skip harmless.
        const bool forgetting = forget_.load(std::memory_order_acquire);
        for (int i = 0; i < 2 && ! forgetting; ++i) {
            // `blend_` is the audio thread's, read here under the contract that says the two never run
            // at once — the same licence prepare() already uses to zero `bandRt_[s].count`.
            if (blend_.held[i] == 0) continue;
            felitronics::nam::blendRestated(blend_, i, warmFor(slotStageOf(i)), timeScale);
            const int d = std::clamp(delayOfModel(blend_.held[i], slotStageOf(i)), 0, kMaxDelay);
            slotDelay_[(std::size_t) i].store(d, std::memory_order_relaxed);
            line_[(std::size_t) i].set(d);                        // no signal to splice: the lines were just cleared
            xo_.setLine(i, d, 0);
        }
        if (landFlag_.load(std::memory_order_acquire)) {
            const int ls = landSlot_.load(std::memory_order_relaxed) & 1;
            landWarm_ .store(warmFor(slotStageOf(ls)), std::memory_order_relaxed);
            landDelay_.store(std::clamp(delayOfModel(landModel_.load(std::memory_order_relaxed),
                                                     slotStageOf(ls)), 0, kMaxDelay),
                             std::memory_order_relaxed);
        }
    }

    void setRequest(std::uint64_t want0, std::uint64_t want1, float targetB) {
        reqWant_[0].store(want0, std::memory_order_relaxed);
        reqWant_[1].store(want1, std::memory_order_relaxed);
        reqTarget_.store(std::clamp(targetB, 0.0f, 1.0f), std::memory_order_release);
    }

    // Put this model in that slot and tell the law it landed, with the delay that travels with the
    // model — applied when it lands, the one instant the slot is guaranteed silent. Only the ask this
    // answers is cleared, and a failure carries its own slot: sharing either cell stranded the other
    // slot for the rest of a session.
    bool loadSlot(int slot, felitronics::nam::NamStage::PreparedModel prepared, std::uint64_t model) {
        auto& stage = nam_[(std::size_t) (slot & 1)];
        const bool ok = prepared != nullptr && stage.install(std::move(prepared));
        return ok ? land(slot, stage, model) : failSlot(slot);
    }

    void clearAsk(int slot) {
        if (const auto ask = loadAsk_.load(std::memory_order_acquire); ask != 0 && (int) (ask & 1u) == slot)
            loadAsk_.store(0, std::memory_order_release);
    }
    bool failSlot(int slot) {
        clearAsk(slot);
        landFail_.store(slot + 1, std::memory_order_release);
        return false;
    }

    // The slot runs `stage` from its next block — its own, where a model was just installed, or a preloaded copy — and
    // the law is told the model landed. The stage is published BEFORE the flag, so the block that takes the landing
    // runs it (process() reads the slot's stage after the law).
    bool land(int slot, felitronics::nam::NamStage& stage, std::uint64_t model) {
        slotStage_[(std::size_t) (slot & 1)].store(&stage, std::memory_order_seq_cst);
        if (model >= 1 && model <= modelRate_.size())         // the model's own rate, learned: the delays below read it
            modelRate_[(std::size_t) model - 1] = stage.modelSampleRate();
        const int delay = delayOfModel(model, stage);             // after the load: the rate is the model's
        clearAsk(slot);
        landSlot_.store(slot, std::memory_order_relaxed);
        landModel_.store(model, std::memory_order_relaxed);
        landWarm_.store(warmFor(stage), std::memory_order_relaxed);
        landDelay_.store(std::clamp(delay, 0, kMaxDelay), std::memory_order_relaxed);
        if (model >= 1 && model <= modelRate_.size()) {     // the crossover's clean tap: now the rate is the model's
            publishCrossoverLags();
            if (align_.derivedFromAbsolute) stageDelays();     // a rate learned moves the others' delays (at silence)
        }
        landFlag_.store(true, std::memory_order_release);
        return true;
    }

    // ------------------------------------------------------------------------- the preload ----

    enum class Pre : std::uint8_t { Empty, InFlight, Ready, Failed, Unfetched };
    struct PoolEntry {
        std::uint64_t model = 0;                       // BlendModelId
        int  slot = 0;                                 // the slot this copy plays in: one copy per (capture, slot)
        bool wanted = true;                            // in the set; false = kept only while a slot runs it or its job is out
        bool ran = false;                              // a slot has run it: the audio thread may still hold its address
        Pre  state = Pre::Empty;
        felitronics::nam::NamStage* stage = nullptr;   // holds the prepared capture once Ready; owned by poolStages_
    };
    struct RetiredStage {
        std::unique_ptr<felitronics::nam::NamStage> stage;
        std::uint64_t at = 0;                          // audioClock_ once no slot named it: freed when the clock is past it
    };

    felitronics::nam::NamStage& slotStageOf(int slot) const {
        return *slotStage_[(std::size_t) (slot & 1)].load(std::memory_order_seq_cst);
    }

    // THE PANEL the set was made for: the knots' files AND the other controls' settings. The files alone cannot tell
    // the panels of a pack with no gain dial apart (it has no knots, so every panel read "the same"): the set was never
    // made again, and the law's asks joined it one by one past the cap. Compared in place, no allocation.
    bool samePanel() const {
        if (sel_.knots.size() != preloadPanel_.size()) return false;
        for (std::size_t i = 0; i < sel_.knots.size(); ++i) if (sel_.knots[i].file != preloadPanel_[i]) return false;
        std::size_t i = 0;
        for (const auto& c : stage_.device.controls) {
            if (c.name == dial_) continue;
            if (i >= preloadAxes_.size()) return false;
            const auto v = axes_.find(c.name);
            if (v == axes_.end() ? ! preloadAxes_[i].empty() : v->second != preloadAxes_[i]) return false;
            ++i;
        }
        return i == preloadAxes_.size();
    }

    int findEntry(std::uint64_t model, int slot) const {
        for (std::size_t i = 0; i < pool_.size(); ++i)
            if (pool_[i].model == model && pool_[i].slot == slot) return (int) i;
        return -1;
    }

    // A COPY GOES WHOLE — its NamStage with its capture — and is never cleared into a list for reuse. NamStage frees a
    // capture it retires only once its OWN process() has stepped past it (NeuralStage::collectGarbage), and a pool stage
    // no slot runs is never processed again: a cleared copy was never freed (unload() kept 0.26 % of the set), and a
    // stage reused 64 times parked its next install while it went on playing the old capture. So: a copy no slot ever
    // ran is freed here and now — the audio thread never had its address. One a slot ran is tagged with the audio clock
    // read AFTER the slots were moved off it, and service() frees it once the clock is past the tag: process() ticks the
    // clock before it reads a slot's stage (both sequentially consistent, as the slots' stores are), so a block that
    // began after the tag runs the new stage, and every block that might have read this one has returned — the audio
    // thread runs one block at a time. Message thread.
    void retireStage(PoolEntry& e) {
        if (e.stage == nullptr) return;
        const auto it = std::find_if(poolStages_.begin(), poolStages_.end(),
                                     [&e] (const auto& st) { return st.get() == e.stage; });
        if (it != poolStages_.end()) {
            if (e.ran) retiredStages_.push_back({ std::move(*it), audioClock_.load(std::memory_order_seq_cst) });
            poolStages_.erase(it);                     // not ran: freed here
        }
        e.stage = nullptr;
    }

    void freeRetired() {
        const auto now = audioClock_.load(std::memory_order_seq_cst);
        std::erase_if(retiredStages_, [now] (const RetiredStage& r) { return now > r.at; });
    }

    // A fresh stage for every copy (retireStage says why none is reused), at the player's numbers.
    std::unique_ptr<felitronics::nam::NamStage> freshStage() const {
        auto st = std::make_unique<felitronics::nam::NamStage>();
        if (prepared_) st->prepare(fs_, maxBlock_, channels_);
        return st;
    }

    bool runBySlot(const PoolEntry& e) const {
        return e.stage != nullptr && (slotStage_[0].load(std::memory_order_seq_cst) == e.stage
                                      || slotStage_[1].load(std::memory_order_seq_cst) == e.stage);
    }

    // Copies out of the set go — but not one a slot is running (it goes when the slot moves off it), nor one whose job
    // is out (its delivery decides: it lands if the law still asks for it, and goes if not).
    void dropUnwanted() {
        std::size_t w = 0;
        for (std::size_t i = 0; i < pool_.size(); ++i) {
            if (! pool_[i].wanted && ! runBySlot(pool_[i]) && pool_[i].state != Pre::InFlight) {
                retireStage(pool_[i]);
                continue;
            }
            if (w != i) pool_[w] = pool_[i];
            ++w;
        }
        pool_.resize(w);
    }

    // The set was ready once since load(): from here a copy it lacks waits for the law's ask (takePreloadJob).
    void noteBuilt() {
        if (! preloadBuilt_ && preloadProgress().ready()) preloadBuilt_ = true;
    }

    // THE SET, made again: for the panel sounding and then the others nearest first (setPreload). Every (capture, slot)
    // the plan can name is found by asking the plan itself — at every knot, between every two, at both ends, with two
    // models and with one (stepped) — so the set is the law's own reach, not a second account of it.
    void rebuildPreload() {
        noteBuilt();                                   // a set that was ready stays "built" across the change
        preloadStale_ = false;
        const auto& d = stage_.device;
        preloadPanel_.clear();
        for (const auto& k : sel_.knots) preloadPanel_.push_back(k.file);
        preloadAxes_.clear();
        for (const auto& c : d.controls)
            if (c.name != dial_) {
                const auto v = axes_.find(c.name);
                preloadAxes_.push_back(v == axes_.end() ? std::string() : v->second);
            }
        std::vector<std::pair<std::uint64_t, int>> want;
        const auto reach = [&] (const Settings& ax) {
            std::vector<std::pair<std::uint64_t, int>> got;
            const auto put = [&] (const Selection& sl, bool one) {
                const auto pl = slotPlan(sl, d);
                for (int i = 0; i < 2; ++i) {
                    if (pl.file[i] < 0 || (one && i == (pl.targetB >= 0.5 ? 0 : 1))) continue;
                    const std::pair<std::uint64_t, int> c { modelIdOf(pl.file[i]), i };
                    if (c.first != 0 && std::find(got.begin(), got.end(), c) == got.end()) got.push_back(c);
                }
            };
            const auto base = select(d, ax, dial_, dialDeg_, shape_, topExtend_);
            std::vector<double> at { dialDeg_, 0.0, (double) dialSweep_ };
            for (std::size_t k = 0; k < base.knots.size(); ++k) {
                at.push_back(base.knots[k].deg);
                if (k + 1 < base.knots.size()) at.push_back(0.5 * (base.knots[k].deg + base.knots[k + 1].deg));
            }
            for (const double deg : at) {
                const auto sl = select(d, ax, dial_, deg, shape_, topExtend_);
                put(sl, false);
                put(steppedSelection(sl, -1, kStepDeadband), true);
            }
            return got;
        };
        const auto merge = [&] (const std::vector<std::pair<std::uint64_t, int>>& got) {
            for (const auto& c : got) if (std::find(want.begin(), want.end(), c) == want.end()) want.push_back(c);
        };
        merge(reach(axes_));                                           // the panel sounding: always whole
        // …then the other panels: the captured combinations of the other controls, nearest first.
        std::vector<std::pair<int, Settings>> panels;
        for (const auto& f : d.files) {
            Settings ax = axes_;
            int far = 0;
            for (const auto& [name, value] : f.settings) {
                if (name == dial_) continue;
                if (ax[name] != value) { ax[name] = value; ++far; }
            }
            if (far == 0) continue;
            bool seen = false;
            for (const auto& p : panels) if (p.second == ax) { seen = true; break; }
            if (! seen) panels.emplace_back(far, std::move(ax));
        }
        std::stable_sort(panels.begin(), panels.end(), [] (const auto& x, const auto& y) { return x.first < y.first; });
        for (const auto& p : panels) {
            const auto got = reach(p.second);
            std::size_t fresh = 0;
            for (const auto& c : got) if (std::find(want.begin(), want.end(), c) == want.end()) ++fresh;
            if (want.size() + fresh <= (std::size_t) preloadCap_) merge(got);
        }
        // The pool follows: copies in the set keep their state, in the set's order; the rest are dropped.
        std::vector<PoolEntry> next;
        next.reserve(want.size() + pool_.size());
        for (const auto& c : want) {
            const int k = findEntry(c.first, c.second);
            PoolEntry e;
            if (k >= 0) { e = pool_[(std::size_t) k]; pool_[(std::size_t) k].stage = nullptr; pool_[(std::size_t) k].model = 0; }
            else { e.model = c.first; e.slot = c.second; }
            e.wanted = true;
            next.push_back(e);
        }
        for (auto& e : pool_) if (e.model != 0) { e.wanted = false; next.push_back(e); }
        pool_ = std::move(next);
        dropUnwanted();
    }

    // The law's ask, answered from the pool where it can be: a prepared copy lands now, a copy that failed is reported.
    // Neither is a job. (An ask for a copy still to be prepared is takePreloadJob's.)
    void servePreloadAsk() {
        if (preloadCap_ <= 0 || ! loaded_) return;
        const auto ask = loadAsk_.load(std::memory_order_acquire);
        if (ask == 0) return;
        const auto id = ask >> 1;
        const int slot = (int) (ask & 1u);
        const int k = id == 0 || id > models_.size() ? -1 : findEntry(id, slot);
        if (k < 0) return;
        if (pool_[(std::size_t) k].state == Pre::Ready) landFromPool((std::size_t) k);
        else if (pool_[(std::size_t) k].state == Pre::Failed) failSlot(slot);
    }

    void landFromPool(std::size_t k) {
        auto& e = pool_[k];
        // A COPY TAKEN AGAIN HOLDS ITS LAST VISIT — the network's lanes and the rate-matcher's — where a load starts clean.
        // A capture with a field owes the law a warm-up, which feeds that whole memory out before it is heard. One with
        // none is heard at once, and off the model rate its matcher would replay the tail of its last visit (measured
        // 0.0139 at 44.1 kHz on the fixture) — so it is drained to the silence state here first (NamStage::reset: a
        // memoryless capture's drain is its matcher's few samples). Here, because nothing runs it: it left its slot at an
        // earlier landing, and the slot has run a block since — the law asked again after it.
        if (e.stage->prewarmSamples() <= 0) e.stage->reset();
        e.ran = true;                         // from the store in land() on, the audio thread may hold its address
        land(e.slot, *e.stage, e.model);
        dropUnwanted();                       // the copy the slot ran before, if the set has moved on without it
    }

    // A JOB FOR THE SET: the law's ask first; then the next copy the set lacks — until the set is first ready after a
    // load, and while the host says its jobs cost nothing (setPreloadIdle). The host sets the pace: it asks for a job
    // when it can run one (the worklet: one a render quantum, while it plays — since v0.7.0; in silence before). After
    // that a copy the set lacks — a panel past the cap, a file to fetch again — waits for the law to ask for it, as it
    // would without the preload: a switch while playing never runs more jobs than the player without it. Never before
    // prepare(): there are no numbers to prepare a copy at.
    std::optional<LoadJob> takePreloadJob() {
        servePreloadAsk();
        if (! prepared_) return std::nullopt;
        noteBuilt();
        int k = -1;
        if (const auto ask = loadAsk_.load(std::memory_order_acquire); ask != 0) {   // the law's ask first
            const auto id = ask >> 1;
            const int slot = (int) (ask & 1u);
            if (id == 0 || id > models_.size()) {                  // an ask that outlived its pack
                loadAsk_.store(0, std::memory_order_release);
                landFail_.store(slot + 1, std::memory_order_release);
                return std::nullopt;
            }
            k = findEntry(id, slot);
            if (k < 0) {                                           // outside the set: a copy for this ask alone
                PoolEntry e; e.model = id; e.slot = slot; e.wanted = false;
                pool_.push_back(e);
                k = (int) pool_.size() - 1;
            }
            const auto st = pool_[(std::size_t) k].state;
            if (st != Pre::Empty && st != Pre::Unfetched) k = -1;   // ready or failed: answered above; in flight: out
        }
        if (k < 0 && (! preloadBuilt_ || preloadIdle_))
            for (std::size_t i = 0; i < pool_.size(); ++i)
                if (pool_[i].wanted && pool_[i].state == Pre::Empty) { k = (int) i; break; }
        if (k < 0) return std::nullopt;
        auto& e = pool_[(std::size_t) k];
        e.state = Pre::InFlight;
        const auto& m = models_[(std::size_t) e.model - 1];
        LoadJob job;
        job.slot = e.slot; job.model = e.model; job.fileId = m.id; job.bytes = m.bytes;
        job.source = source_; job.sampleRate = fs_; job.maxBlock = maxBlock_; job.channels = channels_;
        job.generation = gen_;
        job.preload = true;
        jobOut_ = true;
        return job;
    }

    void deliverPreload(Loaded loaded) {
        const auto& job = loaded.job;
        const int k = findEntry(job.model, job.slot);
        if (k < 0 || pool_[(std::size_t) k].state != Pre::InFlight) return;   // the set moved on without it
        auto& e = pool_[(std::size_t) k];
        if (loaded.model != nullptr) {
            auto st = freshStage();
            if (st->install(std::move(loaded.model))) {
                e.stage = st.get();
                poolStages_.push_back(std::move(st));
                e.state = Pre::Ready;
            } else {
                e.state = Pre::Failed;                                         // the fresh stage goes with `st`
            }
        } else {
            e.state = loaded.bytes == nullptr || loaded.bytes->empty() ? Pre::Unfetched : Pre::Failed;
        }
        // The law's ask, if this is it, is answered now — where a slot's own job lands, on its deliver().
        const auto ask = loadAsk_.load(std::memory_order_acquire);
        if (ask != 0 && (ask >> 1) == job.model && (int) (ask & 1u) == job.slot) {
            if (e.state == Pre::Ready) landFromPool((std::size_t) k);
            else failSlot(job.slot);
        }
        dropUnwanted();                       // a copy outside the set the law no longer asks for (a slot's is kept)
        noteBuilt();
    }

    // How many samples this model owes before it may be heard, in THIS rate: its receptive field,
    // scaled — a 96 kHz host feeds twice as many to fill the same network — plus the RATE-MATCH DELAY,
    // plus one block, so a slot is never marked audible for a block it is still short in.
    //
    // 🔴 THE LATENCY TERM IS NOT DECORATION, and it used to be missing. When the stage is resampling,
    // the first latencySamples() host samples out of it are the network's response to the resampler's
    // own leading zeros, not to the signal — so a full receptive field of REAL material needs that many
    // more. The old expression relied on `+ maxBlock_` to absorb it silently, which worked only while
    // that delay was 3.84 samples: P34's 64-tap kernel makes it 61.4 at 44.1 kHz, and at the 32- and
    // 64-sample blocks live rigs run the slack stopped covering it. The effect is small against a
    // ~6300-sample receptive field (a crossfade starting up to 1.4 ms early), but the sentence above
    // was a GUARANTEE, and a guarantee that quietly stopped holding is worse than a smaller number.
    long long warmFor(const felitronics::nam::NamStage& st) const {
        const int pre = st.prewarmSamples();
        // 🔴 AND THIS EARLY RETURN DROPS THE LATENCY TERM TOO, which is a different claim from "no
        // field, no warm-up" and is the one that costs something. A capture with no memory still runs
        // through a rate-matcher off the model rate, and a slot that has just been WOKEN starts by
        // emitting that matcher's `latencySamples()` leading zeros — 61 at 44.1 kHz, 96 at 96 kHz.
        // Returning zero here makes the law audible-immediately for exactly those captures, so the
        // woken slot contributes a hole where a slot that never slept contributes signal. Measured
        // against a player that never sleeps, 0.1 input, on the block of the wake: **4.97e-03 at
        // 44.1 kHz and 7.28e-03 at 96 kHz**, and 3.76e-07 for a capture that HAS memory, which does not
        // take this branch. Removing the early return was measured too: 96 kHz goes to exactly
        // 0.000000000 and 44.1 to 2.87e-06, i.e. down to the rate-matcher's own resumption floor.
        // It is NOT removed here — it moves the warm-up of every memoryless capture in every consumer,
        // which is a decision with its own blast radius rather than a line to change in passing. What
        // is done instead is that the guarantee it breaks no longer stands unqualified: see
        // RigPlayerTests, "a player that sleeps sounds bit-identically to one that never does — AT THE
        // MODEL RATE", where both the rate it holds at and the size of the divergence off it are pinned.
        if (pre <= 0) return 0;
        // 🔴 ASK for the rate the model will be RUN at, do not read the rate it REPORTS. An untagged
        // capture reports -1 and NamStage runs it at kModelSampleRate anyway; the previous line here
        // restated the normalisation with a different answer — `scale = 1.0` — and therefore
        // under-warmed such a model by a whole receptive field at a 96 kHz host, which is exactly the
        // guarantee the comment above says must not quietly stop holding.
        const double mr = felitronics::nam::NamStage::rateMatch(fs_, st.modelSampleRate()).modelRunSR;
        const double scale = (mr > 0.0 && fs_ > 0.0) ? fs_ / mr : 1.0;
        return (long long) std::ceil((double) pre * scale) + (long long) st.latencySamples() + maxBlock_;
    }

    // The rest before a slot goes cold, in this rate's samples, for the law. Zero = never.
    long long coldSamples(double seconds) const {
        return seconds > 0.0 ? (long long) std::llround(seconds * fs_) : 0;
    }

    // ------------------------------------------------------------------------------- the tone ----

    // Which side of the models a knob sits on: 0 before, 1 after, -1 for a placement this player does
    // not know — such a knob is skipped, as the format says.
    static int sideOf(const namz::rig::Tone& t) {
        return t.placement == "pre" ? 0 : t.placement == "post" ? 1 : -1;
    }

    void rebuildKnob(const namz::rig::Tone& t) {
        // A FREQUENCY knob has no filter of its own and no side: it moves a band of another knob, wherever that sits.
        if (namz::rig::isFrequencyKnob(t)) { rebuildBands(0); rebuildBands(1); return; }
        const int side = sideOf(t);
        if (side < 0) return;
        // Bands, whether they travel with a dial or stand still at a switch's position; else the curve.
        if (! t.sections.empty() || bandsPerPosition(t)) rebuildBands(side); else rebuildCurves(side);
    }

    // Every curve-form knob on one side, summed (cascaded linear filters multiply, which in dB is a
    // sum) on one common grid — each knob may ship its own — and designed as ONE minimum-phase FIR.
    // Flat, or nothing there, is a bypass rather than a convolution with an impulse.
    void rebuildCurves(int side) {
        std::vector<double> sum(commonGrid_.size(), 0.0);
        bool any = false;
        for (const auto& t : tones()) {
            // A knob whose positions carry BANDS ships no curve and no grid: it belongs to the other
            // path, and asking this one for its curve would ask an empty grid for a value.
            if (sideOf(t) != side || t.positions.empty() || bandsPerPosition(t) || namz::rig::isFrequencyKnob(t)) continue;
            const auto grid  = gridOf(t);
            const auto curve = curveAt(t, grid, toneAt_[t.name]);
            if (curve.empty()) continue;
            any = true;
            for (std::size_t k = 0; k < sum.size(); ++k)
                sum[k] += felitronics::lineareq::curveDbAt(curve, grid, commonGrid_[k]);
        }
        curveSum_[side] = any ? sum : std::vector<double> {};
        auto taps = any ? felitronics::lineareq::magnitudeCurveToFir(sum, commonGrid_, fs_, kFirTaps, kFirDesign)
                        : std::vector<float> {};
        firTaps_[side] = std::move(taps);
        if (! firTaps_[side].empty() && prepared_) {
            const float* t[1] { firTaps_[side].data() };
            fir_[side].loadIR(t, 1, (int) firTaps_[side].size(), fs_);
            firBypass_[side].store(false, std::memory_order_release);
        } else
            firBypass_[side].store(true, std::memory_order_release);
    }

    // Every band of every section-form knob on one side, at its knob's position — in a fixed order,
    // so band k keeps its state across knob moves.
    void rebuildBands(int side) {
        // A band naming a frequency knob (`hz_by`) asks it where it sits now: that knob's position, by name.
        const auto knobs = tones();                          // once: tones() hands out a copy
        const auto frequencyOf = [this, &knobs] (const std::string& knob, double& hz, double& q) {
            for (const auto& f : knobs)
                if (f.name == knob && namz::rig::isFrequencyKnob(f)) {
                    const auto at = toneAt_.find(knob);
                    return frequencyAt(f, at != toneAt_.end() ? at->second : toneStart(f), hz, q);
                }
            return false;
        };
        BandSet set;
        bandsShown_[side].clear();
        int dropped = 0;
        for (const auto& t : knobs) {
            if (sideOf(t) != side) continue;
            // A DIAL's bands travel with its rotation; a SWITCH's stand whole at the position it is on.
            // One list either way, in a fixed order, so band k keeps its state across knob moves.
            const auto qs = ! t.sections.empty() ? sectionsAt(t, toneAt_[t.name], fs_, frequencyOf)
                          : bandsPerPosition(t)  ? sectionsAtValue(t, toneAt_[t.name], fs_)
                                                 : std::vector<felitronics::rigplayer::SectionBiquad> {};
            for (const auto& q : qs) {
                if (set.count < kMaxBands) { set.c[set.count++] = q; bandsShown_[side].push_back(q); }
                else ++dropped;
            }
        }
        bandsDropped_ = dropped;
        publishBands(side, set);
    }

    // The first blend knob of the stage — a pedal has one. Its dry path's shape is designed once; the
    // gains move with the knob and never rebuild a filter.
    const namz::rig::Blend* blendKnob() const { return stage_.blend.empty() ? nullptr : &stage_.blend.front(); }

    void rebuildDry() {
        const auto* b = blendKnob();
        dryTaps_.clear();
        if (b != nullptr) {
            const auto grid = gridOf(*b);
            dryTaps_ = felitronics::lineareq::magnitudeCurveToFir(dryCurve(*b, grid), grid, fs_, kFirTaps, kFirDesign);
        }
        if (! dryTaps_.empty() && prepared_) {
            const float* t[1] { dryTaps_.data() };
            dry_.loadIR(t, 1, (int) dryTaps_.size(), fs_);
            dryFirBypass_.store(false, std::memory_order_release);
        } else
            dryFirBypass_.store(true, std::memory_order_release);
        applyBlendGains();
        dryActive_.store(b != nullptr, std::memory_order_release);
    }

    void applyBlendGains() {
        const auto* b = blendKnob();
        const BlendGains g = b != nullptr ? blendGainsAt(*b, blendAt_[b->name]) : BlendGains {};
        dryGain_.store((float) std::clamp(g.dry, -4.0, 4.0), std::memory_order_release);
        wetGain_.store((float) std::clamp(g.wet,  0.0, 4.0), std::memory_order_release);
    }

    // ------------------------------------------------------------ the bands, across the threads ----

    struct BandSet {
        int count = 0;
        felitronics::rigplayer::SectionBiquad c[kMaxBands];
    };
    // A small pool instead of a heap: the message thread fills a free set and publishes its index; the
    // audio thread takes the index, copies the set and frees it. At most one pending and one being
    // filled at a time, so four never run out — and nothing is allocated or freed on the audio thread.
    struct BandSlot { BandSet set; std::atomic<bool> busy { false }; };
    static constexpr int kBandPool = 4;

    void publishBands(int side, const BandSet& set) {
        auto& pool = bandPool_[side];
        for (int i = 0; i < kBandPool; ++i) {
            if (pool[i].busy.load(std::memory_order_acquire)) continue;
            pool[i].set = set;
            pool[i].busy.store(true, std::memory_order_release);
            const int old = bandNext_[side].exchange(i, std::memory_order_acq_rel);
            if (old >= 0) pool[old].busy.store(false, std::memory_order_release);   // never taken: superseded
            return;
        }
    }

    // Audio thread, at the top of every block.
    void takeBands(int side) {
        const int i = bandNext_[side].exchange(-1, std::memory_order_acq_rel);
        if (i < 0) return;
        auto& rt = bandRt_[side];
        const auto& in = bandPool_[side][i].set;
        // A band that appears (a load) starts AT its coefficients — there is nothing to ramp from; one
        // that is already running ramps to the new ones across the next block.
        for (int k = rt.count; k < in.count; ++k) {
            bandCur_[side][k] = bandFrom_[side][k] = bandTo_[side][k] = in.c[k];
            bandPos_[side][k] = bandLen_[side][k] = 0;         // arrived: nothing to travel
            for (auto& b : bq_[side][k]) b.reset();
        }
        rt = in;
        bandPool_[side][i].busy.store(false, std::memory_order_release);
    }

    // The same five numbers, bit for bit: a band that did not move ramps nothing.
    static bool same(const felitronics::rigplayer::SectionBiquad& x, const felitronics::rigplayer::SectionBiquad& y) {
        return std::memcmp(&x.b0, &y.b0, sizeof(double)) == 0 && std::memcmp(&x.b1, &y.b1, sizeof(double)) == 0
            && std::memcmp(&x.b2, &y.b2, sizeof(double)) == 0 && std::memcmp(&x.a1, &y.a1, sizeof(double)) == 0
            && std::memcmp(&x.a2, &y.a2, sizeof(double)) == 0;
    }

    // Every band of a side, on every channel. Coefficients that changed travel linearly over a length
    // THE BAND ITSELF DECLARES (see bandRampLength) — a knob dragged sixty times a second never steps a
    // filter, and it now does not step it differently on a different host either. The ramp carries
    // across calls: `bandPos_` counts SAMPLES, so where the caller cuts the stream changes nothing.
    //
    // THE SEGMENT LOOP IS ON THE OUTSIDE, and the first version of this had it on the inside — all the
    // audio processed first, then a loop that counted grid boundaries and flushed at each. That flushes
    // the same FINAL state eight times for a 512-sample call and never once inside a whole-file call,
    // which is the very defect the grid exists to remove, dressed as its fix. Found by the diff-pass
    // review; the suite could not see it, because a mutation that removes the flush entirely fails
    // while one that merely misplaces it does not.
    void runBands(int side, float* const* planes, int count) {
        auto& rt = bandRt_[side];

        // A NEW TARGET STARTS A NEW RAMP, from wherever the last one had got to — a hand that moves
        // again mid-travel is the ordinary case, not the exception. This is an ARRIVAL, so it is read
        // once per call, at the call boundary, exactly where the caller put it.
        for (int k = 0; k < rt.count; ++k)
            if (! same(rt.c[k], bandTo_[side][k])) {
                bandFrom_[side][k] = bandCur_[side][k];
                bandTo_[side][k]   = rt.c[k];
                bandLen_[side][k]  = bandRampLength(bandFrom_[side][k], rt.c[k], fs_);
                bandPos_[side][k]  = 0;
            }

        auto& grid = bandGrid_[side];
        for (int off = 0; off < count; ) {
            const int seg = grid.segment(count - off);
            for (int k = 0; k < rt.count; ++k) runBandSegment(side, k, planes, off, seg);
            off += seg;
            // LAW 8 ON THE AUDIO-TIME GRID (core/StateGrid.h, law 8a), which means HERE — after the
            // segment that ends on a boundary and before the next one, not after the call.
            if (grid.advance(seg))
                for (int k = 0; k < rt.count; ++k)
                    for (int c = 0; c < channels_; ++c) bq_[side][k][(std::size_t) c].flushDenormals();
        }

        // The poison half keeps the call's clock — see eq::Biquad::healPoison(). Invisible while finite.
        for (int k = 0; k < rt.count; ++k)
            for (int c = 0; c < channels_; ++c) bq_[side][k][(std::size_t) c].healPoison();
    }

    // One band, one grid segment: `n` samples starting at `off`, every channel, walking the ramp.
    void runBandSegment(int side, int k, float* const* planes, int off, int n) {
        auto& bands = bq_[side][k];
        if (bandPos_[side][k] >= bandLen_[side][k]) {           // arrived: no interpolation at all
            bandCur_[side][k] = bandTo_[side][k];
            for (int c = 0; c < channels_; ++c) {
                auto& bq = bands[(std::size_t) c];
                bq.c = bandTo_[side][k];
                float* x = planes[c] + off;
                for (int i = 0; i < n; ++i) x[i] = bq.processSample(x[i]);
            }
            return;
        }
        const auto& from = bandFrom_[side][k];
        const auto& to   = bandTo_[side][k];
        const int    len = bandLen_[side][k];
        const double inv = 1.0 / (double) len;
        const int    p0  = bandPos_[side][k];
        for (int c = 0; c < channels_; ++c) {
            auto& bq = bands[(std::size_t) c];
            float* x = planes[c] + off;
            int p = p0;
            for (int i = 0; i < n; ++i) {
                if (p < len) {
                    ++p;
                    const double t = (double) p * inv;
                    bq.c.b0 = from.b0 + (to.b0 - from.b0) * t;
                    bq.c.b1 = from.b1 + (to.b1 - from.b1) * t;
                    bq.c.b2 = from.b2 + (to.b2 - from.b2) * t;
                    bq.c.a1 = from.a1 + (to.a1 - from.a1) * t;
                    bq.c.a2 = from.a2 + (to.a2 - from.a2) * t;
                } else bq.c = to;
                x[i] = bq.processSample(x[i]);
            }
            bandCur_[side][k] = bq.c;                           // every channel walks the same path
        }
        bandPos_[side][k] = std::min(p0 + n, len);
    }

    // Law 8. Every gain here approaches its target asymptotically — `end = want + (current-want)*decay`
    // — so it never arrives: the residual parks in a fixed-point band and stays. For want == 0 that band
    // is subnormal (at 128 samples / 48 kHz decay = 0.766, so every k*u with k <= 0.5/(1-decay) ~= 2.1
    // maps to itself; measured: frozen at 2 ulp, stall beginning ~1 s in), and the audio then pays for it
    // per sample: `gd += stepDry; a[c][i]*gw + d[c][i]*gd` is ~3 assisting operations per sample per
    // channel, and the mix loop is gated on `dryActive_` — a dry IR being LOADED — not on either gain.
    //
    // An EXACT zero is reachable and the repo's own fixture ships one: `BlendKnob::linOf` returns 0.0 for
    // any level at or below -120 dB, which is how a pack spells "this path is off" (RigPlayerTests.cpp's
    // rig: wetDb -120 at the dry end, dryDb -120 at the wet end). What does NOT stall is the initialised
    // or reset 0 — 0 -> 0 stays exactly 0; the stall needs an audible position first and a -120 dB one
    // after it. The second condition below covers the non-zero targets the same way core::Smoother does.
    static float rampEnd(float want, float current, float decay) {
        const float d  = (current - want) * decay;
        const float nx = want + d;
        return (std::fabs(d) < 1e-30f || felitronics::core::exactlyEqual(nx, current)) ? want : nx;
    }

    // One linear ramp per block toward an exponential ~10 ms endpoint: smooth moves without an exp()
    // per sample. `current` is audio-thread-only.
    static bool isOne(float g) { const float one = 1.0f; return std::memcmp(&g, &one, sizeof(float)) == 0; }   // bit for bit, as same()
    void rampInto(float* const* planes, int nch, int count, float want, float& current) const {
        const float decay = std::exp(-(float) count / (float) (0.010 * fs_));
        const float end   = rampEnd(want, current, decay);
        const float step  = (end - current) / (float) count;
        if (! isOne(current) || ! isOne(want))
            for (int c = 0; c < nch; ++c) {
                float g = current;
                float* x = planes[c];
                for (int i = 0; i < count; ++i) { g += step; x[i] *= g; }
            }
        current = end;
    }

    // ------------------------------------------------------------------------------------ state ----

    // message thread
    struct Model { std::string id; std::shared_ptr<const std::vector<std::byte>> bytes; };   // null = not fetched yet
    std::vector<Model> models_;                        // BlendModelId = index + 1; 0 = nothing
    std::uint64_t      gen_ = 0;                       // bumped by every unload(): a job carries the one it was taken under
    bool               jobOut_ = false;                // a job is with the host; nothing else is handed out
    std::vector<int>   fileModel_;                     // Device::files index → models_ index
    namz::rig::Stage   stage_;
    ModelSource        source_;
    bool               loaded_ = false;
    Settings           axes_;
    std::string        dial_;
    int                dialSweep_ = 0;
    double             dialDeg_ = 0.0;
    std::map<std::string, std::string> toneAt_, blendAt_;
    std::vector<namz::rig::Tone> toneOverride_;        // tone handed in beside the manifest; empty = none
    Selection          sel_;
    SlotPlan           plan_;
    BlendShape         shape_ {};
    double             topExtend_ = kTopExtendDbPerDeg;
    AlignmentTable     align_;
    long long          loads_ = 0;
    int                bandsDropped_ = 0;
    double             coldSeconds_ = kColdAfterSeconds;
    int                maxModels_ = 2;                 // setMaxModels; the audio side reads single_
    int                stayFile_ = -1;                 // the file entry a one-model player sounds (kStepDeadband)
    // A 1/12-octave grid from 20 Hz to 20 kHz, on which every curve-form knob is summed whatever grid
    // it shipped on.
    std::vector<double> commonGrid_ = felitronics::lineareq::logFreqGrid(20.0, 20000.0, 121);
    std::vector<double> curveSum_[2];
    std::vector<float>  firTaps_[2], dryTaps_;
    std::vector<felitronics::rigplayer::SectionBiquad> bandsShown_[2];

    // both, by contract
    double fs_ = 48000.0;
    double ledgerFs_ = 0.0;      // the rate blend_'s host-sample counts are in; 0 = never prepared (restateInHostSamples)
    int    maxBlock_ = 0, channels_ = 1;
    bool   prepared_ = false;
    long long dipSamples_ = 1;   // kDipSeconds at fs_, for the law's one-model dip

    // the mailboxes (message → audio, audio → message)
    felitronics::nam::NamStage nam_[2];
    // WHICH STAGE EACH SLOT RUNS: its own nam_[i], or — preloading (setPreload) — a stage of the pool that holds the
    // capture prepared for that slot. Written on the message thread at a landing (the instant an install would be) and
    // by unload(); read by the audio thread, which runs whatever it names, and by latencySamples().
    std::atomic<felitronics::nam::NamStage*> slotStage_[2] { &nam_[0], &nam_[1] };

    // THE AUDIO CLOCK: process() and reset() tick it before they read slotStage_; the preload frees a copy a slot ran
    // only once it has moved past the copy's retirement (retireStage).
    std::atomic<std::uint64_t> audioClock_ { 0 };

    // ---- the preload (setPreload), message thread ----
    std::vector<std::unique_ptr<felitronics::nam::NamStage>> poolStages_;   // the copies held; the audio thread reads two
    std::vector<RetiredStage> retiredStages_;                               // copies a slot ran, freed past their tag
    std::vector<PoolEntry>   pool_;                                         // the set first, in order, then the unwanted
    std::vector<int>         preloadPanel_;                                 // the knots' file entries the set was made for
    std::vector<std::string> preloadAxes_;                                  // …and the other controls' settings (samePanel)
    int                      preloadNext_ = 0;                              // setPreload: taken by the next load()
    int                      preloadCap_ = 0;                               // the pack's: 0 = not preloading
    bool                     preloadStale_ = false;                         // load(): the set is to be made
    bool                     preloadBuilt_ = false;                         // ready once since load() (takePreloadJob)
    bool                     preloadIdle_ = false;                          // setPreloadIdle
    std::atomic<std::uint64_t> reqWant_[2] { 0, 0 };
    std::atomic<float>         reqTarget_ { 0.0f };
    std::atomic<std::uint64_t> loadAsk_ { 0 };          // (model << 1) | slot; 0 = nothing asked
    std::atomic<bool>          landFlag_ { false };
    std::atomic<int>           landSlot_ { 0 };
    std::atomic<std::uint64_t> landModel_ { 0 };
    std::atomic<long long>     landWarm_ { 0 };
    std::atomic<int>           landDelay_ { 0 };
    std::atomic<int>           landFail_ { 0 };          // slot + 1; 0 = none
    std::atomic<bool>          forget_ { false };
    std::atomic<std::uint64_t> pendDelay_[2] { 0, 0 };     // staged(model, delay): one publication, see the retime
    std::atomic<int>           slotDelay_[2] { 0, 0 };
    std::atomic<std::uint64_t> held_[2] { 0, 0 };
    std::atomic<float>         liveMix_ { 0.0f };
    std::atomic<float>         liveDry_ { 0.0f }, liveWet_ { 1.0f };
    std::atomic<int>           warmBlocks_ { 0 }, mixJumps_ { 0 };
    std::atomic<bool>          audible_ { false };          // the law's gain above zero at the last block's end
    static constexpr long long kQuietForever = std::numeric_limits<long long>::max() / 4;
    long long                  quietRun_ = kQuietForever;   // audio thread: samples the models' input has been exactly 0
    std::atomic<float>         biggestJump_ { 0.0f };
    std::atomic<long long>     coldAfter_ { 0 };          // coldSeconds_ at fs_, for the law; 0 = never
    std::atomic<bool>          slotCold_[2] { false, false };
    std::atomic<int>           coldBlocks_[2] { 0, 0 };
    std::atomic<int>           runBlocks_[2] { 0, 0 };
    std::atomic<int>           pairBlocks_ { 0 };
    std::atomic<bool>          single_ { false };       // setMaxModels(1), for the audio thread
    // The pack's own levels, and the reason they are two gains of their own rather than one more
    // term in chainGain_: inGain_ has to reach the dry side of a blend, and chainGain_ is applied
    // after the dry block has already been taken.
    std::atomic<float>         inGain_ { 1.0f }, outGain_ { 1.0f };
    std::optional<double>      hostIn_, hostOut_;      // message thread only; empty = the pack's own
    // The feed (setFeedDb): its dB on the message thread, summed into inGain_ there; its gain alone for the scope's dry.
    double                     feedDb_ = 0.0;
    std::atomic<float>         feedGain_ { 1.0f };
    std::atomic<float>         chainGain_ { 1.0f };
    std::atomic<float>         slotGain_[2] { 1.0f, 1.0f };
    // A model's `metadata.loudness` tag is a CONTRACT, not a listener's option: off, every capture
    // plays at whatever level the hardware happened to give, and two packs cannot be compared at all.
    std::atomic<bool>          normalize_ { true };
    std::atomic<bool>          inputTrims_ { true };
    std::atomic<bool>          firBypass_[2] { true, true };
    std::atomic<bool>          dryActive_ { false }, dryFirBypass_ { true };
    std::atomic<float>         dryGain_ { 0.0f }, wetGain_ { 1.0f };
    BandSlot                   bandPool_[2][kBandPool];
    std::atomic<int>           bandNext_[2] { -1, -1 };

    // audio thread only
    felitronics::nam::BlendState blend_ {};
    bool coldRt_[2] {};                                // the law's cold flags as of the last block, to see a slot fall asleep
    SlotLine line_[2];                           // each slot's alignment delay line, every plane (CrossoverBlend.h)
    std::vector<float> lineTmp_;                 // its scratch: one block
    int retimeFade_ = 1;                         // a heard slot's retime: 10 ms at fs_
    int ranNch_ = 0;                        // planes that advanced state on the previous call
    float curIn_ = 1.0f, curOut_ = 1.0f;
    float curFeed_ = 1.0f;                             // the feed's own ramp, which only the scope's dry rides
    float curChain_ = 1.0f, curSlot_[2] { 1.0f, 1.0f }, curDry_ = 0.0f, curWet_ = 1.0f;
    BandSet                    bandRt_[2];
    felitronics::rigplayer::SectionBiquad   bandCur_[2][kMaxBands];    // what the filters are running NOW
    felitronics::rigplayer::SectionBiquad   bandFrom_[2][kMaxBands];   // where the ramp in flight started
    felitronics::rigplayer::SectionBiquad   bandTo_[2][kMaxBands];     // ...and where it is going
    int                                     bandPos_[2][kMaxBands] {}; // samples of it consumed
    int                                     bandLen_[2][kMaxBands] {}; // its declared length (bandRampLength)
    felitronics::core::StateGrid            bandGrid_[2];              // law 8 on audio time, per side
    felitronics::eq::Biquad    bq_[2][kMaxBands][kMaxChannels];
    felitronics::convolution::CabConvolver fir_[2], dry_;
    felitronics::core::DryAligner dryLatency_;   // holds the dry path back by the models' rate-match
    felitronics::core::DryAligner wire_;         // the stand-by wire: the raw input at latencySamples()
    std::vector<float> slotB_[kMaxChannels], dryBuf_[kMaxChannels], spare_[kMaxChannels], quietBuf_[kMaxChannels];

    // the crossover blend (setCrossoverAmount): the settings on the message thread, their atomics, the audio side
    double xoHzSet_ = 150.0, xoAmountSet_ = 0.0, xoCleanDbSet_ = 0.0;
    bool   xoInvertSet_ = false, xoFits_ = true, alignFits_ = true;
    int    xoTrim_ = 0;                                         // the host trim (setCrossoverLag), the bench's
    int    xoRefOffset_ = 0;                                    // the reference offset (setCrossoverReferenceLag)…
    std::string xoPack_, xoRefPack_, xoRefFile_;                // …the pack, and the reference, it belongs to…
    double xoRefRate_ = 0.0;                                    // …and the samples it is in (the table's rate; 0 = the models')…
    std::map<std::string, int> xoRefTable_;                     // …and the relative table it was bound to, word for word
    bool   xoRefPending_ = false;                               // set with nothing loaded: the next pack's
    std::vector<double> modelRate_;                             // message thread: each model's own rate; NaN = not landed
    std::atomic<bool> xoInvert_ { false };
    std::unique_ptr<XoModels> xoModels_;                        // message thread owns…
    std::atomic<XoModels*> xoModelsRt_ { nullptr };             // …the audio thread reads
    std::vector<std::pair<std::unique_ptr<XoModels>, std::uint64_t>> xoRetired_;   // freed once the clock is past
    CrossoverBlend xo_;                                         // the mechanism; RigPlayer says when

    // stand-by: the request (message → audio) and what the audio thread made of it
    std::atomic<bool> standby_ { false }, standingBy_ { false };
    float fadeG_ = 1.0f, fadeStep_ = 1.0f;       // audio thread (and the two restarts): BypassFade's g and perSample
    bool  parkedRt_ = false;                     // audio thread: the stages are stopped and the device is not run

    // the scope tap: sized by prepare() (message thread, never beside process()), written by the audio thread,
    // read from any thread
    int scopeN_ = 0;
    std::size_t scopeCap_ = 0;
    std::unique_ptr<std::atomic<float>[]> scopeDry_, scopeWet_;
    std::vector<float> scopeIn_;                                    // audio thread: this block's dry, kept till the end
    std::uint64_t scopeW_ = 0;                                      // audio thread: samples written
    std::atomic<std::uint64_t> scopeClaim_ { 0 }, scopeWritten_ { 0 };
};

} // namespace felitronics::rigplayer