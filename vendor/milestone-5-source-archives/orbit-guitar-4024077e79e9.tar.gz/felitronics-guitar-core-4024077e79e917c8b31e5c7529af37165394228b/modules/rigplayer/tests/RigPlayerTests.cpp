// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

// The pack player (src/rigplayer), driven the way a hand drives it and checked without a sound card.
// The pack is written by namz's writer and read back by its canonical reader, so what the player is
// handed is what a plugin will be handed. The models are tiny Linear NAMs — a gain, or a pure delay —
// whose output IDENTIFIES them, so "which capture is sounding, how loud, and how far apart" are numbers
// read off the audio, not off a variable.

#include <felitronics_test.h>
// THE TEST SEAM in RigPlayer::process (FELITRONICS_RIGPLAYER_TEST_AFTER_LAW): called on every block right after the
// law has stepped and before either stage runs — the instant a native host's job thread, pre-empting the audio thread,
// could deliver a load the law has just asked for. Defined here, before the header, for this executable alone.
namespace felitronics::rigplayer { class RigPlayer; }
void afterLaw(felitronics::rigplayer::RigPlayer& player);
#define FELITRONICS_RIGPLAYER_TEST_AFTER_LAW(player) afterLaw(player)
#include <felitronics/rigplayer/RigPlayer.h>

#include <namz.h>
#include <namz_rig_load.h>
#include <namz_rig_write.h>

#include <cmath>
#include <cstdio>
#include <limits>
#include <functional>
#include <tuple>
#include <map>
#include <string>
#include <utility>
#include <vector>

using felitronics::test::approx;
using felitronics::test::group;
using felitronics::test::ok;
using namespace felitronics::rigplayer;

namespace {

constexpr double kFs = 48000.0;
constexpr int    kBlock = 256;

// A NAM that is a gain: Linear, receptive field 1, one weight. What comes out says which one it is.
std::string gainModel(double w) {
    char buf[256];
    std::snprintf(buf, sizeof buf,
        R"({"version":"0.5.0","architecture":"Linear","config":{"receptive_field":1,"bias":false,"implementation":"direct"},"weights":[%.6f],"sample_rate":48000})", w);
    return buf;
}

// A NAM that is a gain AND AN OFFSET: y = w*x + b. The offset is what makes this fixture worth
// having — it is the cheapest thing that is not a pure scalar, and a pure scalar cannot tell the
// player's two levels apart. Feed the network half as much and the offset is untouched (w*x/2 + b);
// halve the STAGE's output and the offset halves with everything else ((w*x + b)/2). So the mean of
// the output says which of the two was applied, and the release's central claim — input is drive,
// output is volume — finally has a test that a swap would fail.
std::string biasModel(double w, double b) {
    char buf[320];
    std::snprintf(buf, sizeof buf,
        R"({"version":"0.5.0","architecture":"Linear","config":{"receptive_field":1,"bias":true,"implementation":"direct"},"weights":[%.6f,%.6f],"sample_rate":48000})", w, b);
    return buf;
}

// The same gain WITH the loudness tag a real capture ships: the model's own metadata block, where it
// says how loud it came out of the hardware. The audio still says WHICH model this is; the tag says
// which one a read-out is looking at.
std::string taggedGainModel(double w, double loudnessDb) {
    char buf[320];
    std::snprintf(buf, sizeof buf,
        R"({"version":"0.5.0","architecture":"Linear","config":{"receptive_field":1,"bias":false,"implementation":"direct"},"weights":[%.6f],"sample_rate":48000,"metadata":{"loudness":%.6f}})", w, loudnessDb);
    return buf;
}

// A NAM that is a pure delay of `d` samples: the window's first tap is the oldest sample and its last
// the newest, so a weight on the first alone hands back what came in `d` samples ago.
std::string delayModel(int d) {
    std::string w = "[";
    for (int i = 0; i < d; ++i) w += "0.0,";
    w += "1.0]";
    return R"({"version":"0.5.0","architecture":"Linear","config":{"receptive_field":)" + std::to_string(d + 1)
         + R"(,"bias":false,"implementation":"direct"},"weights":)" + w + R"(,"sample_rate":48000})";
}

// A REAL WaveNet whose memory is as long as it says: one one-channel layer, kernel 2, one dilation.
// The weight order is rechannel; dilated conv (OLDEST tap, then newest) + bias; condition mixin;
// residual 1x1 + bias; head rechannel; head scale. The 1 goes on the OLDEST tap — that is what makes
// the network reach back `dilation` samples. With both convolution taps at zero (the shape the nam
// module's own RT fixture ships) the impulse response's last non-zero sample is 0 whatever field the
// config declares, which is a fixture blind to exactly the half this group exists to measure.
std::string waveNetDelayModel(int dilation) {
    return std::string(R"({"version":"0.5.0","architecture":"WaveNet","config":{"layers":[{"input_size":1,)")
         + R"("condition_size":1,"head_size":1,"head_bias":false,"channels":1,"kernel_size":2,"dilations":[)"
         + std::to_string(dilation)
         + R"(],"activation":"Tanh","gated":false}],"head_scale":1.0},"weights":[1,1,0,0,1,0,0,1,1],)"
         + R"("sample_rate":48000})";
}

std::vector<std::byte> bytesOf(const std::string& s) {
    const auto* p = reinterpret_cast<const std::byte*>(s.data());
    return { p, p + s.size() };
}

std::vector<std::byte> packed(const std::string& nam) {
    const auto z = namz::pack(nam.data(), nam.size());
    const auto* p = reinterpret_cast<const std::byte*>(z.data());
    return { p, p + z.size() };
}

// THE DEVICE UNDER TEST. Two axes: a channel switch and a gain dial captured at 60, 150 and 240 of a
// 300-degree sweep on the green channel, one capture on red. The bottom of the dial is a LINK — gain 0
// plays the 60 capture fed 6 dB softer — spelled the way the pack spells it: a second files[] entry
// pointing at the same file with an input_db. One tone knob as bands (a high shelf after the model),
// one as a curve (a bass lift before it), and a blend knob whose dry path is a wire 6 dB down.
namz::rig::Rig testRig(int polarity = 1) {
    namz::rig::Rig rig;
    rig.rigId = "test-rig"; rig.name = "Test Pedal"; rig.modeledBy = "the test";
    namz::rig::Stage st;
    st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam"; st.slot = "pedal";
    st.make = "Darwin's Cat"; st.model = "Test Pedal"; st.gearType = "pedal";
    auto& d = st.device;
    d.family = "Test Pedal"; d.rigId = "test-rig"; d.slot = "pedal";
    namz::rig::Control ch; ch.name = "channel"; ch.role = namz::rig::Role::Channel; ch.values = { "green", "red" };
    namz::rig::Control g;  g.name = "gain";     g.role = namz::rig::Role::Gain;    g.values = { "60", "150", "240" }; g.sweep = 300;
    d.controls = { ch, g };
    const auto file = [](const char* id, const char* chan, const char* gain, double inDb = 0.0) {
        namz::rig::FileEntry f; f.id = id; f.settings = { { "channel", chan }, { "gain", gain } }; f.inputDb = inDb; return f;
    };
    d.files = { file("g60", "green", "60"), file("g150", "green", "150"), file("g240", "green", "240"),
                file("r150", "red", "150"), file("g60", "green", "0", -6.0) };

    // `tone`: one band after the model, +6 dB at the top of the travel, -6 at the bottom, zero at 150.
    namz::rig::Tone tone;
    tone.name = "tone"; tone.sweep = 300; tone.placement = "post"; tone.reference = "150"; tone.defaultValue = "150";
    namz::rig::Section hs; hs.kind = namz::rig::SectionKind::HighShelf; hs.hz = 3000.0; hs.q = 0.7;
    hs.dbAtMin = -6.0; hs.dbAtMax = 6.0;
    tone.sections = { hs };
    // `bass`: a curve before the model — flat at 0 (the reference), and at 300 a +6 dB lift that runs
    // out between 200 Hz and 2 kHz, on a 25-point grid of its own.
    namz::rig::Tone bass;
    bass.name = "bass"; bass.sweep = 300; bass.placement = "pre"; bass.reference = "0"; bass.defaultValue = "0";
    bass.grid.fLo = 20.0; bass.grid.fHi = 20000.0; bass.grid.points = 25;
    bass.trusted.levels = 1;
    const auto grid = felitronics::lineareq::logFreqGrid(20.0, 20000.0, 25);
    namz::rig::TonePosition p0; p0.value = "0"; p0.norm = 0.0; p0.db.assign(25, 0.0);
    namz::rig::TonePosition p1; p1.value = "300"; p1.norm = 1.0;
    for (const double f : grid)
        p1.db.push_back(f <= 200.0 ? 6.0 : f >= 2000.0 ? 0.0 : 6.0 * (1.0 - std::log(f / 200.0) / std::log(10.0)));
    bass.positions = { p0, p1 };
    st.tone = { tone, bass };

    // `mix`: wet at 300 (where the models were captured), dry at 0; the dry path is flat, 6 dB down.
    namz::rig::Blend mix;
    mix.name = "mix"; mix.sweep = 300; mix.reference = "300"; mix.dryEnd = "0"; mix.defaultValue = "300";
    mix.polarity = polarity; mix.dryLevelDb = -6.0;
    mix.grid.fLo = 20.0; mix.grid.fHi = 20000.0; mix.grid.points = 25;
    mix.dryDb.assign(25, 0.0);
    namz::rig::BlendPosition dry; dry.value = "0";   dry.norm = 0.0; dry.dryDb = 0.0;    dry.wetDb = -120.0;
    namz::rig::BlendPosition wet; wet.value = "300"; wet.norm = 1.0; wet.dryDb = -120.0; wet.wetDb = 0.0;
    mix.positions = { dry, wet };
    st.blend = { mix };

    rig.chain = { st };
    return rig;
}

// The same rig, as a plugin would meet it: written by the pack writer, read by the canonical reader.
namz::rig::Rig throughTheFormat(const namz::rig::Rig& rig, bool* okOut = nullptr) {
    return namz::rig::loadRigManifest(namz::rig::writeManifest(rig), okOut);
}

// The same device with the pack's own two levels written on the stage, through the format as well.
namz::rig::Rig levelled(double inDb, double outDb) {
    auto r = testRig();
    r.chain[0].inputDb = inDb; r.chain[0].outputDb = outDb;
    return throughTheFormat(r);
}

struct Bench {
    RigPlayer p;
    std::map<std::string, std::vector<std::byte>> files;
    int fetches = 0;
    double phase = 0.0;
    double fs = kFs;

    Bench(const namz::rig::Rig& rig, int channels = 1, double sampleRate = kFs) : fs(sampleRate) {
        files["g60"]  = packed(gainModel(0.25));           // packed, as the pack ships them…
        files["g150"] = packed(gainModel(0.5));
        files["g240"] = bytesOf(gainModel(1.0));           // …and raw, which the stage takes as well
        files["r150"] = bytesOf(gainModel(0.75));
        felitronics::test::run (p.prepare(fs, kBlock, channels));
        load(rig);
    }
    void load(const namz::rig::Rig& rig) {
        p.load(rig, [this](const std::string& id) {
            ++fetches;
            const auto it = files.find(id);
            return it == files.end() ? std::vector<std::byte> {} : it->second;
        });
    }

    // Run the transport on a sine and read the RMS of channel `channel` over the last `measure` blocks
    // — RMS, because a sampled peak is off by up to a fraction of a sample. Channel 1, when there is
    // one, gets the same sine at `aR`. `serviceHere()` after every block — a host's timer, with the
    // load job run right here rather than on a worker.
    double rms(double hz, double a, int blocks = 48, int measure = 32, int channel = 0, double aR = 0.0) {
        const int nch = p.channels();
        std::vector<float> l((std::size_t) kBlock), r((std::size_t) kBlock);
        double sum = 0.0; long n = 0;
        for (int b = 0; b < blocks + measure; ++b) {
            for (int i = 0; i < kBlock; ++i) {
                const double s = std::sin(phase);
                phase += 2.0 * 3.14159265358979323846 * hz / fs;
                if (phase > 2.0 * 3.14159265358979323846) phase -= 2.0 * 3.14159265358979323846;
                l[(std::size_t) i] = (float) (a * s);
                r[(std::size_t) i] = (float) (aR * s);
            }
            float* io[2] { l.data(), r.data() };
            felitronics::test::run (p.process(io, nch, kBlock));
            p.serviceHere();
            if (b >= blocks) {
                const auto& x = channel == 0 ? l : r;
                for (const float v : x) { sum += (double) v * v; ++n; }
            }
        }
        return std::sqrt(sum / (double) std::max(1L, n));
    }
    // A measurement AGAINST the input: the chain's gain at `hz`, linear.
    double gainAt(double hz, double a = 0.1, int blocks = 48, int measure = 32) {
        return rms(hz, a, blocks, measure) / (a / std::sqrt(2.0));
    }
};

double db(double lin) { return 20.0 * std::log10(std::max(1e-12, lin)); }

// The test device with captures that REMEMBER: the 150 and the 240 are WaveNets reaching back 300 and
// 700 samples, so a model not fed its field sounds wrong and a second network is real work. The 60
// stays a gain, a capture with no field at all.
constexpr long kField150 = 300, kField240 = 700;   // the dilations; a kernel-2 WaveNet's field is one more
void withFields(Bench& b, const namz::rig::Rig& rig) {
    b.files["g150"] = bytesOf(waveNetDelayModel((int) kField150));
    b.files["g240"] = bytesOf(waveNetDelayModel((int) kField240));
    b.p.unload();
    b.load(rig);
}
// The blocks a resting capture's DRAIN can span: NamStage feeds a lane it is no longer handed its receptive field of
// silence (no tail for a WaveNet), and that is a network running.
int drainBlocks(long dilation) { return (int) ((dilation + 1 + kBlock - 1) / kBlock); }

// A host, one block at a time: the audio callback, then the timer — every load job COUNTED as it is
// taken, then run right here. The guitar is a function of the absolute sample index, so two hosts
// started together feed their players the same signal, sample for sample.
struct Host {
    Bench& b;
    int jobs = 0;
    std::string took;                         // "slot:fileId " per job, in order
    long long k = 0;
    std::vector<float> l, r;
    explicit Host(Bench& bench) : b(bench), l((std::size_t) kBlock), r((std::size_t) kBlock) {}
    const std::vector<float>& block() {
        for (int i = 0; i < kBlock; ++i) {
            const double t = (double) (k * kBlock + i) / b.fs;
            const float s = (float) (0.2 * std::sin(2.0 * 3.14159265358979323846 * 220.0 * t)
                                   + 0.05 * std::sin(2.0 * 3.14159265358979323846 * 1730.0 * t));
            l[(std::size_t) i] = s; r[(std::size_t) i] = -s;
        }
        float* io[2] { l.data(), r.data() };
        felitronics::test::run (b.p.process(io, b.p.channels(), kBlock));
        b.p.service();
        while (auto job = b.p.takeLoadJob()) {
            ++jobs;
            took += std::to_string(job->slot) + ":" + job->fileId + " ";
            b.p.deliver(RigPlayer::run(std::move(*job)));
        }
        ++k;
        return l;
    }
    void play(int blocks) { for (int i = 0; i < blocks; ++i) block(); }
    void forget() { jobs = 0; took.clear(); b.p.clearCounters(); }
};

// The seam's other half: on the one player a test arms it for, a load the law asks for is taken and delivered INSIDE
// the block that asked — what an audio thread pre-empted for as long as a prepareModel takes would meet.
RigPlayer* gDeliverInside = nullptr;
int        gDeliveredInside = 0;
}  // namespace
std::function<void(RigPlayer&)> gAfterLawHook;               // a test's own step in the same seam
void afterLaw(felitronics::rigplayer::RigPlayer& player) {
    if (gAfterLawHook) gAfterLawHook(player);
    if (&player != gDeliverInside) return;
    while (auto job = player.takeLoadJob()) { ++gDeliveredInside; player.deliver(RigPlayer::run(std::move(*job))); }
}
namespace {

// Stretches of silence at least `minRun` samples long — a dip is one; a sine crossing zero is not. Silence
// is below -240 dBFS rather than exactly zero: the dip is a GAIN on the models' mix, and the post-model
// tone after it (a band at its reference) rings its own rounding out at some 1e-19 for the rest of the
// block in which the gain arrives.
struct Silence { int runs = 0; long first = -1, last = -1; };
Silence silenceIn(const std::vector<float>& y, int minRun = 32) {
    Silence s;
    long start = -1;
    for (long i = 0; i <= (long) y.size(); ++i) {
        const bool z = i < (long) y.size() && std::abs(y[(std::size_t) i]) <= 1.0e-12f;
        if (z && start < 0) start = i;
        if (! z && start >= 0) {
            if (i - start >= minRun) { if (s.runs == 0) s.first = start; s.last = i - 1; ++s.runs; }
            start = -1;
        }
    }
    return s;
}

// Sample for sample, from `from` on: the count of samples that differ (== on floats, so -0 is 0).
long differing(const std::vector<float>& a, const std::vector<float>& b, long from) {
    long n = 0;
    for (long i = std::max(0L, from); i < (long) std::min(a.size(), b.size()); ++i)
        if (a[(std::size_t) i] != b[(std::size_t) i]) ++n;
    return n;
}

// What the test rig's high shelf (3 kHz, Q 0.7) reads between 10 kHz and 100 Hz at `gainDb`, by the
// format's own formula at this rate — the claim is "the player applies that formula", not "a shelf is
// exactly its nominal gain 1.7 octaves up", which it is not.
double shelfDb(double gainDb, double fs) {
    const auto q = felitronics::rigplayer::designSection(felitronics::rigplayer::SectionKind::HighShelf, 3000.0, gainDb, 0.7, fs);
    return felitronics::rigplayer::sectionMagnitudeDb(q, 10000.0, fs) - felitronics::rigplayer::sectionMagnitudeDb(q, 100.0, fs);
}

} // namespace


// A STAGED DELAY TRAVELS WITH ITS CAPTURE. The request (which capture each slot wants) and the staged delay are two
// publications; a dial edit landing between the audio thread's reads of them — here, in the seam after the law — used
// to let the delay of the capture now asked for retime the capture still playing.
void stagedDelayCarriesItsCapture() {
    group("a staged delay is published with its capture: an edit between the request and the delay retimes nothing it should not");
    auto field = [](int d) {
        std::string w = "[";
        for (int i = 0; i < 40; ++i) w += (i == d ? "1.0" : "0.0") + std::string(i < 39 ? "," : "]");
        const std::string j = R"({"version":"0.5.0","architecture":"Linear","config":{"receptive_field":40,"bias":false,"implementation":"direct"},"weights":)"
                            + w + R"(,"sample_rate":48000})";
        const auto* q = reinterpret_cast<const std::byte*>(j.data());
        return std::vector<std::byte>(q, q + j.size());
    };
    std::map<std::string, std::vector<std::byte>> files { { "early", field(0) }, { "mid", field(20) }, { "late", field(10) } };
    namz::rig::Rig r;
    namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam"; st.slot = "pedal";
    namz::rig::Control g; g.name = "gain"; g.role = namz::rig::Role::Gain; g.values = { "60", "150", "240" }; g.sweep = 300;
    st.device.controls = { g };
    for (const auto& [id, at, lag] : std::vector<std::tuple<std::string, std::string, int>> { { "early", "60", 0 }, { "mid", "150", 20 }, { "late", "240", 10 } }) {
        namz::rig::FileEntry f; f.id = id; f.settings = { { "gain", at } }; f.lagSamples = lag; st.device.files.push_back(f);
    }
    r.chain = { st };
    RigPlayer p;
    felitronics::test::run(p.prepare(48000.0, 128, 1));
    p.setNormalize(false);
    p.load(r, [&files](const std::string& id) { return files.at(id); });
    (void) p.setDial("gain", 172.5);                         // slot 0 plays late (delay 10), slot 1 mid
    std::vector<float> x(128);
    long at = 0;
    auto block = [&] {
        for (int i = 0; i < 128; ++i) x[(std::size_t) i] = (float) (0.3 * std::sin(0.02 * (double) (at + i)));
        at += 128;
        float* io[1] { x.data() };
        felitronics::test::run(p.process(io, 1, 128));
        p.serviceHere();
    };
    for (int k = 0; k < 120; ++k) block();
    const bool playing = p.heldFileId(0) == "late" && p.liveMix() > 0.05f && p.liveMix() < 0.95f && p.appliedSlotDelay(0) == 10;
    bool fired = false;
    gAfterLawHook = [&] (RigPlayer& q) { if (&q == &p && ! fired) { fired = true; (void) q.setDial("gain", 140.0); } };
    block();
    gAfterLawHook = nullptr;
    ok(playing && fired && p.heldFileId(0) == "late" && p.appliedSlotDelay(0) == 10, "slot 0 still playing late after "
       "the edit: its delay " + std::to_string(p.appliedSlotDelay(0)) + " (10 is late's; 20 would be early's)");
}

int main() {
    std::printf("felitronics::rigplayer::RigPlayer tests\n");
    stagedDelayCarriesItsCapture();

    group("law 11b: prepare() is binding — it used to CLAMP the width");
    {
        // `prepare(48000, 256, 4)` was accepted as a 2-channel player, after which every
        // `process(io, 4, n)` was refused forever and the caller learned of it only at the second call.
        // That is the defect law 11(b)'s own text describes, in this file.
        RigPlayer rp;
        ok(! rp.prepare(kFs, 256, 4), "prepare(numChannels = 4) is REFUSED (the player's ceiling is 2)");
        ok(! rp.prepare(kFs, 256, 0), "prepare(numChannels = 0) is REFUSED");
        ok(! rp.prepare(kFs, 0,   2), "prepare(maxBlock = 0) is REFUSED");
        ok(  rp.prepare(kFs, 256, 2), "...and a width it can honour is accepted");
        // DISARM COMES FIRST: a refused RE-prepare must not leave the previous build answering.
        ok(! rp.prepare(kFs, 256, 4), "a refused RE-prepare");
        ok(! rp.prepared(),           "...leaves the player unprepared, not armed on the old build");
        std::vector<float> l(64, 0.0f), r(64, 0.0f);
        float* io2[2] { l.data(), r.data() };
        ok(! rp.process(io2, 2, 64),  "...so process() refuses too");
    }

    group("a plane that stops playing and plays again brings nothing back with it");
    {
        // The models run on the planes they are GIVEN, and so do the per-slot alignment delay lines
        // beside them. A plane the host stops handing over keeps its `lagTail_` frozen rather than
        // draining it, and hands it back when the host widens again. The tail is EXACTLY as many samples
        // as the slot's delay, so how loud it is depends on where in the waveform the plane was taken —
        // which makes a single measurement a lower bound and not a number. The ceiling is derivable: the
        // tail sits after the slot's gain and before the blend, so it cannot exceed amplitude x slot
        // weight, here 0.5 x 0.5 = 0.25. A sweep of all 218 leaving phases at SAMPLE resolution reaches
        // 0.249986 — 99.99% of that ceiling, so the number is 0.25 (-12.0 dBFS) and nothing can beat it.
        // All of it lands in the first three samples of the return, and none on the plane that stayed.
        //
        // 🔴 THAT WAS THE DELAY LINE'S CEILING AND THIS GROUP USED TO SPEND IT ON BOTH HALVES. The
        // models' own state is a different shape and 3.8x larger — BOTH slots freeze, so the weights sum
        // instead of picking, and a frozen rate-matcher is not a replay (its phase rows are normalised by
        // their SUM, so their modulus exceeds one). Derived and attained: 0.949383 at 44.1 kHz, reached
        // to 100.00% by the sign pattern of the worst return row, where a swept sine reaches 55%.
        // See RigPlayer::process for the table and the formula.
        //
        // 🔴 AND THE FIXTURE WAS BLIND TWICE OVER, each blindness hiding one half.
        //   · kFs = 48000 is the ONE rate at which no rate-matcher is installed, so the resampler half
        //     could not appear at all: 0.518588 out of digital silence at 44.1 kHz, on this very group,
        //     with one token changed. Hence the rate sweep.
        //   · a capture with a one-sample field cannot show the MODEL half: at 48 kHz a 2001-tap one
        //     read 0.499533 with a 2003-sample tail while the memoryless one read a clean zero. Hence
        //     the second shape — and it is a real WaveNet with a real 1024-sample memory, not a
        //     declared one: a dilated tap costs the same nine scalars at any distance, and the weight
        //     goes on the OLDEST tap because with both taps at zero the network forgets after one
        //     sample however long a field it advertises.
        //
        // The fixture still measures the DELAY LINE too: two memoryless gain models with the alignment
        // table set by hand, so on that shape the only per-plane state in the path is the tail.
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control g; g.name = "gain"; g.role = namz::rig::Role::Gain; g.values = { "60", "240" }; g.sweep = 300;
        st.device.controls = { g };
        namz::rig::FileEntry fa; fa.id = "early"; fa.settings = { { "gain", "60" } };
        namz::rig::FileEntry fc; fc.id = "late";  fc.settings = { { "gain", "240" } };
        st.device.files = { fa, fc };
        r.chain = { st };

        struct Shape { const char* name; std::string json; int field; };
        const Shape shapes[] { { "a memoryless capture", gainModel(1.0), 1 },
                               { "a 1024-sample WaveNet", waveNetDelayModel(1023), 1024 } };

        for (const auto& shape : shapes) {
        std::map<std::string, std::vector<std::byte>> files {
            { "early", bytesOf(shape.json) }, { "late", bytesOf(shape.json) } };
        // EVERY audio rate, because 48000 is the only one where the rate-matcher is absent.
        for (const double fs : { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0 }) {
        // BOTH SLOT ASSIGNMENTS. delayOf() is maxLag - lag, so one table always puts the delay on slot 0
        // and the other on slot 1. A version of this test that used only the first passed with a fix that
        // cleared slot 0 alone — the mutation survived the whole suite, 247 checks, because slot 1 never
        // carried a delay in it.
        for (int flip = 0; flip < 2; ++flip)
        for (int narrowFirst = 1; narrowFirst >= 0; --narrowFirst) {
        AlignmentTable table;
        table.lagByFile = flip ? std::map<std::string, int> { { "early", 3 }, { "late", 0 } }
                               : std::map<std::string, int> { { "early", 0 }, { "late", 3 } };
        table.sampleRate = fs;

        Bench b(r, 2, fs);
        b.files = files;
        b.p.setAlignment(table);
        b.p.setDial("gain", 150.0);
        const std::string at = std::string(shape.name) + " at " + std::to_string((int) fs) + " Hz";

        std::vector<float> L((std::size_t) kBlock), R((std::size_t) kBlock);
        float* io[2] { L.data(), R.data() };
        double phase = 0.0, charged = 0.0;
        // Long enough for the crossfade to settle AND for a plane to fill the capture's memory at THIS
        // rate — the field is model-rate samples, so a 192 kHz host needs four times as many of its own.
        const int blocks = 96 + (int) std::ceil((double) shape.field * fs / 48000.0 / (double) kBlock);
        for (int k = 0; k < blocks; ++k) {
            for (int i = 0; i < kBlock; ++i) {
                L[(std::size_t) i] = 0.0f;
                R[(std::size_t) i] = (float) (0.5 * std::sin(phase));
                phase += 2.0 * 3.14159265358979 * 220.0 / fs;
            }
            felitronics::test::run (b.p.process(io, 2, kBlock)); b.p.serviceHere();
            for (float v : R) charged = std::fmax(charged, (double) std::fabs(v));
        }
        ok(b.p.appliedSlotDelay(flip) > 0,
           "precondition: THIS pass's slot carries the delay, so its tail holds samples — " + at);
        ok(! b.p.slotCold(flip), "precondition: and that slot is awake, so it is the one contributing — " + at);
        ok(charged > 0.1, "precondition: the plane under test really was playing — " + at);

        // THE GAP. `narrowFirst` picks its WIDTH: 1 plane (the P18 case — the plane under test keeps
        // playing zeros while its neighbour stops) or 0 planes (the P20 case — nothing plays at all).
        // Both are gaps under law 11a, because both carry samples. Only the zero-width pass can see the
        // second defect: with one plane still playing, the plane under test drains itself and there is
        // nothing left to replay, which is why folding this into the existing loop caught nothing.
        const int gapWidth = narrowFirst ? 1 : 0;
        for (int k = 0; k < blocks; ++k) { std::fill(L.begin(), L.end(), 0.0f); std::fill(R.begin(), R.end(), 0.0f);
                                        felitronics::test::run (b.p.process(io, gapWidth, kBlock)); b.p.serviceHere(); }

        // FINITENESS BESIDE THE PEAK: std::fmax IGNORES a NaN, so a return poisoned with them reads a
        // peak of exactly zero and passes. Measured — a drain writing NaNs passed every row here.
        double worst = 0.0; bool finite = true;
        for (int k = 0; k < blocks; ++k) {
            std::fill(L.begin(), L.end(), 0.0f); std::fill(R.begin(), R.end(), 0.0f);
            felitronics::test::run (b.p.process(io, 2, kBlock)); b.p.serviceHere();
            for (float v : R) { worst = std::fmax(worst, (double) std::fabs(v)); finite = finite && std::isfinite(v); }
            for (float v : L) { worst = std::fmax(worst, (double) std::fabs(v)); finite = finite && std::isfinite(v); }
        }
        ok(finite && worst == 0.0, std::string("silence in, FINITE exact zero out after a ") + (narrowFirst ? "NARROW" : "ZERO-WIDTH")
                         + " gap — " + at + " (the ceiling here is 0.949383 = -0.45 dBFS, and this used to"
                         " read 0.518588 at 44.1 kHz and 0.499533 at 48 kHz)");
        }
        }
        }
    }

    group("a slot the LAW puts to sleep brings nothing back with it either");
    {
        // 🔴 THE SECOND WAY THIS PLAYER STOPS CLOCKING A STAGE. A plane the host takes away is one; a
        // slot the blend law puts to sleep is the other, and it used to be `if (run[s]) nam_[s].process`
        // — the stage not called at all. Measured on this fixture before the fix: after two seconds at
        // rest the sleeping slot held the tone, and a turn on a SILENT input replayed it at per-block
        // peaks 0.114 · 0.22 · 0.366 · 0.486 · 0.5 · 0.5 · 0.5 · 0.5 — 0.500000 out of DIGITAL SILENCE,
        // for exactly one receptive field, under the law's own 0.25-per-call ramp.
        //
        // 🔴 AND THE FIXTURE HAS TO BE BUILT AGAINST TWO TRAPS, both of which read a clean zero:
        //   · THREE knots, not two. With two files each knot assigns the SAME capture to both slots, so
        //     a turn SWAPS the sleeping slot's backend (a fresh instance) instead of WAKING it, and a
        //     swap has nothing to leak. The first version of this measurement read 0.000000 for that
        //     reason alone and the mechanism was called "not reproducible".
        //   · the turn happens on DIGITAL SILENCE. Turning while the tone still plays hides the replay
        //     as a discontinuity in the sound rather than showing it out of nothing.
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control g; g.name = "gain"; g.role = namz::rig::Role::Gain;
        g.values = { "60", "150", "240" }; g.sweep = 300;
        st.device.controls = { g };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        r.chain = { st };

        // TWO SHAPES, and the second is the one that can actually FAIL. With a 2001-tap capture the
        // blend law's own warm-up (`warmFor` = field + latency + maxBlock) is longer than the memory, so
        // a woken slot is inaudible while it drains anyway and the row passes either way — it pins the
        // historical 0.500000 rather than the fix. A MEMORYLESS capture reports no field at all, so the
        // warm-up is ZERO and nothing masks the leak; what freezes there is the rate-matcher, which is
        // why that row runs at 44.1 kHz, where one is installed. Two mutations reverting this file to
        // `if (run[s]) nam_[s].process(...)` survived the whole suite until this row existed.
        // 🔴 AND BOTH SLOT INDICES, for the same reason the gap group runs both alignment tables: a
        // fixture that only ever puts the sleeping slot on one index passes a fix that clears the other.
        // Measured — a mutation reverting slot 1's line alone SURVIVED the whole suite until the second
        // direction existed. Which index sleeps is decided by the law, not by us, so the pass asserts
        // COVERAGE of both rather than assuming it.
        // WHICH index sleeps is the law's business, and it is not symmetric: from a fresh player the
        // first landing takes slot 0, so parking on the middle knot always sleeps slot 0. Slot 1 only
        // ever sleeps after a SECOND landing, which is what the `then` column arranges — park, turn once
        // so the middle capture's slot goes quiet, and wake it by turning back. Both turns are load-free
        // (`modelLoads()` is asserted below), so both are WAKES rather than swaps.
        // ALL THREE knots carry the SAME capture, so whichever slot the law puts to sleep is holding the
        // shape under test. Handing one knot the long capture and the others a gain looked tidier and was
        // a tautology: the precondition read `slotCold(0) ? 0 : 1` and then asserted that slot was cold,
        // which says nothing about WHAT it holds — measured, the middle-knot pass slept a slot holding a
        // different file than the one the fixture had loaded, so two of its four rows tested nothing.
        struct Cold { const char* name; std::string parked; double then; double wake; double fs; };
        const Cold cases[] {
            { "a 2001-tap capture", delayModel(2000), -1.0, 200.0, kFs },
            { "a 2001-tap capture, one landing further on, so the OTHER slot sleeps",
                                    delayModel(2000), 240.0, 150.0, kFs },
            { "a MEMORYLESS capture, where no warm-up masks it", gainModel(1.0), -1.0, 200.0, 44100.0 },
            { "a MEMORYLESS capture, one landing further on",    gainModel(1.0), 240.0, 150.0, 44100.0 } };
        bool sleptOn[2] { false, false };
        for (const auto& c : cases) {
        Bench b(r, 1, c.fs);
        b.files = { { "early", bytesOf(c.parked) }, { "mid", bytesOf(c.parked) },
                    { "late",  bytesOf(c.parked) } };
        b.load(r);
        b.p.setBlendShape({ 0.5, 0.0 });                               // STEP: one capture at a time
        b.p.setDial("gain", 150.0);                                    // …park on the middle knot

        std::vector<float> x((std::size_t) kBlock);
        float* io[1] { x.data() };
        double phase = 0.0, charged = 0.0;
        const int rest = (int) std::ceil(2.0 * c.fs / kBlock);          // kColdAfterSeconds is 2 s by default
        for (int k = 0; k < 2 * (rest + 60); ++k) {
            if (c.then >= 0.0 && k == rest + 60) b.p.setDial("gain", c.then);
            for (int i = 0; i < kBlock; ++i) {
                x[(std::size_t) i] = (float) (0.5 * std::sin(phase));
                phase += 2.0 * 3.14159265358979323846 * 220.0 / c.fs;
            }
            felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.serviceHere();
            for (float v : x) charged = std::fmax(charged, (double) std::fabs(v));
        }
        // WHICH capture the sleeping slot holds is the thing this group is about, and reading the index
        // off `slotCold` alone makes the precondition a tautology — it says a slot is asleep, not that
        // the slot holding the PARKED capture is. `held()` names the model id, so the assertion below
        // is about identity rather than about which of the two happened to be cold.
        const int late = b.p.slotCold(0) ? 0 : 1;
        sleptOn[(std::size_t) late] = true;
        ok(charged > 0.1, std::string("precondition: the tone really played — ") + c.name);
        ok(b.p.slotCold(late) && ! b.p.slotCold(late ^ 1) && ! b.p.heldFileId(late).empty(),
           std::string("precondition: slot ") + std::to_string(late) + " is asleep holding "
           + b.p.heldFileId(late) + ", the other awake — " + c.name);
        ok(b.p.modelLoads() == 2, std::string("precondition: two captures were fetched — the turn below WAKES"
                                              " a slot, it does not swap one (a swap cannot leak, and that is"
                                              " the trap) — ") + c.name);

        // DIGITAL SILENCE, long enough that a slot which is being clocked has drained. 8 blocks is
        // 2048 samples against a 2000-sample memory.
        // The first blocks of silence still carry the chain's own LATENCY tail — 61 samples at 44.1 kHz,
        // where the rate-matcher is installed — AND the AWAKE slot's own memory, which is 2000 samples
        // here because every knot carries the same capture. So the reading starts past both. Measuring
        // from the first block reads the tone leaving, not the slot holding anything.
        float before = 0.0f;
        const int hush = 16 + 2 * (2001 / kBlock);           // past the AWAKE slot's own memory and latency
        for (int k = 0; k < hush; ++k) {
            std::fill(x.begin(), x.end(), 0.0f);
            felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.serviceHere();
            if (k >= hush / 2) for (float v : x) before = std::max(before, std::abs(v));
        }
        ok(before == 0.0f, std::string("precondition: silence in, silence out BEFORE the turn — ") + c.name);

        b.p.setDial("gain", c.wake);                                   // …and the turn WAKES it, on silence
        float worst = 0.0f; bool finite = true;
        for (int k = 0; k < 60; ++k) {
            std::fill(x.begin(), x.end(), 0.0f);
            felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.serviceHere();
            for (float v : x) { worst = std::max(worst, std::abs(v)); finite = finite && std::isfinite(v); }
        }
        ok(finite && worst == 0.0f, std::string("silence in, FINITE exact zero out when a SLEEPING slot wakes (was 0.500000"
                                      " — a whole receptive field of the tone it was holding when it fell"
                                      " asleep) — ") + c.name);
        ok(b.p.modelLoads() == 2, std::string("…and nothing was loaded for the turn: a wake, not a swap — ") + c.name);
        }
        ok(sleptOn[0] && sleptOn[1], "precondition on the PASS: both slot indices took a turn at sleeping,"
                                     " so a fix that clears one of them cannot pass this group");
    }

    group("the rig round-trips through the pack writer and the canonical reader");
    bool okManifest = false;
    const auto rig = throughTheFormat(testRig(), &okManifest);
    {
        ok(okManifest, "the writer's manifest is a manifest to the reader");
        ok(rig.chain.size() == 1 && rig.chain[0].kind == namz::rig::StageKind::Nam, "one NAM stage");
        const auto& st = rig.chain[0];
        ok(st.device.files.size() == 5, "five file entries, the link among them");
        ok(st.device.files.size() == 5 && st.device.files[4].id == "g60" && st.device.files[4].inputDb == -6.0,
           "the link is a second entry for the same file, with its input_db");
        ok(st.tone.size() == 2, "both tone knobs survive");
        ok(st.tone.size() == 2 && st.tone[0].sections.size() == 1 && st.tone[0].positions.empty(), "the band knob is bands");
        ok(st.tone.size() == 2 && st.tone[1].positions.size() == 2 && st.tone[1].sections.empty(), "the curve knob is a curve");
        ok(st.blend.size() == 1 && st.blend[0].positions.size() == 2, "the blend knob and its two ends");
        ok(crossfadeDial(st.device) != nullptr && crossfadeDial(st.device)->name == "gain", "the gain dial is the crossfade axis");
    }
    const auto& dev = rig.chain[0].device;

    group("selection: which files sound where (pure)");
    {
        Settings green { { "channel", "green" }, { "gain", "150" } };
        auto s = select(dev, green, "gain", 150.0);
        ok(s.knots.size() == 4, "four knots on green: the link at 0, then 60, 150, 240");
        ok(s.fileA == 1 && s.fileB == 2 && s.mixB == 0.0,
           "at 150 exactly the pair is 150 and 240 with nothing of 240: the neighbour is named, so it can be warm");
        s = select(dev, green, "gain", 200.0);
        ok(s.fileA == 1 && s.fileB == 2, "at 200 the pair is 150 and 240");
        approx(s.mixB, 50.0 / 90.0, 1e-9, "…mixed by angle: 50 of the 90 degrees between them");
        auto plan = slotPlan(s, dev);
        ok(plan.file[0] == 1 && plan.file[1] == 2, "150 is the third knot (even) so it keeps slot 0");
        approx(plan.targetB, 50.0 / 90.0, 1e-9, "…and slot 1's weight is the 240 share");
        s = select(dev, green, "gain", 30.0);
        ok(s.fileA == 4 && s.fileB == 0, "at 30 the pair is the link (a knot at 0) and the 60 capture");
        plan = slotPlan(s, dev);
        approx(plan.inputDb[0], -6.0, 1e-9, "…the link's slot is fed 6 dB softer");
        approx(plan.inputDb[1], 0.0, 1e-9, "…the capture's is not");
        s = select(dev, green, "gain", 300.0);
        ok(s.fileA == 2 && s.fileB == 2, "past the top capture it plays alone");
        approx(s.extendDb, 3.0, 1e-9, "…driven 0.05 dB per degree harder: 60 degrees, 3 dB");
        Settings red { { "channel", "red" }, { "gain", "150" } };
        s = select(dev, red, "gain", 240.0);
        ok(s.knots.size() == 1 && s.fileA == 3 && s.fileB == 3, "red has one knot; at 240 it plays alone");
        approx(s.extendDb, 4.5, 1e-9, "…90 degrees past it");
        s = select(dev, green, "", 150.0);
        ok(s.fileA == 1 && s.fileB == 1, "with no dial the panel's own file plays");
    }

    group("the law asks and service answers: silent until fed, then sounding");
    {
        Bench b(rig);
        ok(b.p.loaded(), "loaded");
        ok(b.p.settings().at("channel") == "green" && b.p.settings().at("gain") == "150",
           "the pack's defaults: first channel, the middle of the gain sweep");
        approx(b.p.dialDegrees(), 150.0, 1e-9, "…and the dial stands there");
        // No service: nothing can land, and the law keeps the unfed slots silent.
        std::vector<float> x((std::size_t) kBlock, 0.1f);
        float* io[1] { x.data() };
        for (int i = 0; i < 8; ++i) felitronics::test::run (b.p.process(io, 1, kBlock));
        double e = 0.0; for (const float v : x) e += v * v;
        ok(e == 0.0, "before any model lands the output is silence, not the raw DI");
        ok(b.fetches == 0, "…and nothing was fetched: the law asks, the host answers");
        approx(b.gainAt(1000.0), 0.5, 0.01, "at 150 the 0.5 capture plays");
        ok(b.fetches == 2, "two fetches: the capture sounding, and its neighbour above, warm at zero weight");
        ok(b.p.heldFileId(0) == "g150" && b.p.heldFileId(1) == "g240", "slot 0 holds it, slot 1 the neighbour");
    }

    group("the load as a job: taken once, run anywhere, delivered back — and a stale one dropped");
    {
        Bench b(rig);
        std::vector<float> x((std::size_t) kBlock, 0.1f);
        float* io[1] { x.data() };
        felitronics::test::run (b.p.process(io, 1, kBlock));                                  // the law asks
        b.p.service();                                               // …and service does not load
        ok(b.fetches == 0, "service() fetches nothing: the ask is work for the host");
        auto job = b.p.takeLoadJob();
        // Which slot first is the law's business (it frees the one at weight zero — slot 1, cold): the job
        // names one of the two wanted captures, in the slot the law freed for it.
        ok(job.has_value() && ((job->slot == 0 && job->fileId == "g150") || (job->slot == 1 && job->fileId == "g240")),
           "the job names a wanted capture, for the slot the law freed");
        ok(! b.p.takeLoadJob().has_value(), "one job out: no second one until it is back");
        auto loaded = RigPlayer::run(std::move(*job));                // any thread — here; a worker in the app
        ok(loaded.fetched && loaded.model != nullptr && b.fetches == 1, "run() fetched the bytes and built the model");
        b.p.deliver(std::move(loaded));
        ok(b.p.modelLoads() == 1, "delivered: the fetch is counted and the bytes kept");
        approx(b.gainAt(1000.0), 0.5, 0.01, "…and it sounds (the neighbour arrives the same way)");
        ok(b.fetches == 2, "…each file fetched once");

        // A job out while the pack changes comes back for a pack that is gone — and is dropped whole.
        b.p.setDial("gain", 0.0);                                    // wants the 60 capture
        std::optional<RigPlayer::LoadJob> late;
        for (int i = 0; i < 24 && ! late; ++i) { felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.service(); late = b.p.takeLoadJob(); }
        ok(late.has_value() && late->fileId == "g60", "the job for the 60 capture is out");
        b.p.unload();
        b.load(rig);
        ok(! b.p.takeLoadJob().has_value(), "…and nothing new is handed out while it is out");
        b.p.deliver(RigPlayer::run(std::move(*late)));
        felitronics::test::run (b.p.process(io, 1, kBlock));                                  // the new pack's law: nothing landed
        ok(b.p.heldFileId(0).empty() && b.p.heldFileId(1).empty(), "delivered to the new pack it is dropped: no slot holds it");
        approx(b.gainAt(1000.0), 0.5, 0.01, "…and the new pack loads its own and sounds");
    }

    group("a landing published before the pack leaves dies with it");
    {
        // deliver() and unload() on the message thread, with no audio block between them: the landing
        // sat published, the pack left, and the landing used to be consumed AFTER the forget — a stale
        // model in a wiped law, over an emptied stage.
        Bench b(rig);
        std::vector<float> x((std::size_t) kBlock, 0.1f);
        float* io[1] { x.data() };
        felitronics::test::run (b.p.process(io, 1, kBlock));                                  // the law asks
        auto job = b.p.takeLoadJob();
        ok(job.has_value(), "a job is out");
        b.p.deliver(RigPlayer::run(std::move(*job)));                // …and lands, published for the audio thread
        b.p.unload();
        b.load(rig);
        felitronics::test::run (b.p.process(io, 1, kBlock));
        ok(b.p.heldFileId(0).empty() && b.p.heldFileId(1).empty(),
           "the new pack's law holds nothing of the old landing");
        approx(b.gainAt(1000.0), 0.5, 0.01, "…and the new pack loads its own and sounds");
    }

    group("a file that cannot be a model is asked for once, not every block");
    {
        // THE STORM THIS PREVENTS: red's file is broken in this pack. The switch to red asks for it
        // once, fails once, and the captures the hand came from carry on; it used to be re-fetched and
        // re-parsed on every service tick, for ever, fixing nothing.
        Bench b(rig);
        b.files["r150"] = bytesOf("not a model at all");
        approx(b.gainAt(1000.0), 0.5, 0.01, "green 150 sounds");
        ok(b.p.setSwitch("channel", "red"), "the hand switches to red, whose file is broken");
        approx(b.gainAt(1000.0), 0.5, 0.01, "…and the captures it came from carry on");
        ok(b.fetches == 3, "the broken file was asked of the source once");
        ok(b.p.heldFileId(0) == "g150" && b.p.heldFileId(1) == "g240", "…and both slots keep their real models");
        std::vector<float> x((std::size_t) kBlock, 0.1f);
        float* io[1] { x.data() };
        int asks = 0;
        for (int k = 0; k < 100; ++k) {
            std::fill(x.begin(), x.end(), 0.1f);
            felitronics::test::run (b.p.process(io, 1, kBlock));
            b.p.service();
            if (b.p.takeLoadJob().has_value()) ++asks;
        }
        ok(asks == 0 && b.fetches == 3, "a hundred blocks later it has not been asked for again");
        ok(b.p.setSwitch("channel", "green"), "the hand leaves for green…");
        felitronics::test::run (b.p.process(io, 1, kBlock));                              // the law hears the wish change
        ok(b.p.setSwitch("channel", "red"), "…and asks for red again");
        std::optional<RigPlayer::LoadJob> again;
        for (int k = 0; k < 10 && ! again; ++k) { felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.service(); again = b.p.takeLoadJob(); }
        ok(again.has_value() && again->fileId == "r150", "a new wish tries the file anew");
        b.p.deliver(RigPlayer::run(std::move(*again)));          // fails again; the slot is refused again
        approx(b.gainAt(1000.0), 0.5, 0.01, "…and the sound never blinked");
    }

    group("a fetch that answered nothing is not kept: the next visit asks again");
    {
        // An empty answer is the host's "could not fetch it" — a network hiccup, not the file. It used to be kept as
        // the file's bytes, so every later visit ran on nothing without asking: the capture dead until the pack was
        // loaded again. (Bytes that are not a model are kept: they are what the file is — the group above.)
        Bench b(rig);
        const auto red = b.files["r150"];
        b.files.erase("r150");                                   // the first fetch of red answers nothing
        approx(b.gainAt(1000.0), 0.5, 0.01, "green 150 sounds");
        ok(b.p.setSwitch("channel", "red"), "the hand switches to red, whose fetch fails");
        approx(b.gainAt(1000.0), 0.5, 0.01, "…and the captures it came from carry on");
        ok(b.fetches == 3 && b.p.modelLoads() == 2, "red was asked for once, and nothing of it was kept");
        b.files["r150"] = red;                                   // the network is back
        ok(b.p.setSwitch("channel", "green"), "the hand leaves for green…");
        approx(b.gainAt(1000.0), 0.5, 0.01, "…which plays from the bytes it kept");
        ok(b.p.setSwitch("channel", "red"), "…and comes back to red");
        approx(b.gainAt(1000.0), 0.75, 0.01, "red's capture lands now, and sounds");
        ok(b.fetches == 4 && b.p.modelLoads() == 3, "…asked for a second time, and kept this time ("
                                                    + std::to_string(b.fetches) + " fetches)");
    }

    group("the dial: a pair mixed by angle, the extension past the top, each file fetched once");
    {
        Bench b(rig);
        approx(b.gainAt(1000.0), 0.5, 0.01, "150: the 0.5 capture");
        ok(b.p.setDial("gain", 200.0), "the dial turns to 200");
        approx(b.gainAt(1000.0), (40.0 / 90.0) * 0.5 + (50.0 / 90.0) * 1.0, 0.015,
               "200: the 150 and 240 captures, 4/9 and 5/9 of each");
        approx((double) b.p.liveMix(), 50.0 / 90.0, 0.01, "…and that is the weight the audio thread applied");
        b.p.setDial("gain", 300.0);
        approx(b.gainAt(1000.0), 1.0 * std::pow(10.0, 3.0 / 20.0), 0.03, "300: the top capture, 3 dB harder in");
        b.p.setDial("gain", 150.0);
        approx(b.gainAt(1000.0), 0.5, 0.01, "back at 150");
        b.p.setDial("gain", 240.0);
        approx(b.gainAt(1000.0), 1.0, 0.02, "240 alone");
        ok(b.fetches == 2, "two fetches for two files, however many times the dial crossed them");
        ok(b.p.modelLoads() == 2, "…which is what the player counts too");
        const auto& knots = b.p.selection().knots;
        ok(knots.size() == 4 && knots[0].deg == 0.0 && knots[3].deg == 240.0, "the ring's knots: 0 (the link) to 240");
    }

    group("the shape of the handover: where the 50/50 lands and how wide the fade is");
    {
        Bench b(rig);
        ok(b.p.blendShape().point == 0.5 && b.p.blendShape().width == 1.0, "the default is the original law: midpoint, full span");
        b.p.setDial("gain", 195.0);                                  // the middle of 150..240
        approx(b.p.selection().mixB, 0.5, 1e-9, "…so the 50/50 sits in the middle of the pair");
        b.p.setBlendShape({ 0.25, 1.0 });
        ok(b.p.blendShape().point == 0.25, "the point moves to a quarter of the span");
        b.p.setDial("gain", 172.5);                                  // 150 + 0.25 * 90
        approx(b.p.selection().mixB, 0.5, 1e-9, "…and the 50/50 sits there now");
        approx(b.gainAt(1000.0), 0.5 * 0.5 + 0.5 * 1.0, 0.015, "…which is what sounds: half of each capture");
        b.p.setDial("gain", 161.25);                                 // halfway up the near side
        approx(b.p.selection().mixB, 0.25, 1e-9, "the near side is a quarter of the way at its own half");
        b.p.setBlendShape({ 0.25, 0.0 });
        b.p.setDial("gain", 170.0);
        approx(b.p.selection().mixB, 0.0, 1e-9, "width zero: below the point the lower capture alone");
        b.p.setDial("gain", 175.0);
        approx(b.p.selection().mixB, 1.0, 1e-9, "…above it the upper alone — a step, where the bench asked for one");
        approx(b.gainAt(1000.0), 1.0, 0.02, "…and that is what sounds");
        b.p.setBlendShape({});
        b.p.setDial("gain", 195.0);
        approx(b.p.selection().mixB, 0.5, 1e-9, "back to the law");
    }

    group("every knob by name: a dial in degrees, a switch by value, its position read back");
    {
        Bench b(rig);
        ok(b.p.knobValue("tone") == "150" && b.p.knobValue("bass") == "0" && b.p.knobValue("mix") == "300",
           "the tone and blend knobs start where the pack says");
        ok(b.p.knobValue("gain") == "150" && b.p.knobValue("channel") == "green", "…and so do the captured axes");
        ok(b.p.setDial("tone", 300.0) && b.p.knobValue("tone") == "300", "a band knob turned by degrees reads back in degrees");
        ok(b.p.setDial("bass", 210.0) && b.p.knobValue("bass") == "210", "a curve knob the same");
        ok(b.p.setDial("mix", 0.0) && b.p.knobValue("mix") == "0", "the blend knob the same");
        ok(b.p.setSwitch("tone", "0") && b.p.knobValue("tone") == "0", "…or set to a value outright");
        ok(b.p.setDial("gain", 200.0) && b.p.knobValue("gain") == "150",
           "a captured dial reads back the knot at or below the hand; the angle is dialDegrees()");
        approx(b.p.dialDegrees(), 200.0, 1e-9, "…which is where the hand is");
        ok(! b.p.setDial("nope", 10.0) && b.p.knobValue("nope").empty(), "a knob the pack has not got: refused, and empty");
    }

    group("a linked setting plays its neighbour's weights, fed softer");
    {
        Bench b(rig);
        b.p.setDial("gain", 0.0);
        approx(b.gainAt(1000.0), 0.25 * std::pow(10.0, -6.0 / 20.0), 0.005,
               "at 0 the 60 capture sounds, 6 dB less going in");
        ok(b.p.heldFileId(0) == "g60", "…and it is that file in the slot");
        b.p.setDial("gain", 30.0);
        approx(b.gainAt(1000.0), 0.5 * 0.25 * std::pow(10.0, -6.0 / 20.0) + 0.5 * 0.25, 0.01,
               "at 30, halfway to 60, the same weights softer and louder are crossfaded");
    }

    group("a switch turn is namz::rig's resolve; the dial keeps its angle and follows the new knots");
    {
        Bench b(rig);
        b.p.setDial("gain", 240.0);
        ok(b.p.setSwitch("channel", "red"), "channel to red");
        ok(b.p.settings().at("channel") == "red", "…pinned");
        ok(b.p.settings().at("gain") == "150", "…and the combination is red's only capture");
        approx(b.p.dialDegrees(), 240.0, 1e-9, "…while the dial still stands at 240");
        approx(b.gainAt(1000.0), 0.75 * std::pow(10.0, 4.5 / 20.0), 0.03, "so the red capture plays, 4.5 dB harder in");
        ok(! b.p.setSwitch("channel", "blue"), "a value nothing was captured at is refused");
        ok(b.p.settings().at("channel") == "red", "…and changes nothing");
        ok(b.p.setSwitch("channel", "green"), "back to green");
        approx(b.gainAt(1000.0), 1.0, 0.02, "…and the dial, still at 240, finds its capture again");
        ok(b.p.setSwitch("gain", "60"), "the crossfade dial set by value");
        approx(b.p.dialDegrees(), 60.0, 1e-9, "…is the dial turned there");
    }

    group("tone as bands: the travel law at the reference and at the stops");
    {
        Bench b(rig);
        ok(b.p.bands(1).size() == 1 && b.p.bands(0).empty(), "one band after the model, none before");
        ok(b.p.knobValue("tone") == "150", "the knob starts at its default, the reference");
        const double flatLo = b.gainAt(100.0), flatHi = b.gainAt(10000.0);
        approx(db(flatHi / flatLo), 0.0, 0.1, "at the reference the band is flat");
        ok(b.p.setDial("tone", 300.0), "tone to the plus stop");
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)), shelfDb(6.0, kFs), 0.1, "+6 dB of high shelf at the plus stop, as the formula draws it");
        b.p.setDial("tone", 0.0);
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)), shelfDb(-6.0, kFs), 0.1, "-6 dB at the minus stop");
        b.p.setDial("tone", 225.0);
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)), shelfDb(3.0, kFs), 0.1, "halfway up from the reference: half the gain, in dB");
        ok(b.p.knobValue("tone") == "225", "…and the knob reads back in the pack's words");
    }

    group("tone as a curve: the pack's decibels at this frequency, as a FIR before the model");
    {
        Bench b(rig);
        ok(! b.p.curveActive(0), "at the reference the curve is flat and there is no FIR");
        const double refLo = b.gainAt(60.0), refHi = b.gainAt(10000.0);
        ok(b.p.setDial("bass", 300.0), "bass to the top");
        ok(b.p.curveActive(0) && ! b.p.curveDb(0).empty(), "…and now there is a FIR on the pre side");
        approx(db(b.gainAt(60.0) / refLo), 6.0, 0.6, "+6 dB at 60 Hz");
        approx(db(b.gainAt(10000.0) / refHi), 0.0, 0.3, "nothing at 10 kHz");
        b.p.setDial("bass", 150.0);
        approx(db(b.gainAt(60.0) / refLo), 3.0, 0.6, "halfway: the two curves interpolated, +3 dB");
    }

    group("tone handed in beside the manifest: the same structures, another source");
    {
        Bench b(rig);
        b.p.setDial("bass", 300.0);
        const double refLo = b.gainAt(60.0);                  // the pack's curve: +6 dB at 60 Hz
        // The bench rewrites `bass` as one band — a low shelf reaching +12 dB — and hears it at once.
        namz::rig::Tone bass;
        bass.name = "bass"; bass.sweep = 300; bass.placement = "pre"; bass.reference = "0"; bass.defaultValue = "0";
        namz::rig::Section ls; ls.kind = namz::rig::SectionKind::LowShelf; ls.hz = 200.0; ls.q = 0.7;
        ls.dbAtMin = 0.0; ls.dbAtMax = 12.0;
        bass.sections = { ls };
        b.p.setToneOverride({ bass });
        ok(b.p.toneOverridden(), "the override is in");
        ok(b.p.tones().size() == 2 && b.p.tones()[1].name == "bass" && b.p.tones()[1].positions.empty(),
           "…and the knob plays as the band, in the pack's place for it");
        ok(b.p.knobValue("bass") == "300", "the knob keeps its position across the swap");
        const auto q = felitronics::rigplayer::designSection(felitronics::rigplayer::SectionKind::LowShelf, 200.0, 12.0, 0.7, kFs);
        const double want = felitronics::rigplayer::sectionMagnitudeDb(q, 60.0, kFs);
        approx(db(b.gainAt(60.0) / refLo) + 6.0, want, 0.3, "at 60 Hz the band's own decibels, not the curve's");
        b.p.clearToneOverride();
        ok(! b.p.toneOverridden(), "cleared");
        approx(db(b.gainAt(60.0) / refLo), 0.0, 0.3, "…and the pack's curve is back");

        // A knob the pack has no block for is a new knob, at its default.
        namz::rig::Tone presence;
        presence.name = "presence"; presence.sweep = 300; presence.placement = "post"; presence.reference = "150";
        namz::rig::Section hs; hs.kind = namz::rig::SectionKind::HighShelf; hs.hz = 3000.0; hs.q = 0.7;
        hs.dbAtMin = -6.0; hs.dbAtMax = 6.0;
        presence.sections = { hs };
        b.p.setToneOverride({ presence });
        ok(b.p.tones().size() == 3 && b.p.knobValue("presence") == "150", "a new knob appears, at its reference");
        const double flat = db(b.gainAt(10000.0) / b.gainAt(100.0));
        ok(b.p.setDial("presence", 300.0), "…and turns");
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)) - flat, shelfDb(6.0, kFs), 0.1, "+6 dB of the new shelf");
    }

    // A KNOB THAT CLICKS. Its positions are words with an order and no angle, so there is no rotation
    // for a band's gain to travel on: each position states the filter it IS, and nothing is computed
    // between two of them. Before schema 4 such a knob could not say this at all — it was given an
    // evenly spaced `norm` nobody measured, and a bench that declared it as bands heard its measured
    // curve instead, silently.
    group("a knob that clicks: the filter is stated at the position, whole");
    {
        Bench b(rig);
        namz::rig::Tone edge;
        edge.name = "edge"; edge.placement = "post"; edge.reference = "sharp"; edge.defaultValue = "sharp";
        namz::rig::TonePosition sharp;  sharp.value  = "sharp";      // the anchor states nothing: flat by construction
        namz::rig::TonePosition smooth; smooth.value = "smooth";
        namz::rig::PositionSection hs;
        hs.kind = namz::rig::SectionKind::HighShelf; hs.hz = 3000.0; hs.q = 0.7; hs.gainDb = -6.0;
        smooth.sections = { hs };
        edge.positions = { sharp, smooth };
        b.p.setToneOverride({ edge });
        ok(b.p.knobValue("edge") == "sharp", "the switch opens at its anchor");
        const double flat = db(b.gainAt(10000.0) / b.gainAt(100.0));
        ok(b.p.setSwitch("edge", "smooth") && b.p.knobValue("edge") == "smooth", "…and clicks over");
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)) - flat, shelfDb(-6.0, kFs), 0.1,
               "what sounds is that position's own filter, at its own decibels");
        ok(b.p.setSwitch("edge", "sharp"), "back to the anchor");
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)) - flat, 0.0, 0.1,
               "…where the models play exactly as they were captured");
        ok(! b.p.setSwitch("edge", "smoothh"), "a position this knob does not declare is REFUSED");
        ok(b.p.knobValue("edge") == "sharp",
           "…and the knob stayed where it was: it used to accept the word, read it back, and play the anchor");
    }

    // LAW 8 (state, not timing). The blend ramps are `end = want + (current-want)*decay` — asymptotic, so
    // without a snap they never arrive. An EXACT-zero target is not hypothetical and needs no special pack:
    // BlendKnob::linOf returns 0.0 for any level at or below -120 dB, which is how this very rig spells
    // "off" (dry end: wetDb -120). Move the dial there after an audible position and the wet gain decays
    // to a subnormal fixed point (decay 0.587 at kBlock 256 => k <= 0.5/(1-decay) ~= 1.2, so 1 ulp) and
    // stays, while `mixDry` — gated on a dry IR being LOADED, not on the gains — keeps the per-sample mix
    // loop running over it for the life of the rig.
    //
    // Asserted twice, as in the Saturator's law-8 test: at 5 s the un-flushed value is 1 ulp (subnormal,
    // so a machine with hardware FTZ could read it as zero and hide a regression), while at 0.8 s it is
    // 1.8e-35 — a NORMAL float — and the flush has already fired (it does so at 0.69 s). The observable is
    // liveWet(), the applied gain the audio thread actually multiplied by.
    group("blend: law 8 — a gain aimed at exact zero ARRIVES (it used to park in the subnormals)");
    {
        Bench b(rig);
        b.rms(440.0, 0.2, 16, 0);                                   // default dial = wet end: curWet_ -> 1
        ok(b.p.liveWet() > 0.9f, "the wet gain is up before the move");
        ok(b.p.setDial("mix", 0.0), "mix to the dry end — the pack states the wet path at -120 dB, i.e. 0");
        b.rms(440.0, 0.2, 150, 0);                                  // 0.8 s: un-flushed would be 1.8e-35
        ok(b.p.liveWet() == 0.0f, "applied wet is EXACTLY 0 at 0.8 s (a normal 1.8e-35 without the snap)");
        b.rms(440.0, 0.2, 788, 0);                                  // out to 5 s
        ok(b.p.liveWet() == 0.0f, "still exactly 0 after 5 s");
    }

    group("blend: the dry path and the wet one as the pack states them");
    {
        Bench b(rig);
        approx(b.gainAt(1000.0), 0.5, 0.01, "wet end (the default): the model alone");
        ok(b.p.setDial("mix", 0.0), "mix to the dry end");
        approx(b.gainAt(1000.0), std::pow(10.0, -6.0 / 20.0), 0.01, "dry end: the DI through the dry path, 6 dB down");
        b.p.setDial("mix", 150.0);
        approx(b.gainAt(1000.0), 0.5 * std::pow(10.0, -6.0 / 20.0) + 0.5 * 0.5, 0.01,
               "halfway: half of each, in amplitude, summing in phase");
    }
    {
        Bench b(throughTheFormat(testRig(-1)));
        b.p.setSwitch("gain", "240");                          // a unity capture, so the two paths match
        b.p.setDial("mix", 150.0);
        const double half = b.gainAt(1000.0);
        ok(half < 0.5 * 0.501 + 0.5 - 0.4, "polarity -1: the dry path is subtracted, and the middle of the knob nearly nulls");
        approx(half, 0.5 - 0.5 * std::pow(10.0, -6.0 / 20.0), 0.01, "…to exactly the difference of the two");
    }

    group("the pack's own levels: the guitar in, the device out");
    {
        const double q6 = std::pow(10.0, -6.0 / 20.0);
        Bench b(levelled(-6.0, 0.0));
        ok(b.p.stageInputDb() == -6.0 && b.p.stageOutputDb() == 0.0, "the player reads both levels off the pack");
        approx(b.gainAt(1000.0), 0.5 * q6, 0.01, "at 150 the model is fed 6 dB softer");
        b.p.setDial("gain", 0.0);
        approx(b.gainAt(1000.0), 0.25 * q6 * q6, 0.005,
               "at the link the two ADD: the pack's 6 dB and the alias's own 6 dB");
    }
    {
        // The input level reaches the DRY side of a blend too. One guitar cannot arrive at the two ends
        // of a mix at two different levels, so both move together and the stated mix is untouched.
        const double q6 = std::pow(10.0, -6.0 / 20.0);
        Bench plain(rig), quiet(levelled(-6.0, 0.0));
        ok(plain.p.setDial("mix", 0.0), "the plain pack to the dry end");
        ok(quiet.p.setDial("mix", 0.0), "the levelled one too");
        approx(quiet.gainAt(1000.0), plain.gainAt(1000.0) * q6, 0.01, "the dry path is fed 6 dB softer as well");
        plain.p.setDial("mix", 150.0); quiet.p.setDial("mix", 150.0);
        approx(quiet.gainAt(1000.0), plain.gainAt(1000.0) * q6, 0.01,
               "…so halfway across the knob the mix is the same mix, 6 dB down");
    }
    {
        // The output level is a scalar on the whole stage, applied AFTER the mix — the same number at
        // every position of the blend knob, which is what "it cannot move the blend" means as a number.
        const double q6 = std::pow(10.0, -6.0 / 20.0);
        Bench plain(rig), quieter(levelled(0.0, -6.0));
        approx(quieter.gainAt(1000.0), plain.gainAt(1000.0) * q6, 0.005, "the wet end comes out 6 dB down");
        ok(plain.p.setDial("mix", 0.0), "the plain pack to the dry end");
        ok(quieter.p.setDial("mix", 0.0), "the levelled one too");
        approx(quieter.gainAt(1000.0), plain.gainAt(1000.0) * q6, 0.005, "so does the dry end — the same scalar");
        plain.p.setDial("mix", 150.0); quieter.p.setDial("mix", 150.0);
        approx(quieter.gainAt(1000.0), plain.gainAt(1000.0) * q6, 0.005,
               "and so does halfway across, which is the blend's ratio left exactly where the pack put it");
    }
    {
        // A pack level cannot put a step into a crossfade that had none: the ladder with one is the
        // ladder without one times the scalar, at every angle — the link at the bottom included.
        const double q3 = std::pow(10.0, -3.0 / 20.0);
        Bench plain(rig), lower(levelled(0.0, -3.0));
        for (const double deg : { 0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0 }) {
            plain.p.setDial("gain", deg); lower.p.setDial("gain", deg);
            char what[96];
            std::snprintf(what, sizeof what, "the crossfade at %.0f deg is untouched but for the scalar", deg);
            approx(lower.gainAt(1000.0), plain.gainAt(1000.0) * q3, 0.01, what);
        }
    }
    {
        // The loudness tag is a contract, not a listener's option. A player that opens un-normalised
        // plays every capture at whatever level the hardware gave, and this default must not be
        // quietly turned back — hence a test on the default itself.
        RigPlayer fresh;
        ok(fresh.normalize(), "a player normalizes by default");
        Bench b(rig);
        ok(b.p.normalize(), "…and so does one with a pack in it");
        b.p.setNormalize(false);
        b.p.unload();
        b.load(rig);
        ok(! b.p.normalize(), "the switch is still the host's to throw, and survives a reload");
    }

    group("the loudness tag answers for the slot that is SOUNDING, not for slot 0");
    {
        // Slots are handed out by the PARITY of a capture's place on the dial, so on an odd rung the
        // whole sound leaves slot 1 while slot 0 holds the silent neighbour. A read-out fixed to slot 0
        // therefore names a model nobody can hear — and a host that draws "no tag, plays raw" from it
        // warns about a capture that carries one.
        //
        // The three captures are told apart twice over: by the gain that comes out (0.25 / 0.5 / 1.0,
        // with normalizing off so the models play raw) and by the tag each carries — -33 on the 60
        // capture, -12 on the 150 one, and none at all on the 240. So the tag is checked against the
        // audio, not against a variable.
        const auto tagged = [](const std::string& id) {
            if (id == "g60")  return bytesOf(taggedGainModel(0.25, -33.0));
            if (id == "g150") return bytesOf(taggedGainModel(0.5, -12.0));
            if (id == "g240") return bytesOf(gainModel(1.0));
            return std::vector<std::byte> {};
        };
        Bench b(rig);
        b.p.setNormalize(false);
        b.p.load(rig.chain[0], tagged);

        approx(b.gainAt(1000.0), 0.5, 0.01, "at 150 the 0.5 capture sounds: the third knot, an EVEN rung");
        auto l = b.p.soundingLoudness();
        ok(l.slot == 0 && l.tagged && ! l.blended, "…so slot 0 is the sound, alone, and carries a tag");
        approx(l.db, -12.0, 1e-9, "…which is the 150 capture's own");

        b.p.setDial("gain", 60.0);
        approx(b.gainAt(1000.0), 0.25, 0.01, "at 60 the 0.25 capture sounds: an ODD rung, and slot 1 has all of it");
        ok(b.p.heldFileId(1) == "g60" && b.p.heldFileId(0) == "g150",
           "…while slot 0 holds the neighbour it will fade back to, silent");
        l = b.p.soundingLoudness();
        ok(l.slot == 1 && l.tagged && ! l.blended, "the read-out follows the sound into slot 1");
        approx(l.db, -33.0, 1e-9, "…and states the tag of the capture that is sounding, not the silent one's -12");

        b.p.setDial("gain", 200.0);
        approx(b.gainAt(1000.0), (40.0 / 90.0) * 0.5 + (50.0 / 90.0) * 1.0, 0.015,
               "at 200 both captures sound, five ninths of the way to the 240");
        l = b.p.soundingLoudness();
        ok(l.slot == 1 && ! l.tagged,
           "the heavier half is the 240 capture, which has NO tag — and that is what a face must warn about");
        ok(l.blended, "…and it says so: a second, different capture is audible beside it, so this is one tag of two");

        b.p.unload();
        l = b.p.soundingLoudness();
        ok(! l.tagged && ! l.blended, "an unloaded player sounds nothing, so it tags nothing");
    }

    group("input is drive and output is volume: a model that is not a pure scalar tells them apart");
    {
        // The mean of the output IS the offset the network adds. Scale what goes IN and the offset
        // stands; scale what comes OUT and the offset scales too. Every other fixture in this file is
        // a pure gain, through which the two levels are indistinguishable — swap where the player
        // applies them and nothing else here would notice.
        const auto biased = [] (const std::string& nam) {
            return [nam] (const std::string&) { return bytesOf(nam); };
        };
        const auto meanOf = [] (Bench& b) {
            std::vector<float> l((std::size_t) kBlock);
            double sum = 0.0; long n = 0;
            for (int k = 0; k < 80; ++k) {
                std::fill(l.begin(), l.end(), 0.0f);          // silence in: what comes out is the offset
                float* io[2] { l.data(), nullptr };
                felitronics::test::run (b.p.process(io, 1, kBlock));
                b.p.serviceHere();
                if (k >= 48) for (const float v : l) { sum += (double) v; ++n; }
            }
            return sum / (double) std::max(1L, n);
        };
        const auto model = biasModel(0.5, 0.25);

        Bench plain(rig);
        plain.p.load(throughTheFormat(testRig()).chain[0], biased(model));
        const double base = meanOf(plain);
        ok(std::abs(base - 0.25) < 0.02, "the fixture adds its offset: mean 0.25");

        auto inRig = testRig(); inRig.chain[0].inputDb = -6.0;
        Bench fedLess(rig);
        fedLess.p.load(throughTheFormat(inRig).chain[0], biased(model));
        ok(std::abs(meanOf(fedLess) - 0.25) < 0.02,
           "input_db does NOT touch the offset — it is drive, and drive is not volume");

        auto outRig = testRig(); outRig.chain[0].outputDb = -6.0;
        Bench quieter(rig);
        quieter.p.load(throughTheFormat(outRig).chain[0], biased(model));
        ok(std::abs(meanOf(quieter) - 0.25 * std::pow(10.0, -6.0 / 20.0)) < 0.02,
           "…while output_db takes the offset down with everything else: it is volume");
    }

    group("the host's own hand: the WHOLE number, and the player does the subtracting");
    {
        // A host with a fader states what it wants the device played at. It never sends a difference:
        // the difference needs to know which pack is loaded, the host reads that from its own document,
        // and the document and the pack disagree whenever an edit or a rebuild is in flight. Here there
        // is one number and one place that applies it.
        const double q6 = std::pow(10.0, -6.0 / 20.0);
        Bench b(levelled(-6.0, 0.0));
        ok(! b.p.hostInputDb() && ! b.p.hostOutputDb(), "a fresh player holds no hand: the pack's own stands");
        approx(b.gainAt(1000.0), 0.5 * q6, 0.01, "…and it is the pack's -6 dB that is heard");

        b.p.setHostInputDb(0.0);
        approx(b.gainAt(1000.0), 0.5, 0.01, "the hand at 0 REPLACES the pack's -6, it does not add to it");

        b.p.setHostInputDb(-12.0);
        approx(b.gainAt(1000.0), 0.5 * std::pow(10.0, -12.0 / 20.0), 0.01, "…and -12 is heard as -12, once");

        // THE WHOLE POINT: a new pack states something else, and the hand still wins without the host
        // saying a word. This is the case that was wrong when the host did the subtracting — the pack
        // changed under it and its arithmetic did not.
        b.load(levelled(-18.0, 0.0));
        approx(b.gainAt(1000.0), 0.5 * std::pow(10.0, -12.0 / 20.0), 0.01,
               "a pack swap does not move the hand, and does not double with it");

        b.p.setHostInputDb(std::nullopt);
        approx(b.gainAt(1000.0), 0.5 * std::pow(10.0, -18.0 / 20.0), 0.01,
               "letting go hands the level back to the pack");

        b.p.setHostOutputDb(-6.0);
        approx(b.gainAt(1000.0), 0.5 * std::pow(10.0, -18.0 / 20.0) * q6, 0.01, "the other end works the same way");
    }

    group("an empty player holds the feed alone, whatever hand the host holds — the order of the setters changes nothing");
    {
        // An empty player sounds nothing, but its two levels still ride their ramps, and the next pack's glide in FROM
        // there. unload() publishes the wire's: the feed in, unity out, the hand kept for the next load. A setter called
        // on the empty player has to publish the same — it used to add the hand back in. Two benches that make the same
        // calls in another order (the hand before or after the unload, the feed restated or not) must play the same bytes.
        const auto lin = [](double dB) { return std::pow(10.0, dB / 20.0); };
        const auto play = [](Bench& x, int blocks) {
            std::vector<float> out, l((std::size_t) kBlock), r((std::size_t) kBlock);
            for (int k = 0; k < blocks; ++k) {
                for (int i = 0; i < kBlock; ++i)
                    l[(std::size_t) i] = (float) (0.1 * std::sin(2.0 * 3.14159265358979323846 * 1000.0 * (k * kBlock + i) / x.fs));
                float* io[2] { l.data(), r.data() };
                felitronics::test::run (x.p.process(io, x.p.channels(), kBlock));
                x.p.serviceHere();
                out.insert(out.end(), l.begin(), l.end());
            }
            return out;
        };
        Bench one(levelled(0.0, 0.0)), two(levelled(0.0, 0.0));
        for (Bench* x : { &one, &two }) { x->p.setHostInputDb(-12.0); felitronics::test::run (x->p.setFeedDb(6.0)); }
        approx(one.gainAt(1000.0), 0.5 * lin(-12.0 + 6.0), 0.01, "loaded: the hand -12 plus the feed +6");
        (void) two.gainAt(1000.0);
        one.p.setHostOutputDb(-6.0);
        one.p.unload();
        two.p.unload();
        felitronics::test::run (two.p.setFeedDb(6.0));    // the feed restated on the empty player…
        two.p.setHostOutputDb(-6.0);                      // …and the output hand stated there
        std::vector<float> a = play(one, 20), b = play(two, 20);
        one.load(levelled(0.0, 0.0));
        two.load(levelled(0.0, 0.0));
        const auto a2 = play(one, 40), b2 = play(two, 40);
        a.insert(a.end(), a2.begin(), a2.end());
        b.insert(b.end(), b2.begin(), b2.end());
        long off = 0;
        for (std::size_t i = 0; i < a.size(); ++i) off += a[i] != b[i];
        double peak = 0.0;
        for (std::size_t i = a.size() - (std::size_t) kBlock; i < a.size(); ++i) peak = std::max(peak, (double) std::abs(a[i]));
        ok(off == 0 && peak > 0.01, "20 blocks empty, a load, 40 blocks: the same bytes whichever order the setters ran in ("
           + std::to_string(off) + " of " + std::to_string(a.size()) + " samples differ)");
        approx(one.gainAt(1000.0), 0.5 * lin(-12.0 + 6.0) * lin(-6.0), 0.01, "loaded again: the hand, the feed and the output hand heard");
        approx(two.gainAt(1000.0), 0.5 * lin(-12.0 + 6.0) * lin(-6.0), 0.01, "…on both benches");
    }

    group("alignment: two captures that land apart are lined up before they mix");
    {
        // Two files: unity, and unity two samples late.
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control g; g.name = "gain"; g.role = namz::rig::Role::Gain; g.values = { "60", "240" }; g.sweep = 300;
        st.device.controls = { g };
        namz::rig::FileEntry a; a.id = "early"; a.settings = { { "gain", "60" } };
        namz::rig::FileEntry c; c.id = "late";  c.settings = { { "gain", "240" } };
        st.device.files = { a, c };
        r.chain = { st };
        std::map<std::string, std::vector<std::byte>> files {
            { "early", bytesOf(gainModel(1.0)) }, { "late", bytesOf(delayModel(2)) } };
        const ModelSource src = [&files](const std::string& id) { return files.at(id); };

        const auto table = measureAlignment(st.device, src, kFs);
        ok(table.lagByFile.size() == 2, "both files measured");
        ok(table.lagByFile.count("late") && table.lagByFile.at("late") == 2, "the late one reads two samples late");
        ok(table.delayOf("early") == 2 && table.delayOf("late") == 0, "so the early one is delayed by two, the late one not at all");

        // At 6 kHz two samples are a quarter turn: unaligned, a 50/50 sum of the two is 3 dB down.
        {
            Bench b(r);
            b.files = files;
            b.p.setDial("gain", 150.0);
            approx(b.gainAt(6000.0), std::sqrt(0.5), 0.02, "without the table the pair combs: 0.707 at 6 kHz");
        }
        {
            Bench b(r);
            b.files = files;
            b.p.setAlignment(table);                           // before anything lands: it travels with the loads
            b.p.setDial("gain", 150.0);
            approx(b.gainAt(6000.0), 1.0, 0.02, "with the table in hand before playing, the pair sums to one");
            ok(b.p.appliedSlotDelay(0) == 2 && b.p.appliedSlotDelay(1) == 0, "…the early slot delayed, the late one not");
        }
        {
            // A table that arrives MID-MIX reaches the captures that are playing — the delay is theirs — through a
            // 10 ms crossfade of each slot's line, never as a splice on a live signal (it used to wait for a slot to
            // fall silent, so the comb stood until the dial visited a knot).
            Bench b(r);
            b.files = files;
            b.p.setDial("gain", 150.0);
            approx(b.gainAt(6000.0), std::sqrt(0.5), 0.02, "mid-mix, before the table: the comb");
            b.p.setAlignment(table);
            approx(b.gainAt(6000.0), 1.0, 0.02, "…and the comb gone: the playing slots crossfade to the table's delays");
            b.p.setDial("gain", 240.0);
            b.gainAt(6000.0);                                  // the top: the early capture leaves its slot at zero
            b.p.setDial("gain", 150.0);
            approx(b.gainAt(6000.0), 1.0, 0.02, "back at the middle it lands again, delayed, and the pair sums to one");
        }
    }

    group("alignment from the pack: the lags written at pack time, no probe at load");
    {
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control g; g.name = "gain"; g.role = namz::rig::Role::Gain; g.values = { "60", "240" }; g.sweep = 300;
        st.device.controls = { g };
        namz::rig::FileEntry a; a.id = "early"; a.settings = { { "gain", "60" } };  a.lagSamples = 0;
        namz::rig::FileEntry c; c.id = "late";  c.settings = { { "gain", "240" } }; c.lagSamples = 2;
        st.device.files = { a, c };
        r.chain = { st };
        bool okM = false;
        const auto packed = throughTheFormat(r, &okM);
        ok(okM && packed.chain.size() == 1 && packed.chain[0].device.files.size() == 2
           && packed.chain[0].device.files[1].lagSamples == 2, "lag_samples round-trips through the writer and the reader");
        const auto table = AlignmentTable::fromDevice(packed.chain[0].device);
        ok(table.fromPack && ! table.empty() && table.delayOf("early") == 2 && table.delayOf("late") == 0,
           "the table comes from the pack: the early file delayed by two");
        approx(table.delayOf("early", 96000.0, 48000.0), 4.0, 0.0, "…and in host samples at 96 kHz, four");

        std::map<std::string, std::vector<std::byte>> files {
            { "early", bytesOf(gainModel(1.0)) }, { "late", bytesOf(delayModel(2)) } };
        Bench b(packed);
        b.files = files;
        ok(b.p.alignmentFromPack(), "the player took the pack's reading at load");
        b.p.setDial("gain", 150.0);
        approx(b.gainAt(6000.0), 1.0, 0.02, "no setAlignment, no probe: the pair sums to one from the pack's numbers");
        ok(b.p.appliedSlotDelay(0) == 2 && b.p.appliedSlotDelay(1) == 0, "…the early slot delayed by the pack's two");

        // Half a reading is no reading.
        auto half = packed;
        half.chain[0].device.files[1].lagSamples.reset();
        ok(AlignmentTable::fromDevice(half.chain[0].device).empty(), "a stage with one entry unmeasured is not measured");
        Bench h(half);
        h.files = files;
        ok(! h.p.alignmentFromPack(), "…and the player does not pretend it is");
    }

    group("stereo: each channel its own signal through the same decision");
    {
        Bench b(rig, 2);
        const double l = b.rms(1000.0, 0.1, 48, 32, 0, 0.2);
        const double rr = b.rms(1000.0, 0.1, 48, 32, 1, 0.2);
        approx(l / (0.1 / std::sqrt(2.0)), 0.5, 0.01, "left: the 0.5 capture on its own signal");
        approx(rr / (0.2 / std::sqrt(2.0)), 0.5, 0.01, "right: the same capture on the other");
    }

    group("another rate: the bands and the curves are designed for it");
    {
        Bench b(rig, 1, 96000.0);
        // A 48 kHz model at a 96 kHz host is rate-matched by the stage, and its resampler is not
        // perfectly flat to 10 kHz — so the shelf is read against what the chain does with it flat.
        const double base = db(b.gainAt(10000.0) / b.gainAt(100.0));
        b.p.setDial("tone", 300.0);
        approx(db(b.gainAt(10000.0) / b.gainAt(100.0)) - base, shelfDb(6.0, 96000.0), 0.1,
               "the shelf at 96 kHz, as the formula draws it there");
        b.p.setDial("tone", 150.0);
        const double refLo = b.gainAt(60.0, 0.1, 48, 64);
        b.p.setDial("bass", 300.0);
        approx(db(b.gainAt(60.0, 0.1, 48, 64) / refLo), 6.0, 0.6, "+6 dB of curve at 96 kHz");
    }

    group("a dial at rest: after kColdAfterSeconds the silent neighbour is not run — and stays loaded");
    {
        // THE ECONOMY, measured in the plugin: a dial parked on a capture kept its neighbour's network
        // running at weight zero, every block, for nothing — 4.5 % of a P-core, 14 % of an E-core.
        // With the handover a step (the plugin's STEP), the hand is always on a capture and the
        // neighbour is always at exactly zero: after the rest it sleeps, and one model plays.
        Bench b(rig);
        b.p.setBlendShape({ 0.5, 0.0 });
        ok(b.p.coldAfterSeconds() == RigPlayer::kColdAfterSeconds && RigPlayer::kColdAfterSeconds == 2.0,
           "the rest is the player's constant, two seconds");
        approx(b.gainAt(1000.0), 0.5, 0.01, "150: the 0.5 capture alone");
        ok(b.p.heldFileId(1) == "g240" && ! b.p.slotCold(1), "…its neighbour held at zero, awake: the hand only just arrived");
        ok(b.p.modelLoads() == 2, "two loads");
        b.p.clearCounters();
        const int rest = (int) std::ceil(2.0 * kFs / kBlock);
        approx(b.rms(1000.0, 0.1, rest, 32) / (0.1 / std::sqrt(2.0)), 0.5, 0.01, "two seconds later it sounds exactly the same");
        ok(b.p.slotCold(1), "…and the neighbour's slot is cold");
        ok(! b.p.slotCold(0), "the sounding slot is not");
        ok(b.p.heldFileId(1) == "g240", "the model is still in the cold slot");
        ok(b.p.modelLoads() == 2, "…nothing was loaded, nothing unloaded");
        // The rest began when the neighbour landed and settled — somewhere inside the first
        // measurement's 80 blocks — so of the 80 + 375 + 32 blocks since, it slept between 32 and 112.
        const int slept = b.p.coldBlocks(1);
        ok(slept >= 32 && slept <= 80 + 32, "it fell asleep at the two-second line, not before (" + std::to_string(slept)
                                            + " blocks slept of " + std::to_string(80 + rest + 32) + ")");
        ok(b.p.warmBlocks() == 0, "a sleeping slot is not a warming one");
        b.rms(1000.0, 0.1, 0, 20);
        ok(b.p.coldBlocks(1) == slept + 20, "twenty more blocks, twenty more slept: the model was not run once");
        ok(b.p.coldBlocks(0) == 0, "…and the sounding one never slept");

        // THE TURN AFTER THE REST. The hand moves to the next capture; in STEP that is all of the
        // neighbour at once. The cold slot wakes on the first block, is fed its field — a warm-up, not
        // a load — and only then does the weight travel, at the law's own pace, never in a step.
        b.p.clearCounters();
        ok(b.p.setDial("gain", 200.0), "the hand moves past the midpoint: the 240 capture, all of it");
        int firstMove = -1, arrived = -1;
        bool awakeAtOnce = false;
        std::vector<double> level;
        for (int k = 0; k < 40; ++k) {
            level.push_back(b.rms(1000.0, 0.1, 0, 1) / (0.1 / std::sqrt(2.0)));
            if (k == 0) awakeAtOnce = ! b.p.slotCold(1);
            const float m = b.p.liveMix();
            if (firstMove < 0 && m > 0.0f) firstMove = k;
            if (arrived < 0 && m >= 1.0f) arrived = k;
        }
        ok(awakeAtOnce, "the first block of the turn wakes the slot");
        // A Linear model DECLARES no field (NAM answers prewarm only for convnet and lstm; WaveNet's is
        // read from its config), so its need is zero and the law may move the weight in the block the
        // slot woke in. A model with a field waits it out first — the law's own test proves that with
        // a 6332-sample field; here the claim is only "no later than the warm-up plus one block".
        ok(firstMove >= 0 && firstMove <= 2, "the weight starts moving no later than the warm-up plus one block (block "
                                             + std::to_string(firstMove) + ")");
        ok(arrived == firstMove + 3, "…and arrives four blocks later, a quarter per block: the law's own slew, no step");
        ok(b.p.biggestJump() <= 0.25f + 1e-6f, "no block moved the weight more than the law allows");
        ok(b.p.modelLoads() == 2, "no load in the wake: the model never left");
        ok(b.p.heldFileId(1) == "g240" && ! b.p.slotCold(1), "…the same model, awake");
        // One block of a 1 kHz sine is 5⅓ cycles, so a block's RMS wanders by a percent or two with
        // its phase; a step would be the whole half of level in one block.
        bool monotone = true; double worstRise = 0.0;
        for (std::size_t k = 1; k < level.size(); ++k) {
            monotone = monotone && level[k] >= level[k - 1] - 0.03;
            worstRise = std::max(worstRise, level[k] - level[k - 1]);
        }
        approx(level.back(), 1.0, 0.02, "what sounds at the end is the 240 capture");
        ok(monotone && worstRise <= 0.5 * 0.25 * 1.3, "…reached by a rise, block on block, none of them a step (the worst "
                                                      + std::to_string(worstRise) + " of level in one block)");
        ok(b.p.warmBlocks() >= 0 && b.p.warmBlocks() <= 2, "the wake cost at most two blocks of warming");

        // Zero means never: a host that wants both networks running says so.
        b.p.setColdAfterSeconds(0.0);
        b.p.clearCounters();
        b.p.setDial("gain", 150.0);
        b.rms(1000.0, 0.1, rest + 40, 32);
        ok(! b.p.slotCold(0) && ! b.p.slotCold(1) && b.p.coldBlocks(0) == 0 && b.p.coldBlocks(1) == 0,
           "with the rest set to zero nothing sleeps, however long the hand rests");
        b.p.setColdAfterSeconds(0.5);
        b.rms(1000.0, 0.1, (int) std::ceil(0.5 * kFs / kBlock), 32);
        ok(b.p.slotCold(1), "…and half a second, once set, is a rest");
    }

    group("a player that sleeps sounds bit-identically to one that never does — AT THE MODEL RATE");
    {
        // 🔴 THE TITLE NARROWED, AND THE NUMBER THAT NARROWED IT IS BELOW. This claim was made without a
        // rate on it and measured at 48 000 only, which is the ONE host rate where no rate-matcher is
        // installed. Off it, a woken slot differs from one that never slept by **4.97e-03 on the block
        // of the wake** at 44.1 kHz and **7.28e-03** at 96 kHz, against a 0.1 input. That is not a
        // regression and not a phase offset; it is the woken slot's rate-matcher emitting its
        // `latencySamples()` leading zeros — 61 samples at 44.1, 96 at 96 kHz — while the law has
        // ALREADY made the slot audible, because `RigPlayer::warmFor` returns early on `pre <= 0` and
        // drops its own `latencySamples()` term for exactly the captures that have no memory.
        //
        // The cause is not inferred. Three independent things say it, and the group pins all three:
        //   · a capture WITH memory does not show it (`warmFor` does not take the early return there):
        //     3.76e-07 at 44.1 kHz on a 2001-tap capture, against 4.97e-03 on a memoryless one;
        //   · at 96 kHz the transient is the WHOLE difference — every later block is exactly 0.00e+00 —
        //     so it is separable from the rate-matcher's resumption phase, which is what the small
        //     persistent floor at 44.1 (1.1e-06 … 2.8e-06) is and which no warm-up can remove;
        //   · removing the early return was MEASURED: 96 kHz goes to exactly 0.000000000 and 44.1 to
        //     2.87e-06, i.e. down to that floor. It is a one-token change and it is NOT made here —
        //     it moves the warm-up of every memoryless capture in every consumer, which is a separate
        //     decision with its own blast radius. What is not acceptable is merging the work that
        //     proved the claim false while leaving the claim standing.
        //
        // So: the guarantee is stated at the model rate, the divergence off it is asserted to EXIST
        // (a suite that pinned it at zero everywhere would be pinning something untrue) and to be
        // confined to the block of the wake, and the next reader is told what makes it go away.
        Bench sleeps(rig), never(rig);
        sleeps.p.setBlendShape({ 0.5, 0.0 }); never.p.setBlendShape({ 0.5, 0.0 });
        never.p.setColdAfterSeconds(0.0);
        const int rest = (int) std::ceil(2.0 * kFs / kBlock);
        std::vector<float> x((std::size_t) kBlock), y((std::size_t) kBlock);
        double phase = 0.0;
        const auto both = [&](int blocks) {
            float worst = 0.0f;
            for (int b = 0; b < blocks; ++b) {
                for (int i = 0; i < kBlock; ++i) {
                    x[(std::size_t) i] = y[(std::size_t) i] = (float) (0.1 * std::sin(phase));
                    phase += 2.0 * 3.14159265358979323846 * 1000.0 / kFs;
                }
                float* ix[1] { x.data() }; float* iy[1] { y.data() };
                felitronics::test::run (sleeps.p.process(ix, 1, kBlock)); sleeps.p.serviceHere();
                felitronics::test::run (never.p.process(iy, 1, kBlock));  never.p.serviceHere();
                for (int i = 0; i < kBlock; ++i) worst = std::max(worst, std::abs(x[(std::size_t) i] - y[(std::size_t) i]));
            }
            return worst;
        };
        ok(both(rest + 60) == 0.0f, "two and a half seconds on 150: identical, and by then slot 1 sleeps in one player");
        ok(sleeps.p.slotCold(1) && ! never.p.slotCold(1), "…which it does");
        sleeps.p.setDial("gain", 200.0); never.p.setDial("gain", 200.0);
        ok(both(rest + 60) == 0.0f, "the turn to 240 and two and a half seconds there: identical, slot 0 now asleep");
        ok(sleeps.p.slotCold(0) && ! sleeps.p.slotCold(1), "…the live buffer's slot, and the other awake");
        sleeps.p.setDial("gain", 150.0); never.p.setDial("gain", 150.0);
        ok(both(60) == 0.0f, "…and the turn back: identical to the last sample");
        ok(sleeps.p.modelLoads() == 2 && never.p.modelLoads() == 2, "neither player loaded anything for a turn");

        // …AND OFF THE MODEL RATE IT DOES NOT, which is the half this group did not say. Same protocol,
        // rebuilt per rate, with the shape of the difference read out rather than a peak: `wake` is the
        // block the slot comes back on, `after` is every block past it.
        struct Off { double fs; int taps; };
        for (const Off c : { Off { 44100.0, 1 }, Off { 96000.0, 1 }, Off { 44100.0, 2001 } }) {
            const std::string what = std::to_string((int) c.fs) + " Hz, "
                                   + (c.taps == 1 ? "a memoryless capture" : "a 2001-tap capture");
            std::map<std::string, std::vector<std::byte>> files;
            for (const char* id : { "g60", "g150", "g240", "r150" })
                files[id] = bytesOf(c.taps == 1 ? gainModel(1.0) : delayModel(c.taps - 1));
            Bench sl(rig, 1, c.fs), nv(rig, 1, c.fs);
            sl.files = files; nv.files = files; sl.load(rig); nv.load(rig);
            sl.p.setBlendShape({ 0.5, 0.0 }); nv.p.setBlendShape({ 0.5, 0.0 });
            nv.p.setColdAfterSeconds(0.0);
            std::vector<float> a((std::size_t) kBlock), b((std::size_t) kBlock);
            double ph = 0.0;
            const auto run = [&](int blocks, float* first) {
                float worst = 0.0f;
                for (int k = 0; k < blocks; ++k) {
                    for (int i = 0; i < kBlock; ++i) {
                        a[(std::size_t) i] = b[(std::size_t) i] = (float) (0.1 * std::sin(ph));
                        ph += 2.0 * 3.14159265358979323846 * 1000.0 / c.fs;
                    }
                    float* ia[1] { a.data() }; float* ib[1] { b.data() };
                    felitronics::test::run (sl.p.process(ia, 1, kBlock)); sl.p.serviceHere();
                    felitronics::test::run (nv.p.process(ib, 1, kBlock)); nv.p.serviceHere();
                    float w = 0.0f;
                    for (int i = 0; i < kBlock; ++i) w = std::max(w, std::abs(a[(std::size_t) i] - b[(std::size_t) i]));
                    if (first != nullptr && k == 0) *first = w;
                    worst = std::max(worst, w);
                }
                return worst;
            };
            const int restOff = (int) std::ceil(2.0 * c.fs / kBlock);
            ok(run(restOff + 60, nullptr) == 0.0f, "before any wake the two are still identical — " + what);
            ok(sl.p.slotCold(0) || sl.p.slotCold(1), "precondition: one of them really did sleep — " + what);
            sl.p.setDial("gain", 200.0); nv.p.setDial("gain", 200.0);
            float wake = 0.0f;
            const float rest2 = [&] { const float w = run(1, &wake); return w; } ();
            (void) rest2;
            const float after = run(restOff + 40, nullptr);
            if (c.taps == 1) {
                // 61 leading zeros at 44.1 kHz and 96 at 96 kHz, under the law's own 0.25-per-call ramp
                // and a 0.1 input: 4.97e-03 and 7.28e-03 measured. The bound is deliberately loose —
                // what this pins is that the difference EXISTS and is of that order, not its last digit.
                // 🔴 AN UPPER BOUND ONLY, DELIBERATELY. Asserting that the difference EXISTS would pin
                // today's defect as a requirement and FAIL the right answer: removing warmFor's early
                // return takes this to 5.36e-07 at 44.1 kHz and to exactly 0.000000000 at 96, both
                // measured, and that must pass here too. What is pinned is that it stays SMALL and,
                // below, that it stays CONFINED to the block of the wake — the two properties that
                // make it a stated cost rather than a regression. Today's reading is 4.97e-03 at
                // 44.1 kHz and 7.28e-03 at 96, against a 0.1 input.
                ok(wake < 2.0e-2f,
                   "the wake block may DIFFER off the model rate, bounded, and that is expected: "
                   + std::to_string(wake) + " — the slot's rate-matcher emitting its "
                   + std::to_string(sl.p.latencySamples()) + " leading zeros while warmFor's `pre <= 0`"
                   " early return has already made it audible (" + what + ")");
            } else {
                // This one IS a lower-bounded claim in spirit and stays true whichever way warmFor goes:
                // a capture with memory never took the early return, so it never had the transient.
                ok(wake < 1.0e-5f,
                   "…and a capture WITH memory does not show it at all: " + std::to_string(wake)
                   + " — warmFor does not take that early return there, which is what names the cause ("
                   + what + ")");
            }
            if (c.fs == 96000.0)
                ok(after == 0.0f, "…and at 96 kHz the wake block is the WHOLE of it: every later block is"
                                  " exactly zero, so the transient is not the resampler's resumption phase");
            else
                ok(after < 1.0e-5f, "…and past the wake only the rate-matcher's own floor remains: "
                                    + std::to_string(after) + " (" + what + ")");
        }
    }

    group("a slot's delay line is cleared on the way to sleep, as it is on a landing");
    {
        // THE BURST THIS CATCHES: with an alignment delay on the sleeping slot, its delay line held the
        // last hundred samples from before the rest; a model that declares no field is heard on the
        // block it wakes in, and those samples came out first — two seconds old, on a silent input.
        AlignmentTable table;
        table.lagByFile = { { "g60", 100 }, { "g150", 100 }, { "g240", 0 }, { "r150", 100 } };   // 240 is early: delayed by 100
        Bench b(rig);
        b.p.setBlendShape({ 0.5, 0.0 });
        b.p.setAlignment(table);
        const int rest = (int) std::ceil(2.0 * kFs / kBlock);
        b.rms(1000.0, 0.1, rest + 40, 8);
        ok(b.p.slotCold(1) && b.p.appliedSlotDelay(1) == 100, "the delayed neighbour is asleep");
        std::vector<float> z((std::size_t) kBlock);
        float* io[1] { z.data() };
        float peak = 0.0f;
        for (int k = 0; k < 8; ++k) { std::fill(z.begin(), z.end(), 0.0f); felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.serviceHere(); }
        for (const float v : z) peak = std::max(peak, std::abs(v));
        ok(peak == 0.0f, "silence in, silence out, before the turn");
        b.p.setDial("gain", 200.0);
        for (int k = 0; k < 8; ++k) {
            std::fill(z.begin(), z.end(), 0.0f); felitronics::test::run (b.p.process(io, 1, kBlock)); b.p.serviceHere();
            for (const float v : z) peak = std::max(peak, std::abs(v));
        }
        ok(peak == 0.0f, "…and after it: nothing of the rest comes back out (peak " + std::to_string(peak) + ")");
        ok(! b.p.slotCold(1) && b.p.liveMix() >= 1.0f, "the slot woke and took the sound — of a silent input");
    }

    group("between two captures both models run, however long the hand rests");
    {
        // SMOOTH between two captures: both are heard, so neither can be cold — two passes, as it
        // must be. The saving is for the dial at rest on a capture, never for a mix.
        Bench b(rig);
        b.p.setDial("gain", 200.0);
        b.p.clearCounters();
        const int rest = (int) std::ceil(2.0 * kFs / kBlock);
        approx(b.rms(1000.0, 0.1, rest + 40, 32) / (0.1 / std::sqrt(2.0)), (40.0 / 90.0) * 0.5 + (50.0 / 90.0) * 1.0, 0.015,
               "two and a half seconds at 200: still 4/9 and 5/9 of each");
        ok(! b.p.slotCold(0) && ! b.p.slotCold(1), "neither slot is cold");
        ok(b.p.coldBlocks(0) == 0 && b.p.coldBlocks(1) == 0, "…and neither slept a single block");
    }

    // ---------------------------------------------------------------- ONE MODEL AT A TIME ----
    const long dipLen = std::lround(RigPlayer::kDipSeconds * kFs);   // 720 samples

    group("one model: the neighbour is never asked for, never run — and the capture alone is the player as it was");
    {
        Bench b(rig);
        withFields(b, rig);
        ok(b.p.maxModels() == 2, "two by default: the player as it always was");
        ok(! b.p.setMaxModels(0) && ! b.p.setMaxModels(3) && ! b.p.setMaxModels(-1) && b.p.maxModels() == 2,
           "law 11: 0, 3 and -1 are refused, and change nothing");
        ok(b.p.setMaxModels(1) && b.p.maxModels() == 1, "one, asked for");
        Host h(b);
        h.play(400);                                                     // two seconds at 150, and more
        ok(h.jobs == 1 && h.took == "0:g150 ", "ONE job in two seconds at 150 — the capture, in its own slot (" + h.took + ")");
        ok(b.fetches == 1 && b.p.heldFileId(1).empty(), "…one fetch, and the far slot holds nothing: it was asked for nothing");
        ok(b.p.runBlocks(1) == 0 && b.p.pairBlocks() == 0,
           "no block ran a second network (" + std::to_string(b.p.pairBlocks()) + " pair blocks)");
        ok(b.p.runBlocks(0) >= 398, "the one model ran every block once it had landed (" + std::to_string(b.p.runBlocks(0)) + ")");

        // THE SAME SOUND as the player as it always was, with a pack that holds ONLY this capture on the
        // green channel — which plays both slots of it, and runs both for two seconds. This plays one.
        auto soloRig = testRig();
        auto& files = soloRig.chain[0].device.files;
        files.erase(std::remove_if(files.begin(), files.end(), [](const namz::rig::FileEntry& f) {
            return f.settings.at("channel") == "green" && f.settings.at("gain") != "150"; }), files.end());
        Bench s(soloRig);
        withFields(s, soloRig);
        Bench o(rig);
        withFields(o, rig);
        o.p.setMaxModels(1);
        Host hs(s), ho(o);
        std::vector<float> ys, yo;
        for (int k = 0; k < 400; ++k) {
            const auto& a = hs.block(); ys.insert(ys.end(), a.begin(), a.end());
            const auto& c = ho.block(); yo.insert(yo.end(), c.begin(), c.end());
        }
        ok(hs.jobs == 2 && ho.jobs == 1, "the solo pack loaded its capture twice, the one-model player once ("
                                         + hs.took + "/ " + ho.took + ")");
        const long diff = differing(yo, ys, 32L * kBlock);
        ok(diff == 0, "…and from the 32nd block on, the two are the same samples (" + std::to_string(diff) + " differ)");
    }

    group("one model: a change of capture is ONE dip — down, swap, up — never two networks, and it lands on the new capture's bits");
    {
        Bench b(rig);
        withFields(b, rig);
        b.p.setMaxModels(1);
        Bench ref(rig);                                 // the player as it always was, parked at 240 throughout
        withFields(ref, rig);
        ref.p.setDial("gain", 240.0);
        Host h(b), hr(ref);
        for (int k = 0; k < 200; ++k) { h.block(); hr.block(); }
        h.forget();
        ok(b.p.setDial("gain", 240.0), "the hand goes to 240 — a capture that lives in the OTHER slot");
        std::vector<float> y, want;
        int offRail = 0, blended = 0, restBlock = -1, ranAtRest = -1;
        for (int k = 0; k < 120; ++k) {
            const int ran0 = b.p.runBlocks(0);
            const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end());
            const auto& c = hr.block(); want.insert(want.end(), c.begin(), c.end());
            if (b.p.liveMix() > 0.0f && b.p.liveMix() < 1.0f) ++offRail;
            if (b.p.soundingLoudness().blended) ++blended;
            if (restBlock < 0 && b.p.slotCold(0)) { restBlock = k; ranAtRest = b.p.runBlocks(0) - ran0; }
        }
        ok(offRail == 0 && blended == 0, "through the dip the weight stands on a rail and nothing reads as a blend ("
                                         + std::to_string(offRail) + " blocks off a rail, " + std::to_string(blended) + " blended)");
        const auto dip = silenceIn(y);
        ok(dip.runs == 1, "exactly ONE stretch of silence (" + std::to_string(dip.runs) + ")");
        ok(std::abs(dip.first - dipLen) <= 1, "the fall ends kDipSeconds after the turn, to the sample (silence from "
                                              + std::to_string(dip.first) + ", " + std::to_string(dipLen) + " due)");
        // The hole is the incoming capture's warm-up and nothing else: at least the law's need (the field, 701, plus a
        // block — RigPlayer::warmFor; no rate-matcher at 48 kHz), at most that rounded up to a block, plus the rest of
        // the block the fall ends in.
        const long hole = dip.last - dip.first + 1, need240 = kField240 + 1 + kBlock, fallRest = kBlock - dipLen % kBlock;
        ok(hole >= need240 && hole <= need240 + kBlock + fallRest,
           "…and lasts the incoming capture's warm-up, fed while nothing is heard — no longer (" + std::to_string(hole)
           + " in [" + std::to_string(need240) + ", " + std::to_string(need240 + kBlock + fallRest) + "])");
        // ONE NETWORK ON AUDIO, plus the outgoing capture's bounded drain (NamStage feeds a lane it is no longer handed
        // its field of silence), which overlaps the incoming warm-up: the counters see that drain, so the bound is it.
        ok(b.p.pairBlocks() <= drainBlocks(kField150), "two networks only while the outgoing capture drains ("
                                                       + std::to_string(b.p.pairBlocks()) + " pair blocks)");
        ok(restBlock >= 0 && ranAtRest == 1, "…and the block it rests in, its drain is counted as a run ("
                                             + std::to_string(ranAtRest) + ")");
        ok(h.jobs == 1 && h.took == "1:g240 ", "ONE job: the new capture, into its own slot (" + h.took + ")");
        const long rose = dip.last + 1 + dipLen;
        ok(differing(y, want, rose) == 0 && differing(y, want, rose - kBlock) > 0,
           "kDipSeconds after the silence ends, every sample is the 240 capture's own — and not before ("
           + std::to_string(differing(y, want, rose)) + " differ after)");
        approx(b.p.liveMix(), 1.0, 0.0, "the weight stands on slot 1's rail");
        ok(b.p.slotCold(0) && b.p.heldFileId(0) == "g150", "the old capture RESTS in its slot, still loaded");

        // BACK to 150: its slot still holds it, so the swap is a wake — a warm-up, no load.
        h.forget();
        ok(b.p.setDial("gain", 150.0), "back to 150");
        y.clear();
        for (int k = 0; k < 60; ++k) { const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end()); }
        ok(silenceIn(y).runs == 1 && h.jobs == 0 && b.fetches == 2, "one dip, and no job: the capture never left ("
                                                                     + h.took + ")");
        ok(b.p.pairBlocks() <= drainBlocks(kField240) && b.p.slotCold(1) && b.p.heldFileId(1) == "g240",
           "…one network on audio, beside 240's drain as it rests (" + std::to_string(b.p.pairBlocks()) + " pair blocks)");

        // …and to 0, the bottom LINK — the 60 capture fed softer, in the SAME slot as the one sounding: the
        // swap happens in place, under the dip, and the far slot is not touched.
        h.forget();
        ok(b.p.setDial("gain", 0.0), "down to 0: a capture of the same slot's parity");
        y.clear();
        for (int k = 0; k < 60; ++k) { const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end()); }
        ok(silenceIn(y).runs == 1 && h.jobs == 1 && h.took == "0:g60 ", "one dip, one job, in place (" + h.took + ")");
        ok(b.p.pairBlocks() == 0 && b.p.heldFileId(0) == "g60" && b.p.heldFileId(1) == "g240",
           "…one network throughout; the far slot kept its capture");
        double e = 0.0; for (long i = (long) y.size() - kBlock; i < (long) y.size(); ++i) e += (double) y[(std::size_t) i] * y[(std::size_t) i];
        ok(e > 0.0, "…and it sounds");
    }

    group("one model -> two while playing: the neighbour is asked for at weight zero, and nothing changes until the dial moves");
    {
        Bench a(rig), twin(rig);
        withFields(a, rig); withFields(twin, rig);
        a.p.setMaxModels(1); twin.p.setMaxModels(1);
        Host ha(a), ht(twin);
        for (int k = 0; k < 200; ++k) { ha.block(); ht.block(); }
        ha.forget();
        ok(a.p.setMaxModels(2), "two, while playing");
        std::vector<float> ya, yt;
        float worstMix = 0.0f;
        for (int k = 0; k < 150; ++k) {
            const auto& u = ha.block(); ya.insert(ya.end(), u.begin(), u.end());
            const auto& v = ht.block(); yt.insert(yt.end(), v.begin(), v.end());
            worstMix = std::max(worstMix, a.p.liveMix());
        }
        ok(ha.jobs == 1 && ha.took == "1:g240 ", "the neighbour is asked for (" + ha.took + ")");
        ok(worstMix <= 0.0f && differing(ya, yt, 0) == 0, "…at weight zero: every sample the same as a twin that stayed at one ("
                                                          + std::to_string(differing(ya, yt, 0)) + " differ)");
        ok(a.p.pairBlocks() > 0 && ! a.p.slotCold(1), "…and it runs, warm and waiting, as a two-model player's neighbour does");
        ok(a.p.setDial("gain", 200.0), "the dial moves");
        std::vector<float> mix;
        for (int k = 0; k < 8; ++k) { ha.block(); mix.push_back(a.p.liveMix()); }
        ok(mix[0] > 0.0f && a.p.biggestJump() <= 0.25f + 1e-6f, "…and the weight glides at once, a quarter per block at most ("
                                                                + std::to_string(mix[0]) + " after the first block)");
        approx(mix.back(), 50.0 / 90.0, 1e-6, "…to the pair's mix at 200");
    }

    group("two -> one while playing: on a capture the neighbour rests and the sound does not change; between two, a dip to the nearer");
    {
        Bench a(rig), twin(rig);
        withFields(a, rig); withFields(twin, rig);
        Host ha(a), ht(twin);
        for (int k = 0; k < 100; ++k) { ha.block(); ht.block(); }   // half a second: the neighbour awake
        ok(! a.p.slotCold(1) && a.p.heldFileId(1) == "g240", "two models: the neighbour awake at zero");
        ha.forget();
        ok(a.p.setMaxModels(1), "one, while playing");
        std::vector<float> ya, yt;
        for (int k = 0; k < 150; ++k) {
            const auto& u = ha.block(); ya.insert(ya.end(), u.begin(), u.end());
            const auto& v = ht.block(); yt.insert(yt.end(), v.begin(), v.end());
        }
        ok(differing(ya, yt, 0) == 0, "every sample the same as a twin that stayed at two (" + std::to_string(differing(ya, yt, 0)) + " differ)");
        ok(a.p.slotCold(1) && a.p.runBlocks(1) <= drainBlocks(kField240) && ha.jobs == 0,
           "…the neighbour rested on the first block — it ran only its drain — and nothing was loaded ("
           + std::to_string(a.p.runBlocks(1)) + " blocks)");

        // Between two captures: the nearer one alone, by a dip — the captures both already held.
        Bench m(rig), ref(rig);
        withFields(m, rig); withFields(ref, rig);
        m.p.setDial("gain", 220.0);
        ref.p.setDial("gain", 240.0);
        Host hm(m), hr(ref);
        for (int k = 0; k < 200; ++k) { hm.block(); hr.block(); }
        approx(m.p.liveMix(), 70.0 / 90.0, 1e-6, "at 220, two captures sound: 2/9 of 150, 7/9 of 240");
        hm.forget();
        ok(m.p.setMaxModels(1), "one, between two captures");
        std::vector<float> y, want;
        for (int k = 0; k < 60; ++k) {
            const auto& u = hm.block(); y.insert(y.end(), u.begin(), u.end());
            const auto& v = hr.block(); want.insert(want.end(), v.begin(), v.end());
        }
        const auto dip = silenceIn(y);
        ok(dip.runs == 1 && hm.jobs == 0, "one dip and no job (" + std::to_string(dip.runs) + " silences, " + hm.took + ")");
        const int fallBlocks = (int) ((dipLen + kBlock - 1) / kBlock);
        ok(m.p.pairBlocks() <= fallBlocks + drainBlocks(kField150),
           "two networks only through the dip's fall — the stated exception — and the farther one's drain ("
           + std::to_string(m.p.pairBlocks()) + " pair blocks)");
        ok(differing(y, want, dip.last + 1 + dipLen) == 0, "…and then the 240 capture's own samples");
        ok(m.p.slotCold(0) && m.p.liveMix() >= 1.0f, "the farther capture rests; the weight stands on the nearer one's rail");
    }

    group("a cold start: an EMPTY slot that still carries weight is never heard — its stage passes the raw DI");
    {
        for (int fields = 0; fields < 2; ++fields) {
            Bench b(rig);
            if (fields == 1) withFields(b, rig);
            Host h(b);
            int checked = 0, leaks = 0;
            float prev = b.p.liveMix();
            for (int k = 0; k < 40; ++k) {
                const auto& y = h.block();
                const float mix = b.p.liveMix();
                const bool empty0 = b.p.heldFileId(0).empty() && (prev < 1.0f || mix < 1.0f);
                const bool empty1 = b.p.heldFileId(1).empty() && (prev > 0.0f || mix > 0.0f);
                if (empty0 || empty1) {
                    ++checked;
                    for (float v : y) if (v != 0.0f) { ++leaks; break; }
                }
                prev = mix;
            }
            ok(checked > 0 && leaks == 0, std::string(fields ? "WaveNets" : "gains") + ": every block an empty slot carries "
               "weight in is digital silence (" + std::to_string(leaks) + " of " + std::to_string(checked) + " leak)");
        }
    }

    group("one model -> two in the middle of a dip: the incoming capture is not heard until it is fed");
    {
        constexpr long kLong = 4000;                    // 240 with a field of 4001: fed fifteen whole blocks after it lands
        for (int F : { 3, 5, 7 }) {
            Bench b(rig);
            b.files["g150"] = bytesOf(waveNetDelayModel((int) kField150));
            b.files["g240"] = bytesOf(waveNetDelayModel((int) kLong));
            b.p.unload();
            b.load(rig);
            b.p.setMaxModels(1);
            Host h(b);
            h.play(200);
            b.p.setDial("gain", 240.0);
            int landed = -1, heard = 0, sounded = 0;
            float prev = b.p.liveMix();
            for (int k = 0; k < 60; ++k) {
                if (k == F) b.p.setMaxModels(2);
                const auto& y = h.block();
                const float mix = b.p.liveMix();
                if (landed < 0 && b.p.heldFileId(1) == "g240") landed = k;
                bool loud = false;
                for (float v : y) if (v != 0.0f) { loud = true; break; }
                const bool unfed = landed < 0 || k <= landed + (int) ((kLong + 1) / kBlock);
                if (loud && unfed && (prev > 0.0f || mix > 0.0f)) ++heard;
                sounded += loud ? 1 : 0;
                prev = mix;
            }
            ok(heard == 0 && sounded > 0 && b.p.liveMix() >= 1.0f && b.p.heldFileId(1) == "g240",
               "two models from dip block " + std::to_string(F) + ": no block with 240's weight in it sounds before 240 is "
               "fed (" + std::to_string(heard) + "), and 240 sounds in the end");
        }
    }

    group("one model: the hole is the incoming capture's warm-up, in time — a capture with no field costs at most a block");
    {
        Bench b(rig);
        withFields(b, rig);
        b.p.setMaxModels(1);
        Host h(b);
        h.play(200);
        h.forget();
        ok(b.p.setDial("gain", 60.0), "150 -> 60: a gain capture, no field, in the other slot");
        std::vector<float> y;
        for (int k = 0; k < 40; ++k) { const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end()); }
        const auto dip = silenceIn(y);
        const long hole = dip.runs == 1 ? dip.last - dip.first + 1 : -1;
        ok(dip.runs == 1 && hole <= kBlock, "one hole, of at most a block (" + std::to_string(hole) + " samples)");
        ok(h.jobs == 1 && h.took == "1:g60 " && b.p.liveMix() >= 1.0f, "…one job, and 60 sounds (" + h.took + ")");
    }

    group("one model: a hand resting on the handover does not flicker — the step has a deadband");
    {
        Bench b(rig);
        withFields(b, rig);
        b.p.setMaxModels(1);
        b.p.setDial("gain", 194.0);
        Host h(b);
        h.play(200);
        ok(b.p.heldFileId(0) == "g150" && b.p.liveMix() <= 0.0f, "at 194, the nearer capture: 150");
        h.forget();
        std::vector<float> y;
        for (int k = 0; k < 120; ++k) {
            if (k % 12 == 0) b.p.setDial("gain", (k / 12) % 2 ? 194.0 : 196.0);
            const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end());
        }
        const auto jitter = silenceIn(y);
        ok(jitter.runs <= 1 && h.jobs <= 1, "196, 194, ten times across the handover: at most one dip ("
                                            + std::to_string(jitter.runs) + " dips, " + std::to_string(h.jobs) + " jobs)");
        h.forget();
        y.clear();
        ok(b.p.setDial("gain", 210.0), "…and a real move, to 210");
        for (int k = 0; k < 40; ++k) { const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end()); }
        ok(silenceIn(y).runs == 1 && b.p.heldFileId(1) == "g240" && b.p.liveMix() >= 1.0f, "…is one dip, to 240");
    }

    group("one model -> two between captures: nothing changes until the neighbour is fed, then the weight glides to the dial's blend");
    {
        Bench a(rig), twin(rig);
        withFields(a, rig); withFields(twin, rig);
        a.p.setMaxModels(1); twin.p.setMaxModels(1);
        // 240, then back to 200 — inside the step's deadband, so 240 stays (a hand coming from 150 would keep 150).
        for (auto* p : { &a.p, &twin.p }) { p->setDial("gain", 240.0); p->setDial("gain", 200.0); }
        Host ha(a), ht(twin);
        for (int k = 0; k < 200; ++k) { ha.block(); ht.block(); }
        ok(a.p.liveMix() >= 1.0f && a.p.heldFileId(1) == "g240" && a.p.heldFileId(0).empty(),
           "one model at 200, come from 240: 240 alone");
        ha.forget();
        ok(a.p.setMaxModels(2), "two, the dial where it was");
        int landed = -1, moved = -1;
        long differ = 0;
        for (int k = 0; k < 40; ++k) {
            const auto& u = ha.block();
            const auto& v = ht.block();
            if (landed < 0 && a.p.heldFileId(0) == "g150") landed = k;
            if (moved < 0 && a.p.liveMix() < 1.0f) moved = k;
            if (moved < 0) for (int i = 0; i < kBlock; ++i) differ += u[(std::size_t) i] != v[(std::size_t) i] ? 1 : 0;
        }
        ok(differ == 0, "until the weight moves, every sample is the twin's that stayed at one (" + std::to_string(differ) + " differ)");
        ok(landed >= 0 && moved > landed + drainBlocks(kField150) - 1,
           "…and it moves only once 150 has landed and run its field (landed " + std::to_string(landed) + ", moved "
           + std::to_string(moved) + ")");
        ok(a.p.biggestJump() <= 0.25f + 1e-6f, "…then glides, a quarter per block at most");
        approx(a.p.liveMix(), 50.0 / 90.0, 1e-6, "…to the dial's own blend at 200, with no hand on the dial");
    }

    group("one model: crossing a LINK costs a load — one file at two angles of different parity");
    {
        Bench b(rig);
        withFields(b, rig);
        b.p.setMaxModels(1);
        b.p.setDial("gain", 0.0);
        Host h(b);
        h.play(200);
        ok(b.p.heldFileId(0) == "g60" && b.p.liveMix() <= 0.0f, "at 0, the link: g60, in slot 0");
        h.forget();
        b.p.setDial("gain", 60.0);
        std::vector<float> y;
        for (int k = 0; k < 40; ++k) { const auto& a = h.block(); y.insert(y.end(), a.begin(), a.end()); }
        ok(silenceIn(y).runs == 1 && h.jobs == 1 && h.took == "1:g60 ",
           "0 -> 60: one dip and one job — the same file, into the other slot (" + h.took + ")");
    }

    group("a load the law asks for is offered to the host only after both stages have run the block that asked");
    {
        // 200 -> 100: slot 1's 240 must become 60. Its weight travels to zero, and it is asked for in the block where it
        // ARRIVES there — a block that STARTED at 0.056 of the sound. A host that took the job and delivered it before
        // that block's stages ran would play the new, unfed model in it.
        Bench a(rig), twin(rig);
        a.p.setDial("gain", 200.0); twin.p.setDial("gain", 200.0);
        Host ha(a), ht(twin);
        for (int k = 0; k < 200; ++k) { ha.block(); ht.block(); }
        ok(a.p.heldFileId(1) == "g240" && a.p.liveMix() > 0.5f, "at 200: 150 and 240 sounding");
        ha.forget(); ht.forget();
        a.p.setDial("gain", 100.0); twin.p.setDial("gain", 100.0);
        gDeliverInside = &a.p;
        gDeliveredInside = 0;
        long differ = 0;
        for (int k = 0; k < 40; ++k) {
            const auto& u = ha.block();
            const auto& v = ht.block();
            for (int i = 0; i < kBlock; ++i) differ += u[(std::size_t) i] != v[(std::size_t) i] ? 1 : 0;
        }
        gDeliverInside = nullptr;
        ok(ha.jobs + gDeliveredInside == 1 && ht.jobs == 1 && a.p.heldFileId(1) == "g60", "one job: 60, into slot 1");
        ok(gDeliveredInside == 0 && differ == 0, "…and nobody could have delivered it inside the block that asked: every "
           "sample is the twin's (" + std::to_string(gDeliveredInside) + " delivered inside, " + std::to_string(differ) + " differ)");
    }

    group("unload: silence, and a second device loads clean");
    {
        Bench b(rig);
        approx(b.gainAt(1000.0), 0.5, 0.01, "sounding");
        b.p.unload();
        ok(! b.p.loaded() && b.p.settings().empty(), "nothing loaded");
        const double after = b.rms(1000.0, 0.1, 8, 8);
        ok(after < 1e-6, "…and nothing sounds");
        b.load(rig);
        approx(b.gainAt(1000.0), 0.5, 0.01, "loaded again, sounding again");
    }

    // The dry leg's applied delay, measured as a POSITION rather than inferred from a comb. Used by
    // two groups below, so it lives out here rather than being written twice.
    auto appliedDryDelay = [](Bench& b, double& peakOut, int blocks = 8) {
        std::vector<float> l((std::size_t) kBlock, 0.0f), r((std::size_t) kBlock, 0.0f);
        float* io[2] { l.data(), r.data() };
        for (int i = 0; i < 48; ++i) {          // settle: the load is serviced from the audio loop,
            std::fill(l.begin(), l.end(), 0.0f);  //   and the blend gains ramp
            felitronics::test::run(b.p.process(io, 1, kBlock));
            b.p.serviceHere();
        }
        int bestIdx = -1; double best = 0.0;
        for (int blk = 0; blk < blocks; ++blk) {
            std::fill(l.begin(), l.end(), 0.0f);
            if (blk == 0) l[0] = 1.0f;         // one impulse, then silence
            felitronics::test::run(b.p.process(io, 1, kBlock));
            b.p.serviceHere();
            for (int i = 0; i < kBlock; ++i)
                if (std::fabs((double) l[(std::size_t) i]) > best)
                    { best = std::fabs((double) l[(std::size_t) i]); bestIdx = blk * kBlock + i; }
        }
        peakOut = best;
        return bestIdx;
    };

    // Hoisted out of the group below: the capacity group that follows measures the same rig at a
    // different host rate, and a second copy of a fixture is a restatement like any other.
    auto combRig = [] {
        auto rig = testRig();
        auto& mix = rig.chain[0].blend.front();
        mix.dryLevelDb = 0.0;                       // no dry trim: a true 50/50 at the middle
        mix.defaultValue = "150";
        namz::rig::BlendPosition dryEnd; dryEnd.value = "0";   dryEnd.norm = 0.0; dryEnd.dryDb = 0.0;    dryEnd.wetDb = -120.0;
        namz::rig::BlendPosition half;   half.value   = "150"; half.norm   = 0.5; half.dryDb   = 0.0;    half.wetDb   = 0.0;
        namz::rig::BlendPosition wetEnd; wetEnd.value = "300"; wetEnd.norm = 1.0; wetEnd.dryDb = -120.0; wetEnd.wetDb = 0.0;
        mix.positions = { dryEnd, half, wetEnd };
        return throughTheFormat(rig);
    };

    // ================================================================================================
    group("🔴 THE DRY/WET BLEND MUST NOT COMB — the rate-match delay belongs to BOTH legs");
    {
        // WHAT THIS IS FOR. The mix in process() sums `a` — which has been through the models, hence
        // through their rate-match — with `d`, the DI. Nothing used to hold `d` back, so the two were
        // misaligned by exactly latencySamples() and their sum was a COMB FILTER with its first null at
        // fs/(2·D). That is not a new defect: with the Catmull-Rom cubic's 3.84 samples the null sat at
        // 5742 Hz and nobody had put a number on it. P34's 64-tap kernel makes D = 61.4 samples and
        // moves the null to 359 Hz — the body of a guitar, not a phasey top.
        //
        // 🔴 AND THE HOST CANNOT FIX IT. latencySamples() reports the whole player's PDC outward, so a
        // DAW delays everything downstream equally; this notch is INTERNAL to the blend, between two
        // legs of the same signal. The only place it can be fixed is here.
        //
        // The fixture is built so that the ONLY difference between the two legs is the models and their
        // rate-match: the dry curve is flat, and magnitudeCurveToFir returns {} for anything under
        // 0.05 dB, so the dry FIR is bypassed; the tone controls sit at their reference positions, so
        // the wet FIRs are empty too; and the models are memoryless Linear gains. Anything left that is
        // not flat across frequency is the misalignment.

        // 44.1 kHz on purpose: the models are tagged 48 000, so this is the rate at which NamStage
        // engages its rate-matcher at all. At 48 kHz there is no resampler and nothing to align.
        Bench b(combRig(), 1, 44100.0);
        ok(b.p.setDial("mix", 150.0), "the blend knob takes the middle of its travel");

        // ---- PRECONDITIONS. Without these the sweep below is a fixture that cannot fail. ----------
        // ORDER MATTERS HERE, and the first draft got it wrong in a way worth recording: the load is
        // posted by the Bench constructor and SERVICED from inside the audio loop, so a player that has
        // not yet run a block still has empty slots and reports 0 samples of latency. The precondition
        // caught it — reading "D = 0" and passing a beautifully flat sweep is exactly the blind fixture
        // this is here to prevent — so the measurement runs first and the claim about it second.
        const double atHalf = b.gainAt(1000.0);

        const int lat = b.p.latencySamples();
        ok(lat > 0, "precondition 1: at 44.1 kHz the WET leg really is delayed — the player reports "
                    + std::to_string(lat) + " samples of rate-match latency. At 48 kHz this would be 0 "
                    "and the whole group would pass while measuring nothing");

        // …and the dry path is genuinely IN THE SUM. A blend that silently sat at full wet would give a
        // beautifully flat sweep and prove nothing, which is the same shape of blindness one level up.
        ok(b.p.setDial("mix", 300.0), "…and the knob reaches its wet end");
        const double atWet = b.gainAt(1000.0);
        ok(b.p.setDial("mix", 0.0), "…and its dry end");
        const double atDry = b.gainAt(1000.0);
        ok(b.p.setDial("mix", 150.0), "…and comes back to the middle");
        ok(std::fabs(atHalf - atWet) > 0.2 * std::max(atHalf, atWet),
           "precondition 2: the dry path is audibly IN the sum — 50/50 reads "
           + std::to_string(atHalf) + " against " + std::to_string(atWet) + " at the wet end, a "
           + std::to_string(100.0 * std::fabs(atHalf - atWet) / std::max(atHalf, atWet)) + " % difference");

        // precondition 3: the two legs are COMPARABLE in level, so a null can actually form. A comb's
        // depth is set by how equal its two arms are — |1 - g| against |1 + g| — so a blend where one
        // leg is 40 dB below the other would ripple by a fraction of a dB even completely unaligned,
        // and the sweep below would pass on a broken player. Measured here: dry-only "
        // + atDry + ", wet-only " + atWet + ", i.e. within a few dB of each other.
        std::printf("      legs at 1 kHz: dry-only %.4f, wet-only %.4f, 50/50 %.4f\n", atDry, atWet, atHalf);
        ok(std::fabs(db(atDry) - db(atWet)) < 12.0,
           "precondition 3: the two legs are within " + std::to_string(std::fabs(db(atDry) - db(atWet)))
           + " dB of each other, so a misalignment CAN null them — a lopsided blend would ripple by "
             "almost nothing however badly it were aligned");

        // ---- THE SWEEP. Frequencies chosen AGAINST the defect, not on a round grid: the first three
        // nulls of an unaligned 61.4-sample comb sit at fs/(2D)·{1,3,5} = 359 / 1077 / 1796 Hz, and the
        // peaks between them at fs/D·{1,2} = 718 / 1436. A grid of decades would have straddled all of
        // them and read almost flat. --------------------------------------------------------------
        const double probes[] = { 100.0, 359.1, 500.0, 718.2, 1077.4, 1436.5, 1795.6, 3000.0, 6000.0, 10000.0 };
        double lo = 1e9, hi = 0.0, loAt = 0.0, hiAt = 0.0;
        for (const double f : probes) {
            const double g = b.gainAt(f);
            if (g < lo) { lo = g; loAt = f; }
            if (g > hi) { hi = g; hiAt = f; }
        }
        std::printf("      50/50 blend at 44.1 kHz, D = %d: response spans %.4f (%.0f Hz) .. %.4f (%.0f Hz)"
                    " = %.3f dB\n", lat, lo, loAt, hi, hiAt, db(hi) - db(lo));
        ok(db(hi) - db(lo) < 0.5,
           "the blend is FLAT across the comb's own null frequencies (" + std::to_string(db(hi) - db(lo))
           + " dB of ripple over 100 Hz .. 10 kHz). MEASURED on this fixture with the alignment removed:"
             " 9.54 dB of ripple, the minimum landing on one of the comb's nulls (359 or 1077 Hz — they"
             " are equally deep and which reads lowest is float rounding) and the maximum at 1436 Hz,"
             " which is the peak between them. Depth is set by how equal the legs are: dry 1.00 against"
             " wet 0.50 gives |1-0.5| against |1+0.5| = 9.54 dB, and a true 50/50 would null completely."
             " The threshold is 0.5 dB, a factor of nineteen under the measurement");

        // …and the deepest single probe is the one the defect would have destroyed. Asserted on its own
        // so a failure names the frequency instead of a span.
        const double atNull = b.gainAt(359.1);
        ok(db(atNull) - db(atHalf) > -0.5,
           "359.1 Hz — the first null of an unaligned 61.4-sample comb — is within half a dB of 1 kHz ("
           + std::to_string(db(atNull) - db(atHalf)) + " dB), not in a notch");
    }

    // ================================================================================================
    group("🔴 THE DRY ALIGNER'S CAPACITY, CHECKED WHERE IT IS MEAN — 384 kHz, not 44.1");
    {
        // WHY A SECOND RATE, AND WHY THIS ONE. The group above runs at 44.1 kHz. It used to be a
        // four-fold margin there — capacity 256 against a delay of 61, so the sizing arithmetic could
        // be wrong by almost anything and the sweep stayed flat — and a diverse-testing round proved
        // that was not a worry but a hole: TWO mutations of that arithmetic survived the entire suite,
        // swapping the two rates and dropping the "+ 2".
        //
        // 🔴 P38 REMOVED THAT MARGIN EVERYWHERE, so the sentence above is history rather than the
        // present: the capacity is now `maxLatencySamples(fs) + 1`, which is 62 at 44.1 kHz against a
        // delay of 61. Usable capacity equals the bound; an individual model can request less.
        // That makes this second rate LESS load-bearing than it
        // was and the group is kept anyway: 384 kHz exercises a larger delay than ordinary host rates.
        // The later 3 MHz test exercises the largest supported host.
        //
        // 🔴 THAT PARAGRAPH ALSO CARRIED A FLOOR THAT NO LONGER EXISTS, and it is corrected rather
        // than deleted because the reason it was written still holds. The old threshold was misstated:
        // the floor bound through 333000 Hz. Capacity was floored at 256, so 44.1, 96 and 192 kHz sized to 256
        // for the cited mutations. That mitigation lasted until P38 removed
        // the floor; since then every rate sizes from the geometry, no rate is equivalent-by-flooring,
        // and 384 kHz earns its place on the size of the number rather than on being past a threshold.
        //
        // 🔴 AND THE INSTRUMENT IS THE DELAY, NOT THE COMB. A comb reading cannot see this: the mutant
        // that drops the spare slot is short by exactly ONE sample, whose first null sits at
        // fs/2 = 192 kHz, which reads -0.117 dB at 20 kHz — a quarter of the 0.5 dB threshold the group
        // above uses, i.e. a defect that fits under its own tolerance. So this measures the quantity
        // itself. (The slot was "+ 2" when this was written and is "+ 1" since P38; the arithmetic of
        // the sentence is unchanged — one slot is one sample either way.) It can, because the
        // dry leg here is a PURE DELAY — the dry curve is flat so magnitudeCurveToFir returns {} and
        // the dry FIR is bypassed, and the models are memoryless — which makes the position of an
        // impulse in the output the applied delay, exactly, in samples.

        // PRECONDITION 0 — the instrument reads POSITION, not merely "something arrived". At 48 kHz the
        // models need no rate-match, the player asks for zero delay, and the impulse must come back at
        // index zero. Without this cell a lambda that always returned the same index would pass below.
        {
            Bench b48(combRig(), 1, 48000.0);
            ok(b48.p.setDial("mix", 0.0), "…the blend sits at its dry end at 48 kHz too");
            double peak0 = 0.0;
            const int at0 = appliedDryDelay(b48, peak0);
            ok(b48.p.latencySamples() == 0 && at0 == 0,
               "precondition 0: at 48 kHz the player asks for " + std::to_string(b48.p.latencySamples())
               + " samples of dry delay and the impulse returns at index " + std::to_string(at0)
               + " — the instrument resolves POSITION, so a shifted answer below means a shifted delay");
        }

        Bench b(combRig(), 1, 384000.0);
        ok(b.p.setDial("mix", 0.0), "the blend sits at its dry end — the leg under test is the only one sounding");

        double peak = 0.0;
        const int measured = appliedDryDelay(b, peak);
        const int asked    = b.p.latencySamples();

        // PRECONDITION 1 — the delay asked for is the one the geometry says, and it is LARGE.
        ok(asked == 288,
           "precondition 1: at a 384 kHz host against a 48 kHz model the player asks the dry path for "
           + std::to_string(asked) + " samples (geometry: 32 + 32·8 = 288, exactly an integer; "
           "a one-slot capacity reduction is exposed by the impulse below)");
        // PRECONDITION 2 — capacity has no margin over the requested delay at THIS host/tag pair.
        // In general it equals the bound plus one, not every model's request: at 48 kHz all accepted
        // models request zero and the bound is 64. This used to read "288 exceeds the usable range of the
        // 256 that shipped", and that floor is gone: the sizing is derived now, so the usable range is
        // exactly what this player asks here. Asserted as the property
        // rather than the old number, because the old number would still PASS and would no longer mean
        // anything.
        ok(RigPlayer::dryAlignerCapacity(384000.0) - 1 == asked,
           "precondition 2: the capacity's usable range is " 
           + std::to_string(RigPlayer::dryAlignerCapacity(384000.0) - 1) + " against " 
           + std::to_string(asked) + " asked — EXACTLY equal, so any sizing error at all is visible "
           "here. Before P38 it was 289 against 288: the floor was already inert at this rate (it "
           "binds only below 333001) and the spare slot was the whole margin. A first draft of this "
           "line said 255 and blamed the floor — a pre-merge round measured it false");
        // PRECONDITION 3 — the instrument is not reading noise.
        ok(peak > 0.1,
           "precondition 3: the impulse really is in the output — peak " + std::to_string(peak)
           + ", against a wet leg held 120 dB down");

        // THE CLAIM. Both surviving mutants fail exactly here, and they fail by DIFFERENT amounts, which
        // is why the message prints the difference rather than a verdict. RE-DERIVED for P38's sizing
        // (`maxLatencySamples(fs) + 1`, the geometry taken at the accepted window's low edge 47999.5):
        //   swapping the two rates → 32 + 32·47999.5/384000 = 35.99996 → 36, capacity 37, usable 36
        //                            against 288 asked → clamped, SHORT BY 252;
        //   the spare slot dropped → capacity 288, usable 287 → short by 1.
        // The first of those was 33 samples under the old floored sizing and is 252 under this one; the
        // second is one sample either way.
        ok(measured == asked,
           "the dry path is delayed by EXACTLY what the player reports — asked " + std::to_string(asked)
           + ", measured " + std::to_string(measured) + " (difference " + std::to_string(measured - asked)
           + "). DryAligner clamps to capacity-1 SILENTLY, so a capacity that is one slot short shows up "
             "here as a one-sample shift; the pure capacity pins and 44.1 kHz blend also catch it");

        // A SECOND ORACLE, OF A DIFFERENT CONSTRUCTION, for the mutant that is loud enough to hear — and
        // its frequency MOVED with the sizing, which is exactly how a second oracle goes blind. Under
        // the old floored capacity the swap cost 33 samples and notched at fs/(2·33) = 5818 Hz; under
        // P38's it costs 252 and notches at fs/(2·252) = 762 Hz. Probing 5818 Hz now would read a
        // PASSBAND of the 252-sample comb (5818/762 = 7.63, between nulls) and the oracle would agree
        // with the mutant. The one-sample mutant is inaudible here by construction and is caught by the
        // line above alone.
        ok(b.p.setDial("mix", 150.0), "…and back to a 50/50 blend for the audible half of the check");
        const double atRef  = b.gainAt(1000.0);
        const double atNull = b.gainAt(762.0);
        std::printf("      384 kHz, D = %d: 50/50 blend reads %.4f at 1 kHz, %.4f at 762 Hz (%.3f dB)\n",
                    asked, atRef, atNull, db(atNull) - db(atRef));
        ok(db(atNull) - db(atRef) > -0.5,
           "762 Hz — the first null a 252-sample misalignment would cut, which is what a swapped pair of "
           "rates costs at this host rate under P38's sizing — is within half a dB of 1 kHz ("
           + std::to_string(db(atNull) - db(atRef)) + " dB)");
    }

    // ================================================================================================
    group("🔴 A HOST RATE OUT OF RANGE FALLS BACK — and the property is the RANGE, not finiteness");
    {
        // WHY. prepare() derives the dry-aligner capacity from the rate — `(int) ceil(f(fs_)) + 2` —
        // and an out-of-range float→int conversion is undefined. The guard in front of it once said
        // `isfinite`, which is not that property: 1e300 is perfectly finite and converts just as badly
        // as an infinity. Measured through this very function with UBSan before the guard was widened,
        // prepare(1e300, 64, 2) returned TRUE and fired twice — the conversion, then `INT_MAX + 2`.
        // The same line has a second, entirely legal face: the capacity used to be a constant and is
        // now a function of the argument, so one prepare() call asked the heap for 508.6 MiB at 1e11.
        //
        // A sanitizer is not in the default build, so this gates the fix by VALUE instead: latency is
        // computed from fs_, so a rate that was NOT replaced shows up in it immediately.
        // 🔴 AND THE BLOCKS ARE NOT OPTIONAL. The first draft of this read latencySamples() straight
        // after prepare() and every cell passed — including the ones that were supposed to fail. The
        // load is POSTED by the Bench constructor and SERVICED from inside the audio loop, so a player
        // that has not yet run a block has empty slots and reports 0 whatever its rate. The
        // precondition below is what caught it; without those two lines this whole group was a fixture
        // that could not fail.
        const auto rig = testRig();
        auto latencyPreparedAt = [&rig](double rate) {
            Bench b(rig, 1, rate);
            std::vector<float> l((std::size_t) kBlock, 0.0f), r((std::size_t) kBlock, 0.0f);
            float* io[2] { l.data(), r.data() };
            for (int i = 0; i < 8; ++i) { felitronics::test::run(b.p.process(io, 1, kBlock)); b.p.serviceHere(); }
            return b.p.latencySamples();
        };
        // A rate inside the range is KEPT — without this the group would pass on a guard that threw
        // every rate away, which is the same blindness one level down.
        ok(latencyPreparedAt(384000.0) == 288,
           "precondition: a rate inside the range is kept — 384 kHz still reports "
           + std::to_string(latencyPreparedAt(384000.0)) + " samples, so the guard is not simply "
           "swallowing everything");
        ok(RigPlayer::kMaxSampleRate == 3.0e6 && latencyPreparedAt(RigPlayer::kMaxSampleRate) == 2032,
           "…and the ceiling itself is INSIDE the range: a host at kMaxSampleRate = "
           + std::to_string(RigPlayer::kMaxSampleRate) + " reports "
           + std::to_string(latencyPreparedAt(RigPlayer::kMaxSampleRate))
           + " samples, want 2032 = 32 + 32·62.5 — so the comparison is <= and not <, and the constant "
             "is the house 3.0e6 rather than whatever it happens to be");

        // 🔴 THE TWO PURE FUNCTIONS, PINNED DIRECTLY — the same reason the nam suite pins rateMatch:
        // nothing in this repository varies them, and what they decide is invisible to every signal
        // test in the tree. Values computed BY HAND from the two documented facts — kHalf per leg, the
        // return leg converted at h/m — evaluated at the ACCEPTED WINDOW'S LOW EDGE (47999.5, the
        // slowest model NamStage will take, hence the longest round trip), rounded to nearest, plus the
        // one slot DryAligner's [0, capacity-1] costs. NOT by asking the code.
        //
        // 🔴 THIS TABLE USED TO PIN A FLOOR OF 256 AND A SPARE SLOT, AND BOTH ARE GONE WITH THE DEFECT
        // THEY MITIGATED (P38). They existed because install() judged a model against the rate the
        // stage was RUNNING and prepare() then adopted it, so repeated loads walked the run rate down
        // without bound and no capacity derived from 48 kHz could be trusted. The gate's reference is
        // the constant now, so the window is fixed and the capacity is derivable — and a mitigation
        // that outlives its defect is just a number nobody can re-derive.
        {
            struct C { double fs; int want; const char* why; };
            for (const C c : { C {  44100.0,   62, "32 + 32*44100/47999.5 = 61.400306 -> 61, +1" },
                               C {  96000.0,   97, "32 + 64.000667 = 96.000667 -> 96, +1" },
                               C { 192000.0,  161, "32 + 128.001333 -> 160, +1" },
                               C { 352800.0,  268, "32 + 235.202450 = 267.202450 -> 267, +1" },
                               C { 384000.0,  289, "32 + 256.002667 -> 288, +1" },
                               C { RigPlayer::kMaxSampleRate, 2033, "the ceiling: 32 + 2000.020834 -> 2032, +1" },
                               C {     0.0,    65, "a rejected rate becomes 48 kHz: 32 + 32.000333 -> 64, +1" },
                               C {    1e300,   65, "…and so does a finite-but-out-of-range one" } })
                ok(RigPlayer::dryAlignerCapacity(c.fs) == c.want,
                   "dryAlignerCapacity(" + std::to_string(c.fs) + ") = "
                   + std::to_string(RigPlayer::dryAlignerCapacity(c.fs)) + ", want "
                   + std::to_string(c.want) + " — " + c.why);

            // 🔴 THE CELL THAT SEPARATES THE TWO DERIVATIONS. Everywhere above, asking the geometry at
            // the NOMINAL 48000 gives the same integer, so a table of round rates cannot tell "derived
            // from the accepted window" from "derived from the nominal rate". At 2999249 Hz it can:
            // 32 + 32*2999249/48000 = 2031.499333 rounds to 2031, while 32 + 32*2999249/47999.5 =
            // 2031.520162 rounds to 2032 — and 2032 is what an accepted model tagged 47999.5 really
            // reports. A ring built as `lround(nominal) + 1` therefore has a usable range of 2031 and
            // clamps it by one sample, in silence. It is not a lone freak either: the two derivations
            // disagree at 30256 integer hosts in [40000, 3e6], the lowest of them 96749 Hz — which is
            // 1.3 kHz above a rate people actually run.
            //
            // 🔴 AND WHAT IT DOES *NOT* SAY, because the first draft of this comment said it and a
            // review round measured it false: the capacity that SHIPPED — max(256, ceil(nominal) + 2) —
            // was 2034 here, usable 2033, and did NOT clamp. The spare slot covered exactly this. So
            // the cell is the gate on the NEW derivation's argument, not evidence against the old code.
            ok(RigPlayer::dryAlignerCapacity(2999249.0) == 2033,
               "dryAlignerCapacity(2999249) = " + std::to_string(RigPlayer::dryAlignerCapacity(2999249.0))
                   + ", want 2033 — asking at the nominal rate would give 2032, one slot short of an "
                     "accepted model's 2032-sample delay");

            // …and the capacity is a FUNCTION of the rate, not a constant: no two neighbours in the
            // table share a value, and a mutant returning any fixed number fails on the second cell.
            ok(RigPlayer::dryAlignerCapacity(44100.0) < RigPlayer::dryAlignerCapacity(96000.0)
                   && RigPlayer::dryAlignerCapacity(96000.0) < RigPlayer::dryAlignerCapacity(192000.0)
                   && RigPlayer::dryAlignerCapacity(192000.0) < RigPlayer::dryAlignerCapacity(384000.0),
               "…and it rises strictly with the host rate, so no constant passes this table");

            // 🔴 AND THE CAPACITY IS SUFFICIENT, which the cells above do not say: a pin only says the
            // number did not change. This says the number is RIGHT — DryAligner's usable range is
            // capacity-1, so it must cover what the stage really reports for EVERY model the stage
            // would accept, and the window is swept rather than sampled at its edges.
            {
                int checked = 0, covered = 0;
                for (const double h : { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0,
                                        352800.0, 384000.0, 2999249.0, RigPlayer::kMaxSampleRate })
                    for (int k = 0; k <= 40; ++k)
                    {
                        const double m = 47999.5 + 0.025 * k;      // the whole accepted window
                        ++checked;
                        if (felitronics::nam::NamStage::rateMatch(h, m).latencySamples
                                <= RigPlayer::dryAlignerCapacity(h) - 1)
                            ++covered;
                    }
                ok(covered == checked, "the capacity's usable range covers every accepted model rate at "
                                       "every host tried: " + std::to_string(covered) + "/"
                                       + std::to_string(checked));
            }

            // 🔴 A NON-INTEGER RATE, because every other cell in this file is a whole number and a review
            // round exploited exactly that: a mutant that FLOORED the host rate passed the entire
            // repository. Rates are doubles in this API and 48000.6 is a real one — it is the rate the
            // resampling gate is pinned against one file over.
            ok(RigPlayer::usableSampleRate(48000.6) == 48000.6,
               "usableSampleRate(48000.6) = " + std::to_string(RigPlayer::usableSampleRate(48000.6))
               + " — a fractional rate survives unrounded, which no integer cell can tell you");

            for (const C c : { C { 48000.0, 48000, "a sane rate is kept" },
                               C { RigPlayer::kMaxSampleRate, 3000000, "the ceiling is INSIDE the range (<=, not <)" },
                               C { 0.0, 48000, "zero" }, C { -48000.0, 48000, "negative" },
                               C { 1e300, 48000, "finite, out of range" },
                               C { 3.0e6 * 1.000001, 48000, "a hair over the ceiling" } })
                ok(RigPlayer::usableSampleRate(c.fs) == (double) c.want,
                   "usableSampleRate(" + std::to_string(c.fs) + ") = "
                   + std::to_string(RigPlayer::usableSampleRate(c.fs)) + " — " + c.why);
            ok(RigPlayer::usableSampleRate(std::numeric_limits<double>::quiet_NaN()) == 48000.0
                   && RigPlayer::usableSampleRate(std::numeric_limits<double>::infinity()) == 48000.0,
               "…and NaN and infinity fall back too, which is what makes an explicit isfinite "
               "redundant rather than merely unnecessary");
        }

        struct Bad { double rate; const char* name; };
        for (const Bad r : { Bad { 0.0, "zero" }, Bad { -48000.0, "negative" },
                             Bad { std::numeric_limits<double>::quiet_NaN(), "NaN" },
                             Bad { std::numeric_limits<double>::infinity(), "infinite" },
                             Bad { 1e300, "1e300 — FINITE, and the one the old guard let through" },
                             Bad { 1e11, "1e11 — finite, and the one that asked for 508 MiB" },
                             Bad { RigPlayer::kMaxSampleRate * 1.000001, "a hair over the ceiling" } })
            ok(latencyPreparedAt(r.rate) == 0,
               std::string("a ") + r.name + " host rate falls back to 48 kHz — reported latency "
               + std::to_string(latencyPreparedAt(r.rate)) + ", the same 0 a 48 kHz host gives. With "
               "only `isfinite` in front of it, 1e300 reported -1 and 1e11 reported 66666699");

        // …and the capacity really is derived, all the way to the top of the range: the impulse comes
        // back exactly where the player says it will, at a rate 7.8x the highest a DAW offers.
        {
            Bench b(combRig(), 1, RigPlayer::kMaxSampleRate);
            ok(b.p.setDial("mix", 0.0), "…the blend sits at its dry end at 3 MHz too");
            double peak = 0.0;
            const int measured = appliedDryDelay(b, peak, 16);
            const int asked    = b.p.latencySamples();
            ok(asked == 2032 && measured == asked,
               "at the ceiling rate the dry path is delayed by exactly what the player reports — asked "
               + std::to_string(asked) + ", measured " + std::to_string(measured)
               + " — so the capacity is computed correctly across the whole accepted range, not just "
                 "at the two rates the rest of this file uses");
        }
    }

    group("P86: reset() — the restart a product can actually call, through the player");
    {
        // 🔴 WHY THIS GROUP EXISTS. P47 made `nam::NamStage::reset()` an exact stream restart, and it
        // was unreachable from the product: orbit-amp reaches a NamStage only through this class, whose
        // `releaseResources()` is empty and which overrides no host reset, and this class had no
        // restart verb and never called `nam_[i].reset()`. P85 opened HALF that road — `prepare()`
        // performs the restart now, and `RigPlayer::prepare()` already forwards to it — and P86 opens
        // the other half, the verb a host can call without reconfiguring. So the gate that matters is
        // not "the stage flushes", which the nam suite owns, but "the player flushes, asked the way the
        // product asks", by BOTH verbs.

        // A DEVICE WITH MEMORY. The bench's own captures are memoryless gains, which cannot tell a
        // flush from a no-op: every fixture here is a `delayModel`, whose whole output IS what it was
        // fed `d` samples ago, so anything left behind is audible at full amplitude.
        const auto memoryRig = [] {
            namz::rig::Rig r;
            namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
            namz::rig::Control g; g.name = "gain"; g.role = namz::rig::Role::Gain;
            g.values = { "60", "150", "240" }; g.sweep = 300;
            st.device.controls = { g };
            namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
            namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
            namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
            st.device.files = { fe, fm, fl };
            r.chain = { st };
            return r;
        }();

        // 1. SILENCE IN, EXACT ZERO OUT, after the restart — at a rate where a rate-matcher IS
        //    installed (44.1 kHz) and one where it is not (48 kHz), mono and stereo, and through BOTH
        //    verbs: reset() is P86's, prepare() is P85's arriving at the same door.
        for (const double fs : { 44100.0, 48000.0 })
        for (const int nch : { 1, 2 })
        for (int viaPrepare = 0; viaPrepare < 2; ++viaPrepare)
        {
            const std::string where = std::string(viaPrepare != 0 ? "prepare()" : "reset()") + " at "
                                    + std::to_string((int) fs) + " Hz, " + std::to_string(nch) + " ch";
            RigPlayer p;
            if (! p.prepare(fs, kBlock, nch)) { ok(false, "the P86 fixture prepares — " + where); continue; }
            std::map<std::string, std::vector<std::byte>> files {
                { "early", bytesOf(delayModel(513)) },
                { "mid",   bytesOf(delayModel(514)) },
                { "late",  bytesOf(delayModel(515)) },
            };
            if (! p.load(memoryRig, [&files](const std::string& id) {
                    const auto it = files.find(id);
                    return it == files.end() ? std::vector<std::byte> {} : it->second; }))
            { ok(false, "the P86 fixture loads — " + where); continue; }

            std::vector<float> l((std::size_t) kBlock), r((std::size_t) kBlock);
            float* io[2] { l.data(), r.data() };
            double phase = 0.0, charged = 0.0;
            for (int k = 0; k < 120; ++k) {                       // long enough for a capture to land
                for (int i = 0; i < kBlock; ++i) {
                    const float v = (float) (0.5 * std::sin(phase));
                    phase += 2.0 * 3.14159265358979323846 * 220.0 / fs;
                    l[(std::size_t) i] = v; r[(std::size_t) i] = v;
                }
                felitronics::test::run(p.process(io, nch, kBlock));
                p.serviceHere();
                if (k > 60) for (int i = 0; i < kBlock; ++i) charged = std::fmax(charged, (double) std::fabs(l[(std::size_t) i]));
            }
            ok(charged > 0.1, "precondition: the capture really sounds — " + where);

            if (viaPrepare != 0) felitronics::test::run(p.prepare(fs, kBlock, nch));
            else                 p.reset();

            double worst = 0.0; bool finite = true;
            for (int k = 0; k < 60; ++k) {
                std::fill(l.begin(), l.end(), 0.0f); std::fill(r.begin(), r.end(), 0.0f);
                felitronics::test::run(p.process(io, nch, kBlock));
                p.serviceHere();
                for (int i = 0; i < kBlock; ++i)
                    for (const float v : { l[(std::size_t) i], r[(std::size_t) i] }) {
                        worst = std::fmax(worst, (double) std::fabs(v));
                        finite = finite && std::isfinite(v);
                    }
            }
            ok(finite && worst == 0.0,
               "digital silence in, FINITE EXACT ZERO out after " + where + " — worst " + std::to_string(worst));
        }

        // 2. THE TONE STACK IS STILL THERE AFTERWARDS. prepare() retires the bands (`bandRt_.count = 0`)
        //    because their coefficients were designed for the old rate and `rebuildBands()` follows it.
        //    Copying that line into reset() — which nothing follows — switches the tone stack OFF until
        //    the next message-thread publish: `runBands` walks `count`, and only `rebuildBands` raises
        //    it again. The shelf below would read 0 dB instead of its +6.
        {
            Bench b(rig);
            ok(b.p.setDial("tone", 300.0), "the shelf is taken to its plus stop");
            const double before = db(b.gainAt(10000.0) / b.gainAt(100.0));
            b.p.reset();
            const double after = db(b.gainAt(10000.0) / b.gainAt(100.0));
            approx(after, shelfDb(6.0, kFs), 0.1, "a restart leaves the BANDS designed and running, not retired"
                                                  " — the shelf still reads its +6 dB");
            approx(after, before, 0.05, "…and reads the same as it did before the restart");
        }

        // 3. A FILTER PUBLISHED AND NOT YET LIVE SURVIVES THE RESTART. When this was written,
        //    `MatrixConvolverNupc::reset()` flushed the history AND cancelled the swap, keeping `cur_` on
        //    the OLD operator — and `CabConvolver`'s retry flag is already clear after a successful
        //    publish, so nothing ever re-staged it: a restart landing between a knob move and the end of
        //    its 50 ms crossfade lost the knob move for good. The restart here takes the
        //    `clearAudioState()` half, which touches only what process() writes; `reset()` now adopts the
        //    publication instead (law 11e), and which of the two the player should call is P110. No process() call stands between
        //    the publish and the restart, so the operator is still merely STAGED when it arrives.
        {
            Bench b(rig);
            const double refLo = b.gainAt(60.0);
            ok(b.p.setDial("bass", 300.0), "a curve is published — +6 dB at 60 Hz");
            b.p.reset();                                     // …before a single block has picked it up
            approx(db(b.gainAt(60.0) / refLo), 6.0, 0.6, "a restart keeps a filter that was published and"
                                                         " not yet live — the curve is still applied");
            ok(b.p.curveActive(0), "…and the player still reports a FIR on the pre side");
        }

        // 4. THE PROMISE IS INDEPENDENCE. Two players fed DIFFERENT audio, restarted, then handed the
        //    same programme: identical bits. This is what a consumer can act on, and it is what a
        //    PARTIAL flush would break while the exact-zero gate above still passed.
        //
        //    🔴 AND THE FIXTURE HAS TO CARRY EVERY PLACE THAT HOLDS SAMPLES, OR IT CERTIFIES NOTHING.
        //    The first version of this used the bench's own rig and a review round took it apart: its
        //    captures are memoryless gains, so the MODELS could go unflushed and it still passed; its
        //    tone dial sits at the 0 dB reference, so the BANDS were never running; and no file carries
        //    a lag, so `blendDelay` returns before it touches `lagTail_` and an uncleared alignment
        //    tail survived the whole suite. Four different half-flushes read green. So this one is
        //    built with delay captures (memory), an alignment table (a real per-slot lag), the shelf
        //    off its reference (live biquads), the curve up (a live FIR) and the blend mid-travel
        //    (the dry ring) — and the assertions below name which of those is exercised.
        for (const double fs : { 44100.0, 48000.0 })
        {
            Bench one(rig, 1, fs), two(rig, 1, fs);
            const std::map<std::string, std::vector<std::byte>> memoryFiles {
                { "g60",  bytesOf(delayModel(300)) }, { "g150", bytesOf(delayModel(514)) },
                { "g240", bytesOf(delayModel(700)) }, { "r150", bytesOf(delayModel(200)) },
            };
            // 🔴 THE LAG HAS TO LAND ON THE SLOT THAT SOUNDS, and getting that backwards is why the
            // first version of this fixture let an uncleared `lagTail_` through the whole suite.
            // `AlignmentTable::delayOf` holds every model back to the SLOWEST — `max(0, latest - me)`
            // — so the file with the LARGEST lag is the one delayed by NOTHING. Writing 7 against the
            // capture the dial sits on therefore gave the delay to its silent neighbour, `blendDelay`
            // returned before touching the tail, and the mutation stand said so.
            AlignmentTable table;
            table.lagByFile = { { "g60", 0 }, { "g150", 0 }, { "g240", 16 }, { "r150", 0 } };
            table.sampleRate = fs;
            bool knobs = true;
            for (Bench* b : { &one, &two }) {
                b->files = memoryFiles;
                b->load(rig);                                  // …re-fetched, so the captures have MEMORY
                b->p.setAlignment(table);
                knobs = b->p.setDial("tone", 300.0)             // the shelf off its reference: live biquads
                      && b->p.setDial("bass", 300.0)             // the curve up: a live FIR
                      && b->p.setDial("mix",  150.0) && knobs;   // mid-blend: the dry ring is read
            }
            ok(knobs, "precondition: every knob of the independence fixture took — "
               + std::to_string((int) fs) + " Hz");
            std::vector<float> a((std::size_t) kBlock), c((std::size_t) kBlock);
            float* ioA[1] { a.data() }; float* ioC[1] { c.data() };
            double phase = 0.0; std::uint32_t noise = 12345u;
            for (int k = 0; k < 80; ++k) {                    // one a tone, the other white noise
                for (int i = 0; i < kBlock; ++i) {
                    a[(std::size_t) i] = (float) (0.4 * std::sin(phase));
                    phase += 2.0 * 3.14159265358979323846 * 311.0 / fs;
                    noise = noise * 1664525u + 1013904223u;
                    c[(std::size_t) i] = (float) ((double) (noise >> 8) / 16777216.0 - 0.5);
                }
                felitronics::test::run(one.p.process(ioA, 1, kBlock)); one.p.serviceHere();
                felitronics::test::run(two.p.process(ioC, 1, kBlock)); two.p.serviceHere();
            }
            one.p.reset(); two.p.reset();
            long long diff = 0; double p2 = 0.0, loud = 0.0;
            for (int k = 0; k < 60; ++k) {
                for (int i = 0; i < kBlock; ++i) {
                    const float v = (float) (0.35 * std::sin(p2) * std::sin(0.017 * p2));
                    p2 += 2.0 * 3.14159265358979323846 * 220.0 / fs;
                    a[(std::size_t) i] = c[(std::size_t) i] = v;
                }
                felitronics::test::run(one.p.process(ioA, 1, kBlock)); one.p.serviceHere();
                felitronics::test::run(two.p.process(ioC, 1, kBlock)); two.p.serviceHere();
                for (int i = 0; i < kBlock; ++i) {
                    if (a[(std::size_t) i] != c[(std::size_t) i]) ++diff;
                    loud = std::fmax(loud, (double) std::fabs(a[(std::size_t) i]));
                }
            }
            ok(loud > 0.05, "precondition: the programme after the restart really sounds — "
               + std::to_string((int) fs) + " Hz, peak " + std::to_string(loud));
            // …and the precondition is about the AUDIBLE slot, not about any slot: `liveMix()` is the
            // applied weight of slot 1, so the heavier one is the one whose tail can be heard.
            {
                const int loud = one.p.liveMix() >= 0.5f ? 1 : 0;
                ok(one.p.appliedSlotDelay(loud) > 0,
                   "precondition: the slot that SOUNDS carries an alignment delay, so lagTail_ is in play"
                   " — slot " + std::to_string(loud) + " delay " + std::to_string(one.p.appliedSlotDelay(loud))
                   + ", weight " + std::to_string(one.p.liveMix()));
            }
            ok(one.p.curveActive(0), "precondition: a FIR is really running on the pre side");
            ok(diff == 0, "a tone and white noise before the restart leave the same PLAYER behind — "
               + std::to_string((int) fs) + " Hz (" + std::to_string(diff) + " differing samples)");
        }

        // 4b. A RESTART LANDING INSIDE A BAND RAMP LEAVES THE SAME PLAYER AS ONE LANDING AFTER IT.
        //     This is what `clearAudioState()`'s `bandPos_ = bandLen_ = 0` and the one surviving line
        //     of the band snap are FOR, and nothing else in this file exercised either: the mutation
        //     stand ran "a band ramp in flight survives the restart" and "bandCur_ is left mid-glide"
        //     and both came back green, which is a gap in the suite and not a property of the code.
        //     Two players, the same programme: one is restarted ONE BLOCK into a long ramp, the other
        //     after the ramp has arrived. A restart ends the parameter epoch, so the two must be
        //     bit-identical from there on — and a ramp that survives it, or a `bandCur_` left where
        //     the glide abandoned it, makes them differ.
        for (const double fs : { 44100.0, 48000.0 })
        {
            Bench mid(rig, 1, fs), settled(rig, 1, fs);
            // A SLOW band: the ramp length is the band's own (bandRampLength), and a big jump on a
            // narrow bell buys the longest one the rails allow — 42.7 ms, which is 1837 samples at
            // 44.1 kHz against the 256-sample block below.
            ok(mid.p.setDial("tone", 0.0) && settled.p.setDial("tone", 0.0), "both start at the shelf's minus stop — "
               + std::to_string((int) fs) + " Hz");
            std::vector<float> a((std::size_t) kBlock), c((std::size_t) kBlock);
            float* ioA[1] { a.data() }; float* ioC[1] { c.data() };
            double phase = 0.0;
            const auto feed = [&](Bench& b, float* const* io, std::vector<float>& x, int blocks, double& ph) {
                for (int k = 0; k < blocks; ++k) {
                    for (int i = 0; i < kBlock; ++i) {
                        x[(std::size_t) i] = (float) (0.35 * std::sin(ph));
                        ph += 2.0 * 3.14159265358979323846 * 220.0 / fs;
                    }
                    felitronics::test::run(b.p.process(io, 1, kBlock)); b.p.serviceHere();
                }
            };
            double phB = 0.0;
            feed(mid, ioA, a, 40, phase); feed(settled, ioC, c, 40, phB);
            // …the hand moves, and the band starts travelling.
            ok(mid.p.setDial("tone", 300.0) && settled.p.setDial("tone", 300.0), "the hand crosses the whole shelf");
            double ph1 = phase, ph2 = phB;
            feed(mid, ioA, a, 1, ph1);            // one block in: the ramp is in flight
            mid.p.reset();
            feed(settled, ioC, c, 24, ph2);       // …and this one lets it arrive first
            settled.p.reset();
            // 🔴 AND THE HAND MOVES AGAIN AFTER THE RESTART, which is the only thing that can see the
            // one surviving line of the band snap. `runBands`'s arrival loop starts the NEW ramp from
            // `bandCur_`; the restart set that to `bandTo_`, so both players begin the next glide from
            // the same coefficients. Without it the one restarted MID-ramp begins from where its glide
            // had got to and never reached — inaudible on its own, and a different filter trajectory.
            // Without this line the mutation stand runs "bandCur_ is left mid-glide" and it SURVIVES.
            ok(mid.p.setDial("tone", 60.0) && settled.p.setDial("tone", 60.0),
               "…and the hand moves again after the restart");
            long long diff = 0; double loud = 0.0, p3 = 0.0;
            for (int k = 0; k < 40; ++k) {
                for (int i = 0; i < kBlock; ++i) {
                    const float v = (float) (0.3 * std::sin(p3) * std::sin(0.013 * p3));
                    p3 += 2.0 * 3.14159265358979323846 * 330.0 / fs;
                    a[(std::size_t) i] = c[(std::size_t) i] = v;
                }
                felitronics::test::run(mid.p.process(ioA, 1, kBlock));      mid.p.serviceHere();
                felitronics::test::run(settled.p.process(ioC, 1, kBlock));  settled.p.serviceHere();
                for (int i = 0; i < kBlock; ++i) {
                    if (a[(std::size_t) i] != c[(std::size_t) i]) ++diff;
                    loud = std::fmax(loud, (double) std::fabs(a[(std::size_t) i]));
                }
            }
            ok(loud > 0.05, "precondition: the programme after the restart sounds — "
               + std::to_string((int) fs) + " Hz, peak " + std::to_string(loud));
            ok(diff == 0, "a restart one block INTO a band ramp leaves the same player as one after the ramp"
                          " arrived — " + std::to_string((int) fs) + " Hz (" + std::to_string(diff)
                          + " differing samples)");
        }

        // 5. THE GAINS LAND ON THEIR TARGETS. A restart restarts the parameter epoch as well as the
        //    audio — `eq::EqBand::reset()` settled that for the house, and with a number: a band left
        //    mid-ramp made a second render of the same programme differ from a fresh one by 0.51 full
        //    scale. Nothing else in this group can see it: both sides of an independence test ramp
        //    identically, because a ramp is a function of the block count and the target and not of
        //    the audio. So it is asked directly — the level is moved and the restart must ARRIVE at it
        //    rather than glide, which is what prepare() already does with the same six lines.
        {
            Bench b(rig);
            b.rms(220.0, 0.25, 8, 8);                        // …a stream, so the ramps are somewhere
            b.p.setHostInputDb(-20.0);                       // …and the hand moves, arming a glide
            b.p.reset();
            std::vector<float> x((std::size_t) kBlock);
            float* io[1] { x.data() };
            std::fill(x.begin(), x.end(), 0.5f);             // DC: whatever gain is applied IS the reading
            felitronics::test::run(b.p.process(io, 1, kBlock));
            const double first = std::fabs((double) x[0]) / 0.5;
            // The capture at the default dial is the 0.5 gain (`g150`), and the pack's own levels are
            // unity on this rig, so the only thing between input and output is the host's -20 dB.
            approx(db(first / 0.5), -20.0, 0.5, "the first sample after a restart is AT the level the hand"
                                                " asked for, not gliding toward it — read "
                                                + std::to_string(db(first / 0.5)) + " dB");
        }

        // 6. IDEMPOTENT AND CHEAP WHEN THERE IS NOTHING TO DO, and callable before anything is sized.
        {
            RigPlayer fresh;
            fresh.reset();                                   // unprepared: nothing to restart, no crash
            ok(! fresh.prepared(), "a restart on an unprepared player does nothing and leaves it unprepared");
            Bench b(rig);
            b.p.reset(); b.p.reset();
            std::vector<float> x((std::size_t) kBlock, 0.0f);
            float* io[1] { x.data() };
            ok(b.p.process(io, 1, kBlock), "…and two restarts in a row leave a prepared player playable");
        }
    }

    // ==========================================================================================
    // P89 — WHAT A prepare() LEAVES EXPRESSED IN THE SAMPLES OF A RATE THAT IS GONE.
    //
    // The player counts two things in HOST samples and used to write both once and read them for ever:
    // the blend law's warm-up debt (`need`, latched from warmFor() at the landing) and the two per-slot
    // alignment delays (AlignmentTable::delayOf scales by the host rate). prepare() rebuilt everything
    // that was DESIGNED for a rate — the FIRs, the bands, the dry aligner, both stages, the cold
    // threshold — and nothing that was COUNTED in one.
    //
    // ⚠️ THE ONE-POINT FIXTURE WOULD HAVE PASSED. On the base commit this grid read 85 cells under-warm,
    // 85 over-warm and exactly 10 right — eight of those 10 are 44.1 <-> 48 kHz, the pair a fixture would
    // reach for first, and the other two are 88.2 <-> 96 on the WaveNet at a 256-sample block. The
    // warm-up was frozen at the LANDING rate, so the error follows the ratio of the two rates, and the
    // obvious pairs are where that ratio is ~1. The grid below is what makes the defect visible at all,
    // and it is P85's lesson with a second set of numbers.
    group("P89: a slot woken after a RATE CHANGE warms for the field the NEW rate owes");
    {
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
        gc.values = { "60", "150", "240" }; gc.sweep = 300;
        st.device.controls = { gc };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        r.chain = { st };

        // THE FIELD THE LEDGER REPORTS, WHICH IS NOT THE TAP COUNT. `delayModel(2000)` declares
        // `receptive_field: 2001`, and NamStage::prewarmSamples() answers 2000 — the house convention is
        // the model's REACH BACK, taps minus the sample it is answering for, and NamStage.h says so of
        // this very shape ("a 2001-tap Linear reports 2000"). Writing 2001 here agreed with the measured
        // player at every rate on the grid EXCEPT 96 kHz, where the doubling and the ceil push the extra
        // sample across a block boundary — an off-by-one that only a grid can see, and the reason this
        // oracle is spelled out rather than read back off warmFor().
        constexpr int kField = 2000;

        // One player, driven to the state the measurement needs: parked so the neighbour slot falls
        // asleep, then hushed so the waking turn lands on silence. Returns the host samples of warm-up
        // the law actually held the woken slot for, or -1 if the turn turned out to be a SWAP rather
        // than a wake — a load re-lands the slot and would answer a different question.
        struct Warm {
            RigPlayer p;
            std::map<std::string, std::vector<std::byte>> files;
            double fs; int block; double phase = 0.0;
            Warm(const namz::rig::Rig& rig, const std::string& nam, double sampleRate, int blk)
                : fs(sampleRate), block(blk) {
                files = { { "early", bytesOf(nam) }, { "mid", bytesOf(nam) }, { "late", bytesOf(nam) } };
                felitronics::test::run (p.prepare(fs, block, 1));
                p.load(rig, [this](const std::string& id) {
                    const auto it = files.find(id);
                    return it == files.end() ? std::vector<std::byte> {} : it->second;
                });
                p.setBlendShape({ 0.5, 0.0 });             // STEP: the neighbour sits at exactly zero
            }
            void run(int blocks, double a) {
                std::vector<float> x((std::size_t) block);
                for (int b = 0; b < blocks; ++b) {
                    for (int i = 0; i < block; ++i) {
                        x[(std::size_t) i] = (float) (a * std::sin(phase));
                        phase += 2.0 * 3.14159265358979323846 * 220.0 / fs;
                        if (phase > 6.283185307179586) phase -= 6.283185307179586;
                    }
                    float* io[1] { x.data() };
                    felitronics::test::run (p.process(io, 1, block));
                    p.serviceHere();
                }
            }
            void parkAndSleep() {
                p.setDial("gain", 150.0);
                run((int) std::ceil(2.6 * fs / block), 0.5);   // past kColdAfterSeconds
                run((int) std::ceil(0.3 * fs / block), 0.0);   // …then hush
            }
            long long wake() {
                p.clearCounters();
                const long long loadsBefore = p.modelLoads();
                p.setDial("gain", 200.0);                      // BETWEEN knots: a wake, not a swap
                run((int) std::ceil(1.5 * fs / block), 0.0);
                if (p.modelLoads() != loadsBefore) return -1;
                return (long long) p.warmBlocks() * block;
            }
        };

        // THE ORACLE IS SPELLED HERE, not read back off the player. warmFor()'s three terms are the
        // model's field converted into host samples, the rate-matcher's latency, and one block; the law
        // counts a block as warming while `fed < need`, and `fed` advances by one block per call. This
        // is an independent statement of the same arithmetic, so a mutation that changes warmFor() and
        // the differential together still fails here.
        const auto owed = [](double fs, int block, int latency) {
            const long long need = (long long) std::ceil((double) kField * fs / 48000.0)
                                 + (long long) latency + (long long) block;
            return ((need + block - 1) / block - 1) * block;
        };

        const double rates[] { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0 };
        const int blocks[] { 64, 256 };
        int cells = 0, matched = 0, oracled = 0, skipped = 0;
        double worstRatio = 1.0;
        for (const int blk : blocks)
        for (const double f1 : rates)
        for (const double f2 : rates) {
            if (f1 == f2) continue;
            Warm a(r, delayModel(2000), f1, blk);
            a.parkAndSleep();
            const bool slept = a.p.slotCold(0) || a.p.slotCold(1);
            felitronics::test::run (a.p.prepare(f2, blk, 1));       // …the host changes its rate
            const long long got = a.wake();

            Warm b(r, delayModel(2000), f2, blk);                   // …against one that never moved
            b.parkAndSleep();
            const long long want = b.wake();

            ++cells;
            if (! slept || got < 0 || want < 0) { ++skipped; continue; }
            if (got == want) ++matched;
            else worstRatio = std::max(worstRatio, want > 0 ? std::max((double) got / (double) want,
                                                                      (double) want / (double) got) : 1.0);
            if (got == owed(f2, blk, b.p.latencySamples())) ++oracled;
        }
        ok(skipped == 0, "precondition: every cell actually slept and woke without a load ("
                         + std::to_string(cells - skipped) + " of " + std::to_string(cells) + ")");
        ok(matched == cells,
           "a player whose rate CHANGED warms exactly as long as one prepared at that rate from the start"
           " (" + std::to_string(matched) + " of " + std::to_string(cells) + " cells; worst ratio "
           + std::to_string(worstRatio) + " — on the base commit 85 cells under-warmed, 48 -> 96 kHz to"
           " HALF the field and 48 -> 192 to a quarter, while 44.1 <-> 48 read exactly right)");
        ok(oracled == cells,
           "…and the length is the one warmFor()'s three terms ask for, stated independently here ("
           + std::to_string(oracled) + " of " + std::to_string(cells) + ")");
    }

    // ------------------------------------------------------------------------------------------
    // 🔴 A RESTART LANDING INSIDE A WARM-UP, which is the case every other fixture here steps over: the
    // groups above park a slot until it is fully warm or fully asleep and only then change the rate. A
    // slot caught MID-FIELD is different in kind, and it was wrong at an UNCHANGED rate too — so this is
    // not a rate-change test that happens to use one rate, it is the other half of the same defect.
    //
    // What is wrong: `prepare()` flushes every network (NamStage::prepare ends in its own restart), so
    // afterwards the slot's model holds NOTHING. The law's ledger, left alone, still credits it every
    // sample it heard before the flush — so a slot that was one block short of audible is marked audible
    // one block later, having fed one block of real material into an empty network. That is invariant 3
    // broken by a whole receptive field, and it costs nothing to close: a warming slot is at weight zero
    // by construction, so re-arming it is inaudible.
    //
    // ⚠️ AND THIS IS THE FIXTURE THAT KILLS THE PLAUSIBLE WRONG FIX. Carrying the warm-up across a
    // restart PROPORTIONALLY — rescaling `fed` alongside `need` so the fraction is preserved — passes
    // every other assertion in this file, because every other fixture restarts a slot that is already
    // warm or already asleep, where a preserved fraction and a re-arm agree. Measured: that mutation
    // survives the whole suite without this group and fails it with.
    group("P89: a restart INSIDE a warm-up re-arms it — the field heard before the flush is not credited");
    {
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
        gc.values = { "60", "150", "240" }; gc.sweep = 300;
        st.device.controls = { gc };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        r.chain = { st };

        // `partial` blocks of warm-up are spent, THEN the restart. The whole field must be owed again.
        // Both verbs, because they are one shared promise, and several depths so a fixture cannot sit on
        // the one place a remainder happens to equal a full field.
        // THE ORACLE IS A DIFFERENTIAL AGAINST DEPTH ZERO, not a predicted absolute, and that is
        // deliberate: `warmBlocks()` is an OR over BOTH slots, so the absolute after a restart mixes the
        // re-landing slot with whatever its neighbour is doing and is not a number this file can
        // predict. What it CAN say is that the answer must not depend on how much of the field was
        // spent before the restart — a restart eight blocks into a warm-up must cost exactly what a
        // restart at the instant of the landing costs. Carrying the progress across makes the answer
        // fall as the depth rises, which is precisely the reading this compares away.
        const auto warmAfterRestart = [&r](const char* verb, int partial) {
            std::map<std::string, std::vector<std::byte>> files {
                { "early", bytesOf(delayModel(2000)) }, { "mid", bytesOf(delayModel(2000)) },
                { "late",  bytesOf(delayModel(2000)) } };
            RigPlayer p;
            felitronics::test::run (p.prepare(kFs, kBlock, 1));
            p.load(r, [&files](const std::string& id) {
                const auto it = files.find(id);
                return it == files.end() ? std::vector<std::byte> {} : it->second;
            });
            p.setBlendShape({ 0.5, 0.0 });
            p.setDial("gain", 150.0);

            std::vector<float> x((std::size_t) kBlock);
            float* io[1] { x.data() };
            double phase = 0.0;
            const auto drive = [&](int blocks) {
                for (int b = 0; b < blocks; ++b) {
                    for (int i = 0; i < kBlock; ++i) {
                        x[(std::size_t) i] = (float) (0.3 * std::sin(phase));
                        phase += 2.0 * 3.14159265358979323846 * 220.0 / kFs;
                        if (phase > 6.283185307179586) phase -= 6.283185307179586;
                    }
                    felitronics::test::run (p.process(io, 1, kBlock));
                    p.serviceHere();
                }
            };

            drive(24);                                     // both models land and go warm
            p.setDial("gain", 60.0);                       // …a turn, so a slot re-lands and starts warming
            drive(2);
            p.clearCounters();
            drive(partial);                                // …part of the field, and no more
            const int spent = p.warmBlocks();

            p.clearCounters();
            if (std::string(verb) == "reset") p.reset();
            else felitronics::test::run (p.prepare(kFs, kBlock, 1));
            drive(64);                                     // …long enough for any warm-up to finish
            const int after = p.warmBlocks();

            return std::pair<int, int> { spent, after };
        };

        for (const char* verb : { "reset", "prepare" }) {
            const auto base = warmAfterRestart(verb, 0);   // …the restart at the instant of the landing
            ok(base.second > 0, std::string("precondition: a restart at depth 0 owes a warm-up at all (")
                                + std::to_string(base.second) + " blocks) — " + verb);
            // ⚠️ THE DEPTHS MUST STAY STRICTLY INSIDE THE FIELD, and 8 does not. This capture's warm-up
            // is 2000 + 256 = 2256 samples = 8.8 blocks, of which the landing itself has already spent
            // one or two by the time the count starts; a restart at depth 8 therefore lands AFTER the
            // slot went audible, where "re-arm" and "carry the progress" agree and the row proves
            // nothing. It read 8 against 15 for that reason and not because the fix had missed it.
            for (const int partial : { 1, 2, 3 }) {
                const auto got = warmAfterRestart(verb, partial);
                ok(got.first > 0 && got.first <= partial,
                   std::string("precondition: the restart really lands mid-warm-up (")
                   + std::to_string(got.first) + " blocks spent of " + std::to_string(partial)
                   + " driven) — " + verb);
                ok(got.second == base.second,
                   std::string("a ") + verb + "() " + std::to_string(partial) + " blocks into a warm-up"
                   " costs exactly what one at depth 0 costs (" + std::to_string(got.second) + " against "
                   + std::to_string(base.second) + ") — the field heard before the flush is not credited");
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    group("P89: the per-slot ALIGNMENT DELAY is restated at the new rate too");
    {
        // A table measured at 48 kHz, so `delayOf` has a rate to scale FROM. Every real file owes 64
        // samples there against a "ghost" entry that lands latest — so whichever capture a slot holds,
        // and whichever slot is silent, its delay is 64 x the rate ratio. A table where some file owed 0
        // would let a stale number and a restated one agree on exactly the slot a check happened to read.
        const auto rig = throughTheFormat(testRig());
        AlignmentTable t;
        t.sampleRate = 48000.0;
        t.lagByFile = { { "g60", 0 }, { "g150", 0 }, { "g240", 0 }, { "r150", 0 }, { "ghost", 64 } };

        // ⚠️ AND THE TOP OF THE GRID IS A CLAMP, NOT A SCALING — registered here because the fixture
        // found it (P99). `AlignmentTable::delayOf` clamps to `nam::kBlendMaxDelay`, which is 128 SAMPLES
        // and therefore a duration that shrinks with the rate: 2.67 ms at 48 kHz, 0.67 ms at 192 kHz. A
        // pack whose captures land 64 samples apart at 48 kHz asks for 256 at 192 kHz and silently gets
        // 128, so the pair is aligned at 48 and 96 kHz and combs at 192. That is a bound in the wrong unit
        // — the same defect this file's band ramps were cured of — and it is NOT P89's to move: it is a
        // constant in BlendLaw.h with its own consumers. Pinned at its real value so the day it changes,
        // this says so.
        struct Case { double fs; int want; };
        const Case cases[] { { 48000.0, 64 }, { 96000.0, 128 }, { 44100.0, 59 },
                             { 192000.0, felitronics::nam::kBlendMaxDelay } };
        for (const auto& c : cases) {
            Bench b(rig, 1, 48000.0);
            b.p.setAlignment(t);
            b.p.setDial("gain", 60.0);
            b.rms(220.0, 0.2, 24, 8);                       // land a model, so a slot holds something
            felitronics::test::run (b.p.prepare(c.fs, kBlock, 1));
            b.fs = c.fs;

            // `delayOf` is the arithmetic; what is asserted is that prepare() RAN it. The reference is
            // the table's own number scaled by hand, not a second call into the player.
            const int hand = std::clamp((int) std::lround(64.0 * c.fs / 48000.0), 0, RigPlayer::kMaxDelay);
            ok(hand == c.want, "precondition: the hand-scaled delay at " + std::to_string((int) c.fs)
                               + " Hz is " + std::to_string(c.want) + " (" + std::to_string(hand) + ")");
            ok(b.p.appliedSlotDelay(0) == c.want && b.p.appliedSlotDelay(1) == c.want,
               "prepare() restates BOTH applied slot delays at " + std::to_string((int) c.fs)
               + " Hz: want " + std::to_string(c.want) + ", got " + std::to_string(b.p.appliedSlotDelay(0))
               + " and " + std::to_string(b.p.appliedSlotDelay(1))
               + " (the base commit kept 64 at every rate — the number measured for 48 kHz)");

            // 🔴 …AND THEY STAY RESTATED ONCE AUDIO RUNS, which the line above cannot see. A SILENT slot
            // takes its delay from the STAGED one (`pendDelay_`) on every block, so a prepare() that
            // restated the applied delay but not the staged one looks right until the first block — and
            // then snaps the silent slot back to the old rate's number while the sounding one keeps the
            // new, splitting the pair by exactly the error this group is about. Measured: without the
            // staged half, this suite passed whole.
            b.rms(220.0, 0.2, 16, 4);
            ok(b.p.appliedSlotDelay(0) == c.want && b.p.appliedSlotDelay(1) == c.want,
               "…and both are still " + std::to_string(c.want) + " after blocks have run at "
               + std::to_string((int) c.fs) + " Hz (got " + std::to_string(b.p.appliedSlotDelay(0)) + " and "
               + std::to_string(b.p.appliedSlotDelay(1)) + ")");
        }
    }

    // ------------------------------------------------------------------------------------------
    // A LANDING THAT STRADDLES THE prepare(). `loadSlot()` runs on the message thread and latches the
    // incoming model's warm-up and delay at the rate of that moment; the audio thread takes them on its
    // next block. A prepare() between those two instants would hand the law a warm-up measured for the
    // rate that has just gone — the base defect, for exactly the slot that is changing capture. The
    // other groups never reach this: the grid asserts no load happened, and the warm-up-depth group
    // consumes its landing before it restarts. Measured: without the restatement of the pending
    // landing, this suite passed whole.
    group("P89: a landing delivered before a rate change and taken after it warms at the NEW rate");
    {
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
        gc.values = { "60", "150", "240" }; gc.sweep = 300;
        st.device.controls = { gc };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        r.chain = { st };

        // `straddle`: the landing is delivered at `from` and taken at `to`. Otherwise the player is
        // moved to `to` first and the same turn is made there — the reference. Both count the warm-up
        // from the block that takes the landing.
        const auto warmOfLanding = [&r](double from, double to, bool straddle, bool* pending) {
            std::map<std::string, std::vector<std::byte>> files {
                { "early", bytesOf(delayModel(2000)) }, { "mid", bytesOf(delayModel(2000)) },
                { "late",  bytesOf(delayModel(2000)) } };
            RigPlayer p;
            felitronics::test::run (p.prepare(from, kBlock, 1));
            p.load(r, [&files](const std::string& id) {
                const auto it = files.find(id);
                return it == files.end() ? std::vector<std::byte> {} : it->second;
            });
            p.setBlendShape({ 0.5, 0.0 });
            p.setDial("gain", 150.0);
            std::vector<float> x((std::size_t) kBlock, 0.1f);
            float* io[1] { x.data() };
            const auto block = [&] { felitronics::test::run (p.process(io, 1, kBlock)); };
            for (int k = 0; k < 40; ++k) { block(); p.serviceHere(); }   // mid and late land and warm
            if (! straddle) felitronics::test::run (p.prepare(to, kBlock, 1));
            const long long loads = p.modelLoads();
            const std::string before = p.heldFileId(0) + "|" + p.heldFileId(1);
            p.setDial("gain", 60.0);                       // wants "early", which is not loaded yet
            block();                                       // …the law asks for it
            p.serviceHere();                               // …and it is delivered: landFlag_ is up
            *pending = p.modelLoads() == loads + 1
                    && p.heldFileId(0) + "|" + p.heldFileId(1) == before;   // …and NOT yet taken
            if (straddle) felitronics::test::run (p.prepare(to, kBlock, 1));
            p.clearCounters();
            for (int k = 0; k < 96; ++k) { block(); p.serviceHere(); }
            return p.warmBlocks();
        };
        for (const auto& pair : { std::pair<double, double> { 48000.0, 96000.0 },
                                  std::pair<double, double> { 96000.0, 48000.0 },
                                  std::pair<double, double> { 44100.0, 192000.0 } }) {
            bool pendingA = false, pendingB = false;
            const int straddled = warmOfLanding(pair.first, pair.second, true,  &pendingA);
            const int reference = warmOfLanding(pair.first, pair.second, false, &pendingB);
            const std::string at = std::to_string((int) pair.first) + " -> " + std::to_string((int) pair.second);
            ok(pendingA && pendingB, "precondition: the landing was delivered and NOT yet taken when the"
                                     " rate changed — " + at);
            ok(straddled == reference && straddled > 0,
               "a landing taken after a rate change warms as one made at the new rate (" + std::to_string(straddled)
               + " blocks against " + std::to_string(reference) + ") — " + at);
        }
    }

    // ------------------------------------------------------------------------------------------
    // THE REST COUNT, which is the one host-sample count here that is RESCALED rather than recomputed.
    // It is pure elapsed time, so a restart must preserve the time a slot has already rested — at a new
    // rate by converting it, and at an UNCHANGED rate by leaving it exactly alone. Three behaviours are
    // told apart by one measurement, the seconds from the restart until the parked neighbour sleeps:
    //   · the base commit left the count in the old rate's samples — 48 -> 96 kHz slept late, and
    //     96 -> 48 slept at once;
    //   · the first draft of this fix ZEROED it — every restart, same rate included, postponed sleep
    //     by a whole cold window;
    //   · converting it keeps every row equal to the same-rate one.
    group("P89: the time a slot has already RESTED survives a restart — converted, never reset");
    {
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
        gc.values = { "60", "150", "240" }; gc.sweep = 300;
        st.device.controls = { gc };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        r.chain = { st };

        // Park at `from`, rest `rested` seconds (under the cold window), restart into `to` by `verb`,
        // then return the SECONDS until a slot falls asleep. The part before the restart is identical
        // for every row that starts at the same rate, so rows compare on the part after it.
        const auto secondsToSleep = [&r](double from, double to, const char* verb, double rested) {
            std::map<std::string, std::vector<std::byte>> files {
                { "early", bytesOf(gainModel(0.25)) }, { "mid", bytesOf(gainModel(0.5)) },
                { "late",  bytesOf(gainModel(1.0)) } };
            RigPlayer p;
            felitronics::test::run (p.prepare(from, kBlock, 1));
            p.load(r, [&files](const std::string& id) {
                const auto it = files.find(id);
                return it == files.end() ? std::vector<std::byte> {} : it->second;
            });
            p.setBlendShape({ 0.5, 0.0 });
            p.setDial("gain", 150.0);
            std::vector<float> x((std::size_t) kBlock, 0.1f);
            float* io[1] { x.data() };
            const int restBlocks = (int) std::lround(rested * from / kBlock);
            for (int k = 0; k < restBlocks; ++k) { felitronics::test::run (p.process(io, 1, kBlock)); p.serviceHere(); }
            if (p.slotCold(0) || p.slotCold(1)) return -1.0;           // slept BEFORE the restart: row is void
            if (std::string(verb) == "reset") p.reset();
            else felitronics::test::run (p.prepare(to, kBlock, 1));
            for (int k = 1; k < (int) (4.0 * to / kBlock); ++k) {
                felitronics::test::run (p.process(io, 1, kBlock)); p.serviceHere();
                if (p.slotCold(0) || p.slotCold(1)) return (double) (k * kBlock) / to;
            }
            return 99.0;                                                // never slept
        };

        const double same = secondsToSleep(48000.0, 48000.0, "prepare", 1.5);
        // ⚠️ THIS IS THE ASSERTION THAT CATCHES ZEROING, and it has to be an ABSOLUTE one: a count
        // zeroed at every restart moves every row below by the same whole window, so the differentials
        // all still agree with each other and pass. Only "a same-rate restart leaves the rest alone"
        // stated against the clock can see it. Measured on the zeroing draft: 2.005 s here.
        ok(same > 0.0 && same < 1.0,
           "a same-rate prepare() after 1.5 s of rest still sleeps within the ~0.5 s the 2 s window has"
           " left (" + std::to_string(same) + " s) — zeroing the count read 2.005 s, postponing every"
           " parked dial's sleep by a whole window at every restart");
        const double viaReset = secondsToSleep(48000.0, 48000.0, "reset", 1.5);
        approx(viaReset, same, 0.012, "…and a reset() leaves the rest where a same-rate prepare() does");

        struct Row { double from, to; const char* what; };
        // Measured on a count left in the old rate's samples: 48 -> 96 slept 1.267 s against 0.533
        // (0.73 s late), 96 -> 48 slept after ONE block against 0.515, 48 -> 192 slept 1.10 s late, and
        // even 44.1 -> 48 was 0.12 s late.
        const Row rows[] { { 48000.0, 96000.0,  "48 -> 96 kHz" },
                           { 96000.0, 48000.0,  "96 -> 48 kHz" },
                           { 48000.0, 192000.0, "48 -> 192 kHz" },
                           { 44100.0, 48000.0,  "44.1 -> 48 kHz" } };
        for (const auto& row : rows) {
            const double sameHere = secondsToSleep(row.from, row.from, "prepare", 1.5);
            const double moved    = secondsToSleep(row.from, row.to,   "prepare", 1.5);
            // Two blocks of the coarser grid: the two rows quantize the same instant differently.
            const double tol = 2.0 * kBlock / std::min(row.from, row.to) + 1.0e-9;
            approx(moved, sameHere, tol,
                   std::string("the rest already served is converted, not stranded: ") + row.what);
        }
    }

    // ------------------------------------------------------------------------------------------
    // ⚠️ A prepare() BETWEEN A load() AND THE NEXT BLOCK. load() posts a forget and rebuilds `models_`,
    // but the audio thread wipes `blend_` only on its next block — so in that window `blend_.held[]`
    // still names the PREVIOUS pack's models, as indices into a `models_` that now belongs to the new
    // one. Restating the ledger there would resolve an old id against the new pack's table and store
    // that delay for a slot the audio thread is about to empty. It is muted and would heal within a
    // block, but it is a change to base behaviour in a window this fix was never aimed at — so the
    // restatement stands back there, and this pins it doing so.
    group("P89: a prepare() between load() and the next block does not resolve the OLD pack's ids");
    {
        namz::rig::Rig r;
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
        gc.values = { "60", "150", "240" }; gc.sweep = 300;
        st.device.controls = { gc };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        r.chain = { st };

        std::map<std::string, std::vector<std::byte>> files {
            { "early", bytesOf(gainModel(0.25)) }, { "mid", bytesOf(gainModel(0.5)) },
            { "late",  bytesOf(gainModel(1.0)) } };
        RigPlayer p;
        felitronics::test::run (p.prepare(kFs, kBlock, 1));
        const auto source = [&files](const std::string& id) {
            const auto it = files.find(id);
            return it == files.end() ? std::vector<std::byte> {} : it->second;
        };
        p.load(r, source);                                 // pack A: no alignment, every delay is 0
        p.setDial("gain", 150.0);
        std::vector<float> x((std::size_t) kBlock, 0.1f);
        float* io[1] { x.data() };
        for (int k = 0; k < 24; ++k) { felitronics::test::run (p.process(io, 1, kBlock)); p.serviceHere(); }
        const int a0 = p.appliedSlotDelay(0), a1 = p.appliedSlotDelay(1);
        ok(a0 == 0 && a1 == 0 && ! p.heldFileId(0).empty() && ! p.heldFileId(1).empty(),
           "precondition: pack A has landed in both slots with no delay ("
           + std::to_string(a0) + ", " + std::to_string(a1) + ")");

        // Pack B: the SAME file names, so an old id resolves to a real entry of the new table — and a
        // table that delays every one of them, so a cross-pack resolution cannot land on zero by luck.
        p.load(r, source);
        AlignmentTable t;
        t.sampleRate = kFs;
        t.lagByFile = { { "early", 0 }, { "mid", 0 }, { "late", 0 }, { "ghost", 96 } };
        p.setAlignment(t);                                 // every real file now owes 96 against "ghost"
        felitronics::test::run (p.prepare(kFs, kBlock, 1));   // …and NO block in between

        ok(p.appliedSlotDelay(0) == a0 && p.appliedSlotDelay(1) == a1,
           "the applied delays are what they were before the prepare, not pack B's 96 read through pack"
           " A's ids (" + std::to_string(p.appliedSlotDelay(0)) + ", "
           + std::to_string(p.appliedSlotDelay(1)) + ")");

        // …and once the audio thread HAS run, the new pack's delays arrive through the ordinary path.
        for (int k = 0; k < 48; ++k) { felitronics::test::run (p.process(io, 1, kBlock)); p.serviceHere(); }
        ok(p.appliedSlotDelay(0) == 96 || p.appliedSlotDelay(1) == 96,
           "…and pack B's own delays land through the ordinary path once blocks run ("
           + std::to_string(p.appliedSlotDelay(0)) + ", " + std::to_string(p.appliedSlotDelay(1)) + ")");
    }

    // ------------------------------------------------------------------------------------------
    // THE WIRING, pinned where only the player can see it. An adversarial round ran 44 mutants against
    // this branch; the code held on every input it tried, and seven mutants survived this file because
    // every fixture above either loads ONE capture into every file (so a slot index passed to the wrong
    // stage answers the same), or restarts a slot that settled long ago (so its count is far past any
    // new need), or carries no alignment table where a landing is pending. The three groups below are
    // those three blind spots, each with the input the round found.
    namz::rig::Rig tri;
    {
        namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
        namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
        gc.values = { "60", "150", "240" }; gc.sweep = 300;
        st.device.controls = { gc };
        namz::rig::FileEntry fe; fe.id = "early"; fe.settings = { { "gain", "60" } };
        namz::rig::FileEntry fm; fm.id = "mid";   fm.settings = { { "gain", "150" } };
        namz::rig::FileEntry fl; fl.id = "late";  fl.settings = { { "gain", "240" } };
        st.device.files = { fe, fm, fl };
        tri.chain = { st };
    }
    struct Tri {
        RigPlayer p;
        std::map<std::string, std::vector<std::byte>> files;
        std::vector<float> x;
        float* io[1];
        Tri(const namz::rig::Rig& rig, const std::string& e, const std::string& m, const std::string& l,
            double fs) : x((std::size_t) kBlock, 0.1f) {
            io[0] = x.data();
            files = { { "early", bytesOf(e) }, { "mid", bytesOf(m) }, { "late", bytesOf(l) } };
            felitronics::test::run (p.prepare(fs, kBlock, 1));
            p.load(rig, [this](const std::string& id) {
                const auto it = files.find(id);
                return it == files.end() ? std::vector<std::byte> {} : it->second;
            });
        }
        void block(bool service = true) {
            felitronics::test::run (p.process(io, 1, kBlock));
            if (service) p.serviceHere();
        }
        void run(int n) { for (int k = 0; k < n; ++k) block(); }
    };

    // 1. AN AUDIBLE SLOT WITH A REAL FIELD STAYS AUDIBLE — including one that has only JUST become
    //    audible when the rate goes up, and across two restarts in a row. Every restart fixture above
    //    that checks audibility uses a memoryless capture, whose need is zero and whose predicate cannot
    //    fail; and a slot that settled long ago has fed far past any new need. Measured on the wrong
    //    twins: an inverted predicate muted both slots, `>` for `>=` re-armed them on the SECOND
    //    restart, and keeping an audible slot's old count warmed it for 7 blocks at 96 kHz and muted it
    //    outright at 192 kHz.
    group("P89: a pair that is AUDIBLE stays audible through any restart — just-audible included");
    {
        struct Seq { const char* name; std::vector<std::pair<char, double>> steps; };   // 'r' reset, 'p' prepare(rate)
        const Seq seqs[] {
            { "reset",                     { { 'r', 0.0 } } },
            { "prepare(same)",             { { 'p', 48000.0 } } },
            { "prepare(96k)",              { { 'p', 96000.0 } } },
            { "prepare(192k)",             { { 'p', 192000.0 } } },
            { "reset, reset",              { { 'r', 0.0 }, { 'r', 0.0 } } },
            { "prepare(same) twice",       { { 'p', 48000.0 }, { 'p', 48000.0 } } },
            { "prepare(96k), reset",       { { 'p', 96000.0 }, { 'r', 0.0 } } },
            { "prepare(96k), prepare(44.1k)", { { 'p', 96000.0 }, { 'p', 44100.0 } } },
        };
        for (const bool justAudible : { true, false })
        for (const auto& q : seqs) {
            Tri t(tri, delayModel(2000), delayModel(2000), delayModel(2000), kFs);
            t.p.setDial("gain", 105.0);                    // between two knots: both slots sound
            // Stop on the first block that warms nobody AFTER BOTH slots hold a model and one of them
            // was still warming — the instant the second landing has just crossed its need, which is
            // where a kept count is shortest. The two slots land one after the other, so "the first quiet
            // block" alone can fall between the landings, with only one capture in the player.
            int warmed = 0;
            for (int k = 0; k < 200; ++k) {
                t.p.clearCounters();
                t.block();
                const bool bothHeld = ! t.p.heldFileId(0).empty() && ! t.p.heldFileId(1).empty();
                if (t.p.warmBlocks() > 0) { if (bothHeld) warmed = k + 1; }
                else if (warmed > 0 && justAudible) break;
            }
            if (! justAudible) t.run(64);
            const bool both = ! t.p.heldFileId(0).empty() && ! t.p.heldFileId(1).empty()
                           && (justAudible || (t.p.liveMix() > 0.05f && t.p.liveMix() < 0.95f));
            for (const auto& [verb, rate] : q.steps) {
                if (verb == 'r') t.p.reset();
                else felitronics::test::run (t.p.prepare(rate, kBlock, 1));
            }
            t.p.clearCounters();
            const float mixBefore = t.p.liveMix();
            t.run(30);
            const std::string label = std::string(q.name) + (justAudible ? ", just audible" : ", settled");
            ok(warmed > 0 && both, "precondition: both slots landed and warmed — " + label);
            // A just-audible pair is still gliding to its target weight, so only the settled rows can
            // also say "the weight does not move"; "nobody is re-armed" is the claim for both.
            ok(t.p.warmBlocks() == 0 && (justAudible || std::abs(t.p.liveMix() - mixBefore) < 1e-6f),
               "no slot is re-armed" + std::string(justAudible ? "" : " and the weight does not move") + " ("
               + std::to_string(t.p.warmBlocks()) + " warming blocks, mix " + std::to_string(mixBefore) + " -> "
               + std::to_string(t.p.liveMix()) + ") — " + label);
        }
    }

    // 2. SLOTS HOLDING CAPTURES WITH DIFFERENT FIELDS. Each slot's warm-up must come from ITS OWN
    //    stage: with one capture in every slot, restating slot 1 from slot 0's stage answers the same
    //    number and the mix-up is invisible. That is harder to arrange than it sounds — slots follow the
    //    PARITY of a knot, so on a three-knot dial a sleeping slot 1 always holds the same capture as
    //    slot 0 (at an end knot both slots carry that knot), and the first version of this group, built
    //    on `tri`, passed with the mix-up planted. Four knots give each index a middle knot whose silent
    //    neighbour is a DIFFERENT capture: parked on 120, slot 0 sleeps on "c" beside "b"; parked on 180,
    //    slot 1 sleeps on "d" beside "c". Each wake is a turn that asks for the same two captures, so it
    //    wakes the sleeper rather than loading into it — a landing would compute its own warm-up from the
    //    right stage whatever the restatement did.
    group("P89: each slot's warm-up is restated from ITS OWN capture, not its neighbour's");
    {
        namz::rig::Rig quad;
        {
            namz::rig::Stage st; st.kind = namz::rig::StageKind::Nam; st.rawKind = "nam";
            namz::rig::Control gc; gc.name = "gain"; gc.role = namz::rig::Role::Gain;
            gc.values = { "60", "120", "180", "240" }; gc.sweep = 300;
            st.device.controls = { gc };
            const char* ids[] { "a", "b", "c", "d" };
            const char* at[]  { "60", "120", "180", "240" };
            for (int k = 0; k < 4; ++k) {
                namz::rig::FileEntry f; f.id = ids[k]; f.settings = { { "gain", at[k] } };
                st.device.files.push_back(f);
            }
            quad.chain = { st };
        }
        struct Case { double park, wake; int sleeper; const char* asleep; };
        const Case cases[] { { 120.0, 165.0, 0, "c" }, { 180.0, 220.0, 1, "d" } };
        // Returns {sleeper, pure wake?, held pair before the wake, warming blocks after it}.
        struct Out { int sleeper; bool pure; std::string held; int warm; };
        const auto drive = [&quad](const Case& c, double fs, double to) {
            std::map<std::string, std::vector<std::byte>> files {
                { "a", bytesOf(delayModel(2000)) }, { "b", bytesOf(delayModel(500)) },
                { "c", bytesOf(delayModel(1000)) }, { "d", bytesOf(delayModel(1500)) } };
            RigPlayer p;
            felitronics::test::run (p.prepare(fs, kBlock, 1));
            p.load(quad, [&files](const std::string& id) {
                const auto it = files.find(id);
                return it == files.end() ? std::vector<std::byte> {} : it->second;
            });
            std::vector<float> x((std::size_t) kBlock, 0.1f);
            float* io[1] { x.data() };
            const auto run = [&](int n) {
                for (int k = 0; k < n; ++k) { felitronics::test::run (p.process(io, 1, kBlock)); p.serviceHere(); }
            };
            p.setBlendShape({ 0.5, 0.0 });
            p.setColdAfterSeconds(0.25);
            p.setDial("gain", c.park);
            run((int) std::ceil(0.6 * fs / kBlock));
            Out o;
            o.sleeper = p.slotCold(0) ? 0 : p.slotCold(1) ? 1 : -1;
            o.held = p.heldFileId(0) + "|" + p.heldFileId(1);
            if (to != fs) felitronics::test::run (p.prepare(to, kBlock, 1));
            const long long loads = p.modelLoads();
            p.clearCounters();
            p.setDial("gain", c.wake);
            run((int) std::ceil(0.5 * to / kBlock));
            o.pure = p.modelLoads() == loads && p.heldFileId(0) + "|" + p.heldFileId(1) == o.held;
            o.warm = p.warmBlocks();
            return o;
        };
        for (const auto& c : cases)
        for (const double to : { 96000.0, 22050.0 }) {
            const Out got  = drive(c, kFs, to);
            const Out want = drive(c, to, to);
            const std::string at = "slot " + std::to_string(c.sleeper) + " asleep on '" + c.asleep + "', held "
                                 + got.held + ", 48000 -> " + std::to_string((int) to);
            const auto sleeperHolds = [&](const Out& o) {
                const auto bar = o.held.find('|');
                const std::string mine  = c.sleeper == 0 ? o.held.substr(0, bar) : o.held.substr(bar + 1);
                const std::string other = c.sleeper == 0 ? o.held.substr(bar + 1) : o.held.substr(0, bar);
                return mine == c.asleep && other != mine;
            };
            ok(got.sleeper == c.sleeper && want.sleeper == c.sleeper && sleeperHolds(got) && sleeperHolds(want)
                   && got.pure && want.pure,
               "precondition: the intended slot slept on its own capture beside a DIFFERENT one, and the turn"
               " woke it without loading — " + at);
            ok(got.warm == want.warm && got.warm > 0,
               "the woken slot warms for its own capture's field at the new rate (" + std::to_string(got.warm)
               + " blocks against " + std::to_string(want.warm) + ") — " + at);
        }
    }

    // 3. DELAYS THAT DIFFER PER FILE, with a load IN FLIGHT and with a landing PENDING across the
    //    prepare. The sounding slot must keep the delay of the capture it HOLDS, not the one the dial is
    //    reaching for (taking the staged number would retime a live signal), and a pending landing must
    //    bring its own capture's delay at the new rate (the straddle group above checks only its warm-up).
    group("P89: a load in flight or a landing pending across a prepare keeps each capture's OWN delay");
    {
        AlignmentTable t;
        t.sampleRate = 48000.0;
        t.lagByFile = { { "early", 0 }, { "mid", 30 }, { "late", 64 } };   // delays 64 / 34 / 0 at 48 kHz
        const auto hand = [](const std::string& id, double fs) {
            const int d48 = id == "early" ? 64 : id == "mid" ? 34 : 0;
            return std::clamp((int) std::lround(d48 * fs / 48000.0), 0, RigPlayer::kMaxDelay);
        };
        for (const double to : { 44100.0, 96000.0, 22050.0 })
        for (const bool pending : { false, true }) {
            Tri p(tri, gainModel(0.25), gainModel(0.5), gainModel(1.0), kFs);
            p.p.setAlignment(t);
            p.p.setBlendShape({ 0.5, 0.0 });
            p.p.setDial("gain", 60.0);
            p.run(60);
            const std::string sounding = p.p.liveMix() < 0.5f ? p.p.heldFileId(0) : p.p.heldFileId(1);
            const int soundingSlot = p.p.liveMix() < 0.5f ? 0 : 1;
            p.p.setDial("gain", pending ? 150.0 : 240.0);
            p.block(false);                                // the law asks; nothing is delivered yet
            if (pending) p.p.serviceHere();                // …or it IS delivered and not yet taken
            felitronics::test::run (p.p.prepare(to, kBlock, 1));
            const std::string at = std::string(pending ? "landing pending" : "load in flight") + ", 48000 -> "
                                 + std::to_string((int) to);
            ok(sounding == "early", "precondition: the sounding capture before the turn is 'early' — " + at);
            ok(p.p.appliedSlotDelay(soundingSlot) == hand(sounding, to),
               "the sounding slot keeps ITS capture's delay at the new rate (" + std::to_string(p.p.appliedSlotDelay(soundingSlot))
               + ", want " + std::to_string(hand(sounding, to)) + ") — " + at);
            if (pending) {
                p.block(false);                            // …the audio thread takes the landing
                const int other = soundingSlot ^ 1;
                const std::string landed = p.p.heldFileId(other);
                ok(! landed.empty() && landed != sounding,
                   "precondition: the pending capture landed in the other slot (" + landed + ") — " + at);
                ok(p.p.appliedSlotDelay(other) == hand(landed, to),
                   "…and it lands with ITS delay at the new rate (" + std::to_string(p.p.appliedSlotDelay(other))
                   + ", want " + std::to_string(hand(landed, to)) + ") — " + at);
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    group("P89: a restart snaps the slot trim THROUGH the switch that turns trims off");
    {
        // 🔴 THE ORACLE IS THE SWITCH'S OWN MEANING, not a level read off one player. `setInputTrims`
        // promises exactly one thing: the pack's per-file `input_db` stops being applied. So with trims
        // OFF, a pack whose linked entry carries −6 dB must sound IDENTICAL to one whose entry carries
        // 0 dB — before a restart and, which is the half that was false, after one.
        //
        // Comparing a restarted player against its own settled level instead would have measured the
        // restart's other transients (the tone curve's 1024-tap FIR is flushed too, and rings in over
        // 0.48 dB on the first block) and called the trim defect part of them. Two players restarted the
        // same way share every one of those and differ only in the number under test.
        auto rigTrimmed = testRig();                       // …files[4] is the link: "g60" at −6 dB
        auto rigFlat    = testRig();
        ok(rigTrimmed.chain[0].device.files.size() == 5
           && std::abs(rigTrimmed.chain[0].device.files[4].inputDb + 6.0) < 1e-9,
           "precondition: the pack's linked entry really carries a −6 dB trim");
        rigFlat.chain[0].device.files[4].inputDb = 0.0;    // …the same pack with nothing to switch off
        const auto trimmed = throughTheFormat(rigTrimmed);
        const auto flat    = throughTheFormat(rigFlat);

        for (const bool viaPrepare : { false, true }) {
            Bench a(trimmed, 1, kFs), b(flat, 1, kFs);
            for (auto* p : { &a, &b }) {
                p->p.setInputTrims(false);                 // …the switch under test, OFF
                p->p.setDial("gain", 0.0);                 // …parked on the linked knot
                p->rms(220.0, 0.2, 32, 8);                 // …settled, so the ramp has arrived
            }
            ok(std::abs(db(a.gainAt(220.0, 0.2, 8, 8)) - db(b.gainAt(220.0, 0.2, 8, 8))) < 0.02,
               "precondition: with trims OFF the two packs already sound the same before any restart");

            if (viaPrepare) { felitronics::test::run (a.p.prepare(kFs, kBlock, 1));
                              felitronics::test::run (b.p.prepare(kFs, kBlock, 1)); }
            else            { a.p.reset(); b.p.reset(); }

            // The FIRST block after the restart is where a wrong snap is loudest: the ramp starts there
            // and takes ~43 ms to travel back to unity.
            const double first = db(a.gainAt(220.0, 0.2, 0, 1)) - db(b.gainAt(220.0, 0.2, 0, 1));
            ok(std::abs(first) < 0.02,
               std::string("with trims OFF the pack's −6 dB trim is invisible on the first block after a ")
               + (viaPrepare ? "prepare()" : "reset()") + " too (" + std::to_string(first)
               + " dB; the base commit snapped to the trim regardless of the switch and read −5.99 dB)");

            // …and across the whole ramp, which is where the old behaviour spent its 43 ms.
            const double ramp = db(a.gainAt(220.0, 0.2, 0, 8)) - db(b.gainAt(220.0, 0.2, 0, 8));
            ok(std::abs(ramp) < 0.02, std::string("…and across the ramp that followed it (")
                                      + std::to_string(ramp) + " dB)");
        }

        // …and with trims ON the trim is still applied, so the fix switched something off rather than
        // deleting it. Same two packs, same restart, opposite expectation.
        {
            Bench a(trimmed, 1, kFs), b(flat, 1, kFs);
            for (auto* p : { &a, &b }) { p->p.setInputTrims(true); p->p.setDial("gain", 0.0);
                                        p->rms(220.0, 0.2, 32, 8); }
            a.p.reset(); b.p.reset();
            const double d = db(a.gainAt(220.0, 0.2, 8, 16)) - db(b.gainAt(220.0, 0.2, 8, 16));
            approx(d, -6.0, 0.05, "with trims ON the −6 dB trim is still there after a restart ("
                                  + std::to_string(d) + " dB)");
        }
    }

    return felitronics::test::report();
}
