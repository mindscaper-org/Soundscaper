# felitronics::nam — OPTIONAL, COMPILED NeuralAmpModelerCore backend for the process-only neural
# seam. Default OFF: consumers that do not opt in remain header-only and fetch no heavy deps.
if(NOT FELITRONICS_WITH_NAM)
    return()
endif()

if(CMAKE_VERSION VERSION_LESS 3.24)
    message(FATAL_ERROR "FELITRONICS_WITH_NAM requires CMake >= 3.24 ($<LINK_LIBRARY:WHOLE_ARCHIVE> for NAM's architecture self-registration)")
endif()

include(FetchContent)

# NeuralAmpModelerCore ships no usable library target. Populate the pinned sources without entering
# its own project, then compile the same source set used by OrbitCab. Its one submodule we need, Eigen, comes
# from our own mirror below, not from where the submodule points.
# A RELEASE, not a commit somebody caught mid-air. The pin was `b5a68c3` — upstream's "Revert A2 fast
# optimizations (#295)" — which was the tip of main when OrbitCab first pinned it and stopped being so
# forty-five minutes later, when v0.5.4 was published. It was inherited here with the NAM path and
# never moved. The three commits between them are an MSVC `restrict` fix on the inline GEMM, an
# introspection feature for slimmable models, and a convolution optimisation; a real SM7 model through
# a second of signal comes out BIT-IDENTICAL across the two, so nothing anyone captured sounds new.
set(FELITRONICS_NAM_CORE_TAG "v0.5.4" CACHE STRING
    "NeuralAmpModelerCore release to build against")
set(FELITRONICS_NAM_CORE_SRC "" CACHE PATH
    "Local NeuralAmpModelerCore checkout (when empty, fetch the pin)")
if(FELITRONICS_NAM_CORE_SRC AND NOT EXISTS "${FELITRONICS_NAM_CORE_SRC}")
    message(FATAL_ERROR "FELITRONICS_NAM_CORE_SRC does not exist: ${FELITRONICS_NAM_CORE_SRC}")
endif()
if(FELITRONICS_NAM_CORE_SRC)
    message(STATUS "NeuralAmpModelerCore: local checkout — ${FELITRONICS_NAM_CORE_SRC}")
    FetchContent_Declare(nam_core_src
        SOURCE_DIR    "${FELITRONICS_NAM_CORE_SRC}"
        SOURCE_SUBDIR Dependencies/nlohmann)
else()
    message(STATUS "NeuralAmpModelerCore: fetching ${FELITRONICS_NAM_CORE_TAG} from GitHub")
    FetchContent_Declare(nam_core_src
        GIT_REPOSITORY https://github.com/sdatkinson/NeuralAmpModelerCore.git
        GIT_TAG        ${FELITRONICS_NAM_CORE_TAG}
        GIT_SUBMODULES ""                    # none at all (an empty list means none under CMP0097, NEW since 3.16)
        GIT_SHALLOW    FALSE
        SOURCE_SUBDIR  Dependencies/nlohmann)
endif()
FetchContent_MakeAvailable(nam_core_src)

# EIGEN, the matrices NAM's networks are computed with — header-only. NeuralAmpModelerCore's submodule points
# at gitlab.com/libeigen/eigen, and every build cloned it from there: on a day GitLab turned requests away
# under load, every build of every product failed at that clone. So it comes from Darwin's Cat's own mirror,
# github.com/darwinscat/eigen — the same repository, untouched — at the very commit v0.5.4's submodule pins
# (Eigen 5.0.1), checked after the fetch. A NeuralAmpModelerCore whose submodule is already on disk (a local
# checkout, FETCHCONTENT_SOURCE_DIR_NAM_CORE_SRC, a parent project's own declaration) brings its own.
# Either way the Eigen built against is held to the commit NeuralAmpModelerCore's own tree pins: v0.4.0 to v0.5.3
# pin another (87300c9), and another tag must not build against this one silently.
find_package(Git REQUIRED)
set(FELITRONICS_EIGEN_TAG "5.0.1" CACHE STRING "Eigen release, as NeuralAmpModelerCore's pin")
set(FELITRONICS_EIGEN_COMMIT "bc3b39870ecb690a623a3f49149a358b95c5781d" CACHE STRING
    "The commit that release must be: NeuralAmpModelerCore v0.5.4's submodule pin")

# git at configure time; a git that fails stops the configure with git's own words, never with an empty answer.
function(felitronics_nam_git out dir)
    execute_process(COMMAND "${GIT_EXECUTABLE}" -C "${dir}" ${ARGN}
                    RESULT_VARIABLE rc OUTPUT_VARIABLE text ERROR_VARIABLE err
                    OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_STRIP_TRAILING_WHITESPACE)
    if(NOT rc EQUAL 0)
        string(REPLACE ";" " " args "${ARGN}")
        message(FATAL_ERROR "${GIT_EXECUTABLE} -C ${dir} ${args} failed (${rc}): ${err}")
    endif()
    set(${out} "${text}" PARENT_SCOPE)
endfunction()

# The commit NeuralAmpModelerCore pins Eigen at: its gitlink, which its tree records whether or not the submodule
# was ever cloned (GIT_SUBMODULES "" skips the clone, not the entry).
if(EXISTS "${nam_core_src_SOURCE_DIR}/.git")
    felitronics_nam_git(nam_eigen_entry "${nam_core_src_SOURCE_DIR}" ls-tree HEAD Dependencies/eigen)
    if(NOT nam_eigen_entry MATCHES "^160000 commit ([0-9a-f]+)\t")
        message(FATAL_ERROR "NeuralAmpModelerCore at ${nam_core_src_SOURCE_DIR} pins no Eigen submodule "
                            "(git ls-tree HEAD Dependencies/eigen: '${nam_eigen_entry}')")
    endif()
    set(nam_eigen_pin "${CMAKE_MATCH_1}")
    if(NOT nam_eigen_pin STREQUAL FELITRONICS_EIGEN_COMMIT)
        message(FATAL_ERROR "NeuralAmpModelerCore at ${nam_core_src_SOURCE_DIR} pins Eigen ${nam_eigen_pin}, "
                            "but this build is held to ${FELITRONICS_EIGEN_COMMIT} (FELITRONICS_EIGEN_COMMIT, Eigen "
                            "${FELITRONICS_EIGEN_TAG}). Build a NeuralAmpModelerCore that pins this Eigen (v0.5.4, "
                            "this module's default, does), or state the Eigen yours pins in FELITRONICS_EIGEN_TAG and "
                            "FELITRONICS_EIGEN_COMMIT.")
    endif()
else()
    message(STATUS "NeuralAmpModelerCore at ${nam_core_src_SOURCE_DIR} is not a git checkout — its Eigen pin is not checked")
endif()

if(EXISTS "${nam_core_src_SOURCE_DIR}/Dependencies/eigen/Eigen/Dense")
    set(FELITRONICS_EIGEN_DIR "${nam_core_src_SOURCE_DIR}/Dependencies/eigen")
    message(STATUS "Eigen: NeuralAmpModelerCore's own — ${FELITRONICS_EIGEN_DIR}")
else()
    message(STATUS "Eigen: fetching ${FELITRONICS_EIGEN_TAG} from github.com/darwinscat/eigen")
    FetchContent_Declare(eigen_src
        GIT_REPOSITORY https://github.com/darwinscat/eigen.git
        GIT_TAG        ${FELITRONICS_EIGEN_TAG}
        GIT_SHALLOW    TRUE
        SOURCE_SUBDIR  no-cmake-here)       # headers only: Eigen's own CMake project is never entered
    FetchContent_MakeAvailable(eigen_src)
    set(FELITRONICS_EIGEN_DIR "${eigen_src_SOURCE_DIR}")
endif()
if(EXISTS "${FELITRONICS_EIGEN_DIR}/.git")
    felitronics_nam_git(eigen_head "${FELITRONICS_EIGEN_DIR}" rev-parse HEAD)
    if(NOT eigen_head STREQUAL FELITRONICS_EIGEN_COMMIT)
        message(FATAL_ERROR "Eigen at ${FELITRONICS_EIGEN_DIR} is ${eigen_head}, not ${FELITRONICS_EIGEN_COMMIT} "
                            "(FELITRONICS_EIGEN_COMMIT, Eigen ${FELITRONICS_EIGEN_TAG})")
    endif()
else()
    message(STATUS "Eigen at ${FELITRONICS_EIGEN_DIR} is not a git checkout — its commit is not checked")
endif()

# namz is a header-only, lossless .nam codec and the .orbitrig rig model (namz_rig*.h — schema 5 with
# `tone`, `lag_samples`, the pack's own two levels, a capture's `input_lag_samples` / `polarity` and the frequency knob
# (`hz_by`, `positions[].hz`), all of which felitronics::rigplayer reads; schema-4 packs load as before).
# Pinned by release tag, and the fetched tag is held to its commit (THIRD_PARTY_NOTICES.md names it): a tag that
# moved, or another tag set without its commit, stops the configure instead of building silently. A host that sets
# FELITRONICS_NAMZ_TAG (OrbitAmp FORCEs it) sets FELITRONICS_NAMZ_COMMIT with it. A local checkout
# (FELITRONICS_NAMZ_SRC, FETCHCONTENT_SOURCE_DIR_NAMZ_SRC) is its owner's choice and is not held; BUILD-INFO names it.
# SOURCE_SUBDIR deliberately points at a directory without CMakeLists.txt: populate the headers without building
# namz's project or fetching nlohmann twice.
set(FELITRONICS_NAMZ_TAG "v5.0.0" CACHE STRING
    "namz release to build against")
set(FELITRONICS_NAMZ_COMMIT "717ca2dc34cc712075abc77c613c507ee8bc8727" CACHE STRING
    "The commit that release must be: namz v5.0.0's tag")
set(FELITRONICS_NAMZ_SRC "" CACHE PATH
    "Local namz checkout (when empty, fetch the pin)")
if(FELITRONICS_NAMZ_SRC AND NOT EXISTS "${FELITRONICS_NAMZ_SRC}")
    message(FATAL_ERROR "FELITRONICS_NAMZ_SRC does not exist: ${FELITRONICS_NAMZ_SRC}")
endif()
if(FELITRONICS_NAMZ_SRC)
    message(STATUS "namz: local checkout — ${FELITRONICS_NAMZ_SRC}")
    FetchContent_Declare(namz_src
        SOURCE_DIR    "${FELITRONICS_NAMZ_SRC}"
        SOURCE_SUBDIR include)
else()
    message(STATUS "namz: fetching ${FELITRONICS_NAMZ_TAG} from GitHub")
    FetchContent_Declare(namz_src
        GIT_REPOSITORY https://github.com/darwinscat/namz.git
        GIT_TAG        ${FELITRONICS_NAMZ_TAG}
        GIT_SHALLOW    TRUE
        SOURCE_SUBDIR  include)
endif()
FetchContent_MakeAvailable(namz_src)
if(NOT FELITRONICS_NAMZ_SRC AND NOT FETCHCONTENT_SOURCE_DIR_NAMZ_SRC)
    if(EXISTS "${namz_src_SOURCE_DIR}/.git")
        felitronics_nam_git(namz_head "${namz_src_SOURCE_DIR}" rev-parse HEAD)
        if(NOT namz_head STREQUAL FELITRONICS_NAMZ_COMMIT)
            message(FATAL_ERROR "namz at ${namz_src_SOURCE_DIR} is ${namz_head}, not ${FELITRONICS_NAMZ_COMMIT} "
                                "(FELITRONICS_NAMZ_COMMIT, namz ${FELITRONICS_NAMZ_TAG})")
        endif()
    else()
        message(STATUS "namz at ${namz_src_SOURCE_DIR} is not a git checkout — its commit is not checked")
    endif()
endif()

add_library(nam_core STATIC
    ${nam_core_src_SOURCE_DIR}/NAM/activations.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/container.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/conv1d.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/convnet.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/dsp.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/get_dsp.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/linear.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/lstm.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/ring_buffer.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/util.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/wavenet/a2_fast.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/wavenet/model.cpp
    ${nam_core_src_SOURCE_DIR}/NAM/wavenet/slimmable.cpp)
target_compile_features(nam_core PUBLIC cxx_std_20)
target_compile_definitions(nam_core PUBLIC NAM_SAMPLE_FLOAT)
set_target_properties(nam_core PROPERTIES POSITION_INDEPENDENT_CODE ON)
target_include_directories(nam_core SYSTEM PUBLIC
    ${nam_core_src_SOURCE_DIR}
    ${nam_core_src_SOURCE_DIR}/NAM
    ${nam_core_src_SOURCE_DIR}/NAM/wavenet
    ${FELITRONICS_EIGEN_DIR}
    ${nam_core_src_SOURCE_DIR}/Dependencies/nlohmann
    ${nam_core_src_SOURCE_DIR}/Dependencies
    ${namz_src_SOURCE_DIR}/include)

add_library(felitronics_nam STATIC src/NamStage.cpp src/DirectBuild.cpp)
add_library(felitronics::nam ALIAS felitronics_nam)
target_include_directories(felitronics_nam PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
# NamStage.cpp defines NAMZ_IMPLEMENTATION exactly once. Consumers deliberately receive namz's
# declarations, include <namz.h> without that define, and link the codec symbols from this archive.
# nlohmann rides along as a USAGE REQUIREMENT of those exported headers — namz's rig headers
# (namz_rig*.h) publicly include <nlohmann/json.hpp>, so a consumer TU that includes them must be
# able to resolve it without fetching its own copy. This exports ONLY namz + nlohmann; the NAM/Eigen
# include dirs stay PRIVATE (see the nam_core link below).
target_include_directories(felitronics_nam SYSTEM PUBLIC
    ${namz_src_SOURCE_DIR}/include
    ${nam_core_src_SOURCE_DIR}/Dependencies/nlohmann
    ${nam_core_src_SOURCE_DIR}/Dependencies)
target_compile_features(felitronics_nam PUBLIC cxx_std_20)
target_compile_definitions(felitronics_nam PUBLIC FELITRONICS_WITH_NAM)
set_target_properties(felitronics_nam PROPERTIES POSITION_INDEPENDENT_CODE ON)
target_link_libraries(felitronics_nam
    PRIVATE
    # NAM registers model architectures through static initializers. Encode WHOLE_ARCHIVE here once;
    # plain static linking silently drops those translation units and valid models then fail to load.
    "$<LINK_LIBRARY:WHOLE_ARCHIVE,nam_core>"
    PUBLIC
    felitronics::neural
    felitronics::core)

if(FELITRONICS_BUILD_TESTS)
    # The dedicated RT test controls Eigen's runtime malloc gate from its TU. NAM's Eigen call sites
    # must see the same opt-in macro for the guard to cover allocations originating inside nam_core.
    target_compile_definitions(nam_core PRIVATE EIGEN_RUNTIME_NO_MALLOC)

    add_executable(felitronics_nam_tests tests/NamStageTests.cpp)
    target_link_libraries(felitronics_nam_tests PRIVATE felitronics::nam)
    target_link_libraries(felitronics_nam_tests PRIVATE felitronics::test_support)
    target_compile_features(felitronics_nam_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_nam_tests COMMAND felitronics_nam_tests)

    # Reads a config's SHAPE only, so it needs no model and no NAM backend — just the json header.
    add_executable(felitronics_nam_rf_tests tests/ReceptiveFieldTests.cpp)
    # Threads: the nesting guard is asserted on a std::thread, whose default stack is the smallest one
    # the registry is asked on (512 KiB on macOS). glibc >= 2.34 carries pthread in libc; this says so anyway.
    find_package(Threads REQUIRED)
    target_link_libraries(felitronics_nam_rf_tests PRIVATE felitronics::nam Threads::Threads)
    target_link_libraries(felitronics_nam_rf_tests PRIVATE felitronics::test_support)
    target_compile_features(felitronics_nam_rf_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_nam_rf_tests COMMAND felitronics_nam_rf_tests)

    # Pure arithmetic — no model, no backend, no sound card. Every assertion is one of the defects
    # that was previously found only by ear.
    add_executable(felitronics_nam_blend_tests tests/BlendLawTests.cpp)
    target_link_libraries(felitronics_nam_blend_tests PRIVATE felitronics::nam)
    target_link_libraries(felitronics_nam_blend_tests PRIVATE felitronics::test_support)
    target_compile_features(felitronics_nam_blend_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_nam_blend_tests COMMAND felitronics_nam_blend_tests)

    # The load (v0.7.0): the direct build's gate against get_dsp, the mono build, Warm::Caller. It builds networks both
    # ways itself, so it sees NAM's headers (nam_core) and NAM's own example models; FELITRONICS_GUITAR_RIG_PACKS, when
    # it names a directory of *.orbitrig, adds every real capture in it to the gate.
    add_executable(felitronics_nam_load_tests tests/NamLoadTests.cpp)
    target_link_libraries(felitronics_nam_load_tests PRIVATE felitronics::nam nam_core felitronics::test_support)
    target_compile_definitions(felitronics_nam_load_tests PRIVATE
        FELITRONICS_NAM_EXAMPLE_MODELS="${nam_core_src_SOURCE_DIR}/example_models")
    # …and for rigplayer's allocation gate, which plays NAM's A2 as the real packs' shape (modules/rigplayer).
    set_property(GLOBAL PROPERTY FELITRONICS_NAM_EXAMPLE_MODELS_DIR "${nam_core_src_SOURCE_DIR}/example_models")
    target_compile_features(felitronics_nam_load_tests PRIVATE cxx_std_20)
    if(FELITRONICS_GUITAR_RIG_PACKS)
        add_test(NAME felitronics_nam_load_tests COMMAND felitronics_nam_load_tests ${FELITRONICS_GUITAR_RIG_PACKS})
    else()
        add_test(NAME felitronics_nam_load_tests COMMAND felitronics_nam_load_tests)
    endif()
    add_executable(felitronics_nam_rtalloc_tests tests/NamStageRtAllocTests.cpp)
    target_link_libraries(felitronics_nam_rtalloc_tests PRIVATE felitronics::nam)
    target_link_libraries(felitronics_nam_rtalloc_tests PRIVATE felitronics::test_support)
    target_include_directories(felitronics_nam_rtalloc_tests SYSTEM PRIVATE
        ${FELITRONICS_EIGEN_DIR})
    target_compile_definitions(felitronics_nam_rtalloc_tests PRIVATE EIGEN_RUNTIME_NO_MALLOC)
    target_compile_features(felitronics_nam_rtalloc_tests PRIVATE cxx_std_20)
    add_test(NAME felitronics_nam_rtalloc_tests COMMAND felitronics_nam_rtalloc_tests)
endif()
