// SPDX-License-Identifier: MIT
#pragma once
// felitronics::nam — WHO IS AUDIBLE, HOW LOUDLY, AND WHEN A MODEL MAY BE REPLACED.
//
// Two model slots play the same input and are mixed linearly; a knob between two captures asks for a
// fraction of each. That much is arithmetic. What is not arithmetic — and what cost a day of chasing
// crackle by ear — is WHO decides the number. This header exists because that answer must be "one
// thing, and it is testable without a sound card".
//
// THE FAILURE THIS PREVENTS. In the player this replaces, three separate places wrote the mix or
// swapped a model: the blend itself, the code that follows the nearest capture, and a warm-up gate
// bolted on later. None was wrong alone. Together they replaced models under a live gain and drove
// the weight across its whole range inside single 10 ms blocks. Measured on one sweep of a nine-
// capture device: 62 model loads, 401 parked retries, and a full 1.000 swing of the weight.
//
// SO: one writer, one recurrence, and every property below provable by construction rather than by
// listening.
//
//   1. The applied weight moves by at most `maxDeltaPerBlock` per block. There is no other writer,
//      so no path — a load, a device change, a give-up, a mode flip — can step it. (One-model mode,
//      blendStepSingle, places it on a rail instead — only at a block that begins with the gain at
//      exactly zero, so no sample anybody hears carries the step.)
//   2. A model is replaced only in a slot whose applied weight is exactly zero.
//   3. A model that has not yet been fed its receptive field is never audible. Its weight is zero,
//      not small: a network that has not heard the last 132 ms does not produce a quiet version of
//      the right sound, it produces the wrong sound.
//   4. Progress is guaranteed without timeouts. Whenever a slot holds the wrong model, some slot's
//      goal is zero and the recurrence reaches it in a bounded number of blocks.
//
// WHAT GIVES, since something must: not (1) and not (3) — they constrain a value and a derivative
// and are compatible. What gives is INSTANTANEOUS ACCURACY. Crossing a capture, the incoming model
// arrives about 132 ms late and the outgoing capture carries alone until it does. That is a morph
// that trails the hand, which is what a person hears as a knob rather than as a fault.
//
// AND ONE ECONOMY, added after the law had settled: a slot that stands at EXACTLY zero under an
// unchanged request for longer than the host allows goes COLD. The host stops running its model — the
// model stays where it is, nothing is unloaded — and the law counts the slot unfed from then on,
// because it is. The next change of request wakes it by the path a landing takes (fed back to zero,
// the same receptive field to serve), so (3) holds across a sleep exactly as it holds across a load,
// and the price is the one already paid at every crossing: the first turn after a rest trails the hand
// by one warm-up. A slot with any weight at all is never cold, so a pair sounding together stays two
// passes, as it must; a dial parked on a capture costs one.

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace felitronics::nam {

using BlendModelId = std::uint64_t;      // 0 = this slot holds nothing
inline constexpr int kBlendSlots = 2;
// Far more than the handful of samples two captures of one device drift apart by, and still small
// enough that the correction can never be mistaken for an effect.
inline constexpr int kBlendMaxDelay = 128;

struct BlendPolicy {
    // How far the weight may travel in one block. The full crossfade therefore takes at least
    // 1/maxDeltaPerBlock blocks — at 512 samples and 48 kHz, 0.25 gives 42.7 ms. This is the one
    // number a listener gets to argue with; everything else is derived from it.
    double maxDeltaPerBlock = 0.25;
    // How long a slot may stand at exactly zero, its request unchanged, before it goes cold (see
    // BlendState::cold). In SAMPLES, so the law stays as rate-blind as the rest of it; the host turns
    // its seconds into these. Zero or less = never — the law's own default, because sleeping is an
    // economy the host asks for with a number in its own rate, not a property of the recurrence.
    long long coldAfterSamples = 0;
    // ONE MODEL AT A TIME (blendStepSingle). Off — the default — is the two-slot law, which this flag
    // and the two numbers below do not reach: the single path is a separate function, entered here and
    // nowhere else. On, the weight never rests
    // between two slots while anything is heard, and a capture is replaced by a DIP instead of a
    // crossfade: the gain falls to exactly zero, the outgoing slot rests, the incoming one is loaded
    // or woken and fed its field while nothing is heard, the weight moves to it, and the gain rises.
    bool single = false;
    // …and how long the dip's two ramps take, in host samples (the host turns its seconds into
    // these, as with coldAfterSamples). Fewer than one counts as one.
    long long dipDownSamples = 1;
    long long dipUpSamples   = 1;
};

struct BlendRequest {
    BlendModelId want[kBlendSlots] {};   // which capture belongs in each slot (assigned by the caller)
    double       targetB = 0.0;          // the weight slot 1 should end up with; slot 0 gets 1 - it
};

// What the law asks the message thread to do. At most one is outstanding at a time: a second swap
// while one is in flight would need a slot that is neither audible nor settled.
struct BlendLoad {
    bool         wanted = false;
    int          slot = 0;
    BlendModelId model = 0;
};

struct BlendState {
    BlendModelId held[kBlendSlots] {};
    // `fed` is read only through `fed >= need`, and blendRestated() keeps the ANSWER rather than the
    // count across a restart — so for a slot that was already audible it is `need`, not a tally.
    long long    fed[kBlendSlots] {};    // samples of real signal since this model landed (see above)
    long long    need[kBlendSlots] {};   // …and how many it must have before it may be heard (host samples)
    bool         inFlight[kBlendSlots] {};
    // COLD: the slot stood at exactly zero, holding the wanted model, fed, under an unchanged request,
    // for BlendPolicy::coldAfterSamples. The host does not run a cold slot's model (it stays held —
    // nothing is unloaded), and the law counts the slot unfed while it sleeps. It wakes on the next
    // change of request, re-landed with the same model and its need as it stands then — restated at the
    // host's current rate if a prepare() came between (blendRestated): a warm-up, never a load.
    bool         cold[kBlendSlots] {};
    long long    still[kBlendSlots] {};  // samples at exactly zero under an unchanged request, so far
    BlendRequest last;                   // the request the previous block was stepped with
    BlendModelId asked[kBlendSlots] {};  // the model the outstanding load wants (0 = none out)
    // A load that FAILED. A file that failed once fails every block, and asking again is a storm, not
    // progress — so the law does not ask for this model in this slot again until the request names
    // something else for it (a hand crossing to another pair is a new question). Any landing clears it.
    BlendModelId refused[kBlendSlots] {};
    double       x = 0.0;                // THE applied weight of slot 1. The only state that sounds.
    double       gain = 0.0;             // …and whether ANY of it may be heard yet
};

struct BlendStep {
    double    beginB = 0.0, endB = 0.0;  // the weight at the block's first and last sample
    // …and how much of the result may be heard at all. One when anything is fed, ramped down to zero
    // when nothing is — which happens only at a cold start, where silence is what a person expects.
    double    beginGain = 1.0, endGain = 1.0;
    BlendLoad load;
    // How many samples of the block, from its first, the gain takes to travel from beginGain to
    // endGain; it holds endGain after them. Zero = all of them — always, outside the single path, whose
    // dip is stated in samples and so may end inside a block (a 15 ms ramp is not stretched to a block).
    int       gainRamp = 0;
};

// A slot is SAFE TO HEAR when it holds a model that has been fed enough. Note this does not ask
// whether it holds the WANTED model: an old capture is still a real one, and letting it carry while
// its replacement warms is the whole reason a crossing sounds like a knob instead of a hole.
inline bool blendAudible(const BlendState& s, int i) {
    return s.held[i] != 0 && ! s.inFlight[i] && ! s.cold[i] && s.fed[i] >= s.need[i];
}

// The same request, number for number. Spelled with the orderings so that -Wfloat-equal has nothing
// to say: a caller republishing the same numbers is the same request, and that is all this asks.
inline bool blendSameRequest(const BlendRequest& a, const BlendRequest& b) {
    return a.want[0] == b.want[0] && a.want[1] == b.want[1]
        && a.targetB <= b.targetB && a.targetB >= b.targetB;
}

inline void blendLanded(BlendState& s, int slot, BlendModelId model, long long prewarm);
inline BlendStep blendStepSingle(BlendState& s, const BlendRequest& r, int blockSamples, const BlendPolicy& p);

// One audio block. Advances the fed counters, decides the goal, moves the weight toward it by at
// most one step, and — only where a slot has arrived at exactly zero — asks for the swap.
inline BlendStep blendStep(BlendState& s, const BlendRequest& r, int blockSamples,
                           const BlendPolicy& p = {}) {
    if (p.single) return blendStepSingle(s, r, blockSamples, p);
    BlendStep out;
    out.beginB = s.x;
    if (blockSamples <= 0) { out.endB = s.x; return out; }

    // A CHANGED REQUEST WAKES WHATEVER SLEEPS. Under an unchanged request a cold slot is at a fixed
    // point — its weight at zero, nothing wrong, nothing in flight — so the only way the law can come
    // to want it again is a new request; and the first block of that request is the earliest the slot
    // can start serving its field. Woken by the landing path, with the model and the need it already
    // has: fed from zero, silent until it has been, exactly as after a load. A wake the new request
    // turns out not to need costs one warm-up of an inaudible model, and it sleeps again after.
    const bool changed = ! blendSameRequest(r, s.last);
    if (changed) {
        for (int i = 0; i < kBlendSlots; ++i) {
            if (s.cold[i]) blendLanded(s, i, s.held[i], s.need[i]);
            if (r.want[i] != s.last.want[i]) s.refused[i] = 0;   // a new wish is worth a new try
        }
        s.last = r;
    }

    // FED BEFORE THIS BLOCK, not after. Counting the block first marks a slot audible for the WHOLE
    // of the block in which its counter crosses the line — including the first few hundred samples,
    // which are still short of the receptive field. One block of conservatism costs 10 ms of lag and
    // buys the invariant outright.
    // A cold slot is not fed — the host is not running it — and so is never marked fed.
    const bool wasFed[kBlendSlots] { ! s.cold[0] && s.fed[0] >= s.need[0], ! s.cold[1] && s.fed[1] >= s.need[1] };
    for (int i = 0; i < kBlendSlots; ++i)
        if (s.held[i] != 0 && ! s.inFlight[i] && ! s.cold[i]) s.fed[i] += blockSamples;

    // The goal, in priority order. Anything unsafe to hear outranks anything merely wrong, and being
    // wrong outranks the request — because a slot cannot take its new model until it is silent.
    const bool unsafe0 = ! (s.held[0] != 0 && ! s.inFlight[0] && wasFed[0]);
    const bool unsafe1 = ! (s.held[1] != 0 && ! s.inFlight[1] && wasFed[1]);
    const bool wrong0 = s.held[0] != r.want[0], wrong1 = s.held[1] != r.want[1];
    double goal;
    // NOTHING MAY BE HEARD YET, so nothing is. Letting a half-fed network out "so that something
    // sounds" breaks the one invariant this law exists for, and it buys nothing: only ONE load is
    // ever in flight, so a slot always holds either a fed model or the previous, warm one — which
    // means this case is reachable only at a cold start or a device change. There, a tenth of a
    // second of silence before the first note is what a person expects, and an empty stage is worse
    // than silence anyway: NamStage with no model passes its input straight through, and a raw DI
    // sits some ten decibels above a normalised capture.
    if (unsafe0 && unsafe1) goal = s.x;                        // hold still; the gain below mutes it
    else if (unsafe1)       goal = 0.0;
    else if (unsafe0)       goal = 1.0;
    else if (wrong0 && wrong1) goal = s.x <= 0.5 ? 0.0 : 1.0;   // evacuate the LIGHTER one first and
                                                                // freeze the heavier: two swaps in a
                                                                // row, never a hole between them
    else if (wrong0)        goal = 1.0;
    else if (wrong1)        goal = 0.0;
    else                    goal = std::clamp(r.targetB, 0.0, 1.0);

    const double d = std::clamp(p.maxDeltaPerBlock, 1.0e-9, 1.0);
    s.x = std::clamp(s.x + std::clamp(goal - s.x, -d, d), 0.0, 1.0);
    out.endB = s.x;

    // THE GAIN rises only while no slot that is unsafe to hear carries any weight in this block — at either edge.
    // "One slot is safe" is not enough: a host that held one model and turns two on mid-dip (blendStepSingle) hands
    // this path a weight standing on a slot that is in flight or unfed, and a cold start puts the weight on an EMPTY
    // slot while the other loads — whose stage passes the raw DI. Until v0.2.0 the gain rose as soon as either slot
    // was safe and both were heard, the unsafe one at its weight, for the blocks the weight took to leave it.
    out.beginGain = s.gain;
    const bool risk0 = unsafe0 && std::max(1.0 - out.beginB, 1.0 - out.endB) > 0.0;
    const bool risk1 = unsafe1 && std::max(out.beginB, out.endB) > 0.0;
    const double wantGain = (risk0 || risk1) ? 0.0 : 1.0;
    s.gain = std::clamp(s.gain + std::clamp(wantGain - s.gain, -d, d), 0.0, 1.0);
    out.endGain = s.gain;

    // A swap is asked for only at EXACTLY zero, and only one at a time. Everything above conspires to
    // make that reachable: a wrong slot's goal is a rail, and the rail is its own zero. (`x` is clamped
    // to [0, 1], so `w <= 0.0` IS exactly zero — spelled so that -Wfloat-equal has nothing to say.)
    const bool busy = s.inFlight[0] || s.inFlight[1];
    if (! busy)
        for (int i = 0; i < kBlendSlots; ++i) {
            const double w = i == 0 ? 1.0 - s.x : s.x;
            if (s.held[i] != r.want[i] && w <= 0.0 && r.want[i] != 0 && r.want[i] != s.refused[i]) {
                out.load = { true, i, r.want[i] };
                s.inFlight[i] = true;
                s.asked[i] = r.want[i];
                break;
            }
        }

    // AT REST, and for how long: the wanted model (or none wanted — a slot asked for nothing keeps
    // its old capture and is never swapped, so it is at rest too), fed, at exactly zero for the whole
    // block, under the request of the block before. Anything else — a move, a swap, a warm-up, a new
    // request — starts the count over. The rest is counted as PLAYED: the block that completes it
    // still runs, and the slot goes cold on the next, which the host reads after this call and skips.
    for (int i = 0; i < kBlendSlots; ++i) {
        const double w = std::max(i == 0 ? 1.0 - out.beginB : out.beginB, i == 0 ? 1.0 - out.endB : out.endB);
        const bool atRest = ! changed && ! s.cold[i] && wasFed[i] && ! s.inFlight[i] && s.held[i] != 0
                         && (s.held[i] == r.want[i] || r.want[i] == 0 || r.want[i] == s.refused[i])
                         && w <= 0.0;
        if (atRest && p.coldAfterSamples > 0 && s.still[i] >= p.coldAfterSamples) s.cold[i] = true;
        s.still[i] = atRest ? s.still[i] + blockSamples : 0;
    }
    return out;
}

// The message thread reporting back. `prewarm` is that model's own receptive field in HOST samples —
// see NamStage::prewarmSamples(), and convert it, because the model counts in its own rate. Also the
// law's own wake of a cold slot: the same model, the same need, fed from zero again.
inline void blendLanded(BlendState& s, int slot, BlendModelId model, long long prewarm) {
    if (slot < 0 || slot >= kBlendSlots) return;
    s.held[slot] = model;
    s.need[slot] = std::max(0LL, prewarm);
    s.fed[slot] = 0;
    s.inFlight[slot] = false;
    s.cold[slot] = false;                // a landing is a wake, whether the model is new or the same one
    s.still[slot] = 0;
    s.asked[slot] = 0;
    s.refused[slot] = 0;                 // what landed is real; whatever was refused may be asked anew
}

// ONE MODEL AT A TIME — BlendPolicy::single, for a host that can afford one network and not two (a
// browser's audio thread on a slow machine). The request names ONE capture: the slot `targetB` sits
// on (it is a rail here, 0 or 1) and the model that slot wants; the other slot is asked for nothing
// and is never loaded. What this path adds is the one thing the crossfade cannot do without a second
// network — replacing the capture that IS the sound — and it does it by a DIP:
//
//   1. the gain falls to exactly zero over dipDownSamples (the outgoing capture still plays alone);
//   2. once nothing is heard, every slot but the one meant to sound RESTS (BlendState::cold — the host
//      does not run it, and it keeps its model: a hand coming back to it costs a warm-up, not a load);
//   3. the incoming capture is loaded — in its own slot, or in place of the outgoing one when both
//      live in the same slot — or woken if its slot already holds it, and it is fed its receptive
//      field while nothing is heard (invariant 3, unchanged: the silence is what pays for it);
//   4. the weight is PLACED on its slot's rail — invariant 1 restated: it moves without a ramp only at a
//      block that begins with the gain at exactly zero, where nothing of it is heard — and only once the
//      slot is fed does the gain rise over dipUpSamples. So the hole is the dip and the warm-up, in time:
//      a capture with no field is heard again in the block after the fall ends.
//
// So at most ONE NETWORK RUNS ON AUDIO at any instant — the dip ends the old one's sound before the new
// one is run — plus the outgoing capture's bounded DRAIN: the host does not hand a resting slot audio,
// and its stage feeds the lane its receptive field of silence once and stops (NamStage, law 11(d)), which
// overlaps the incoming capture's warm-up. With ONE exception, stated rather than hidden: a switch into
// this mode while two captures are sounding (a mode-two crossfade, half way) plays both through the dip's
// fall, because silencing one of them sooner would be a step. Invariant 2 is restated, not broken: a model is replaced only where
// nothing of it is heard — its weight is exactly zero, or the gain is. A slot whose weight is exactly
// zero is put to rest at once, not after BlendPolicy::coldAfterSamples: there is no neighbour to keep
// warm in this mode, which is the point of it.
//
// A capture that fails to load is refused as in the two-slot law (asked once); the slot keeps — and
// sounds — whatever it held, warmed afresh, because it was not run while its replacement was out.
//
// AND THE WAY BACK: a host that turns two models on again hands blendStep a weight standing on whatever
// this path left — a slot in flight, or one landed and not yet fed. The two-slot law raises its gain only
// once no unsafe slot carries weight, so that hand-over is silent until the weight has left the slot.
inline BlendStep blendStepSingle(BlendState& s, const BlendRequest& r, int blockSamples, const BlendPolicy& p) {
    BlendStep out;
    out.beginB = s.x;
    if (blockSamples <= 0) { out.endB = s.x; return out; }
    if (! blendSameRequest(r, s.last)) {
        for (int i = 0; i < kBlendSlots; ++i)
            if (r.want[i] != s.last.want[i]) s.refused[i] = 0;   // a new wish is worth a new try
        s.last = r;
    }
    // The slot meant to sound, and what it should hold. A refused capture falls back to what its slot
    // still holds, else to whatever the other slot holds: a real model rather than a silent panel.
    int t = r.targetB >= 0.5 ? 1 : 0;
    BlendModelId m = r.want[t];
    if (m != 0 && m == s.refused[t]) {
        if (s.held[t] != 0) m = s.held[t];
        else if (s.held[1 - t] != 0) { t = 1 - t; m = s.held[t]; }
    }
    const bool muted = s.gain <= 0.0;                            // at the block's first sample
    const auto weight = [&s](int i) { return i == 0 ? 1.0 - s.x : s.x; };
    // REST: while anything is heard, every slot that is not heard; once nothing is, every slot but the
    // one meant to sound. A slot in flight is not run by the host either way, and is not marked.
    for (int i = 0; i < kBlendSlots; ++i) {
        const bool keeper = i == t && m != 0 && s.held[i] == m;
        if (s.held[i] != 0 && ! s.inFlight[i] && ! s.cold[i] && (muted ? ! keeper : weight(i) <= 0.0))
            s.cold[i] = true;
        s.still[i] = 0;                                          // the rest timer is the two-slot law's
        // A slot in flight is not run by this host — the two-slot host plays its old model meanwhile, and does not
        // reset its count when it asks — so if the load fails, what it keeps has not heard this audio: it warms again.
        if (s.inFlight[i]) s.fed[i] = 0;
    }
    // WAKE the one meant to sound, and only once nothing is heard — sooner would be a second network.
    if (muted && m != 0 && s.held[t] == m && s.cold[t]) blendLanded(s, t, m, s.need[t]);
    const bool wasFed[kBlendSlots] { ! s.cold[0] && s.fed[0] >= s.need[0], ! s.cold[1] && s.fed[1] >= s.need[1] };
    for (int i = 0; i < kBlendSlots; ++i)
        if (s.held[i] != 0 && ! s.inFlight[i] && ! s.cold[i]) s.fed[i] += blockSamples;
    // The weight moves only while nothing is heard, and then it is PLACED on the rail at the block's first sample
    // rather than travelled there: the gain is exactly zero, so the travel would buy nothing anybody hears and cost a
    // block of silence per quarter (four at 0.25 — 21 ms at a 256-sample block, 340 at 4096). The gain may rise only
    // with the weight on the rail for the WHOLE block — so a block that is heard at all is one slot alone, never a mix.
    const double rail = t == 1 ? 1.0 : 0.0;
    if (muted) { s.x = rail; out.beginB = rail; }
    const bool onRail = t == 1 ? s.x >= 1.0 : s.x <= 0.0;
    out.endB = s.x;
    const bool ready = onRail && m != 0 && s.held[t] == m && ! s.inFlight[t] && ! s.cold[t] && wasFed[t];
    // THE DIP, in samples, ending where it ends rather than at the block's edge (BlendStep::gainRamp).
    out.beginGain = s.gain;
    const double want = ready ? 1.0 : 0.0;
    const long long len = std::max(1LL, want > s.gain ? p.dipUpSamples : p.dipDownSamples);
    const double room = (double) blockSamples / (double) len;   // how far the gain may travel this block
    const double dist = want - s.gain;
    if (std::abs(dist) <= room) {
        if (std::abs(dist) > 0.0)
            out.gainRamp = std::clamp((int) std::lround(std::abs(dist) * (double) len), 1, blockSamples);
        s.gain = want;                                           // lands EXACTLY — law 8, as the weight does
    } else {
        s.gain += dist > 0.0 ? room : -room;
    }
    out.endGain = s.gain;
    // THE LOAD, one at a time, into the slot meant to sound — once nothing of that slot is heard: the
    // gain is down, or the slot is not being run at all (empty, or resting at weight zero), in which
    // case the load overlaps the dip's fall instead of following it.
    const bool busy = s.inFlight[0] || s.inFlight[1];
    const bool unheard = muted || (weight(t) <= 0.0 && (s.held[t] == 0 || s.cold[t]));
    if (! busy && m != 0 && s.held[t] != m && m != s.refused[t] && unheard) {
        out.load = { true, t, m };
        s.inFlight[t] = true;
        s.asked[t] = m;
        s.cold[t] = false;      // in flight now, which the host does not run either
        s.fed[t] = 0;           // …and if it fails, what it keeps has not been run: it warms again
    }
    return out;
}

// 🔴 THE HOST RATE MOVED, AND THREE OF THIS LEDGER'S NUMBERS ARE HOST SAMPLES. `need` is a count of them
// (NamStage::prewarmSamples() converted, plus the rate-matcher's latency, plus one block — see
// rigplayer::RigPlayer::warmFor), and until P89 nothing recomputed it when the host handed the player a
// new rate: it was written once, at the landing, and read for ever after — including by the WAKE at the
// top of blendStep(), which re-arms a cold slot with `s.need[i]` exactly as it stands.
//
// WHAT THAT COST, measured through the player on a 6x6 grid of host rates, two block sizes and three
// shapes (a 2001-tap Linear, an untagged one, a WaveNet): the warm-up a woken slot is held for does not
// depend on the new rate AT ALL. It is, sample for sample, the warm-up the slot had at the rate its model
// landed at — so the error tracks fs_landed/fs_now (roughly: the latency and block terms do not scale, so
// 44.1 -> 96 kHz reads 0.469 where the bare ratio is 0.459). 48 -> 96 kHz warms a slot for 2048 host
// samples where 4096 are owed — half a field, which is invariant 3 broken in the direction the law calls
// the bad one. 48 -> 192 kHz warms for a quarter. The other direction over-warms: 192 -> 48 kHz holds a
// slot silent four times longer than it needs.
//
// ⚠️ AND A ONE-POINT FIXTURE WOULD HAVE CALLED IT CLEAN. Of the 180 cells, 85 under-warm, 85 over-warm,
// and exactly 10 read right — eight of them 44.1 <-> 48 kHz, the two rates nearly every session on earth
// uses, and the other two 88.2 <-> 96 on the WaveNet at a 256-sample block. A fixture reaching for the
// obvious pair sits on the one place the defect is invisible. This is P85's lesson with a second set of
// numbers.
//
// WHAT THIS VERB DOES, and it is NOT blendLanded(). A restart is not a landing: it must not clear
// `inFlight` (a second load could then be asked for a slot that already has one out), nor `cold`, nor
// `refused` (a capture that deterministically fails would be asked for again — the storm the law exists
// to prevent). It restates the three numbers that are in host samples and nothing else:
//
//   · `need` is recomputed by the caller, at the NEW rate, from the model actually in the slot, and
//     handed in. It is not RESCALED from the old one: `need` is not homogeneous in the rate — only the
//     receptive-field term scales, while the rate-matcher's latency is 0 at 48 kHz, 61 at 44.1 and 96 at
//     96 kHz, and the `+ maxBlock` term does not scale at all. Rescaling would be a restatement of
//     warmFor() with a different answer, which is the disease this tree keeps curing.
//
//   · `fed` is mapped BY ITS PREDICATE, not by its value, and that is the whole of the design. The only
//     thing anything reads `fed` for is `fed >= need` (audible(), and the wasFed gate in blendStep), so
//     what must be preserved across a restart is the ANSWER to that question, not the count:
//       - a slot that was AUDIBLE stays audible (`fed = need`). Re-arming it to zero would mute a
//         sounding capture at every prepare() — and RigPlayer::reset()'s three reasons for not re-arming
//         `fed` transfer to a rate change one for one, the third most of all: the law would ramp the
//         weight down over four blocks, so the by-hypothesis wrong network is audible anyway, and what
//         the re-arm buys is a HOLE (fade-out, mute for a whole field, fade-in) at every transport start.
//       - a slot that was still WARMING is re-armed to zero, and this is free rather than a cost: such a
//         slot is at weight zero by construction (a landing happens only at zero, and the goal rails away
//         from an unsafe slot), and the restart has just FLUSHED its network — so crediting it the field
//         it heard before the flush is the very defect above, in its worst form. It is also the one thing
//         here that was wrong at an UNCHANGED rate too.
//     ⚠️ SCALING `fed` BY THE RATE RATIO IS THE TRAP, and it flips the predicate rather than preserving
//     it: 96 -> 48 kHz on a slot that had just become audible gives `fed·0.5 = pre/2 + 48 + B/2` against
//     `need = pre/2 + B`, which is short whenever the block exceeds 96 samples — i.e. always. The slot
//     goes inaudible, the law rails the goal to its neighbour, and a spurious full crossfade plays.
//
//   · `still` is RESCALED by `timeScale` (new rate / the rate the ledger was counted in), and here —
//     alone of the three — rescaling is the exact answer rather than the trap. `still` is nothing but
//     accumulated host samples of elapsed time at rest (`still += blockSamples`), with no latency term
//     and no block term, so it IS homogeneous in the rate: multiplying by the ratio preserves the
//     elapsed time exactly. Left alone, a partial count in the old rate's units is measured against
//     `coldAfterSamples`, which the host DOES recompute — 192 -> 48 kHz puts a slot to sleep at once,
//     48 -> 192 postpones it by up to a cold window.
//     ⚠️ ZEROING IT WAS THE FIRST DRAFT, and it was a behaviour change hiding as a cleanup: at an
//     UNCHANGED rate — every same-rate prepare(), which is the common case, and every reset() — it
//     postponed sleep by a whole cold window at each call, so a host restarting at every transport
//     start ran a parked dial's second network for two extra seconds each time. The ratio is exactly 1
//     there, so rescaling changes nothing where nothing changed.
//
// Message thread (prepare) or any thread with audio stopped (reset), under the caller's "never
// concurrent with process()" contract — the one under which RigPlayer::prepare() already zeroes its band
// count and clears its audio state. Arithmetic only: no allocation, no lock, no throw.
inline void blendRestated(BlendState& s, int slot, long long need, double timeScale) noexcept {
    if (slot < 0 || slot >= kBlendSlots) return;
    if (s.held[slot] == 0) return;              // an empty slot has no ledger to restate
    const bool wasAudible = s.fed[slot] >= s.need[slot];
    s.need[slot] = std::max(0LL, need);
    s.fed[slot]  = wasAudible ? s.need[slot] : 0;
    // A scale that is not a positive finite number means "no rate to convert from": leave the count.
    // There is deliberately no `timeScale != 1.0` shortcut: it is a float equality, which gcc's
    // -Wfloat-equal refuses in this header (clang lets it through, which is how it got written), and it
    // bought nothing. Multiplying a double by exactly 1.0 is exact for every double, and the count
    // converts to one exactly below 2^53 samples — about 95 years at 3 MHz, which is the bound that
    // matters, because with the cold window disabled (`coldAfterSamples <= 0`) a slot never goes cold and
    // `still` grows for as long as it rests.
    if (timeScale > 0.0 && timeScale < 1.0e9)
        s.still[slot] = (long long) std::llround((double) s.still[slot] * timeScale);
}

// A load that could not be honoured (unreadable file, wrong rate). The slot keeps whatever it had,
// which is a real model — and the model that failed is remembered as refused: it is not asked for
// again until the request names something else for this slot, because a deterministic failure asked
// for every block is a storm of fetches and parses that fixes nothing. Such a slot is at rest.
inline void blendLoadFailed(BlendState& s, int slot) {
    if (slot < 0 || slot >= kBlendSlots) return;
    s.refused[slot] = s.asked[slot];
    s.asked[slot] = 0;
    s.inFlight[slot] = false;
}

// ---- and the arithmetic that applies it to audio -------------------------------------------------
// Separated from the law on purpose: the law says WHAT the weights are, this says what happens to the
// samples. Losing one of the two model calls in the host was audible only as "the loudness ripples
// with the knob" — because an unprocessed slot passes the DI through, and a DI is some ten decibels
// above a normalised capture. A block of arithmetic that can be run without a model, a device or a
// sound card is a block that cannot lose half of itself unnoticed.

// A whole-sample delay applied in place, carrying its own tail between blocks. The tail MUST advance
// every block, including while the slot is silent, or the first audible samples read a stale line.
inline void blendDelay(float* x, float* tail, int cap, int n, int count) {
    if (x == nullptr || tail == nullptr || n <= 0 || n > cap || count <= 0) return;
    const int carry = std::min(n, count);
    float keep[kBlendMaxDelay] {};
    for (int i = 0; i < carry; ++i) keep[i] = x[count - carry + i];
    for (int i = count - 1; i >= n; --i) x[i] = x[i - n];
    for (int i = 0; i < std::min(n, count); ++i) x[i] = tail[i];
    for (int i = 0; i + carry < n; ++i) tail[i] = tail[i + carry];
    for (int i = 0; i < carry; ++i) tail[n - carry + i] = keep[i];
}

// The two slot outputs, already produced by their own models, mixed by a weight that travels from
// `beginB` to `endB` across the block. `a` is overwritten with the result. Linear, not equal-power:
// both models were fed the identical signal so their harmonics arrive in phase and add — equal-power
// would swell by 3 dB in the middle of every turn of the knob.
inline void blendMix(float* a, const float* b, int count, double beginB, double endB) {
    if (count <= 0) return;
    const float from = (float) beginB, step = (float) ((endB - beginB) / (double) count);
    float m = from;
    for (int i = 0; i < count; ++i) {
        m += step;
        a[i] = a[i] * (1.0f - m) + b[i] * m;
    }
}

} // namespace felitronics::nam
