// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.

#pragma once

#include <felitronics/eq/Svf.h>
#include <felitronics/oversampling/Oversampler.h>
#include <felitronics/oversampling/PolyphaseOversampler.h>
#include <felitronics/poweramp/SagEnvelope.h>
#include <felitronics/poweramp/TubeStage.h>

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstddef>
#include <memory>
#include <vector>

//==============================================================================
// felitronics::poweramp::PowerAmpStage — a white-box ANALYTIC tube power-amp stage: an oversampled
// push-pull / single-ended tube waveshaper (TubeStage) with a power-supply SAG rail, NFB-style
// presence/depth shelves, a reactive-speaker VIRTUAL LOAD pre-EQ, an OUTPUT-TRANSFORMER model and a
// per-sample dynamic BIAS shift. Lifted verbatim from OrbitCab's cab::poweramp::TubePowerAmp — the
// numeric fingerprint (every guard, clamp, chunk boundary and processing order) is pinned by this
// module's golden battery, ported from OrbitCab's PowerAmpCoreGolden CI gate.
//
// Chain: [virtual-load pre-EQ] → Drive pre-gain (·1/s under sag) → upsample ×N → TubeStage (PP/SE,
//   per-sample vbDelta bias) → OS-domain DC-block → output transformer (OS domain) → downsample →
//   per-voicing MID bell → sag rail ·s + presence/depth shelves → drive-comp · Output ramp.
// The sag rail is y = s·shaper(u/s): earlier breakup + lower ceiling = tube squish, not a VCA duck.
// Feel gate: with sag = presence = depth = load = iron = bias = 0 every optional path is skipped
// ⇒ byte-identical to the bare oversampled waveshaper.
//
// THE PRODUCT/CORE SEAM — the stage owns the DSP; the product owns the DATA:
//   • Voicing — the per-tube character (curve shape, sag time constants, NFB shelf voicing, MID
//     fingerprint, load/transformer corners). A product ships its own preset table (OrbitCab keeps
//     kTubeVoicings {6L6, EL34, EL84, KT88}) and passes the chosen entry into setParams(). Trusted
//     data: finite by contract (a constexpr table), not sanitized per block.
//   • Params — the user-facing control values (Drive/Output/PP-SE topology + the [0,1] feel amounts; the
//     OVERSAMPLER topology is a separate, prepare-time choice — see prepare()).
//     UNTRUSTED: sanitized at the setParams() gate (isfinite + clamp), because a bad preset or a
//     non-parameter-system caller would otherwise poison the OS/DC/IIR state with NaN — permanently.
//
// 🔴 RT rule: process() never allocates, locks, does IO or throws. All state/buffers are heap-
// allocated in prepare() behind a pImpl, NOT by-value members — the by-value stage member stays tiny
// and Windows' 1 MB audio-thread stack is never at risk (the MSVC rule). prepare() is message/host
// thread only. Latency = the oversampler round-trip: under the default Kaiser topology tapsPerPhase−1,
// constant across factor; under Topology::Cascade (P31) the cascade's, from the rate and the factor.
//
// TAPS. The stage used to hardcode 32 taps/phase with no way for a caller to say otherwise, and its own
// aliasing gate (PowerAmpGoldenTests, "reference-free non-harmonic energy") declared that adequate. It
// is not, and the gate could not see why: its analysis window stopped at 10 kHz, which is BELOW where
// the transition-band leakage lands. Over the whole band the same gate reads −68.7 dBc at 32 taps — a
// FAILURE of its own −70 dBc bar, by 1.3 dB — against −77.4 at the core default of 64, an 8.7 dB gap;
// a 3 kHz fundamental at +12 dB drive goes −56.2 → −75.9 dBc. (Every figure here is one the suite
// PRINTS, at both taps counts, so it is reproducible by running it rather than quoted from a probe —
// an earlier revision of this note quoted probe numbers that the suite does not produce.)
// So the default is the core's now, and the knob is exposed: a live rig that would rather have the 32
// samples back than the rejection can still ask for 32, which it previously could not express at all.
// It is not free: the stage costs 1.24 %RT at 32 taps and 2.43 at 64 (48 kHz, stereo, 4x, block 512),
// and the round trip goes 31 → 63 samples, i.e. +0.67 ms at 48 kHz.
//
// WHAT THE TAPS DO NOT FIX, so that nobody reads the above as more than it is: the map's hot and
// high-frequency cells (a 3 kHz fundamental at +24 dB reads −40.9 dBc at EITHER taps count) are the
// tube's own harmonics folding INSIDE the oversampled domain. That is the oversampling FACTOR's axis;
// no decimation filter reaches them.
//==============================================================================
namespace felitronics::poweramp
{

// Per-tube-fixed voicing DATA the product supplies with every setParams() call — the amp's
// character, distinct from the user's knobs (Params). Defaults are a neutral, safe PP tube with the
// whole feel/load/transformer character zeroed (every optional stage gated off), matching the
// stage's own pre-setParams coefficient seeds. Field meanings (and OrbitCab's shipped values for
// four archetypes) are documented at the product's preset table.
struct Voicing
{
    // Waveshaper voicing — the static transfer curve:
    float driveScale = 1.0f;      // Drive-knob pre-scale into the nonlinearity (per-tube gain trim)
    float k          = 2.0f;      // tanh drive of the Asym waveshaper halves
    float bSE        = 0.18f;     // single-ended (class A) operating-point bias
    float vbPP       = 0.30f;     // push-pull (class AB) per-half bias
    float evenLeak   = 0.0f;      // per-half bias MISMATCH — the only breaker of PP's exact even-cancellation
    // Power-supply sag — per-tube-fixed dynamics (the user's Sag knob scales the amount):
    float sagFastMs     = 8.0f;   // attack (rectifier + first-cap depletion — how fast B+ collapses)
    float sagRecoveryMs = 150.0f; // release (reservoir recharge — the "bloom")
    float sagMaxDroop   = 0.0f;   // the tube's max rail collapse (stiff tube = small); 0 ⇒ sag inert
    float sagBiasDepth  = 0.0f;   // how far the PP operating point drifts toward class-B under sag (Bias knob scales)
    // NFB-style shelves — nominal knob voicing that OPENS under sag/drive ("feedback releases when pushed"):
    float presenceHz    = 5000.0f;
    float presenceMaxDb = 0.0f;   // full-knob HF shelf gain; 0 ⇒ presence inert
    float depthHz       = 100.0f;
    float depthMaxDb    = 0.0f;   // full-knob LF shelf gain; 0 ⇒ depth inert
    float nfbOpen       = 0.0f;   // how much the shelves "open" past nominal when the supply droops
    // Static MID bell — the amp fingerprint (scoop vs push); always on when the stage runs:
    float midHz = 500.0f, midDb = 0.0f, midQ = 0.70f;   // midDb 0 ⇒ bell skipped
    // VIRTUAL LOAD (reactive-speaker impedance pre-EQ, BEFORE the nonlinearity + the sag detector):
    float loadResHz  = 100.0f;    // LF cone-resonance impedance peak (Bell) — peaks the DRIVE ~80-110 Hz
    float loadResQ   = 1.0f;
    float loadResDb  = 0.0f;      // 0 dB (with loadRiseDb 0) ⇒ the pre-EQ is skipped entirely
    float loadRiseHz = 1500.0f;   // HF inductive impedance rise (HighShelf, Q 0.707)
    float loadRiseDb = 0.0f;
    // OUTPUT TRANSFORMER (OS domain, AFTER the nonlinearity): LF core saturation + HF leakage rolloff.
    float otLfHz = 150.0f;        // LF split-band corner (Hz)
    float otSatK = 1.8f;          // core-saturation drive (tanh k)
    float otHfHz = 0.0f;          // HF leakage-rolloff corner (Hz); 0 ⇒ the transformer is gated off
};

// The user-facing control values, as plain numbers — the product's parameter system fills this POD
// once per block. UNTRUSTED at the gate: setParams() sanitizes every float (isfinite + clamp).
struct Params
{
    float driveDb     = 0.0f;    // input pre-gain into the tube nonlinearity (dB)
    float outputDb    = 0.0f;    // post-stage make-up / trim (dB)
    bool  singleEnded = false;   // false = push-pull class AB, true = single-ended class A
    float autoComp    = 1.0f;    // drive-compensation amount [0,1]: 1 ⇒ small-signal gain is Drive-invariant
    // Feel amounts (all [0,1]; 0 = off ⇒ that path is skipped exactly):
    float sag      = 0.0f;       // dynamic power-supply sag (bloom / touch / compression under load)
    float presence = 0.0f;       // NFB-style HF voicing that opens up when pushed
    float depth    = 0.0f;       // NFB-style LF voicing that loosens when pushed
    float load     = 0.0f;       // reactive-speaker virtual-load amount (scales the voicing's impedance pre-EQ)
    float iron     = 0.0f;       // output-transformer amount (LF core saturation + HF leakage rolloff)
    float bias     = 0.0f;       // dynamic bias-shift / crossover bloom (needs sag > 0 + sagBiasDepth > 0)
};

class PowerAmpStage
{
public:
    PowerAmpStage();
    ~PowerAmpStage();

    // Allocate state for this stream / block size. Message/host thread (prepareToPlay) — never
    // the audio thread. `oversampleFactor` defaults to 4 (the shipping value); a test may pass a
    // higher factor (e.g. 32) to build an alias-free reference for null comparison. Under the default
    // Kaiser topology latency is tapsPerPhase-1 regardless of factor, so 4x and 32x stay sample-aligned
    // (under Cascade they do not — see `topology` below). `tapsPerPhase` takes the
    // core's own default (see the TAPS note above and PolyphaseOversampler.h for its derivation);
    // passing it explicitly pins a topology against that default. It is CLAMPED to [4, 1024], not
    // refused — this prepare() returns void and always has, so a rejected value would leave the stage
    // unprepared with no way to say so. That is deliberately UNLIKE `Saturator` and `TruePeakLimiter`,
    // whose prepare() returns bool and therefore refuses; a caller that needs the refusal should read
    // latencySamples() back and compare, since under Kaiser it is tapsPerPhase - 1 by construction. NB the golden battery lifted from
    // OrbitCab runs at the DEFAULT, not at the old 32: what it pins is the stage's structure (processing
    // order, guards, chunk boundaries, block-size determinism, the feel gate), none of which the taps
    // count touches, and it carries separate two-sided checks at an explicit 32 and 96 for the topology
    // itself. OrbitCab's own copy keeps its 32 and passes it explicitly, so its sound and its host
    // latency are unaffected by this default.
    //
    // `topology` (P31) picks the oversampler: Kaiser (the default, above) or Cascade — CascadeOversampler,
    // flat to 20 kHz at every rate, round trip 131 samples at 44.1 kHz and 76 at 48 kHz (4x), from the rate
    // rather than from `tapsPerPhase`. Clamped like everything else here, never refused: under Cascade the
    // factor is rounded DOWN to a power of two (3 -> 2, 12 -> 8), and the rate the filter is designed for
    // is clamped into [8 kHz, 3 MHz] (every rate up to 44.1 kHz shares one geometry, so the low clamp
    // changes no tap); a rate that is not a finite positive number — NaN, +-inf, 0, negative — gets the
    // 44.1 kHz geometry (the one every rate up to 44.1 kHz shares) rather than being clamped to an end. Read latencySamples() back — it reports what was built.
    void prepare (double sampleRate, int maxBlock, int oversampleFactor = 4,
                  int tapsPerPhase = oversampling::PolyphaseOversampler::kDefaultTapsPerPhase,
                  oversampling::Topology topology = oversampling::Topology::Kaiser);
    void reset();

    // Set the controls + the product-chosen voicing. RT-safe: stores targets (and copies the plain-
    // float voicing) only; the coefficients are smoothed inside process(). Once per block before process().
    void setParams (const Params& params, const Voicing& voicing) noexcept;

    // 🔴 RT-safe, in place on planar channels: the full oversampled tube power-amp chain.
    // Law 11 (DSP-ARCHITECTURE.md §2): any numSamples (chunked inside); numChannels above what prepare()
    // gave REFUSES the whole call — false means nothing was touched.
    [[nodiscard]] bool process (float* const* io, int numChannels, int numSamples) noexcept;

    // Host-rate latency = the oversampler round-trip, constant across drive and PP/SE. Under Kaiser it is
    // tpp-1 at every factor; under Topology::Cascade it is CascadeOversampler's for the rate and the factor
    // (76 at 48 kHz 4x, 80 at 32x), so a 4x stage and a 32x reference are no longer sample-aligned there.
    int  latencySamples() const noexcept;

    // THE SHARED SUPPLY'S CURRENT DROOP, in [0, maxDroop*amount] — the rail collapse the stage is
    // applying right now. It is a meter reading (an amp UI shows sag), and it is also the only public
    // window onto the one piece of state this stage does NOT keep per channel: everything else here —
    // the oversampler FIR, the DC blocker, the transformer poles, five SVF columns — belongs to a lane
    // and is dropped when that lane stops, while this follows whichever lanes are playing. Law 11c is a
    // claim about exactly this quantity, and a claim with no observable is not testable.
    float sagDroop() const noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};

//==============================================================================
// Implementation (header-only: OrbitCab's TubePowerAmp.cpp, inlined verbatim).
//==============================================================================
struct PowerAmpStage::Impl
{
    using Svf = felitronics::eq::Svf;

    static constexpr int    kMinTpp    = 4;        // the oversampler's own floor; clamped, like the factor
    static constexpr int    kMaxCh     = 2;        // stereo max (engine contract)
    static constexpr float  kDcBlockHz = 10.0f;    // OS-domain DC blocker corner
    static constexpr float  kSagMinRail = 0.2f;    // clamp s = 1−droop away from 0 (never invert / div-blow-up)
    static constexpr double kTwoPi     = 6.283185307179586476925287;

    static float dbToGain (float db) noexcept { return std::pow (10.0f, db * 0.05f); }

    // dry/wet blend b so that (1 + b·(Gmax−1)) == Gnom — i.e. the quiet (un-sagged) shelf sits at the
    // nominal knob gain, and sag droop later drives b→1 (the fully-open Gmax). A linear-amplitude blend
    // of a min-phase shelf stays a real, stable, per-sample filter — no per-block coefficient jump.
    static float blendForNominal (float nomDb, float maxDb) noexcept
    {
        const float gn = dbToGain (nomDb), gm = dbToGain (maxDb);
        return (gm > 1.0001f) ? std::clamp ((gn - 1.0f) / (gm - 1.0f), 0.0f, 1.0f) : 1.0f;
    }

    double sampleRate = 0.0;
    int    maxBlock   = 0;
    int    os         = 4;                          // oversampling factor (4 shipping; test may set 32)
    int    tpp        = felitronics::oversampling::PolyphaseOversampler::kDefaultTapsPerPhase;   // FIR taps/phase → (tpp-1)-sample round trip under Kaiser

    felitronics::oversampling::Oversampler ovs;
    std::vector<float> osBuf[kMaxCh];               // maxBlock*os per channel (caller-owned OS scratch)
    float*             osPtr[kMaxCh] { nullptr, nullptr };

    TubeStage stage;                                // the pure PP/SE transfer (TubeStage.h)

    double dcR = 0.0;                                // OS-domain DC-block one-pole coeff
    double dcx1[kMaxCh] { 0.0, 0.0 }, dcy1[kMaxCh] { 0.0, 0.0 };

    // --- "feel" state (all allocated/prepared in prepare()) ---
    SagEnvelope        sag;                          // pure dual-TC sag model (SagEnvelope.h)
    Svf                svfPresence, svfDepth, svfMid; // min-phase HF/LF shelves + a static per-voicing MID bell (one instance = all channels)
    Svf                svfLoadRes, svfLoadRise;       // virtual load: LF impedance-resonance Bell + HF inductive-rise shelf (input pre-EQ)
    std::vector<float> sScratch;                     // per-sample rail s = 1−droop (maxBlock)
    Voicing            voicing;                      // the product-supplied per-tube sag/NFB/load/OT constants (copied in setParams)

    // Targets from the latest setParams(); smoothed per block in process().
    float gTarget = 1.0f, outTarget = 1.0f, topoTarget = 0.0f;   // topo: 0 = PP, 1 = SE
    float kTarget = 2.0f, vbTarget = 0.30f, bSeTarget = 0.18f, leakTarget = 0.0f;
    float sagTarget = 0.0f, presTarget = 0.0f, depthTarget = 0.0f, loadTarget = 0.0f, ironTarget = 0.0f, biasTarget = 0.0f;
    float autoComp = 1.0f;

    // Smoothed running coefficients.
    float gCur = 1.0f, outCur = 1.0f, topoCur = 0.0f;
    float kCur = 2.0f, vbCur = 0.30f, bSeCur = 0.18f, leakCur = 0.0f;
    float sagCur = 0.0f, presCur = 0.0f, depthCur = 0.0f, loadCur = 0.0f, ironCur = 0.0f, biasCur = 0.0f;
    float otLp[kMaxCh] = {}, otHf[kMaxCh] = {};   // output-transformer OS-domain 1-pole states (LF split + HF rolloff)
    float comp = 1.0f;
    float gApplied = 1.0f, postApplied = 1.0f;       // per-sample ramp anchors
    bool  primed = false;
    int   ranNc  = 0;                                // channels that advanced state on the previous call
    bool  ranPres_ = false, ranDepth_ = false, ranMid_ = false;   // and which of this stage's own gates
    bool  ranLoad_ = false, ranIron_  = false, ranSag_ = false;   // were open on the previous CHUNK

    void prepare (double sr, int mb, int osFactor, int tapsPerPhase, felitronics::oversampling::Topology topology)
    {
        using felitronics::oversampling::Topology;
        using felitronics::oversampling::CascadeOversampler;
        sampleRate = sr;
        maxBlock   = std::max (1, mb);
        os         = std::clamp (osFactor, 2, 32);
        if (topology == Topology::Cascade) os = (int) std::bit_floor ((unsigned) os);
        // Clamped rather than refused, because prepare() returns void here and always has: a rejected
        // taps count would leave the stage unprepared with no way to say so, which is the worse failure.
        tpp        = std::clamp (tapsPerPhase, kMinTpp,
                                 felitronics::oversampling::PolyphaseOversampler::kMaxTapsPerPhase);
        const double designRate = (std::isfinite (sr) && sr > 0.0)
                                ? std::clamp (sr, CascadeOversampler::kMinSampleRate, CascadeOversampler::kMaxSampleRate)
                                : CascadeOversampler::kEdgeRate;
        (void) ovs.prepare (topology, designRate, os, kMaxCh, tpp);   // cannot refuse: every argument is clamped
        for (int ch = 0; ch < kMaxCh; ++ch)
        {
            osBuf[ch].assign ((std::size_t) (maxBlock * os), 0.0f);
            osPtr[ch] = osBuf[ch].data();
        }
        const double fsOs = sr * (double) os;
        dcR = fsOs > 0.0 ? std::exp (-kTwoPi * (double) kDcBlockHz / fsOs) : 0.0;
        sag.prepare (sr);
        svfPresence.prepare (sr, kMaxCh);
        svfDepth.prepare (sr, kMaxCh);
        svfMid.prepare (sr, kMaxCh);
        svfLoadRes.prepare (sr, kMaxCh);
        svfLoadRise.prepare (sr, kMaxCh);
        sScratch.assign ((std::size_t) maxBlock, 1.0f);
        reset();
        primed = false;
    }

    void reset()
    {
        ovs.reset();
        for (int ch = 0; ch < kMaxCh; ++ch) { dcx1[ch] = dcy1[ch] = 0.0; }
        sag.reset();
        svfPresence.reset();
        svfDepth.reset();
        svfMid.reset();
        svfLoadRes.reset();
        svfLoadRise.reset();
        for (int c = 0; c < kMaxCh; ++c) { otLp[c] = 0.0f; otHf[c] = 0.0f; }
        ranNc = 0;   // nothing has run, so nothing can be stopping (see dropStoppedChannels)
        ranPres_ = ranDepth_ = ranMid_ = ranLoad_ = ranIron_ = ranSag_ = false;
    }

    // The same rule as the channel drop, applied to this stage's OWN gates. A knob glided to zero stops a
    // real recursion at a CONSTANT channel count, and the stage picks it up again when the knob comes
    // back — measured out of EXACT digital silence, after knob->0, four seconds of silence, knob->0.8:
    // load 1.67e-2 (-35.5 dBFS), iron 9.73e-3 (-40.2 dBFS), presence 5.70e-3 (-44.9 dBFS), depth 1.04e-3.
    // This lives in processChunk and not in process() because the gates are computed PER CHUNK from
    // glided values, so the predicate can cross inside a single oversized call. Every column is cleared,
    // not just the live ones: the gate is global, and a column outside nCh was cleared already.
    // `sag` is one shared supply, so it is cleared whole — it is the only cell here that is not per channel.
    void dropStoppedGates (bool presOn, bool depthOn, bool midOn, bool loadOn, bool ironOn, bool sagOn) noexcept
    {
        if (ranPres_  && ! presOn)  for (int c = 0; c < kMaxCh; ++c) svfPresence.resetChannel (c);
        if (ranDepth_ && ! depthOn) for (int c = 0; c < kMaxCh; ++c) svfDepth.resetChannel (c);
        if (ranMid_   && ! midOn)   for (int c = 0; c < kMaxCh; ++c) svfMid.resetChannel (c);
        if (ranLoad_  && ! loadOn)  for (int c = 0; c < kMaxCh; ++c) { svfLoadRes.resetChannel (c); svfLoadRise.resetChannel (c); }
        if (ranIron_  && ! ironOn)  for (int c = 0; c < kMaxCh; ++c) { otLp[c] = 0.0f; otHf[c] = 0.0f; }
        if (ranSag_   && ! sagOn)   sag.reset();
        ranPres_ = presOn; ranDepth_ = depthOn; ranMid_ = midOn;
        ranLoad_ = loadOn; ranIron_ = ironOn;  ranSag_  = sagOn;
    }

    // Clear the sample memory of every channel that ran on the previous accepted call and does not run on
    // this one. A channel that leaves and RETURNS re-enters with its oversampler FIR, its DC blocker, its
    // output-transformer poles and its five SVF columns frozen rather than decayed, and plays them into
    // whatever comes back — measured 0.649 (-3.8 dBFS) out of DIGITAL SILENCE after stereo -> mono ->
    // stereo. Per channel, never wholesale: the channel that stayed owes nothing to the one that left.
    // `sag` is deliberately untouched — it is ONE supply shared by both channels, so it is supposed to
    // follow whichever channels are actually there, exactly like a linked detector.
    void dropStoppedChannels (int nCh) noexcept
    {
        for (int c = nCh; c < ranNc; ++c)
        {
            ovs.resetChannel (c);
            dcx1[c] = dcy1[c] = 0.0;
            otLp[c] = otHf[c] = 0.0f;
            svfPresence.resetChannel (c); svfDepth.resetChannel (c); svfMid.resetChannel (c);
            svfLoadRes.resetChannel (c);  svfLoadRise.resetChannel (c);
        }
        ranNc = nCh;
    }

    void setParams (const Params& p, const Voicing& v)
    {
        voicing = v;   // plain-float copy — RT-safe; the per-block reads below use this snapshot
        // Sanitize the dB params at the single entry point: a non-finite driveDb/outputDb (a bad preset,
        // or any non-parameter-system caller — Params is a public POD) would make gCur/postTarget NaN, and
        // std::clamp(NaN) passes NaN straight through into the OS/DC state → permanent poison.
        const float driveDb  = std::isfinite (p.driveDb)  ? p.driveDb  : 0.0f;
        const float outputDb = std::isfinite (p.outputDb) ? p.outputDb : 0.0f;
        autoComp   = std::isfinite (p.autoComp) ? std::clamp (p.autoComp, 0.0f, 1.0f) : 1.0f;
        gTarget    = dbToGain (driveDb) * v.driveScale;
        outTarget  = dbToGain (outputDb);
        topoTarget = p.singleEnded ? 1.0f : 0.0f;
        kTarget    = v.k; vbTarget = v.vbPP; bSeTarget = v.bSE; leakTarget = v.evenLeak;
        // feel amounts — same isfinite+clamp discipline (new IIR/envelope state must not be poisoned).
        sagTarget   = std::isfinite (p.sag)      ? std::clamp (p.sag,      0.0f, 1.0f) : 0.0f;
        presTarget  = std::isfinite (p.presence) ? std::clamp (p.presence, 0.0f, 1.0f) : 0.0f;
        depthTarget = std::isfinite (p.depth)    ? std::clamp (p.depth,    0.0f, 1.0f) : 0.0f;
        loadTarget  = std::isfinite (p.load)     ? std::clamp (p.load,     0.0f, 1.0f) : 0.0f;
        ironTarget  = std::isfinite (p.iron)     ? std::clamp (p.iron,     0.0f, 1.0f) : 0.0f;
        biasTarget  = std::isfinite (p.bias)     ? std::clamp (p.bias,     0.0f, 1.0f) : 0.0f;
    }

    [[nodiscard]] bool process (float* const* io, int numChannels, int numSamples)
    {
        if (numChannels < 0 || numSamples < 0) return false;
        if (maxBlock <= 0) return false;                     // process() before prepare(): nothing to run on
        if (numChannels > kMaxCh) return false;              // width is a LIMIT — law 11(b)
        if (numSamples == 0) return true;                    // no samples: no time, no edge
        const int nCh = numChannels;
        dropStoppedChannels (nCh);                           // law 11(d): the edge is clocked by numSamples

        // LAW 11c — A PAUSE IS SILENCE, and this stage is the SEVENTH address of that law rather than
        // one of the five it was written for. Its shared state is not a detector: it is `sag`, ONE
        // supply the header above deliberately keeps out of the per-channel drop because it "follows
        // whichever channels are actually there, exactly like a linked detector" — plus thirteen
        // block-rate parameter glides and the gate edges they drive. All of it stopped dead on a gap.
        // Nothing new runs it: the same `processChunk` runs, at width zero, which is exactly what a
        // silent block of the same length would do. Every per-channel loop inside it is
        // `for (ch = 0; ch < nCh; ...)` and both oversampler ends clamp to `min(channels, channels_)`,
        // so no plane is read and `io` is never dereferenced — while the sag demand, a `max` over zero
        // channels seeded at 0.0f, is the +0.0f silence really would produce. Writing a second copy of
        // the glide block here instead would have been the one thing this repository keeps paying for:
        // a second implementation of arithmetic that has to agree for ever.
        // NB the width-zero call skips `if (nCh == 0) return true;` and goes through the SAME chunk loop
        // below, so the glide cadence — one step per chunk of at most maxBlock — is the cadence silence
        // has, not one step for the whole gap.

        // Chunk to maxBlock so a caller passing numSamples > maxBlock is FULLY processed instead of
        // silently leaving the tail dry. State carries across chunks via the members → seamless.
        float* sub[kMaxCh];
        for (int off = 0; off < numSamples; )
        {
            const int n = std::min (numSamples - off, maxBlock);
            for (int ch = 0; ch < nCh; ++ch) sub[ch] = io[ch] + off;
            processChunk (sub, nCh, n);
            off += n;                                        // `off += maxBlock` could step past INT_MAX
        }
        return true;
    }

    // Law 8 for the block-rate coefficient smoothers below. `cur += a*(target-cur)` is asymptotic, so it
    // never arrives: the residual has a fixed-point band at k*ulp(target), k <= 0.5/a (~5 at block 128 /
    // 48 kHz, where a = 0.101), and simply parks there. Two conditions, as in core::Smoother — a threshold
    // for target 0, and "the update did not move the value" for every other target, which cannot fire
    // early because in the normal range the mantissa makes k*a >> 0.5.
    //
    // Most of these are consumed by a per-BLOCK gate (`presOn`, `depthOn`, `loadOn`, `biasOn`, `ironOn`,
    // all `> 1e-4f`) which reads a stuck subnormal as "off" — the right answer, reached by accident. But
    // `topoCur` is NOT gated: TubeStage blends `(1-topo)*pp + topo*se` on every OVERSAMPLED sample, so
    // after one SE->PP toggle a stuck topo costs two subnormal ops x the oversample factor, per sample,
    // per channel, forever. `leakCur` reaches the per-sample curves the same way. So this is not the
    // 13-FMAs-per-block housekeeping it looks like. Snapping also restores a real property: topo lands on
    // EXACT 0, so the "all-off => bare push-pull path, byte-identical" contract holds after a toggle and
    // not only from a cold start.
    static void glide (float& cur, float target, float a) noexcept
    {
        const float d  = a * (target - cur);
        const float nx = cur + d;
        cur = (std::fabs (d) < 1e-30f || core::exactlyEqual (nx, cur)) ? target : nx;
    }

    void processChunk (float* const* io, int nCh, int n)
    {
        if (n <= 0) return;   // guards the 1.0f/n ramps below: a 0-length chunk is a div-by-zero

        // --- per-block coefficient smoothing (~25 ms one-pole at block rate; first block snaps) ---
        const float a = (! primed) ? 1.0f
                      : (sampleRate > 0.0 ? (float) (1.0 - std::exp (- (double) n / (0.025 * sampleRate))) : 1.0f);
        glide (gCur,    gTarget,    a);
        glide (outCur,   outTarget,   a);
        glide (topoCur,  topoTarget,  a);
        glide (kCur,     kTarget,     a);
        glide (vbCur,    vbTarget,    a);
        glide (bSeCur,   bSeTarget,   a);
        glide (leakCur,  leakTarget,  a);
        glide (sagCur,   sagTarget,   a);
        glide (loadCur,  loadTarget,  a);
        glide (ironCur,  ironTarget,  a);
        glide (biasCur,  biasTarget,  a);
        glide (presCur,  presTarget,  a);
        glide (depthCur, depthTarget, a);

        const Voicing& v = voicing;

        // --- "feel" per-block setup + the FEEL GATE (all-off ⇒ the bare waveshaper path, byte-identical) ---
        const bool sagOn = sagCur > 1.0e-6f;
        sag.setParams (sagCur, v.sagFastMs, v.sagRecoveryMs, v.sagMaxDroop);

        // PRESENCE/DEPTH: the Svf shelves hold their FULLY-OPEN gain (set per block from the settled
        // knob → block-size-independent); the dynamic "NFB opens when pushed" is the PER-SAMPLE dry/wet
        // blend in the post-downsample loop, driven by the per-sample sag droop. Opening per-sample (not
        // per-block off a block-boundary droop sample) is exactly what keeps the output identical across
        // host buffer sizes. presBase/depthBase place the quiet state at the nominal knob gain.
        const float presNomDb  = presCur  * v.presenceMaxDb;
        const float depthNomDb = depthCur * v.depthMaxDb;
        const float presMaxDb  = presNomDb  * (1.0f + v.nfbOpen);
        const float depthMaxDb = depthNomDb * (1.0f + v.nfbOpen);
        const bool  presOn  = presCur  > 1.0e-4f;
        const bool  depthOn = depthCur > 1.0e-4f;
        const float presBase  = blendForNominal (presNomDb,  presMaxDb);
        const float depthBase = blendForNominal (depthNomDb, depthMaxDb);
        if (presOn)  svfPresence.setParams (felitronics::eq::FilterType::HighShelf, (double) v.presenceHz, 0.70710678, (double) presMaxDb);
        if (depthOn) svfDepth.setParams   (felitronics::eq::FilterType::LowShelf,  (double) v.depthHz,    0.70710678, (double) depthMaxDb);

        // static per-voicing MID bell — the amp fingerprint (always on when the tube runs; not knob-gated)
        const bool midOn = std::fabs (v.midDb) > 1.0e-3f;
        if (midOn) svfMid.setParams (felitronics::eq::FilterType::Bell, (double) v.midHz, (double) v.midQ, (double) v.midDb);

        stage.configure (kCur, bSeCur, vbCur, leakCur, topoCur);

        // drive-compensation: numeric small-signal slope of the FULL composite (incl. pre-gain gCur)
        const float sl = stage.slopeAtZero (gCur);
        comp = std::pow (std::max (1.0e-6f, std::fabs (sl)), -autoComp);

        const float postTarget = comp * outCur;
        if (! primed) { gApplied = gCur; postApplied = postTarget; primed = true; }

        // --- VIRTUAL LOAD: reactive-speaker impedance pre-EQ on the RAW input, so the Drive
        // pre-gain + sag DETECTOR below both see the load-coloured signal (frequency-dependent break-up,
        // and sag pulled correctly by the resonance-boosted lows). Min-phase (felitronics Svf), 0 latency;
        // both gains 0 dB ⇒ skipped ⇒ byte-identical to the load-free chain. Static per-voicing (the amp's own load). ---
        const float loadResDb  = loadCur * v.loadResDb;    // the Load knob scales the per-voicing impedance shape
        const float loadRiseDb = loadCur * v.loadRiseDb;
        const bool  loadOn = loadCur > 1.0e-4f && (std::fabs (v.loadResDb) > 1.0e-3f || std::fabs (v.loadRiseDb) > 1.0e-3f);
        if (loadOn)
        {
            svfLoadRes .setParams (felitronics::eq::FilterType::Bell,      (double) v.loadResHz,  (double) v.loadResQ, (double) loadResDb);
            svfLoadRise.setParams (felitronics::eq::FilterType::HighShelf, (double) v.loadRiseHz, 0.70710678,          (double) loadRiseDb);
            for (int i = 0; i < n; ++i)
                for (int ch = 0; ch < nCh; ++ch)
                    io[ch][i] = svfLoadRise.processSample (ch, svfLoadRes.processSample (ch, io[ch][i]));
        }

        // --- input Drive pre-gain ramp (+ SAG rail-shrink 1/s when active) ---
        {
            const float g0 = gApplied, g1 = gCur, inv = 1.0f / (float) n;
            for (int i = 0; i < n; ++i)
            {
                const float g = g0 + (g1 - g0) * ((float) (i + 1) * inv);
                if (sagOn)
                {
                    // mono-linked demand (shared supply) → droop → rail s; push u/s into the shaper.
                    float w[kMaxCh], demand = 0.0f;
                    for (int ch = 0; ch < nCh; ++ch)
                    {
                        const float vch = io[ch][i];
                        w[ch] = (std::isfinite (vch) ? vch : 0.0f) * g;
                        // cap the demand: an extreme FINITE input (|vch|·g > FLT_MAX → +Inf) must not
                        // push the sag envelope to Inf→NaN (which flushDenormals wouldn't clear → stuck rail).
                        demand = std::max (demand, std::min (std::fabs (w[ch]), 1.0e6f));
                    }
                    const float s = std::max (kSagMinRail, 1.0f - sag.process (demand));
                    sScratch[(std::size_t) i] = s;
                    const float invS = 1.0f / s;
                    for (int ch = 0; ch < nCh; ++ch) io[ch][i] = std::clamp (w[ch] * invS, -1.0e6f, 1.0e6f);
                }
                else
                {
                    for (int ch = 0; ch < nCh; ++ch)
                    {
                        const float vch = io[ch][i];                              // sanitize AT THE GATE: a NaN/Inf would
                        const float s2  = (std::isfinite (vch) ? vch : 0.0f) * g;  // poison the OS/DC state; clamp also
                        io[ch][i] = std::clamp (s2, -1.0e6f, 1.0e6f);              // catches huge·gain → +Inf overflow
                    }
                }
            }
            gApplied = g1;
        }

        // --- OUTPUT TRANSFORMER + dynamic BIAS — both act in the OS domain ---
        const double fsOs   = sampleRate * (double) os;
        const bool   ironOn = ironCur > 1.0e-4f && v.otHfHz > 0.0f;
        const float  gLf    = ironOn ? (float) (1.0 - std::exp (-kTwoPi * (double) v.otLfHz / fsOs)) : 0.0f;   // LF split 1-pole
        const float  gHf    = ironOn ? (float) (1.0 - std::exp (-kTwoPi * (double) v.otHfHz / fsOs)) : 0.0f;   // HF leakage 1-pole
        const float  kSat   = std::max (0.1f, v.otSatK);
        const float  otWet  = ironCur;                          // Iron knob scales the LF-sat blend + the HF-rolloff blend
        // dynamic bias: the PP operating point drifts toward class-B under sag (crossover bloom); needs Sag + Bias.
        const bool   biasOn = biasCur > 1.0e-4f && sagOn && v.sagBiasDepth > 0.0f;
        const float  invMaxDroopB = v.sagMaxDroop > 0.0f ? 1.0f / v.sagMaxDroop : 0.0f;
        const float  biasScale    = biasCur * v.sagBiasDepth * vbCur;   // vbEff = vbCur − biasScale·droopN

        dropStoppedGates (presOn, depthOn, midOn, loadOn, ironOn, sagOn);

        // --- upsample → PP/SE waveshape (+ per-sample bias) + DC-block + output transformer (OS domain) → downsample ---
        ovs.upsample (io, nCh, n, osPtr);
        for (int ch = 0; ch < nCh; ++ch)
        {
            float* b = osPtr[ch];
            double x1 = dcx1[ch], y1 = dcy1[ch];
            float  lp = otLp[ch], hf = otHf[ch];
            const int m = n * os;
            for (int j = 0; j < m; ++j)
            {
                float w;
                if (biasOn)   // per-sample class-B drift, ZOH from the host-rate droop (block-size-deterministic)
                {
                    const float droopN = std::clamp ((1.0f - sScratch[(std::size_t) (j / os)]) * invMaxDroopB, 0.0f, 1.0f);
                    w = stage.at (b[j], -biasScale * droopN);
                }
                else
                    w = stage.at (b[j]);
                const double dc = (double) w - x1 + dcR * y1;       // OS-domain DC-block
                x1 = (double) w; y1 = dc;
                float s = (float) dc;
                if (ironOn)                                          // OUTPUT TRANSFORMER
                {
                    lp += gLf * (s - lp);                            //   low band (transformer flux)
                    const float sat = std::tanh (kSat * lp) / kSat;  //   soft-clip the lows (unity small-signal)
                    s += otWet * (sat - lp);                         //   grind / compress the low notes
                    hf += gHf * (s - hf);                            //   HF leakage low-pass
                    s += otWet * (hf - s);                           //   roll off the fizzy top
                }
                b[j] = s;
            }
            // flush non-finite / denormal state so a transient can't poison or CPU-spike the stream
            dcx1[ch] = (std::isfinite (x1) && std::fabs (x1) > 1e-30) ? x1 : 0.0;
            dcy1[ch] = (std::isfinite (y1) && std::fabs (y1) > 1e-30) ? y1 : 0.0;
            otLp[ch] = (std::isfinite (lp) && std::fabs (lp) > 1e-30f) ? lp : 0.0f;
            otHf[ch] = (std::isfinite (hf) && std::fabs (hf) > 1e-30f) ? hf : 0.0f;
        }
        ovs.downsample (osPtr, nCh, n, io);

        // static per-voicing MID band (voicing tone — always on when the tube runs; not sag/knob-gated)
        if (midOn)
            for (int i = 0; i < n; ++i)
                for (int ch = 0; ch < nCh; ++ch)
                    io[ch][i] = svfMid.processSample (ch, io[ch][i]);

        // --- SAG rail output (·s) + PRESENCE/DEPTH shelves (the NFB "output node") ---
        // Skipped entirely when the feel layer is off → the output equals the bare-waveshaper result exactly.
        if (sagOn || presOn || depthOn)
        {
            const float invMaxDroop = v.sagMaxDroop > 0.0f ? 1.0f / v.sagMaxDroop : 0.0f;
            for (int i = 0; i < n; ++i)
            {
                // per-sample droop → per-sample shelf "open" blend (block-size-independent). droopN ∈ [0,1]
                // maps quiet→open; the Svf state still advances every sample so its memory stays coherent.
                const float droopN     = sagOn ? std::clamp ((1.0f - sScratch[(std::size_t) i]) * invMaxDroop, 0.0f, 1.0f) : 0.0f;
                const float presBlend  = presBase  + (1.0f - presBase)  * droopN;
                const float depthBlend = depthBase + (1.0f - depthBase) * droopN;
                for (int ch = 0; ch < nCh; ++ch)
                {
                    float x = io[ch][i];
                    if (sagOn) x *= sScratch[(std::size_t) i];                                     // rail-shrink output ·s
                    if (presOn)  { const float sh = svfPresence.processSample (ch, x); x += presBlend  * (sh - x); }
                    if (depthOn) { const float sh = svfDepth.processSample   (ch, x); x += depthBlend * (sh - x); }
                    io[ch][i] = x;
                }
            }
        }

        // --- drive-comp + Output gain (per-sample ramp) ---
        {
            const float p0 = postApplied, p1 = postTarget, inv = 1.0f / (float) n;
            for (int i = 0; i < n; ++i)
            {
                const float g = p0 + (p1 - p0) * ((float) (i + 1) * inv);
                for (int ch = 0; ch < nCh; ++ch) io[ch][i] = std::clamp (io[ch][i] * g, -1.0e6f, 1.0e6f);
            }
            postApplied = p1;
        }

        sag.flushDenormals();
        svfPresence.flushDenormals();
        svfDepth.flushDenormals();
        svfMid.flushDenormals();
        svfLoadRes.flushDenormals();
        svfLoadRise.flushDenormals();
    }

    int latencySamples() const noexcept { return ovs.latencySamples(); }
};

inline PowerAmpStage::PowerAmpStage() : impl (std::make_unique<Impl>()) {}
inline PowerAmpStage::~PowerAmpStage() = default;

inline void PowerAmpStage::prepare (double sampleRate, int maxBlock, int oversampleFactor, int tapsPerPhase,
                                    oversampling::Topology topology) { impl->prepare (sampleRate, maxBlock, oversampleFactor, tapsPerPhase, topology); }
inline void PowerAmpStage::reset() { impl->reset(); }
inline void PowerAmpStage::setParams (const Params& params, const Voicing& voicing) noexcept { impl->setParams (params, voicing); }
inline bool PowerAmpStage::process (float* const* io, int numChannels, int numSamples) noexcept { return impl->process (io, numChannels, numSamples); }
inline int  PowerAmpStage::latencySamples() const noexcept { return impl->latencySamples(); }
inline float PowerAmpStage::sagDroop() const noexcept { return impl->sag.droop(); }

} // namespace felitronics::poweramp
