// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Darwin's Cat — Oleh Tsymaienko & Alisa Lafoks. Part of felitronics-core — see LICENSE.
//
// MANIACAL adversarial golden for felitronics::poweramp::PowerAmpStage — an oversampled PP/SE
// tube waveshaper + sag/NFB/load/transformer "feel". Ported VERBATIM from OrbitCab's
// tests/PowerAmpCoreGolden.cpp (the CI gate that pins this DSP's numeric fingerprint): same
// battery, same thresholds, same schedules. The ONLY adaptation is the product seam — OrbitCab's
// kTubeVoicings preset table + TubeParams POD + index→voicing lookup stayed in the product, so
// they are reproduced below as a test fixture (identical constants) wrapped in a thin shim that
// re-creates the original TubePowerAmp(params) surface over the lifted core stage.
//
// Tests are written for the IDEA/physics and try to BREAK the code, not pass it. JUCE-free: pure
// kernel via TubeStage.h, full stage via PowerAmpStage, aliasing via a 32x null reference (the OS
// factor is a prepare() arg). A failure means a real limit (documented/fixed) or a bug —
// thresholds are derived from the method, never tuned to go green. CI gate.
//
// Battery:
//   K1 PP exact odd-symmetry (even harmonics cancel by construction)   — all tubes, exact
//   K2 SE asymmetry present (not accidentally PP)
//   K3 kernel bounded + finite for extreme inputs
//   S1 latency MEASURED by impulse == tapsPerPhase-1 (63 at the default; 31 at the lifted explicit 32)
//   S2 latency reported == tapsPerPhase-1, invariant across drive/tube/topology/OS factor, pinned BOTH ways
//   S3 block-size determinism (bit-exact vs hostile schedule)
//   S4 THD monotonic in Drive (all tubes)
//   S5 PP even harmonics < -90 dBc full-chain; SE H2 present and >> PP
//   S6 drive-comp ⇒ small-signal gain unity within 0.05 dB (honest A/B)
//   S7 near-identity at Drive=min, latency-aligned
//   A  aliasing: reference-free non-harmonic-energy MAP (freq × drive); guitar range gated < -80 dBc,
//      HF + hot drive documented as the 8x / hard-class-B boundary
//   X11 RT no-alloc: process() performs ZERO heap allocations (the 🔴 rule, asserted)
//   X12 non-finite params (NaN driveDb / Inf outputDb) ⇒ finite output, no poison
//   X1 boundedness/finite for hostile inputs (silence/DC/full-scale/square/impulse/step/noise)
//   X2 NaN/Inf input: the stream RECOVERS to finite output on the next valid block
//   X3 denormal recovery after long silence
//   X4 stereo isolation (silent channel stays silent) + L==R symmetry
//   X5 parameter-change zipper bounded (Drive jump / tube switch / PP↔SE)
//   X6 DC offset shifts the PP operating point ⇒ even harmonics appear (documented physics)
//   B1-B9 sag / presence / depth / virtual load / output transformer / dynamic bias

#include <felitronics_test.h>   // felitronics::test::run — law 11 verdicts
#include <alloc_counter.h>   // installs the allocation counter: EVERY form of `new`, over-aligned included
#include <felitronics/poweramp/PowerAmpStage.h>
#include <felitronics/poweramp/SagEnvelope.h>
#include <felitronics/poweramp/TubeStage.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <atomic>
#include <cstdlib>
#include <limits>
#include <string>
#include <vector>

using felitronics::poweramp::PowerAmpStage;
using felitronics::poweramp::SagEnvelope;
using felitronics::poweramp::TubeStage;
using felitronics::poweramp::Voicing;

namespace
{
//==============================================================================
// PRODUCT-SEAM FIXTURE — OrbitCab's voicing presets + param POD + lookup, reproduced with the SAME
// constants so the goldens port verbatim (the table itself is product data and stays in OrbitCab;
// the two by-ear levelTrim columns are router-side calibration the stage never reads, so they are
// not part of the core Voicing and are omitted here).
//
// Brand-neutral voicing presets {0=6L6, 1=EL34, 2=EL84, 3=KT88}: the MID bell is the fingerprint —
// 6L6 American scoop, EL34 British mid-push, EL84 Vox upper-mid chime, KT88 near-flat hi-fi.
// 6L6/KT88 stiff sag (SS-rectified), EL84/EL34 spongier. evenLeak = 0 (exact PP cancellation held).
constexpr Voicing kTubeVoicings[4] = {
    /* 6L6  American: scooped mids, deep tight lows, smooth (not sharp) top */
    { 0.82f, 2.3f, 0.25f, 0.30f, 0.0f,   8.0f, 130.0f, 0.20f, 0.40f,   5000.0f, 3.0f,  95.0f, 7.5f, 0.45f,    500.0f, -5.0f, 0.70f,    90.0f, 1.6f, 4.0f,  1600.0f, 3.0f,   150.0f, 1.8f, 8000.0f },
    /* EL34 British: forward mids, aggressive upper-mid crunch */
    { 1.12f, 3.2f, 0.15f, 0.20f, 0.0f,   6.0f,  90.0f, 0.22f, 0.50f,   3400.0f, 5.0f, 118.0f, 4.0f, 0.60f,    680.0f,  4.5f, 0.70f,   100.0f, 1.8f, 3.5f,  1500.0f, 4.0f,   170.0f, 2.2f, 7000.0f },
    /* EL84 Vox chime: bright upper-mid, early soft breakup, heavy spongy sag */
    { 1.45f, 1.7f, 0.45f, 0.18f, 0.0f,  14.0f, 240.0f, 0.42f, 0.70f,   5500.0f, 4.0f, 130.0f, 3.0f, 0.75f,   1600.0f,  4.0f, 0.70f,   110.0f, 2.0f, 4.0f,  1800.0f, 4.5f,   210.0f, 2.6f, 8500.0f },
    /* KT88 hi-fi: huge tight lows + a low resonance "thump", near-flat mids, clean late breakup, stiff supply.
       The "mid" bell is repurposed LOW (100 Hz, resonant Q) — KT88's mids are near-flat, so it buys the
       Hiwatt/Ampeg low-end resonance the ear wants; the depth low-shelf below it adds broad extension. */
    { 0.60f, 3.8f, 0.05f, 0.34f, 0.0f,   4.0f,  80.0f, 0.12f, 0.30f,   4800.0f, 4.0f,  68.0f, 10.0f, 0.30f,    100.0f,  5.0f, 1.40f,    80.0f, 1.4f, 4.0f,  1300.0f, 2.5f,   120.0f, 1.4f, 10000.0f },
};

// The product-side control POD (OrbitCab's cab::TubeParams, minus the router-only osIndex).
struct TubeParams
{
    float driveDb     = 0.0f;
    float outputDb    = 0.0f;
    int   tubeType    = 0;       // 0=6L6, 1=EL34, 2=EL84, 3=KT88 (index into kTubeVoicings)
    bool  singleEnded = false;
    float autoComp    = 1.0f;
    float sag         = 0.0f;
    float presence    = 0.0f;
    float depth       = 0.0f;
    float load        = 0.0f;
    float iron        = 0.0f;
    float bias        = 0.0f;
};

// The original TubePowerAmp(params) surface, re-created over the lifted core stage: the product
// clamps the tube index, looks the voicing up and hands BOTH PODs to the core — exactly the seam.
class TubePowerAmp
{
public:
    // tapsPerPhase forwarded (not swallowed) so a check can pin an EXPLICIT topology against the
    // stage's default — the default is the thing under test, so a fixture that can only reach it
    // cannot tell "the default is 64" from "some number is 64".
    void prepare (double sampleRate, int maxBlock, int oversampleFactor = 4,
                  int tapsPerPhase = felitronics::oversampling::PolyphaseOversampler::kDefaultTapsPerPhase)
    { d.prepare (sampleRate, maxBlock, oversampleFactor, tapsPerPhase); }
    void reset() { d.reset(); }
    void setParams (const TubeParams& t) noexcept
    {
        felitronics::poweramp::Params p;
        p.driveDb = t.driveDb; p.outputDb = t.outputDb; p.singleEnded = t.singleEnded; p.autoComp = t.autoComp;
        p.sag = t.sag; p.presence = t.presence; p.depth = t.depth; p.load = t.load; p.iron = t.iron; p.bias = t.bias;
        d.setParams (p, kTubeVoicings[(std::size_t) std::clamp (t.tubeType, 0, 3)]);
    }
    // Returns the stage's law-11 verdict rather than swallowing it: X8 below drives this seam on an
    // UNPREPARED stage on purpose and now asserts the refusal, instead of only asserting the silence.
    [[nodiscard]] bool process (float* const* io, int numChannels, int numSamples) noexcept { return d.process (io, numChannels, numSamples); }
    int  latencySamples() const noexcept { return d.latencySamples(); }

private:
    PowerAmpStage d;
};
//==============================================================================

int g_checks = 0, g_fail = 0;
void check (bool ok, const char* m) { ++g_checks; if (! ok) { ++g_fail; std::printf ("  [FAIL] %s\n", m); } else std::printf ("  [ok]   %s\n", m); }
void info  (const char* m) { std::printf ("       %s\n", m); }

constexpr double kPi     = 3.14159265358979323846;
constexpr double kSr     = 48000.0;
constexpr int    kMaxBlk = 512;
// The oversampler round-trip, READ from a prepared stage rather than pinned as a literal. It was 31
// while the stage hardcoded 32 taps/phase; the stage now takes the core's default (64 -> 63) and lets a
// caller pass its own, so a literal here would pin the wrong topology the moment either moves — and
// every analysis window in this file is offset by it. The VALUE is asserted separately, two-sidedly,
// against both the default and an explicit 32, so this staying in step is not the same as it being
// unchecked.
const int kLat = [] { TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4); return d.latencySamples(); }();

float dbToGain (float db) { return std::pow (10.0f, db * 0.05f); }
double dbc (double num, double den) { return 20.0 * std::log10 (std::max (1e-15, num) / std::max (1e-15, den)); }

TubeParams P (float driveDb, bool se, int tube = 0, float outDb = 0.0f)
{ TubeParams t; t.driveDb = driveDb; t.outputDb = outDb; t.singleEnded = se; t.tubeType = tube; t.autoComp = 1.0f; return t; }

// Feel params on top of P().
TubeParams Pf (float driveDb, bool se, int tube, float sag, float pres, float depth, float outDb = 0.0f)
{ TubeParams t = P (driveDb, se, tube, outDb); t.sag = sag; t.presence = pres; t.depth = depth; return t; }

// Configure a pure TubeStage from a voicing preset (evenLeak=0), at a given Drive (dB) and topology.
TubeStage makeStage (int tube, bool se, float driveDb)
{
    (void) driveDb;   // the drive pre-gain G is the caller's (stageDriveG) — not baked into the kernel
    const auto& v = kTubeVoicings[tube];
    TubeStage s; s.configure (v.k, v.bSE, v.vbPP, v.evenLeak, se ? 1.0f : 0.0f); return s;
}
float stageDriveG (int tube, float driveDb) { return dbToGain (driveDb) * kTubeVoicings[tube].driveScale; }

std::vector<float> sine (int warm, int N, int tail, int cycles, double amp, double dc = 0.0)
{
    std::vector<float> x ((std::size_t) (warm + N + tail), 0.0f);
    const double w = 2.0 * kPi * cycles / N;
    for (int n = 0; n < (int) x.size(); ++n) x[(std::size_t) n] = (float) (amp * std::sin (w * (n - warm)) + dc);
    return x;
}

double magBin (const std::vector<float>& x, int start, int N, int bin)
{
    double re = 0.0, im = 0.0; const double w = 2.0 * kPi * bin / N;
    for (int n = 0; n < N; ++n) { const double s = x[(std::size_t) (start + n)]; re += s * std::cos (w * n); im -= s * std::sin (w * n); }
    return std::sqrt (re * re + im * im) / N;
}
double rms (const std::vector<float>& x, int start, int N) { double e = 0.0; for (int n = 0; n < N; ++n) { const double s = x[(std::size_t) (start + n)]; e += s * s; } return std::sqrt (e / std::max (1, N)); }

void dftBin (const std::vector<float>& x, int start, int N, int bin, double& re, double& im)
{
    re = 0; im = 0; const double w = 2.0 * kPi * bin / N;
    for (int n = 0; n < N; ++n) { const double s = x[(std::size_t) (start + n)]; re += s * std::cos (w * n); im -= s * std::sin (w * n); }
}
// Run a mono buffer through a fresh TubePowerAmp at OS factor `os`, with an optional block schedule.
std::vector<float> runStage (const TubeParams& tp, std::vector<float> buf, int os = 4, const std::vector<int>* sched = nullptr,
                             int tpp = felitronics::oversampling::PolyphaseOversampler::kDefaultTapsPerPhase)
{
    TubePowerAmp d; d.prepare (kSr, kMaxBlk, os, tpp);
    static const int dflt[] = { 64, 128, 333, 512, 17, 1 };
    const int total = (int) buf.size();
    int pos = 0, bi = 0;
    while (pos < total)
    {
        int n = sched ? (*sched)[(std::size_t) (bi % (int) sched->size())] : dflt[bi % 6];
        n = std::min (n, total - pos);
        d.setParams (tp);
        float* io[1] { buf.data() + pos };
        felitronics::test::run (d.process (io, 1, n));
        pos += n; ++bi;
    }
    return buf;
}

bool allFinite (const std::vector<float>& x) { for (float s : x) if (! std::isfinite (s)) return false; return true; }
double maxAbs (const std::vector<float>& x, int from, int to) { double m = 0; for (int i = from; i < to; ++i) m = std::max (m, (double) std::fabs (x[(std::size_t) i])); return m; }
}

int main()
{
    std::printf ("felitronics::poweramp PowerAmpStage MANIACAL golden (PP/SE tube waveshaper — ported from OrbitCab)\n");
    const int warm = 4096, N = 16384, tail = 512;
    const int an = warm + kLat;

    // ===================== PURE KERNEL (exact, no OS, no DFT) =====================
    // K1: PP is ODD by construction (g(u+Vb)−g(−u+Vb)) ⇒ even harmonics cancel EXACTLY in float.
    {
        double worst = 0.0;
        for (int t = 0; t < 4; ++t)
            for (float drive : { 0.0f, 12.0f, 24.0f, 36.0f })
            {
                TubeStage s = makeStage (t, /*se*/ false, drive);
                const float G = stageDriveG (t, drive);
                for (double x = -4.0; x <= 4.0; x += 0.013)
                    worst = std::max (worst, (double) std::fabs (s.at ((float) (G * x)) + s.at ((float) (-G * x))));
            }
        std::printf ("       PP max|f(x)+f(-x)| = %.2e\n", worst);
        check (worst < 1e-6, "K1 PP kernel is exactly odd (even harmonics cancel) — all tubes/drives");
    }
    // K2: SE is asymmetric ⇒ f(x)+f(-x) is clearly non-zero (not accidentally PP).
    {
        double biggest = 0.0;
        for (int t = 0; t < 4; ++t)
        {
            TubeStage s = makeStage (t, /*se*/ true, 12.0f);
            const float G = stageDriveG (t, 12.0f);
            for (double x = 0.05; x <= 2.0; x += 0.01) biggest = std::max (biggest, (double) std::fabs (s.at ((float) (G * x)) + s.at ((float) (-G * x))));
        }
        check (biggest > 0.02, "K2 SE kernel is asymmetric (even content present)");
    }
    // K3: kernel stays finite + bounded for absurd inputs (tanh saturates).
    {
        bool ok = true; double peak = 0.0;
        for (int t = 0; t < 4; ++t) for (bool se : { false, true })
        {
            TubeStage s = makeStage (t, se, 36.0f);
            for (double x : { -1e6, -10.0, -1.0, 0.0, 1.0, 10.0, 1e6 }) { const float y = s.at ((float) x); ok = ok && std::isfinite (y); peak = std::max (peak, (double) std::fabs (y)); }
        }
        check (ok && peak < 8.0, "K3 kernel finite + bounded (|y|<8) for inputs up to 1e6");
    }

    // ===================== FULL STAGE: LATENCY / DETERMINISM =====================
    // S1: MEASURE latency from an impulse (small ⇒ linear regime). The linear-phase OS FIR puts the
    // MAIN LOBE (peak) at exactly +kLat; symmetric pre-ringing (sinc sidelobes) is EXPECTED and is NOT a
    // latency error — so we assert the peak index, not a (wrong) "pre-impulse silent".
    {
        bool allGood = true;
        for (int t = 0; t < 4; ++t) for (bool se : { false, true })
        {
            std::vector<float> in (4096, 0.0f); in[1000] = 1e-3f;
            auto out = runStage (P (6.0f, se, t), in);
            int peak = 0; double pv = 0; for (int i = 990; i < 1100; ++i) if (std::fabs (out[(std::size_t) i]) > pv) { pv = std::fabs (out[(std::size_t) i]); peak = i; }
            allGood = allGood && (peak == 1000 + kLat);
        }
        check (allGood, (std::string ("S1 measured impulse latency: main lobe at exactly +")
                         + std::to_string (kLat) + " (all tubes/topologies)").c_str());
    }
    // S2: reported latency invariant across drive/tube/PP-SE topology AND OS factor (4x & 32x both tpp-1, under the
    //     default Kaiser oversampler; the cascade's latency does depend on the factor — TT10).
    {
        bool ok = true;
        for (int os : { 4, 8, 16, 32 }) { TubePowerAmp d; d.prepare (kSr, kMaxBlk, os); ok = ok && (d.latencySamples() == kLat); }
        check (ok, (std::string ("S2 reported latency == ") + std::to_string (kLat)
                    + ", invariant across OS factor (4/8/16/32x)").c_str());
        // TWO-SIDED, and the reason this is not one assertion: the round trip is tapsPerPhase-1, so the
        // check above only proves the stage is CONSISTENT with whatever taps it took. These pin WHICH.
        // A default silently returned to 32 passes everything above and fails here.
        {
            // 🔴 The STAGE, not the adapter. TubePowerAmp's own prepare() defaults tapsPerPhase to the
            // primitive's constant and forwards FOUR arguments, so every call through it pins the
            // PRIMITIVE's default and none of them can see PowerAmpStage's. A stage default quietly
            // changed to 62 would pass every other check in this file. Three arguments, real class.
            PowerAmpStage bare; bare.prepare (kSr, kMaxBlk, 4);
            check (bare.latencySamples() == 63,
                   "S2 PowerAmpStage's OWN default (three-argument prepare) is 64 taps -> 63 samples");
            PowerAmpStage wide; wide.prepare (kSr, kMaxBlk, 4, 96);
            check (wide.latencySamples() == 95,
                   "S2 an explicit 96 is honoured, not clamped away -> 95 samples (the knob has range)");
            TubePowerAmp def; def.prepare (kSr, kMaxBlk, 4);
            TubePowerAmp old; old.prepare (kSr, kMaxBlk, 4, 32);
            check (def.latencySamples() == 63,
                   "S2 the DEFAULT topology is 64 taps/phase -> 63 samples (was 32 -> 31)");
            check (old.latencySamples() == 31,
                   "S2 an explicit 32 still reaches the lifted topology -> 31 samples (the knob works)");
        }
    }
    // S3: block-size determinism — one 512-block vs a hostile {1,7,64,333,512} schedule, bit-exact.
    {
        std::vector<float> in ((std::size_t) (warm + N), 0.0f);
        { unsigned long long s = 1; for (auto& v : in) { s = s * 6364136223846793005ULL + 1; v = 0.5f * ((float) ((s >> 40) & 0xFFFFFF) / 8388608.0f - 1.0f); } }
        std::vector<int> blk512 { 512 }, hostile { 1, 7, 64, 333, 512, 128 };
        auto a = runStage (P (24.0f, false, 1), in, 4, &blk512);
        auto b = runStage (P (24.0f, false, 1), in, 4, &hostile);
        double mx = maxAbs ([&]{ std::vector<float> d (a.size()); for (std::size_t i = 0; i < a.size(); ++i) d[i] = a[i] - b[i]; return d; }(), 0, (int) a.size());
        std::printf ("       block-schedule max diff = %.2e\n", mx);
        check (mx < 1e-6, "S3 output is deterministic across block sizes (max diff < 1e-6)");
    }

    // ===================== FULL STAGE: HARMONIC PHYSICS =====================
    const int binF = (int) std::llround (1000.0 * N / kSr);
    auto thd = [&] (const TubeParams& tp, double amp) -> double
    {
        auto out = runStage (tp, sine (warm, N, tail, binF, amp));
        const double f = magBin (out, an, N, binF); double h = 0; for (int k = 2; k <= 12; ++k) { const double m = magBin (out, an, N, binF * k); h += m * m; } return std::sqrt (h) / std::max (1e-12, f);
    };
    // S4: the NONLINEARITY's THD rises monotonically with Drive — measured on the PURE kernel (TubeStage,
    // bell-free). The always-on voicing MID bell is a FIXED linear EQ that re-weights each harmonic by its
    // own frequency gain, so it can legitimately make the FULL-stage THD non-monotonic in Drive (a tone
    // change, not a distortion change) — hence the monotonic claim belongs on the distortion generator, not
    // the voiced output. The full stage is still checked to SPAN a wide THD range across Drive.
    auto kernelThd = [&] (int t, bool se, float driveDb, double amp) -> double
    {
        // The static curve is memoryless, so sample ONE period densely (M points) → harmonics up to M/2
        // are resolved with NO aliasing (the shipping stage oversamples for exactly this reason; at host
        // rate the tanh's high harmonics would fold back and corrupt a monotonic-THD read).
        TubeStage s = makeStage (t, se, driveDb);
        const float G = stageDriveG (t, driveDb);
        const int M = 8192; std::vector<float> y ((std::size_t) M);
        for (int n = 0; n < M; ++n) y[(std::size_t) n] = s.at ((float) (G * amp * std::sin (2.0 * kPi * n / M)));
        const double f = magBin (y, 0, M, 1); double h = 0; for (int k = 2; k <= 12; ++k) { const double m = magBin (y, 0, M, k); h += m * m; } return std::sqrt (h) / std::max (1e-12, f);
    };
    {
        // Over 12 dB Drive steps the kernel THD rises monotonically for EVERY tube. (At FINER steps the
        // highest-bias class-AB voicing — KT88, vbPP 0.34 — shows a small local THD dip near 6→12 dB: real
        // push-pull CROSSOVER physics as the operating point sweeps the bias knee, and it fully recovers.
        // Asserting on 12 dB steps captures the true "more Drive ⇒ more grit" trend and still catches any
        // genuine reversal; a fudge tolerance would have been the dishonest way to absorb the crossover dip.)
        bool monoAll = true; double span = 0;
        for (int t = 0; t < 4; ++t)
        {
            double prev = -1; bool mono = true;
            for (float dr : { 0.0f, 12.0f, 24.0f, 36.0f }) { const double v = kernelThd (t, false, dr, 0.25); if (prev >= 0 && v < prev - 1e-4) mono = false; prev = v; }
            span = std::max (span, thd (P (36.0f, false, t), 0.25) - thd (P (0.0f, false, t), 0.25));
            monoAll = monoAll && mono;
        }
        check (monoAll, "S4 kernel THD monotonic over 12 dB Drive steps (bell-free nonlinearity, every tube)");
        check (span > 0.3, "S4 full-stage THD spans a wide range across Drive (>30 points)");
    }
    // S5: PP cancels even harmonics to near-floor full-chain; SE has real even content and >> PP.
    {
        bool ppOk = true, seOk = true; double worstPP = -200, bestSE = 200;
        for (int t = 0; t < 4; ++t)
        {
            auto pp = runStage (P (24.0f, false, t), sine (warm, N, tail, binF, 0.5));
            auto se = runStage (P (24.0f, true,  t), sine (warm, N, tail, binF, 0.5));
            const double ppF = magBin (pp, an, N, binF), seF = magBin (se, an, N, binF);
            double ppEven = -300; for (int k : { 2, 4, 6 }) ppEven = std::max (ppEven, dbc (magBin (pp, an, N, binF * k), ppF));
            const double seH2 = dbc (magBin (se, an, N, binF * 2), seF);
            worstPP = std::max (worstPP, ppEven); bestSE = std::min (bestSE, seH2);
            // SE has REAL second-harmonic content; PP cancels it. The absolute floor is the GATE, set just
            // below the measured −39.6 dBc: the per-voicing MID scoop legitimately cuts H2 ~6 dB relative to
            // the fundamental, so −35 (pre-bell) → −42 with a 2–3 dB margin — NOT −45 (that would add slack
            // the bell doesn't explain). The SE≥PP+40 term is only a cheap backstop that SE isn't AT the PP
            // cancellation floor; with ppEven≈−175 dBc it has huge slack and does not bind — the floor does.
            ppOk = ppOk && (ppEven < -90.0); seOk = seOk && (seH2 > -42.0) && (seH2 > ppEven + 40.0);
        }
        std::printf ("       worst PP even = %.1f dBc   weakest SE H2 = %.1f dBc\n", worstPP, bestSE);
        check (ppOk, "S5 PP even harmonics < -90 dBc full-chain (all tubes)");
        check (seOk, "S5 SE H2 clearly present (> -42 dBc) and above the PP cancellation floor (all tubes)");
    }
    // S6: drive-comp holds the small-signal level DRIVE-INVARIANT — no loudness cheat when Drive rises.
    // The always-on voicing bell sets the ABSOLUTE small-signal gain (non-unity by design), so "unity" is
    // the wrong claim now; the honest, stronger invariant is that the gain does not DRIFT with Drive. The
    // 1e-4 tone keeps the shaper linear even at Drive 36 (pre-gain·1e-4 ≪ 1), so this isolates drive-comp.
    {
        double worst = 0.0;
        auto in = sine (warm, N, tail, binF, 1e-4);
        const double ri = rms (in, warm, N);
        for (int t = 0; t < 4; ++t) for (bool se : { false, true })
        {
            double lo = 1e9, hi = -1e9;
            for (float dr : { 0.0f, 12.0f, 24.0f, 36.0f })
            {
                const double g = dbc (rms (runStage (P (dr, se, t), in), an, N), ri);
                lo = std::min (lo, g); hi = std::max (hi, g);
            }
            worst = std::max (worst, hi - lo);
        }
        std::printf ("       worst small-signal gain DRIFT across Drive = %.3f dB\n", worst);
        check (worst < 0.05, "S6 drive-comp ⇒ small-signal gain drive-invariant (< 0.05 dB drift, all tube/topology)");
    }
    // S7: at Drive=min the stage is a LINEAR filter == the voicing's always-on MID bell (identity is no
    // longer the claim — the bell colours it BY DESIGN). Two honest sub-claims that a missing/mis-voiced
    // bell would fail: (a) the small-signal gain AT each voicing's midHz equals its spec'd midDb (the bell
    // is present + correct), and (b) the path is LINEAR at Drive=min (the mid tone's harmonics stay at floor).
    {
        double worstErr = 0.0, worstThd = 0.0;
        for (int t = 0; t < 4; ++t)
        {
            const auto& v = kTubeVoicings[t];
            const int bin = (int) std::llround ((double) v.midHz * N / kSr);
            auto in  = sine (warm, N, tail, bin, 0.01);
            auto out = runStage (P (0.0f, false, t), in);
            const double gainDb = dbc (magBin (out, an, N, bin), magBin (in, warm, N, bin));
            worstErr = std::max (worstErr, std::fabs (gainDb - (double) v.midDb));
            double h = 0; for (int k = 2; k <= 6 && bin * k < N / 2; ++k) { const double m = magBin (out, an, N, bin * k); h += m * m; }
            worstThd = std::max (worstThd, std::sqrt (h) / std::max (1e-12, magBin (out, an, N, bin)));
        }
        std::printf ("       S7 worst |bell gain − midDb| = %.3f dB   worst mid-tone THD @Drive-min = %.2e\n", worstErr, worstThd);
        check (worstErr < 0.3,  "S7 MID bell delivers the spec'd per-voicing tone (gain at midHz ≈ midDb)");
        check (worstThd < 5e-3, "S7 stage is linear at Drive=min (mid tone harmonics at floor)");
    }
    // S8: the OVERSAMPLER round-trip is LINEAR-PHASE and its delay EQUALS the reported latency (31). A
    // symmetric-impulse test is no longer valid: the full stage is intentionally MIN-phase (the always-on
    // voicing bell), and a linear-phase FIR convolved with a min-phase IIR is asymmetric at EVERY lobe. So
    // measure the RESIDUAL group delay after latency-aligning the analysis window to +kLat (start = `an`):
    // for a linear-phase OS whose delay is exactly the reported 31, the residual is ≈0 at ALL frequencies.
    // Probe at two HF points (6 kHz, 11 kHz — far above the ≤1.6 kHz bell centres, where the bell's phase is
    // ≈0). A min-phase OS regression, or a reported latency that didn't match the true delay, would leave a
    // NON-zero, frequency-DEPENDENT residual.
    {
        auto phaseAt = [&] (int bin) -> double
        {
            auto out = runStage (P (0.0f, false), sine (warm, N, tail, bin, 0.01));
            double re, im; dftBin (out, an, N, bin, re, im); return std::atan2 (im, re);
        };
        auto residualGroupDelay = [&] (int binA, int binB) -> double   // samples, phase slope between two close HF bins
        {
            double d = phaseAt (binB) - phaseAt (binA);
            while (d >  kPi) d -= 2.0 * kPi;
            while (d < -kPi) d += 2.0 * kPi;
            return -d * (double) N / (2.0 * kPi * (double) (binB - binA));
        };
        const int b1 = (int) std::llround ( 6000.0 * N / kSr);
        const int b3 = (int) std::llround (11000.0 * N / kSr);
        const double gdLo = residualGroupDelay (b1, b1 + 64), gdHi = residualGroupDelay (b3, b3 + 64);
        std::printf ("       S8 OS residual group delay (latency-aligned) = %.2f samp @6 kHz, %.2f @11 kHz\n", gdLo, gdHi);
        check (std::fabs (gdLo) < 1.0 && std::fabs (gdHi) < 1.0,
               (std::string ("S8 OS round-trip is linear-phase, delay == reported latency ") + std::to_string (kLat)
                + " (residual ≈0, frequency-independent)").c_str());
    }
    // S9: sample-rate independence — latency tpp-1, finite, bounded at 44.1/88.2/96/192 kHz. The DC-block
    // coeff, the FIR cutoff, and the 25 ms smoothing all scale with fs; hard-coding 48 k would hide an fs bug.
    {
        bool ok = true;
        for (double sr : { 44100.0, 88200.0, 96000.0, 192000.0 })
        {
            TubePowerAmp d; d.prepare (sr, kMaxBlk, 4);
            ok = ok && (d.latencySamples() == kLat);
            std::vector<float> v (4096); { unsigned long long s = 7; for (auto& x : v) { s = s * 6364136223846793005ULL + 1ULL; x = 0.5f * ((float) ((s >> 40) & 0xFFFFFF) / 8388608.0f - 1.0f); } }
            for (int pos = 0; pos < 4096; pos += 512) { d.setParams (P (24.0f, true, 2)); float* io[1] { v.data() + pos }; felitronics::test::run (d.process (io, 1, 512)); }
            ok = ok && allFinite (v) && maxAbs (v, 0, 4096) < 4.0;
        }
        check (ok, (std::string ("S9 sample-rate independence: latency ") + std::to_string (kLat)
                    + " + finite + bounded at 44.1/88.2/96/192 kHz").c_str());
    }

    // ===================== ALIASING — reference-free non-harmonic energy =====================
    // A memoryless waveshaper on a pure sine emits ONLY exact harmonics k·f0, so ANY energy at NON-harmonic
    // bins IS aliasing (folds of harmonics above Nyquist). No 32x reference, numerical floor (~-120 dBc) —
    // so it certifies the guitar range genuinely below -80 (unlike a 4x-vs-32x null, which floors at ~-76 on
    // passband-ripple mismatch). f0 is chosen INHARMONIC (cyc not a power of 2 dividing 4·aN) so folds land
    // off-harmonic and are measurable. SE = worst case. We print the whole (freq × drive) MAP; the HF +
    // hot-drive cells are the documented 8x / hard-class-B boundary.
    //
    // 🔴 THE WINDOW USED TO STOP AT 10 kHz, AND THAT IS WHY THIS SUITE CERTIFIED tapsPerPhase = 32.
    // The decimator's transition band runs from 0.45 fs to the fold at 0.5 fs, so what leaks through it
    // lands between ~0.5 and 0.55 fs and folds back to 0.45-0.5 fs — i.e. 21.6-24 kHz at 48 k, entirely
    // ABOVE the old 10 kHz cut. Under that window the taps count read as irrelevant, and worse than
    // irrelevant: at a 3 kHz fundamental and +12 dB of drive the 10 kHz window scored 32 taps BETTER than
    // 64 (-77.8 against -77.4), which is how the map came to attribute the floor it saw to "the
    // oversampler's filter quality" and call a sharper OS a future option.
    // The numbers below are the ones this suite PRINTS, at both taps counts, so a reader can check them
    // by running it: a 3 kHz fundamental at +12 dB goes -56.2 (32) -> -75.9 (64), and the worst
    // guitar-range cell -68.7 -> -77.4, which is the shipped configuration FAILING this suite's own
    // -70 dBc bar by 1.3 dB where the widened window shows an 8.7 dB gap.
    // Aliasing at 15 kHz is aliasing; the band ends at Nyquist, not at 10 kHz.
    const int aN = 8192, aWarm = 4096, aTail = 512, aAn = aWarm + kLat;
    auto aliasNHDbcTpp = [&] (int cyc, float dr, bool se, int tpp) -> double {
        auto y = runStage (P (dr, se, 1), sine (aWarm, aN, aTail, cyc, 0.5), 4, nullptr, tpp);
        double fr, fi; dftBin (y, aAn, aN, cyc, fr, fi); const double fund2 = fr * fr + fi * fi;
        const int bLo = std::max (1, (int) std::floor (50.0 * aN / kSr)), bHi = aN / 2 - 1;
        double e = 0;
        for (int b = bLo; b <= bHi; ++b)
        {
            bool harm = false; for (int k = 1; k * cyc <= bHi; ++k) if (std::abs (b - k * cyc) <= 1) { harm = true; break; }
            if (harm) continue;                                    // skip the real harmonics; the rest is aliasing
            double u, w; dftBin (y, aAn, aN, b, u, w); e += u * u + w * w;
        }
        return 10.0 * std::log10 (std::max (1e-30, e) / std::max (1e-30, fund2));
    };
    auto aliasNHDbc = [&] (int cyc, float dr, bool se) -> double
    { return aliasNHDbcTpp (cyc, dr, se, felitronics::oversampling::PolyphaseOversampler::kDefaultTapsPerPhase); };
    {
        const int cycs[] = { 33, 171, 341, 513, 855, 1367, 1879, 2389 };   // inharmonic f0 ~ 193/1k/2k/3k/5k/8k/11k/14k Hz
        // BOTH topologies printed, because the map is the evidence for the default and a one-column map
        // cannot be evidence for a choice. The difference is the transition-band leakage, and it is where
        // the old 10 kHz window used to cut.
        for (int tpp : { 32, felitronics::oversampling::PolyphaseOversampler::kDefaultTapsPerPhase })
        {
            std::printf ("       aliasing MAP at %d taps/phase — reference-free non-harmonic energy, dBc, SE:\n", tpp);
            for (float dr : { 12.0f, 24.0f, 36.0f })
            {
                std::printf ("         Drive %2.0f dB: ", (double) dr);
                for (int c : cycs) std::printf ("%.0fHz=%-6.1f", (double) c * kSr / aN, aliasNHDbcTpp (c, dr, true, tpp));
                std::printf ("\n");
            }
        }
        // The reference-free method still shows a ~-78 dBc FLOOR that is nearly CONSTANT vs drive for low
        // fundamentals (193 Hz reads -78.0 / -77.4 / -77.2 at 12 / 24 / 36 dB). That floor is NOT the
        // oversampler's filter quality, and the earlier claim here that it was is refuted by the two maps
        // above: it barely moves between 32 and 64 taps (-78.4 against -78.0), so it belongs to something
        // else in the stage, and the nonlinearity adds nothing above it in the guitar range. What the taps
        // DO move is everything the old 10 kHz window excluded. The MAP shows the stage's aliasing rising
        // above the floor only at HF + hot drive (the 8x / hard-class-B boundary). Gate at -70 dBc.
        double worstGuitar = -300;
        for (int c : { 33, 171 }) for (float dr : { 12.0f, 24.0f }) worstGuitar = std::max (worstGuitar, aliasNHDbc (c, dr, true));
        std::printf ("       worst guitar-range cell (≤1.2 kHz fund, ≤24 dB SE) = %.1f dBc (OS floor ≈ -76)\n", worstGuitar);
        check (worstGuitar < -70.0, "A aliasing: guitar-range aliasing below -70 dBc at the shipped default");
        // TWO-SIDED, and this is the pair that decided the default. The bar above is the suite's own, and it
        // is not a bar a passing number proves anything about unless something is known to fail it: the
        // stage's PREVIOUS topology does, by 2.4 dB, and the gap is 7.7 dB. A fixture that only ever runs the
        // configuration it certifies cannot distinguish "adequate" from "unmeasured".
        {
            double worstOld = -300;
            for (int c : { 33, 171 }) for (float dr : { 12.0f, 24.0f }) worstOld = std::max (worstOld, aliasNHDbcTpp (c, dr, true, 32));
            std::printf ("       worst guitar-range cell at the OLD explicit 32 taps = %.1f dBc\n", worstOld);
            check (worstOld > -70.0,
                   "A aliasing: the old 32-tap topology FAILS this suite's own -70 dBc bar (it passed only on a 10 kHz window)");
            check (worstGuitar < worstOld - 5.0,
                   "A aliasing: the default buys > 5 dB over it — the instrument can tell the two topologies apart");
        }
        // HF / hot drive is the documented 8x boundary (see MAP) — assert only finite, not relaxed.
        check (std::isfinite (aliasNHDbc (2389, 36.0f, true)), "A aliasing: HF+hard-clip finite (documented 8x limit; see MAP)");
    }

    // ===================== ADVERSARIAL / RT-SAFETY =====================
    // X1: bounded + finite for hostile inputs (Output 0 dB ⇒ |y| must stay well bounded).
    {
        bool ok = true; double peak = 0;
        std::vector<std::vector<float>> sigs;
        { std::vector<float> v (8192, 0.0f); sigs.push_back (v); }                                   // silence
        { std::vector<float> v (8192, 1.0f); sigs.push_back (v); }                                   // DC +1
        { std::vector<float> v (8192); for (int i = 0; i < 8192; ++i) v[(std::size_t) i] = (i & 1) ? 1.0f : -1.0f; sigs.push_back (v); }   // Nyquist square
        { std::vector<float> v (8192, 0.0f); v[100] = 1.0f; sigs.push_back (v); }                    // impulse
        { std::vector<float> v (8192); for (int i = 0; i < 8192; ++i) v[(std::size_t) i] = i < 4096 ? 0.0f : 1.0f; sigs.push_back (v); }   // step
        { std::vector<float> v = sine (0, 8192, 0, 200, 1.0); sigs.push_back (v); }                  // full-scale sine
        for (auto& s : sigs) for (int t = 0; t < 4; ++t) for (bool se : { false, true }) { auto o = runStage (P (36.0f, se, t), s); ok = ok && allFinite (o); peak = std::max (peak, maxAbs (o, 0, (int) o.size())); }
        std::printf ("       X1 worst output peak (Drive 36, Out 0 dB) = %.3f\n", peak);
        check (ok, "X1 finite output for all hostile inputs (no NaN/Inf)");
        check (peak < 4.0, "X1 output bounded (< 4.0) at Drive 36 / Output 0 dB");
    }
    // X2: a NaN/Inf burst must not POISON the stream — output recovers to finite on later valid blocks.
    {
        TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4); d.setParams (P (18.0f, false));
        std::vector<float> bad (256, std::numeric_limits<float>::quiet_NaN()); { float* io[1] { bad.data() }; felitronics::test::run (d.process (io, 1, 256)); }
        std::vector<float> inf (256, std::numeric_limits<float>::infinity()); { float* io[1] { inf.data() }; felitronics::test::run (d.process (io, 1, 256)); }
        bool recovered = true; double tailRms = 0;
        for (int blk = 0; blk < 40; ++blk) { auto s = sine (0, 256, 0, 8, 0.3); d.setParams (P (18.0f, false)); float* io[1] { s.data() }; felitronics::test::run (d.process (io, 1, 256)); if (blk >= 30) { recovered = recovered && allFinite (s); tailRms += rms (s, 0, 256); } }
        std::printf ("       X2 post-NaN recovered RMS (last 10 blocks) = %.4f\n", tailRms / 10);
        check (recovered && tailRms / 10 > 1e-3, "X2 stream recovers to finite, non-zero output after a NaN/Inf burst");
    }
    // X3: long silence then a tiny impulse — denormal underflow must not stall recovery.
    {
        TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4); d.setParams (P (18.0f, false));
        for (int blk = 0; blk < 400; ++blk) { std::vector<float> z (256, 0.0f); float* io[1] { z.data() }; felitronics::test::run (d.process (io, 1, 256)); }
        std::vector<float> imp (256, 0.0f); imp[10] = 1e-3f; float* io[1] { imp.data() }; felitronics::test::run (d.process (io, 1, 256));
        check (allFinite (imp) && maxAbs (imp, 0, 256) > 1e-6, "X3 recovers a tiny impulse after long silence (no denormal stall)");
    }
    // X4: stereo isolation (silent R stays silent) + L==R symmetry for identical input.
    {
        TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4); d.setParams (P (24.0f, true, 2));
        auto sig = sine (0, 4096, 0, 100, 0.5);
        std::vector<float> L = sig, R (4096, 0.0f);
        float* io[2] { L.data(), R.data() }; felitronics::test::run (d.process (io, 2, 4096));
        check (maxAbs (R, 0, 4096) < 1e-9, "X4 stereo isolation: silent R channel stays silent (< -180 dB)");
        TubePowerAmp d2; d2.prepare (kSr, kMaxBlk, 4); d2.setParams (P (24.0f, true, 2));
        std::vector<float> L2 = sig, R2 = sig; float* io2[2] { L2.data(), R2.data() }; felitronics::test::run (d2.process (io2, 2, 4096));
        double sym = 0; for (int i = 0; i < 4096; ++i) sym = std::max (sym, (double) std::fabs (L2[(std::size_t) i] - R2[(std::size_t) i]));
        check (sym < 1e-7, "X4 stereo symmetry: identical L/R inputs give identical outputs");
    }
    // X5: parameter-change zipper bounded. Steady 1 kHz, then an abrupt Drive 0→36 / tube / topology
    // switch mid-stream; the smoothed coeffs must bound the per-sample discontinuity (no hard click).
    {
        auto sweepClick = [&] (const TubeParams& a, const TubeParams& b) -> double {
            TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4);
            std::vector<float> tone = sine (0, 8192, 0, 171, 0.3);    // ~1 kHz over 8192 @48k
            // steady on `a`
            for (int pos = 0; pos < 4096; pos += 256) { d.setParams (a); float* io[1] { tone.data() + pos }; felitronics::test::run (d.process (io, 1, 256)); }
            // switch to `b`
            for (int pos = 4096; pos < 8192; pos += 256) { d.setParams (b); float* io[1] { tone.data() + pos }; felitronics::test::run (d.process (io, 1, 256)); }
            double steady = 0; for (int i = 200; i < 3900; ++i) steady = std::max (steady, (double) std::fabs (tone[(std::size_t) (i + 1)] - tone[(std::size_t) i]));
            double atSwitch = 0; for (int i = 4060; i < 4200; ++i) atSwitch = std::max (atSwitch, (double) std::fabs (tone[(std::size_t) (i + 1)] - tone[(std::size_t) i]));
            return atSwitch / std::max (1e-9, steady);
        };
        const double driveJump = sweepClick (P (0.0f, false, 0), P (36.0f, false, 0));
        const double topoJump  = sweepClick (P (18.0f, false, 0), P (18.0f, true, 0));
        const double tubeJump  = sweepClick (P (18.0f, false, 0), P (18.0f, false, 3));
        std::printf ("       X5 switch/steady slew ratio: drive=%.1f topo=%.1f tube=%.1f\n", driveJump, topoJump, tubeJump);
        check (driveJump < 6.0 && topoJump < 6.0 && tubeJump < 6.0, "X5 param-change discontinuity bounded (< 6x steady slew) — smoothing works");
    }
    // X6: DOCUMENTED physics — a DC offset on the input shifts the PP operating point, so even
    // harmonics reappear (real push-pull amps do this). Assert the EFFECT exists (not a silent zero).
    {
        auto clean = runStage (P (24.0f, false, 1), sine (warm, N, tail, binF, 0.4, 0.0));
        auto biased = runStage (P (24.0f, false, 1), sine (warm, N, tail, binF, 0.4, 0.15));
        const double h2clean = dbc (magBin (clean, an, N, binF * 2), magBin (clean, an, N, binF));
        const double h2bias  = dbc (magBin (biased, an, N, binF * 2), magBin (biased, an, N, binF));
        char buf[128]; std::snprintf (buf, sizeof buf, "X6 PP DC-offset physics: H2 %.0f dBc (no DC) → %.0f dBc (DC+0.15) — even harmonics return", h2clean, h2bias); info (buf);
        check (h2bias > h2clean + 30.0, "X6 DC offset re-introduces PP even harmonics (documented operating-point physics)");
    }

    // ===================== CROSS-PLATFORM / NUMERIC ROBUSTNESS (macOS dev never sees this) =====================
    // X7: pathological numeric inputs — −0, denormals, huge, ±Inf, NaN — never UB/trap; output finite.
    {
        bool ok = true;
        const float vals[] = { -0.0f, 1e-40f, -1e-40f, 1e38f, -1e38f,
                               std::numeric_limits<float>::infinity(), -std::numeric_limits<float>::infinity(),
                               std::numeric_limits<float>::quiet_NaN(), 0.0f, 1.0f, -1.0f };
        for (float v : vals) for (int t = 0; t < 4; ++t) for (bool se : { false, true })
        { std::vector<float> in (1024, v); ok = ok && allFinite (runStage (P (24.0f, se, t), in)); }
        check (ok, "X7 pathological inputs (-0/denormal/huge/Inf/NaN) ⇒ finite output (no UB/trap)");
    }
    // X8: LIFECYCLE — process()/setParams()/latencySamples() BEFORE prepare() must be a clean no-op:
    // never hang (the maxBlock==0 chunk loop) nor divide by zero (1/n). macOS never sees the x86 trap.
    {
        TubePowerAmp d;                                   // deliberately NOT prepared
        d.setParams (P (24.0f, false));                   // must not crash
        (void) d.latencySamples();                        // must not crash
        std::vector<float> in (777, 0.3f), copy = in;
        float* io[1] { in.data() };
        const bool refused = ! d.process (io, 1, 777);        // must return immediately (no hang / no div0)
        check (refused, "X8 lifecycle: process before prepare is REFUSED, and says so (law 11)");
        bool unchanged = true; for (std::size_t i = 0; i < in.size(); ++i) unchanged = unchanged && (in[i] == copy[i]);
        check (unchanged && allFinite (in), "X8 lifecycle: process before prepare is a clean no-op (no hang / div-by-zero)");
    }
    // X9: div-by-zero provocation — maxBlock=1 (n=1 ramps), n>maxBlock (chunking), pure silence (0/0).
    {
        bool ok = true;
        { TubePowerAmp d; d.prepare (kSr, 1, 4); d.setParams (P (24.0f, false)); for (int k = 0; k < 64; ++k) { float s = std::sin (0.3f * (float) k); float* io[1] { &s }; felitronics::test::run (d.process (io, 1, 1)); ok = ok && std::isfinite (s); } }
        { TubePowerAmp d; d.prepare (kSr, 256, 4); d.setParams (P (24.0f, false)); std::vector<float> v (1000, 0.2f); float* io[1] { v.data() }; felitronics::test::run (d.process (io, 1, 1000)); ok = ok && allFinite (v); }
        { TubePowerAmp d; d.prepare (kSr, 512, 4); d.setParams (P (0.0f, false)); std::vector<float> z (4096, 0.0f); float* io[1] { z.data() }; felitronics::test::run (d.process (io, 1, 4096)); ok = ok && allFinite (z); }
        check (ok, "X9 edge block sizes (maxBlock=1, n>maxBlock chunking, silence) ⇒ finite (guards hold)");
    }
    // X10: determinism across two FRESH instances (catches uninitialised state / platform nondeterminism).
    {
        auto in = sine (0, 4096, 0, 171, 0.4);
        auto a = runStage (P (24.0f, false, 2), in), b = runStage (P (24.0f, false, 2), in);
        double mx = 0; for (std::size_t i = 0; i < a.size(); ++i) mx = std::max (mx, (double) std::fabs (a[i] - b[i]));
        check (mx == 0.0, "X10 two fresh instances are bit-identical (deterministic, no uninit state)");
    }

    // X11: RT no-alloc — the 🔴 rule: process() must NOT allocate. Count global operator new across a
    // warmed, prepared stage's process()/setParams calls (all setup allocs happen before the counter is read).
    {
        TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4);
        std::vector<float> buf (kMaxBlk, 0.2f); float* io[1] { buf.data() };
        for (int w = 0; w < 8; ++w) { d.setParams (P (24.0f, false, 1)); felitronics::test::run (d.process (io, 1, kMaxBlk)); }   // warm up (not counted)
        const long long before = alloc::count.load (std::memory_order_relaxed);
        for (int k = 0; k < 64; ++k) { d.setParams (P (24.0f, (k & 1) != 0, k & 3)); felitronics::test::run (d.process (io, 1, kMaxBlk)); }   // vary params + topology too
        const long long allocs = alloc::count.load (std::memory_order_relaxed) - before;
        std::printf ("       X11 heap allocations across 64 process()+setParams calls = %lld\n", allocs);
        check (allocs == 0, "X11 process()/setParams perform ZERO heap allocations (the RT rule, asserted)");
    }
    // X12: non-finite PARAMS (NaN driveDb / Inf outputDb — a bad preset or non-parameter-system caller) must
    // not poison the stream. (The after-review found the gate sanitized the signal but not the gain.)
    {
        TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4);
        TubeParams bad; bad.driveDb = std::numeric_limits<float>::quiet_NaN(); bad.outputDb = std::numeric_limits<float>::infinity(); bad.autoComp = std::numeric_limits<float>::quiet_NaN();
        std::vector<float> in = sine (0, 4096, 0, 171, 0.3);
        d.setParams (bad); { float* io[1] { in.data() }; felitronics::test::run (d.process (io, 1, 4096)); }
        std::vector<float> in2 = sine (0, 4096, 0, 171, 0.3);
        d.setParams (P (18.0f, false)); { float* io[1] { in2.data() }; felitronics::test::run (d.process (io, 1, 4096)); }   // recover with valid params
        check (allFinite (in) && allFinite (in2) && rms (in2, 512, 3000) > 1e-3,
               "X12 non-finite params (NaN driveDb / Inf outputDb / NaN autoComp) ⇒ finite output, no poison");
    }

    // ===================== SAG + PRESENCE/DEPTH ("feel") =====================
    // B1: pure SagEnvelope unit — dual-TC timing (fast attack, slow release) + amount=0 ⇒ zero droop.
    {
        SagEnvelope s; s.prepare (kSr);
        s.setParams (0.0f, 8.0f, 150.0f, 0.4f);
        double m0 = 0; for (int i = 0; i < 8000; ++i) m0 = std::max (m0, (double) s.process (1.0f));
        check (m0 == 0.0, "B1 SagEnvelope: amount=0 ⇒ zero droop (off is exact)");
        s.reset(); s.setParams (1.0f, 8.0f, 200.0f, 0.4f);
        for (int i = 0; i < 10000; ++i) s.process (1.0f); const double finalD = s.droop();
        s.reset(); int atkHalf = 10000; for (int i = 0; i < 10000; ++i) { if (s.process (1.0f) >= 0.5 * finalD) { atkHalf = i; break; } }
        for (int i = 0; i < 10000; ++i) s.process (1.0f); const double d0 = s.droop();
        int relHalf = 300000; for (int i = 0; i < 300000; ++i) { if (s.process (0.0f) <= 0.5 * d0) { relHalf = i; break; } }
        std::printf ("       B1 sag droop=%.3f  attack-half=%d  release-half=%d samples\n", finalD, atkHalf, relHalf);
        check (finalD > 0.2, "B1 SagEnvelope compresses under sustained load (droop > 0.2)");
        check (atkHalf < relHalf && atkHalf < (int) (0.03 * kSr) && relHalf > (int) (0.05 * kSr), "B1 dual-TC: attack fast, release slow");
    }
    // B2: sag COMPRESSES a sustained hot signal (integration) — steady RMS drops with sag on.
    {
        auto in = sine (0, 8192, 0, 171, 0.9);
        const double r0 = rms (runStage (Pf (18.0f, true, 2, 0.0f, 0, 0), in), 3000, 4000);
        const double r1 = rms (runStage (Pf (18.0f, true, 2, 1.0f, 0, 0), in), 3000, 4000);
        std::printf ("       B2 steady RMS: sag off=%.3f  sag on=%.3f (%.1f dB)\n", r0, r1, dbc (r1, r0));
        check (r1 < r0 * 0.98, "B2 sag compresses sustained load (steady RMS drops with sag on)");
    }
    // B3: PRESENCE boosts the HF shelf band; DEPTH boosts the LF shelf band (small-signal).
    {
        const int aW = 2048, aNN = 8192;
        // Probe INSIDE each shelf's passband (not at the corner, where a shelf is only ~half open):
        // presence is a HF shelf at ~3 kHz → probe ~9 kHz; depth is a LF shelf at ~100 Hz → probe ~47 Hz.
        auto band = [&] (float pres, float dep, int cyc) { auto y = runStage (Pf (0.0f, false, 0, 0, pres, dep), sine (aW, aNN, 256, cyc, 0.02)); return magBin (y, aW + kLat, aNN, cyc); };
        const double hf0 = band (0, 0, 1536), hf1 = band (1, 0, 1536);   // ~9 kHz — deep in the presence passband (and far above the ≤1.6 kHz MID bell → bell ≈ 0 dB)
        const double lf0 = band (0, 0, 8),    lf1 = band (0, 1, 8);      // ~47 Hz (LF passband)
        // Presence is voicing-specific (6L6 presenceMaxDb = 3 dB ⇒ ×1.41, not a fixed ×1.5). Probed
        // deep in the shelf passband it delivers exactly the spec, so assert the boost EQUALS dbToGain(spec)
        // within 12 % — a stronger claim than "> some ratio" (catches too-weak AND too-strong presence).
        const double presExp = dbToGain (kTubeVoicings[0].presenceMaxDb);
        std::printf ("       B3 presence HF %.3f→%.3f (×%.2f, spec ×%.2f)   depth LF %.3f→%.3f (×%.2f)\n",
                     hf0, hf1, hf1 / hf0, presExp, lf0, lf1, lf1 / lf0);
        check (std::fabs (hf1 / hf0 - presExp) < 0.12 * presExp, "B3 presence delivers the voicing's spec'd HF boost (presenceMaxDb)");
        check (lf1 > lf0 * 1.5, "B3 depth boosts the LF shelf band");
    }
    // B4: feel FULLY ON is robust — RT no-alloc, latency tpp-1, block-size determinism, finite/bounded.
    {
        TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4);
        std::vector<float> buf (kMaxBlk, 0.5f); float* io[1] { buf.data() };
        for (int w = 0; w < 16; ++w) { d.setParams (Pf (24.0f, false, 2, 1.0f, 1.0f, 1.0f)); felitronics::test::run (d.process (io, 1, kMaxBlk)); }
        const long long before = alloc::count.load (std::memory_order_relaxed);
        for (int k = 0; k < 64; ++k) { d.setParams (Pf (24.0f, (k & 1) != 0, k & 3, 1.0f, 0.7f, 0.7f)); felitronics::test::run (d.process (io, 1, kMaxBlk)); }
        check (alloc::count.load (std::memory_order_relaxed) - before == 0, "B4 feel ON: process()/setParams ZERO allocations (RT rule)");
        check (d.latencySamples() == kLat, (std::string ("B4 feel ON: latency still ") + std::to_string (kLat)).c_str());
        std::vector<float> src ((std::size_t) 4096, 0.0f); { unsigned long long s = 3; for (auto& x : src) { s = s * 6364136223846793005ULL + 1ULL; x = 0.6f * ((float) ((s >> 40) & 0xFFFFFF) / 8388608.0f - 1.0f); } }
        std::vector<int> b512 { 512 }, hostile { 1, 7, 64, 333, 512, 128 };
        auto ya = runStage (Pf (24.0f, false, 2, 1.0f, 0.6f, 0.6f), src, 4, &b512);
        auto yb = runStage (Pf (24.0f, false, 2, 1.0f, 0.6f, 0.6f), src, 4, &hostile);
        double mx = 0; for (std::size_t i = 0; i < ya.size(); ++i) mx = std::max (mx, (double) std::fabs (ya[i] - yb[i]));
        check (mx < 1e-6, "B4 feel ON: block-size determinism holds");
        bool ok = true; for (float v : { 1.0f, std::numeric_limits<float>::quiet_NaN(), 1e30f }) { std::vector<float> h (1024, v); ok = ok && allFinite (runStage (Pf (36.0f, true, 2, 1.0f, 1.0f, 1.0f), h)); }
        check (ok, "B4 feel ON: finite output for NaN/huge/full-scale (no poison)");
    }
    // B5: NFB "opens" — presence's effective HF boost GROWS when pushed (sag droops → shelf opens), i.e.
    // the presence-on/off HF ratio at high drive+sag exceeds the quiet ratio: dynamic, not a static EQ.
    {
        const int aW = 2048, aNN = 8192;
        auto ratio = [&] (float drive, float sag) {
            auto y1 = runStage (Pf (drive, true, 2, sag, 1.0f, 0), sine (aW, aNN, 256, 512, 0.05));
            auto y0 = runStage (Pf (drive, true, 2, sag, 0.0f, 0), sine (aW, aNN, 256, 512, 0.05));
            return magBin (y1, aW + kLat, aNN, 512) / std::max (1e-9, magBin (y0, aW + kLat, aNN, 512));
        };
        const double rLo = ratio (0.0f, 0.0f), rHi = ratio (30.0f, 1.0f);
        std::printf ("       B5 presence HF-open ratio: quiet=%.3f  pushed=%.3f\n", rLo, rHi);
        check (rHi > rLo * 1.03, "B5 NFB opens: presence's HF boost grows when pushed (dynamic, not static EQ)");
    }
    // B6: the sag path RECOVERS from a FINITE-overflow burst — an input whose |x|·g exceeds FLT_MAX pushes
    // the demand to +Inf; the sag envelope must NOT latch to NaN (→ rail stuck at the 0.2 floor forever).
    // The post-burst settled tail must match a clean, never-overflowed run. (Real trigger — B4's 1e30 stays
    // finite after ·g and never exercised this path; this feeds 1e38 which genuinely overflows.)
    {
        const double tp = 6.283185307179586;
        auto tailRms = [&] (bool burst)
        {
            TubePowerAmp d; d.prepare (kSr, kMaxBlk, 4);
            d.setParams (Pf (36.0f, true, 2, 1.0f, 0.0f, 0.0f));   // hot EL84, sag fully on
            std::vector<float> buf ((std::size_t) kMaxBlk); float* io[1] { buf.data() };
            if (burst) { std::fill (buf.begin(), buf.end(), 1.0e38f); felitronics::test::run (d.process (io, 1, kMaxBlk)); }   // overflow
            double e = 0; const int NB = 60;
            for (int b = 0; b < NB; ++b)
            {
                for (int i = 0; i < kMaxBlk; ++i) buf[(std::size_t) i] = 0.3f * (float) std::sin (tp * 220.0 * (b * kMaxBlk + i) / kSr);
                felitronics::test::run (d.process (io, 1, kMaxBlk));
                if (b >= NB - 10) for (int i = 0; i < kMaxBlk; ++i) e += (double) buf[i] * buf[i];
            }
            return std::sqrt (e / (10.0 * kMaxBlk));
        };
        const double clean = tailRms (false), recovered = tailRms (true);
        std::printf ("       B6 tail RMS: clean=%.4f  post-overflow=%.4f\n", clean, recovered);
        check (clean > 1.0e-3 && std::fabs (recovered - clean) < 0.02 * clean,
               "B6 sag recovers from finite-overflow burst (rail not stuck at a NaN floor)");
    }
    // B7: VIRTUAL LOAD — at Load=100% the reactive-impedance pre-EQ delivers the voicing's spec'd
    // shape: a LF cone-resonance PEAK ≈ loadResDb at loadResHz + a HF inductive rise ≈ loadRiseDb, ~flat in
    // between. Measured as the Load=1 / Load=0 gain RATIO so the always-on MID bell + shaper CANCEL (both in
    // numerator and denominator) → a clean read of the load's own contribution. Load=0 ⇒ the block is
    // skipped (byte-identical load-free chain, already covered by the superset invariant of S4-S8/B*).
    {
        double worstRes = 0, worstRise = 0, worstMid = 0;
        for (int t = 0; t < 4; ++t)
        {
            const auto& v = kTubeVoicings[t];
            auto gain = [&] (float load, int bin)
            {
                TubeParams tp = P (0.0f, false, t); tp.load = load;
                return magBin (runStage (tp, sine (warm, N, tail, bin, 0.001)), an, N, bin);
            };
            const int bRes = (int) std::llround ((double) v.loadResHz * N / kSr);
            const int bMid = (int) std::llround (700.0  * N / kSr);
            const int bHi  = (int) std::llround (9000.0 * N / kSr);
            worstRes  = std::max (worstRes,  std::fabs (dbc (gain (1.0f, bRes), gain (0.0f, bRes)) - (double) v.loadResDb));
            worstRise = std::max (worstRise, std::fabs (dbc (gain (1.0f, bHi),  gain (0.0f, bHi))  - (double) v.loadRiseDb));
            worstMid  = std::max (worstMid,  std::fabs (dbc (gain (1.0f, bMid), gain (0.0f, bMid))));
        }
        std::printf ("       B7 load: worst |res−spec|=%.2f dB  |rise−spec|=%.2f dB  |mid−0|=%.2f dB\n", worstRes, worstRise, worstMid);
        check (worstRes  < 0.3, "B7 virtual load: LF resonance peak ≈ loadResDb at loadResHz");
        check (worstRise < 0.3, "B7 virtual load: HF inductive rise ≈ loadRiseDb");
        check (worstMid  < 0.5, "B7 virtual load: ~flat between the resonance and the HF rise");
    }
    // B8: OUTPUT TRANSFORMER — at Iron=1 the LF core saturation COMPRESSES a hot low note
    // and the HF leakage rolls off the top; both gated by the Iron knob (Iron=0 ⇒ bypass). Measured as the
    // Iron=1 / Iron=0 fundamental-gain ratio (isolates the transformer from the rest of the chain).
    {
        bool lfOk = true, hfOk = true; double worstLf = 0, worstHf = 0;
        for (int t = 0; t < 4; ++t)
        {
            auto g = [&] (float iron, int cyc, double amp)
            {
                TubeParams tp = P (6.0f, false, t); tp.iron = iron;
                return magBin (runStage (tp, sine (warm, N, tail, cyc, amp)), an, N, cyc);
            };
            const int bLo = (int) std::llround (80.0    * N / kSr);
            const int bHi = (int) std::llround (12000.0 * N / kSr);
            const double lfRatio = g (1.0f, bLo, 0.6) / std::max (1e-12, g (0.0f, bLo, 0.6));   // hot low note compresses ⇒ < 1
            const double hfRatio = g (1.0f, bHi, 0.1) / std::max (1e-12, g (0.0f, bHi, 0.1));   // top rolls off ⇒ < 1
            worstLf = std::max (worstLf, lfRatio); worstHf = std::max (worstHf, hfRatio);
            lfOk = lfOk && (lfRatio < 0.97); hfOk = hfOk && (hfRatio < 0.85);
        }
        std::printf ("       B8 iron: worst LF-compress ratio=%.3f  worst HF-rolloff ratio=%.3f (both < 1 ⇒ working)\n", worstLf, worstHf);
        check (lfOk, "B8 output transformer: hot low note compresses at Iron=1 (LF core saturation)");
        check (hfOk, "B8 output transformer: top rolls off at Iron=1 (HF leakage)");
    }
    // B9: dynamic BIAS — under sag the PP operating point drifts (crossover bloom). It DOES something
    // when Bias>0 + Sag>0 (non-null vs Bias=0), and the WHOLE feel path (sag+load+iron+bias) is
    // PER-SAMPLE ⇒ block-size DETERMINISTIC (a per-block bias would break this).
    {
        // Sized warm+N+tail (like the sine buffers) so the diffWin windows [an, an+N) below stay IN
        // BOUNDS: an = warm+kLat, so a warm+N buffer ends kLat samples short of the window — an OOB
        // read (ASan heap-buffer-overflow) whose garbage was the phantom "~1e-2 feel-layer block-size
        // discrepancy" this test used to report.
        std::vector<float> in ((std::size_t) (warm + N + tail), 0.0f);
        { unsigned long long s = 3; for (auto& v : in) { s = s * 6364136223846793005ULL + 1; v = 0.4f * ((float) ((s >> 40) & 0xFFFFFF) / 8388608.0f - 1.0f); } }
        TubeParams noB = Pf (24.0f, false, 1, 0.85f, 0.0f, 0.0f);
        TubeParams wiB = noB; wiB.bias = 1.0f;
        auto a0 = runStage (noB, in), a1 = runStage (wiB, in);
        auto diffWin = [&] (const std::vector<float>& x, const std::vector<float>& y, int from, int to)
        { double m = 0; for (int i = from; i < to; ++i) m = std::max (m, (double) std::fabs (x[(std::size_t) i] - y[(std::size_t) i])); return m; };
        const double nonNull = diffWin (a0, a1, an, an + N);
        // Block-size determinism: at feel=0 the stage is BIT-EXACT across block schedules (see S3) — and
        // ROOT-CAUSED (the theory suite's TT9): so is the FEEL layer. The "~1e-2 pre-existing feel-layer
        // discrepancy" this test once reported was NOT the DSP — it was this test's own analysis window
        // reading kLat samples past a warm+N buffer (fixed above); measured in-bounds, baseDet/fullDet are
        // exactly 0. The check stays as-is (never weakened): it still guarantees the load + output-
        // transformer + per-sample bias stages do not regress the sag/presence/depth feel-layer baseline.
        std::vector<int> blk { 512 }, hostile { 1, 7, 64, 333, 512, 128 };
        TubeParams base3 = Pf (24.0f, false, 1, 0.8f, 0.5f, 0.5f);                          // sag/presence/depth feel only
        TubeParams full  = base3; full.load = 1.0f; full.iron = 1.0f; full.bias = 1.0f;     // + load/iron/bias
        const double baseDet = diffWin (runStage (base3, in, 4, &blk), runStage (base3, in, 4, &hostile), an, an + N);
        const double fullDet = diffWin (runStage (full,  in, 4, &blk), runStage (full,  in, 4, &hostile), an, an + N);
        std::printf ("       B9 bias non-null=%.2e   block-schedule diff: feel=%.2e  +load/iron/bias=%.2e\n", nonNull, baseDet, fullDet);
        check (nonNull > 1e-3, "B9 bias shifts the crossover under sag (non-null vs Bias=0)");
        check (fullDet <= baseDet * 1.5 + 1e-4, "B9 load+iron+bias don't regress feel-layer block-size determinism");
    }

    // See the note in PowerAmpTheoryTests: the shared harness's failures (a REFUSED process() call)
    // must reach this runner's exit code, or test::run() is decoration.
    const int sharedFailures = felitronics::test::stats().failures;
    std::printf ("%d checks, %d failures (+%d from the shared harness)\n", g_checks, g_fail, sharedFailures);
    std::printf ((g_fail || sharedFailures) ? "GOLDEN FAILED\n" : "GOLDEN PASSED\n");
    return (g_fail || sharedFailures) ? 1 : 0;
}
