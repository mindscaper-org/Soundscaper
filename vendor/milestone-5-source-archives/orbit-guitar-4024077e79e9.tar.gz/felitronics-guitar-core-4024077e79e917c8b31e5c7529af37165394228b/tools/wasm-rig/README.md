<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->

# fcrig — the pack player, for a browser AudioWorklet

`felitronics::rigplayer::RigPlayer` — one device of a `.orbitrig` pack, playing, with NAM underneath — behind a thin C
ABI, `fc_rig`, compiled to WebAssembly. The page plays a pack as the app plays it (OrbitAmp's `CapturedBlock`): the
player applies the pack's two levels, the files' input trims, the loudness normalisation, the pack's tone and blend
knobs and the crossfade along the gain dial by itself. The module holds no DSP of its own; it shares
`fcguitarfx`'s shape (`../wasm/README.md`) wherever it can.

| file | what |
|---|---|
| `../fc_rig_abi.h` | the C ABI: the contract, the load job, `FC_RIG_ABI_VERSION` |
| `fc_rig.cpp` | its translation unit — one RigPlayer call per entry point, compiled without exceptions |
| `fc_rig_manifest.cpp` | rig.json through namz's reader — nlohmann, so compiled with exceptions |
| `fcrig-worklet.js` | the AudioWorklet processor, `'fc-rig'` |
| `build.sh` | builds `fcrig.mjs` + `fcrig.wasm` into `tools/wasm-rig/build/`, with `BUILD-INFO` |
| `tests/RigAbiTests.cpp`, `tests/rig_fixture.h` | the ABI against RigPlayer driven directly, bit for bit; the job protocol; the contract; no allocation |
| `rig-parity.mjs`, `fc_rig_render.cpp` | the shipped module in a worklet-shaped scope against the native render |

A directory of its own beside `tools/wasm`, not a second target there: this module links NAM, the one thing in the
repository that throws, and is built with SIMD; `fcguitarfx` stays exception-free and scalar. One `build.sh` per module
keeps either set of flags from leaking into the other.

## The ABI

```c
uint32_t fc_rig_abi_version (void);                                         // 3
fc_rig*  fc_rig_create (void);   void fc_rig_destroy (fc_rig*);
int      fc_rig_prepare (fc_rig*, double rate, int maxBlock, int channels);  // 1 ok, 0 refused (disarmed)
float*   fc_rig_buffer (fc_rig*, int channel);                               // maxBlock floats in the module's memory
void*    fc_rig_alloc (int bytes);   void fc_rig_free (void*);              // module memory for strings, the manifest
int      fc_rig_load (fc_rig*, const char* manifest, int length);           // rig.json; 1 = a NAM stage to play
void     fc_rig_unload (fc_rig*);
int      fc_rig_take_job (fc_rig*);                                          // the load job, below
const char* fc_rig_job_file (fc_rig*);   int fc_rig_job_file_length (fc_rig*);   int fc_rig_job_needs_bytes (fc_rig*);
uint8_t* fc_rig_job_bytes (fc_rig*, int size);   int fc_rig_job_run (fc_rig*);   int fc_rig_job_deliver (fc_rig*);
int      fc_rig_set_dial (fc_rig*, const char* name, double degrees);       // any dial, by the pack's name
int      fc_rig_set_switch (fc_rig*, const char* name, const char* value);  // any control, tone switch, blend…
int      fc_rig_set_gain_dial (fc_rig*, double degrees);   double fc_rig_gain_dial_sweep (fc_rig*);
int      fc_rig_set_max_models (fc_rig*, int n);                             // 1 or 2 (default)
void     fc_rig_set_normalize (fc_rig*, int);   void fc_rig_set_input_trims (fc_rig*, int);   // both on by default
void     fc_rig_set_blend_shape (fc_rig*, double point, double width);       // the app's SMOOTH {0.5,1} / STEP {0.5,0}
int      fc_rig_process (fc_rig*, float* left, float* right, int n);        // in place; right NULL = mono
void     fc_rig_reset (fc_rig*);
double   fc_rig_sounding_db (fc_rig*);   int fc_rig_sounding_tagged (fc_rig*);   int fc_rig_sounding_blended (fc_rig*);
int      fc_rig_held (fc_rig*, int slot);   int fc_rig_latency_samples (fc_rig*);
int      fc_rig_run_blocks (fc_rig*, int slot);   int fc_rig_pair_blocks (fc_rig*);   int fc_rig_warm_blocks (fc_rig*);
void     fc_rig_clear_counters (fc_rig*);
// ABI 2
int      fc_rig_scope_read (fc_rig*, float* dry, float* wet, int n);   // the newest ≤ 2048 of the tap; 0 = none yet
double   fc_rig_scope_frames (fc_rig*);                                // samples written to the tap: moves = fresh
void     fc_rig_set_standby (fc_rig*, int on);                         // PARK: 15 ms to the wire, then not run
int      fc_rig_set_feed_db (fc_rig*, double db);                      // the block's IN on top of the pack's level
// ABI 3 — no entry point added: fc_rig_scope_read draws OrbitAmp's two points around the whole player (v0.5.1)
```

The setters are the ones the app's block calls (`setDial`, `setSwitch`, `setBlendShape`, `setInputTrims`) plus
`setMaxModels` and `setNormalize`; the read-outs are what a face shows (`soundingLoudness`) and what a host measures its
budget by (`runBlocks`, `pairBlocks`). **Compatibility is append-only** exactly as `fc_guitar_fx`'s, and a change of
what an existing entry point does moves the version as an addition does (ABI 3 changed only what `fc_rig_scope_read`
draws).

### ABI 2 — what the site's demo needs that ABI 1 lacked (read off its `sound/chain.ts` and `sound/engine.ts`)

| the site today | in the app | ABI 2 |
|---|---|---|
| SHAPE from a scope worklet around TONE3000's node (`readScope`, `ScopeRing`) | `ScopeTap`, written by the captured block (`CapturedBlock.h:556`), level-matched in its reader | `fc_rig_scope_read` + `fc_rig_scope_frames` (the app's points, `CapturedBlock.h:543-556`: the input times the feed, undelayed, and the player's output) |
| PARK as GainNodes around the node, `setTargetAtTime` with τ = 10 ms (~40 ms to settle) | the captured block crossfaded to its wire over `BypassFade`'s 15 ms, then not run (`PluginProcessor.cpp:1397-1559`) | `fc_rig_set_standby` |
| TURBO's push and the position's trim as one gain before the node (`setFeed`) | the push is the block's IN (`Channels.cpp` `blockIn`), applied after the wire and before the dry tap, only while the block runs, ARRIVING on the way back; the position's trim is the player's own (`files[].input_db`) | `fc_rig_set_feed_db` (the push only; the trim is already applied) — `RigPlayer::setFeedDb` |

Looked at and NOT added, because the page has them already or the app keeps them outside its block: the INPUT and
OUTPUT trims, the cuts, the cabinet, the delay and the room (all around the node), the loudness lift (the player
normalises, -18 dB), BASS/MIDDLE/TREBLE (the pack's tone through `{ set: { dial } }` — ABI 1), the capture swap's dip
(the player's law), latency (`fc_rig_latency_samples`). Not exposed still, each one append away: the host OUTPUT level,
tone overrides, the alignment table, the cold rest, the drawing read-outs, the app's drive for a device with no gain
axis (`CapturedBlock.h:546-552` — the site's packs all have one).

The contract in short (the header has it whole): one thread owns an instance; `process()` and `reset()` never lock or
throw, and never allocate while the captures are Linear or WaveNet (LSTM and ConvNet allocate inside the pinned NAM); `prepare()` takes 1 kHz … 768 kHz, maxBlock 1 … 65536, 1 or 2 channels, and a refusal
disarms; a mono call runs ONE network per sounding capture, so a guitar is prepared for 1 channel.

### ABI 4 — the preload (v0.6.0)

| entry point | what it is |
|---|---|
| `fc_rig_set_preload(rig, n)` | `RigPlayer::setPreload`: 0 off (the default), n ≥ 1 on with at most n prepared copies, 2147483647 (`kPreloadWholePack`) the whole pack — from the next `fc_rig_load` |
| `fc_rig_preload_pending(rig)` | copies of the set not yet settled; 0 = ready (or not preloading) |
| `fc_rig_preload_total(rig)` | copies in the set; 0 = the pack loaded is not preloading |
| `fc_rig_preload_failed(rig)` | settled copies that failed or could not be fetched |
| `fc_rig_is_gain_dial(rig, name)` | 1 = `name` is the loaded pack's gain dial |

The jobs the preload hands out are the ordinary ones (`fc_rig_take_job` …). With the set ready, neither a turn of the
gain dial nor a switch within the set takes one. `processorOptions.preload` (`true` = the whole pack, or a cap) turns it
on in the processor, which FILLS THE SET IN THE BACKGROUND (v0.7.0): the start does not wait for it — the law's ask
goes first, so the start sounds as soon as the capture it needs is held, warmed and timed, as without the preload — and
the set is filled behind it, AT MOST ONE JOB A RENDER QUANTUM (a job whose answer arrives after one already ran waits
for the next quantum), while it plays. `{ preloaded: { pack, total, failed, quanta } }` reports the set filled
(`quanta`: those the fill ran in, PARK's excluded); nothing waits for it, it usually comes after `{ calibrated }`, and a
`{ load }` or `{ unload }` before it ends that fill without one. Under PARK nothing loads: no job, no `{ need }`; an
answer that arrives meanwhile is kept and its job runs at the first quantum back. A turn of DRIVE to a copy not filled
yet is the law's ask, and goes first — at a job's cost when the player holds the file: hand the pack's files in with it
(`{ load, files }`, ABI 5), or a fill `{ need }` out holds the next ask back by its round trip (the player hands out one
job at a time). Measured (Playwright, 48 kHz, IR-X Ch1 PowerAmp, the page answering each `{ need }` after 40 ms): the
first sound at 261 ms in WebKit and 248 ms in Chromium (v0.6.0: 2656 and 3981 ms), the set filled ~2.2 s later while it
played, and no render quantum after the first sound later than 12 ms in either. While the start decides, switches,
dials and levels land at once — those in `processorOptions.knobs` and in a `{ set }` posted before the module was up
too — so the set is made around the panel and the DRIVE the page asked for; only `maxModels` waits for the start. The
whole pack is 11 copies for X88-IR Crunch and V4 Sheriff Ch1 (24.1 MiB of module memory for this worklet in the
node parity run, `rig-parity.mjs`, as without the set; `rig-compare.mjs`, which drives the ABI directly, reads 28.9 MiB
— the CHANGELOG's figure), 44 for IR-X Ch2, 66 for IR-X Ch1 PowerAmp (103.8 MiB). What the set is, its memory and what
a copy taken again holds: the player's README, "The preload".

## The load job, across the boundary and across the port

RigPlayer never loads by itself: its law asks for a capture and the host runs a JOB and brings it back. Inside the
module: `take_job` (service, then `takeLoadJob`) → `job_file` says which `files[].id` → `job_needs_bytes` says whether
the player still needs them (it keeps every file's bytes once they arrived; a job run without bytes keeps nothing, so
that file is asked for again on its next visit) → `job_bytes(size)` is where they go → `job_run` is the heavy half
(`NamStage::prepareModel`) → `job_deliver` the light half. A job taken must come back — a failure too (run without
bytes is "could not fetch it"); a job out when the pack is loaded again or unloaded is dropped by the instance
itself, so jobs never stall.

Across the port, the processor does that for the page, which only fetches:

```
processor → page   { need: "X88-IR Crunch-0005.namz", pack: 3 }
page → processor   { file: "X88-IR Crunch-0005.namz", pack: 3, bytes: <ArrayBuffer, transferred> | null }
processor → page   { loaded: "X88-IR Crunch-0005.namz", ok: true }
```

`pack` is the processor's count of loads; an answer for an older pack, or for a file nobody is waiting for, is
dropped. **Every `{ need }` must be answered** — `null` when the fetch or its body failed — because the player hands
out one job at a time: a `{ need }` left open stops every later load. Should the page still not answer, the processor
answers for it after `needTimeoutMs` (10 s by default, `0` = never): the job runs without bytes, `{ loaded, ok:
false }`, and the late answer is dropped. `{ load }` is the other recovery — it drops the job out. The job pump runs after every render quantum; a capture the player already holds the bytes of is run at
once, with no round trip. **The job runs on the audio thread** — a worklet has no other — so the quantum it lands in is
late by the network's build and prewarm (tens of milliseconds for a WaveNet). Accepted for now (Oleh, 19.10.2026);
the player's own dip covers the swap itself.

## The processor

```js
const module = await WebAssembly.compileStreaming(fetch(wasmUrl));          // the page compiles, once
await context.audioWorklet.addModule(workletUrl);                           // imports ./fcrig.mjs statically
const node = new AudioWorkletNode(context, 'fc-rig', {
    numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2],
    channelCount: 1, channelCountMode: 'explicit',                          // a guitar: Web Audio folds to mono
    processorOptions: { module, rig: rigJsonArrayBuffer, knobs: { gain: 150 } } });
node.port.onmessage = async ({ data }) => {                                 // read { ready }, { calibrated }, …
    if (data.need === undefined) return;
    let bytes = null;
    try {                                                                   // the fetch AND the body: a body cut
        const r = await fetch(packDir + encodeURIComponent(data.need));     // off after the headers rejects
        if (r.ok) bytes = await r.arrayBuffer();                            // arrayBuffer()
    } catch (e) { bytes = null; }
    node.port.postMessage({ file: data.need, pack: data.pack, bytes }, bytes ? [bytes] : []);   // always answered
};
node.port.postMessage({ set: { gain: 210, dial: { Bass: 120, Treble: 200 }, switch: { Boost: 'on' } } });
node.port.postMessage({ load: otherRigJsonArrayBuffer });                   // another pack
node.port.postMessage({ read: true });                                      // → { state: { sounding, latency, … } }
node.port.postMessage({ standby: true });                                   // PARK (ABI 2); false plays again
let scope = new ArrayBuffer(2 * 2048 * 4);                                  // the page's ONE scope buffer
node.port.postMessage({ scope }, [scope]);                                  // → { scope, n, frames }: it, transferred back
node.port.postMessage({ dispose: true });                                   // the only end
```

`{ set }` takes `maxModels`, `normalize`, `inputTrims`, `blendShape: [point, width]`, `switch: { name: value }`,
`dial: { name: degrees }`, `gain` (the crossfade dial, whatever the pack names it) and `feed` (dB), applied in that
order, and queued while the start decides. `{ standby }` (PARK; `{ set: { standby } }` is the same) is NEVER queued: a
parked player runs no network, so the start's evidence cannot come while it stands by, and a PARK held behind it held
for ever — a `{ load }` while parked was silence for good. It is applied at once (before the module is up, as soon as
it is); while parked the start pauses, nothing loads (no job, no `{ need }`; an answer that arrives is kept for the
first quantum back) and the output is the player's own (the fade, then the input at the latency) whatever the start's
state; `{ standby: false }` resumes the start, silent until it decides, as after any `{ load }`.

**The scope (ABI 2; its points ABI 3's).** The page owns one `ArrayBuffer` of `2·n` floats (`n` ≤ 2048) and sends it, transferred; the
processor copies the newest frame into it — dry in `[0, n)`, wet at the dry's RMS in `[n, 2n)` — and sends the
buffer back, transferred (the page's own memory again, a new `ArrayBuffer` object): `{ scope, n: <read; 0 = none yet>, frames: <the tap's count> }`. An unchanged `frames` is a
frame already drawn (stood by, it does not move). Before the module is up, or after an error, the buffer still comes
back, `n` 0. Why a travelling buffer: a fresh 16 KB array posted per frame is ~1 MB/s of garbage made on the audio
thread at 60 fps, collected there too; a transferred buffer is neither copied by the structured clone nor allocated on
either side — a message costs the message object and one view, on the port, never in `process()`. One request in
flight: ask again when it is back. The read happens on the audio thread between quanta, so it can never tear. Names
and values travel as UTF-8 written by the processor itself (a worklet may have no TextEncoder or TextDecoder). Options:
`stereo: true` plays two channels (two networks per capture); `calibrate: false` skips the start's decision and
starts at `maxModels` (2 if absent); `needTimeoutMs` (above). Loading, the bytes path (`wasmBytes`, WebKit's null module), errors and dispose
are `fcguitarfx`'s: **an error is not an end** — one `{ error }`, the dry from then on, `process()` true until
`{ dispose }`. A trap inside the module is an error too, and that module is never called again (not even to free).
A failed load is not an error: `{ loaded, ok: false }`, and the law decides what sounds. A knob value that is not a
number (a BigInt survives `postMessage`) is ignored, not a throw — and not a trap.

`process()` allocates nothing per quantum. A load may grow the module's memory, which detaches every older view; the
processor compares its view's buffer with the module's at the top of every quantum and again after the render (an
LSTM or ConvNet capture allocates inside the pinned NAM while it renders — the module's allocation promise covers
Linear and WaveNet only, gated by `felitronics_nam_rtalloc_tests`), and makes the two views again only then (tested:
a 48 MiB file handed in grows the memory and the next quanta still play; a render that grows it copies out bit for
bit).

## The start (v0.7.0: no burst, no hold)

A browser's audio thread may afford two networks or only one, and the only honest way to know is to time one ON it.
At every pack (`{ load }`, and the first one), unless `calibrate: false`, the processor:

1. runs ONE model (`setMaxModels(1)`) — or, once the session has decided anything, the count it decided — and lands
   every knob at once, the gain dial too: the capture timed is the DRIVE's own, so the copy that warms is the copy that
   sounds (no 12 o'clock); only a `maxModels` waits for the decision;
2. once a capture is held, reads its architecture signature (`fc_rig_signature(slot)`: the architecture and the shape
   of its layers, never weights, tags or trained numbers). A session decides once per architecture: every capture held
   already decided on → that decision stands, nothing is timed. The signatures read are those of the captures held
   when the first one lands, so a pack that mixes architectures is decided by those (the site's packs are one each);
3. otherwise times the player's own live renders of the warm-up — `Date.now()` around each render that ran exactly one
   network of that architecture alone (the counters; an outgoing capture's drain is not its evidence), nothing extra
   run for it; a mean of 0-or-1 ms readings over many renders is unbiased;
4. ends when the sound opens — the first quantum `fc_rig_audible` is 1, the first sample of the law's 15 ms fade-in —
   and posts `{ calibrated: { renderUs, quantumUs, share, maxModels, renders, elapsedMs, runs, pairs, warm, valid,
   reason } }` in that quantum (a capture that opens before 8 renders were timed: 8 quanta later at most). Valid: at
   least 8 renders and a clock seen to step by 4 ms or less; valid and one render at most a quarter of the quantum
   (~667 µs at 48 kHz) → the blend (`setMaxModels(2)`); else one capture with dips (`reason`: `'clock'` — Date.now too
   coarse, Firefox's resistFingerprinting — or `'short'`, too few renders timed by then);
5. **settles** a one-model decision: after the sound opens on one model, the architecture is timed on (renders that ran
   one network of it alone, counted from an open — the start's own are the module's first, its coldest — and across
   the session's starts, 512 quanta a start at most) until 64 of them, and decided again from those. Nothing changes
   and nothing is posted meanwhile: the architecture's next start posts and applies it. A one-model decision on a
   start's dozen readings lasts one pack at most, as v0.6.0's per-pack burst did; a two-model one errs the safe way (two
   renders of 0.8 ms still fit) and is not settled. `Date.now()` allocates its heap number at every call in V8 (~12
   bytes a timed quantum in node), so the timed quanta are only the start's and the settle's, both bounded
   (rig-parity's allocation group).

A start's capture that fails to load ends it at once: `{ calibrated: { maxModels, valid: false, reason: 'load-failed'
} }`. `{ calibrate: 'again' }` forgets the session's decisions (a page that knows its next pack is another
architecture): with a `{ load }` that pack's start times; while sounding, one model is timed over 64 renders (256
quanta at most: a neighbour put to rest drains first) and the decision posted as at a start. Nothing here silences the output: it is the player's own, its law keeps a capture
silent until it is warm and fades it in. `{ measure }` still times a ~30 ms burst on demand (it stalls the context).

**The quiet warm** (`fc_rig_warm_quiet`, `processorOptions.quietWarm`, on with the start). A capture is not heard
before its receptive field of input has run through it — 51 quanta (~136 ms) of a site WaveNet at 48 kHz. When the
input has been exactly silent for all of that (PLAY, after a PARK; in a pause only once the tone stack's tail has
decayed to an exact 0 — hundreds of ms after the last note, wasm keeps denormals — and the field has passed again),
the warm-up's input is known; the player feeds the warming capture blocks of silence ahead of time after each render,
as many as fit 60 % of the quantum with the render by an UPPER BOUND on what a render of that architecture costs (the
readings' sum plus 3 clock ticks, or √renders ticks if more, over the renders: eight readings of 0 ms say "under
~0.4 ms", not "nothing"); one block until 8 renders are timed; the budget is the architecture's own, never the last
one timed. A quantum that warmed runs no job — not from the fill, and not from a `{ file }` answer that arrives after
it. Measured in the node harness on X88-IR Crunch, IR-X Ch1 PowerAmp and V4 Sheriff Ch1: PLAY sounds after 20–24
quanta (53–64 ms; 15 with the bare mean, which a 0.3 ms render could push to 2.1 ms a quantum), 53 without it; the
riff after it is the riff after the live warm-up, bit for bit (RigAbiTests on the fixture, rig-parity on the three
packs, maxModels 1 and 2, with a control that differs). Mid-riff (a channel change) the input is not silence: the
live warm-up stays — the sound is back after the dip and ~53 quanta.

v0.6.0's start cost every PLAY and every channel ~266 ms of silence (warm-up 135, a 30 ms burst inside one quantum,
CAL_HOLD 80, ramp 5); the burst stalled the context and WebKit dropped out a second time 16–40 ms after it.

## Build

```sh
source ~/emsdk/emsdk_env.sh                 # or let build.sh source ~/emsdk itself
tools/wasm-rig/build.sh [out-dir]           # FELITRONICS_CORE_DIR=<checkout> to build against another core
```

Configured with `emcmake` like `fcguitarfx`: core's `FelitronicsPolicy.cmake` is the numeric contract. Every object gets
`-fno-exceptions -fno-rtti -msimd128 -msse4.1` (SIMD128, and Eigen's SSE packet path lowered onto it); the NAM objects
get exceptions back (below); `-O3`; linked `-sENVIRONMENT=worklet -sGROWABLE_ARRAYBUFFERS=0`, ES6 factory
`createFcRig`, no eval, no file system, dlmalloc. Core is the PINNED tag, v0.61.1 (the first whose `FlushToZero.h`
compiles for wasm under `-msse4.1`), unless `FELITRONICS_CORE_DIR` names another; NeuralAmpModelerCore v0.5.4, Eigen
5.0.1 (from the mirror github.com/darwinscat/eigen, at the commit v0.5.4's submodule pins — no build asks gitlab.com) and
namz v4.4.0 are `modules/nam`'s pins (`FELITRONICS_NAM_CORE_SRC` / `FELITRONICS_NAMZ_SRC` point at local checkouts of
them for an offline build; a local NeuralAmpModelerCore brings its own Eigen). It proves the artefact single-threaded (core's `check-no-threads.mjs`), reads the wasm features the
module needs off the module (binaryen validation against MVP plus each candidate), refuses a glue that names
`toResizableBuffer`, and writes `BUILD-INFO`:

```
felitronics-guitar-core <git describe>
felitronics-core v0.61.1
NeuralAmpModelerCore v0.5.4
Eigen 5.0.1
namz v4.4.0
fc_rig ABI 5
emscripten 6.0.9 (…)
flags -fno-exceptions -fno-rtti -msimd128 -msse4.1; exceptions on the NAM objects only, wasm legacy EH
wasm features sign-ext nontrapping-float-to-int simd exception-handling
```

| file | raw | gzip | brotli |
|---|---|---|---|
| `fcrig.wasm` | 802 547 | 287 555 | 217 169 |
| `fcrig.mjs` | 12 395 | 4 058 | 3 654 |
| `fcrig-worklet.js` | 27 973 | 9 264 | 8 127 |

(TONE3000's `nam-engine.wasm`, which the site ships today, is 415 269 raw: NAM alone, no player, no tone, no pack.) The
module's memory starts at 24 MiB and grows as captures load.

## C++ exceptions — Oleh's decision of 19.10.2026

**C++ exceptions are allowed only for our NAM — NeuralAmpModelerCore and nlohmann — in this wasm build; everything
else stays `-fno-exceptions`.** NeuralAmpModelerCore throws on a model it cannot read, nlohmann on JSON it cannot parse;
`NamStage::prepareModel` catches both and a bad capture becomes a failed load. So `nam_core`, `felitronics_nam`
(`NamStage.cpp`) and `fc_rig_manifest.cpp` (nlohmann under the manifest) are compiled with
`-fexceptions -fwasm-exceptions -sWASM_LEGACY_EXCEPTIONS=1`, and linked with the runtime that catches; `fc_rig.cpp`,
RigPlayer's `process()` and all of core are not. Tested both ways: garbage handed in for a capture is `{ loaded, ok:
false }` and the node plays on; the same test against a module whose NAM objects throw with catching disabled traps.

**Legacy, not exnref.** Wasm exception handling comes in two encodings, and the floor follows the one chosen
(emscripten's `tools/feature_matrix.py`):

| encoding | Chrome | Firefox | Safari |
|---|---|---|---|
| legacy (`try`/`catch`/`rethrow`, `-sWASM_LEGACY_EXCEPTIONS=1`) | 95 | 100 | 15.2 |
| exnref (`try_table`, `-sWASM_LEGACY_EXCEPTIONS=0`) | 137 | 131 | 18.4 |

Legacy keeps the floor within the ~five years Oleh accepted; exnref would cut it to the last year or so. The built
module has 1 729 `try` blocks and no `try_table` (wasm-dis). Emscripten's JavaScript-based exceptions (`-fexceptions`
alone) would leave the floor where emscripten's own is, and were measured: 933 KB instead of 796 KB, one capture 4.7 %
of a quantum instead of 3.6 %, two 13.6 % instead of 7.4 % (node, X88-IR Crunch) — every call that can throw goes
through a JavaScript trampoline, in the hot path too.

## Browser floor

**Chrome 95, Firefox 100, Safari 16.4 (iOS 16.4)** — the newest of what the module asks for:

- SIMD128: Chrome 91, Firefox 89, **Safari 16.4** — the one that sets Safari's floor;
- legacy wasm exception handling: **Chrome 95, Firefox 100**, Safari 15.2;
- sign-extension and non-trapping float-to-int (Chrome 75, Firefox 64, Safari 15), read off the module;
- the glue's JavaScript at emscripten's default floor (Chrome 85, Firefox 79, Safari 15), with
  `-sGROWABLE_ARRAYBUFFERS=0` (as `fcguitarfx`: otherwise Chrome 144 / Firefox 145 / Safari 26.2);
- module AudioWorklets with a static import (Chrome 66, Firefox 76, Safari 14.1).

Read from the toolchain's tables (emscripten's `tools/feature_matrix.py`; SIMD128, which that table does not list,
from caniuse) and the module, not tried on a device of each version. Against the ~five-year floor
(Chrome 85 / Firefox 79 / Safari 15) that is about a year younger on Chrome and Firefox and eighteen months on Safari —
SIMD, not exceptions, is what costs Safari 15.x.

**The floor is accepted (Oleh, 19.10.2026), and there is no scalar build.** A page detects support before it builds the
node — `WebAssembly.validate` on the module's bytes (or a tiny module with one SIMD128 op and one legacy `try`) — and
below the floor shows its own message instead of the player.

## Cost

Measured in Chromium 151 (Playwright, an Apple M5 Pro, 48 kHz, 128-frame quanta) by the processor's own burst, five
bursts each, the median: one capture sounding **3.8 – 4.2 %** of the quantum (101 – 111 µs), two **8.0 – 8.5 %**
(214 – 227 µs); the start's calibration read 3.9 – 4.0 % on each of X88-IR Crunch, IR-X Ch1 PowerAmp and V4 Sheriff
Ch1 and turned the blend on. In node (rig-parity.mjs): 3.6 % and 7.4 %. DevTools' CPU throttling does not reach the
audio thread (×4 read the same), so the slow-machine decision is tested with an injected slow render instead.

With the preload (Chromium 151, Playwright headless, `latencyHint: 'playback'`, 48 kHz, X88-IR Crunch, a continuous turn
0 → 300 → 0 at a degree every 16 ms, `playbackStats` of a fresh context): without it 8 – 9 underruns (171 – 192 ms) in
the first turn and 10 – 14 more in the second, where every byte is already kept and the loads still run; with it 0 in
either — the 2 – 4 (43 – 85 ms) it costs fall in the silent start, eleven jobs back to back (11 copies in 105 quanta,
the start 0.32 s against 0.19). Firefox 153 (Playwright's build) runs one capture at 70 – 75 % of a quantum and a load
in 305 – 315 ms, in a plain module Worker as in the worklet (Chromium: 95 µs and 24 – 36 ms) — the engine, not the
harness — and so calibrates to one model; a DRIVE step from capture to capture lost 0.45 s of audio clock without the
preload and 0.13 s with it, and 602 knob messages in a turn cost nothing beyond the captures they crossed (in Chromium
not one underrun): nothing heavy runs per knob move. What Firefox still pays per step is the one-model change itself —
the incoming capture's warm-up beside the outgoing capture's drain — on an engine that runs one network at 75 %.

## Tests

- `felitronics_rig_abi_tests` (ctest, native): the ABI against RigPlayer driven directly with a ModelSource — **bit for
  bit**, on the fixture pack: two models and one (set before the load, then 1 → 2 → 1 while playing), mono and stereo,
  the gain swept across captures, the link and past the top, a channel switch, tone and blend knobs, normalisation and
  input trims off and on, a blend shape, a reset, a pack loaded again and unloaded; the jobs and the bytes handed in
  where the source was asked (each file once, revisits from the kept bytes); ABI 2: the scope frame and its count
  bit for bit after every block of every scenario, and PARK — stood by mid-sweep, a fade cut short both ways, knobs and
  the feed moved while stood by, a reload and an unload under a feed — mono and stereo, output and scope bit for bit,
  and the output byte for byte as the player fed on v0.5.0's spelling (the host's input level = the pack's plus the
  feed) up to the unload (v0.5.0's player heard a hand stated on an empty player; this one publishes the feed alone
  there, the numbers v0.5.0's fc_rig left); the feed's MEANING, not only its forwarding (a pack at -6 dB fed +6 taps the input times +6 dB alone and
  plays byte for byte as that pack at 0 dB unfed; reloaded, the tap stays the feed's and the sound follows the new
  level plus the feed; a feed of 0 is byte-identical to none); a missing file and garbage — failures,
  still bit for bit; a fetch that failed once is asked for again on a later visit and lands, still bit for bit; a job out across a load is dropped and jobs flow again; the contract; no allocation in
  `process()`/`reset()` through loads and dips.
- `felitronics_rig_preload_tests` (ctest, native): the preload on the fixture pack — the set (seven copies: green's four
  knots, its two ends' twins, red's one; one job each, each file fetched once), then ZERO jobs through a turn 0 → 300 → 0
  a degree a block, a switch and back, two models and one; bit for bit with the plain player on that path at the model
  rate (failures included: a capture that is not one, a file not fetched), within 1e-4 at 44.1 kHz (5.5e-6, the
  matcher's floor; 0.0139 before a memoryless copy was drained at its landing); no allocation in `process()`; unload
  frees the set, a load makes it again; ABI 4 through the C surface, bit for bit with RigPlayer.
- `felitronics_rig_wasm_parity` (ctest when `FELITRONICS_GUITAR_RIG_WASM_DIR` names `build.sh`'s output; real packs
  too with `FELITRONICS_GUITAR_RIG_PACKS`; `node --experimental-vm-modules --expose-gc rig-parity.mjs [--namz=<namz
  CLI>] [--stand-in=<A2.nam>] <dir> <fc_rig_render> <abi header> [<packs dir>]`; ctest passes `fc_rig_namz`, namz's own
  CLI built from the pin, and NAM's example `A2.nam`, which the start is timed on where no real pack is given — the
  fixture's captures open the sound before a start has timed enough renders to decide): the processor and the glue as
  ES modules in a context shaped like an
  AudioWorkletGlobalScope (no fetch, URL, TextDecoder, TextEncoder, atob, setTimeout, performance; no
  toResizableBuffer), the page simulated; exports == the header; every pack rendered through the processor's own
  `process()` against `fc_rig_render` on the same schedule, within **2e-5** (law 10's contraction is stated alike, but
  Eigen spells its own multiply-add: fused on native arm64's NEON, not on SIMD128 — measured 1.2e-7 on the fixture,
  1.7e-6 … 5.5e-6 on X88-IR Crunch, IR-X Ch1 PowerAmp, V4 Sheriff Ch1, two models and one); garbage for a capture is a
  failed load, not a trap, and growing the memory mid-stream; the start's decision on a real pack or the A2 stand-in, on a clock the test owns
  (a 0.2 ms render: blend on; 2 ms: one model — the same on any machine), the silent start, the queued knobs in order; ABI 2 — PARK never queued (a
  `{ load }` while parked plays the wire bit for bit, the start resumes on the return and decides again, the knobs sent
  during it land after it in order); the `{ scope }` round trip as a page's port carries it (the reply in the
  transfer list, detached on the processor's side, the frame whole on the page's; `n` 0 before anything rendered) and every frame of a render through PARK and back against
  `fc_rig_render`'s (count, length, both sides; 8.9e-8 on the fixture, 8.3e-7 on X88-IR Crunch), frozen while stood by; the load protocol across the port —
  a first capture that fails ends the start at one model, an answer of null is asked for again, an answer with no
  `{ need }` out posts nothing, an answer forty quanta late lands, an old pack's answer is dropped, an unanswered
  `{ need }` times out and the next job flows; a `{ load }` decides again (slow now: one model); a stopped clock and
  polluted counters are not valid evidence (one model); a render that grows the memory copies out bit for bit; a
  BigInt knob is ignored; no module, a refused prepare, a
  foreign quantum and a trap — one error, dry, alive, only dispose ends; no allocation per quantum (under 4 bytes of
  JS heap per quantum over 15 000 with no garbage collection, in two trials of up to three — a boxed number per
  quantum reads 13.7 … 18.0); the cost of
  one quantum with one capture and with two, reported; ABI 4 — with the preload (filled in the background, v0.7.0), every pack, its `{ need }`s answered after 16 quanta, decides its start with copies still to fill, sounds while they fill, runs at most one job between two renders, and once filled a turn 0 → sweep → 0 a degree a quantum posts no `{ need }` and runs no job; PARK mid-fill runs no job and posts no `{ need }`, keeps the answer that arrives and runs its job at the first quantum back; a `{ load }` mid-fill says one `{ preloaded }`, for the new pack; with `calibrate: false` a knob lands at once while the set fills; the start's capture failing ends the start at once, a fill copy failing does not; the preloaded processor bit for bit with a plain one on the same input and dial path; FLOAT16 (namz 4.4.0, with
  `--namz`) — every pack's captures made `.nam16z` by `namz encode --f16` and float32 `.namz` again from those halves
  widened: the `.nam16z` pack plays bit for bit what the widened pack plays, in the module and natively, every `.nam16z`
  asked for and handed in by the name rig.json gives, and the same halves named `.namz` play the same.

## What a page owes it

- Compile `fcrig.wasm` once, post the module; fetch `rig.json` and hand its bytes in `processorOptions.rig` (or
  `{ load }`); answer **every** `{ need }` with the file's bytes (or `null`) and the `pack` it came with — the fetch
  and the body in one `try`, the answer posted whatever failed (an open `{ need }` stops every later load until the
  processor's own timeout or a `{ load }`).
- Keep the node quiet until `{ calibrated }` (it is silent until then anyway) and start the guitar after it — and
  again after every `{ load }`, which decides anew.
- Play the pack's tone through the player (`{ set: { dial: { Bass, Middle, Treble } } }`, a tone switch through
  `switch`), not through biquads of its own; and the gain through `gain` (degrees of the pack's sweep).
- Level: the player normalises every tagged capture to **-18 dB** (NamStage's reference) and applies the pack's
  `output_db` — a page that normalised to its own figure drops that and moves its OUTPUT instead.

## Vendoring

As `fcguitarfx`: the three files travel together and the worklet's static `import './fcrig.mjs'` must keep pointing
at the glue — with content-hashed names, rename the glue, rewrite that one import line in the copied worklet (or put
the three in one hashed directory), and hash the worklet after the rewrite. Ship `BUILD-INFO` beside them. The ABI
version is the `#define FC_RIG_ABI_VERSION <n>u` line of `tools/fc_rig_abi.h`. Licences: this module is AGPL-3.0;
it compiles in NeuralAmpModelerCore (MIT), nlohmann/json (MIT), Eigen (MPL-2.0) and namz (`THIRD_PARTY_NOTICES.md`).

## v0.7.0 — ABI 5: a lighter load, the files up front

- `fc_rig_job_run` builds one network per capture on a mono instance and skips NAM's zero prewarm; a `.namz` of a proven
  architecture is read without JSON. Same audio, bit for bit: `node --experimental-vm-modules rig-compare.mjs <v0.6.0
  build> <this build> <pack.orbitrig>...` runs 12 sessions a pack through both modules (8 at 48 kHz, 4 at 44.1 kHz),
  compares them as bits (−0 is not +0, no NaN passes) and runs a one-ulp control.
- `fc_rig_put_file` / `{ files: [{ file, bytes }, …] }`: a page that has a pack's files hands them in with `{ load }` and
  no load waits on a `{ need }` round trip. The processor needs ABI 5.
- The start has no burst and no hold any more (see "The start"): it times the warm-up's own renders, posts
  `{ calibrated }` in the quantum the sound opens, once per architecture a session (a one-model decision settled for
  the next pack); the quiet warm opens PLAY after ~55–65 ms.
- `fc_rig_put_file` asks the player first (`RigPlayer::wantsFile`): an id the pack does not name, or a file already
  held, returns NULL without growing the module's memory. Before the module is up, a `{ files }` carrying a `pack` is
  kept only with its `{ load }`; a setup that fails drops the files it was handed.
